package domiciliary.pages.Administrator;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GV7AdminLoggedIn.url")
public class DomiciliaryAdminPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryAdminPage.class);
    protected TestDataManager testDataManager = new TestDataManager();



}
