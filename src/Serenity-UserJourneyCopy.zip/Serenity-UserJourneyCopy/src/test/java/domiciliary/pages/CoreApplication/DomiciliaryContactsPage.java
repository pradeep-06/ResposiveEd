package domiciliary.pages.CoreApplication;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryContactsPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryContactsPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//div[@class='ls_loption_title' and contains(.,'Contacts')]")
    private WebElementFacade contactsTabTitle;
    @FindBy(xpath = "//form[contains(@action,'goldvision.aspx?page=contactlist')]/div[@id='mainlistbox']/p[@class='ls_counts']")
    private WebElementFacade searchResultsText;
    @FindBy(xpath = "//form[contains(@action,'goldvision.aspx?page=contactlist')]/div/table[@id='tblContent']/tbody/tr/td/div/input[@id='col1']")
    private WebElementFacade contactNameSearchBox;

    public void isContactsTabPresent(){
        correctTabTitleText(contactsTabTitle, "Contacts:");
    }

    public void typeTextIntoAndEnterContactNameSearchBox(String contactName) {
        element(contactNameSearchBox).typeAndEnter(contactName);
    }

    public void assertSearchResultsTextContains(String text) {
        assertElementContainsText(searchResultsText, text);
    }

    public void assertContactIsInList(String contactName) {
        final String contactXPath = String.format("//div[contains(@onclick,'OpenContact')]/span[contains(.,'%s')]", contactName);
        WebElementFacade contact = findBy(contactXPath);
        assertPageObjectExists(contact);
    }
    public void clickOnNameInList(String contactName) {
        final String nameXPath = String.format("//td[@title='%s']", contactName);
        WebElementFacade name = findBy(nameXPath);
        name.click();
    }

}
