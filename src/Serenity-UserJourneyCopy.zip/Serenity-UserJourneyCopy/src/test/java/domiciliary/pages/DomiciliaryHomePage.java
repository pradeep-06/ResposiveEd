package domiciliary.pages;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.home.url")
public class DomiciliaryHomePage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryHomePage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    //Elements

    //Home page tab title
    @FindBy(xpath = "//span[.='Home Page']")
    private WebElementFacade homePageTabTitle;
    @FindBy(id = "Email")
    private WebElementFacade emailInput;
    @FindBy(xpath = "//button[.='Next']")
    private WebElementFacade emailInputNextButton;
    @FindBy(id = "Password")
    private WebElementFacade passwordInput;
    @FindBy(xpath = "//button[.='Sign in']")
    private WebElementFacade passwordInputSignInButton;

    //Function to test if home page tab title is present
    public void isHomePageTabTitlePresent() {
        correctHomePageTabTitleText(homePageTabTitle, "Home Page");
    }

    //Function for testing login - can have wrong username or wrong password
    public void loginWithCredentials(String username, String password) {
        emailInput.type(username);
        emailInputNextButton.click();
        passwordInput.type(password);
        passwordInputSignInButton.click();
    }

    //GV8 - new login page code

    //public String RetrievingUsername() {
    //    return testDataManager.getTestInputRegionData("credentials.username");
    //}
    //public String RetrievingPassword() {
    //    return testDataManager.getTestInputRegionData("credentials.password");
    //}

    //public void handlingTestInputFromInputFile() {

    //    final String userName = testDataManager.getTestInputRegionData("credentials.username");
    //    logger.info("Input test data retrieved from Resources --> TestData--> domiciliary--> TestInput --> uk" +
    //            "::{}", userName);
    //}

}
