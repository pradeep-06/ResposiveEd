package domiciliary.pages.CoreApplication;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryAppointmentsPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryAppointmentsPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//div[@class='ls_loption_title' and contains(.,'Appointments')]")
    private WebElementFacade appointmentsTabTitle;

    public void isAppointmentsTabPresent(){
        correctTabTitleText(appointmentsTabTitle, "Appointments:");
    }


}
