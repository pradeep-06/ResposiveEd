package domiciliary.pages.CustomerEntry;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
//import javafx.scene.control.Tab;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
//import org.bouncycastle.jcajce.provider.symmetric.Serpent;
//import org.junit.platform.commons.util.ToStringBuilder;
import org.openqa.selenium.By;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.devtools.v85.indexeddb.model.Key;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import javax.swing.*;

@DefaultUrl("page:domiciliary.Availability.url")
public class DomiciliarySchedulingAvailability extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliarySchedulingAvailability.class);
    protected TestDataManager testDataManager = new TestDataManager();

    //Banner Selection
    @FindBy(xpath = "//button[.='Previous']")
    private WebElementFacade previousWeekButton;
    @FindBy(xpath = "//button[.='Next']")
    private WebElementFacade nextWeekButton;
    @FindBy(xpath = "//button[contains(text(), 'Next')]")
    private WebElementFacade nextWeekDiaryButton;
    @FindBy(xpath = "//button[@onclick='PostPage()']")
    private WebElementFacade refreshButton;
    @FindBy(xpath = "//button[@data-reveal-id='optomModal']")
    private WebElementFacade optometristSelectedButton;
    @FindBy(xpath = "//button[.='Submit']")
    private WebElementFacade submitOptometristSelectedButton;

    public void clickPreviousWeekButton(){
        clickElement(previousWeekButton);
    }
    public void clickNextWeekButton(){clickElement(nextWeekButton);}
    public void clickOptometristSelectedButton(){clickElement(optometristSelectedButton);}
    public void clickSubmitOptometristSelectedButton(){clickElement(submitOptometristSelectedButton);}

    //Diary Selections
    @FindBy(xpath = "//td[.='AM']")
    private WebElementFacade AMAvailabilityTextBox;
    @FindBy(xpath = "//td[.='PM']")
    private WebElementFacade PMAvailabilityTextBox;
    @FindBy(xpath = "//button[@id='save-button']")
    private WebElementFacade saveAvailabilityButton;

    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade mondayAMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade tuesdayAMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade wednesdayAMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade thursdayAMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade fridayAMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade mondayPMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade tuesdayPMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade wednesdayPMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade thursdayPMAvailabilityAddButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row text-center']/a/div[.='Add']")
    private WebElementFacade fridayPMAvailabilityAddButton;


    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade mondayAMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade tuesdayAMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade wednesdayAMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade thursdayAMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade fridayAMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade mondayPMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade tuesdayPMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade wednesdayPMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade thursdayPMAvailabilityTerritoryDropDown;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select")
    private WebElementFacade fridayPMAvailabilityTerritoryDropDown;

    //England
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[53]")
    private WebElementFacade mondayAMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade tuesdayAMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade wednesdayAMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade thursdayAMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade fridayAMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade mondayPMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade tuesdayPMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade wednesdayPMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade thursdayPMAvailabilityDropDownBir31Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Bir3-1']")
    private WebElementFacade fridayPMAvailabilityDropDownBir31Option;

    //Scotland
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade mondayAMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade tuesdayAMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade wednesdayAMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade thursdayAMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade fridayAMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade mondayPMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade tuesdayPMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade wednesdayPMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade thursdayPMAvailabilityDropDownGlasgow057Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Glasgow 057-7']")
    private WebElementFacade fridayPMAvailabilityDropDownGlasgow057Option;

    //Wales

    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade mondayAMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade tuesdayAMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade wednesdayAMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade thursdayAMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade fridayAMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade mondayPMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade tuesdayPMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade wednesdayPMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade thursdayPMAvailabilityDropDownClwyd5Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Clwyd-5']")
    private WebElementFacade fridayPMAvailabilityDropDownClwyd5Option;

    //Northern Ireland

    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade mondayAMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade tuesdayAMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade wednesdayAMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade thursdayAMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade fridayAMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade mondayPMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade tuesdayPMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade wednesdayPMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade thursdayPMAvailabilityDropDownBelfast2Option;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-8 text-left']/select/option[.='Belfast-2']")
    private WebElementFacade fridayPMAvailabilityDropDownBelfast2Option;

    @FindBy(xpath = "//td[@class='table-cell avItemAM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade mondayAMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade tuesdayAMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade wednesdayAMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade thursdayAMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemAM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade fridayAMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][1]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade mondayPMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][2]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade tuesdayPMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][3]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade wednesdayPMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][4]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade thursdayPMAvailabilityOKButton;
    @FindBy(xpath = "//td[@class='table-cell avItemPM'][5]/div[contains(@id,'Territory')]/div/div[@class='row SubTerItem'][last()]/div[@class='column large-1 text-left']/a")
    private WebElementFacade fridayPMAvailabilityOKButton;
    @FindBy(xpath = "//input[@id='optomFilterCheck00']")
    private WebElementFacade automationOptometristBot1SelectionTickBoxAvailability;

    boolean[] daysAMStatus = new boolean[5];
    boolean[] daysPMStatus = new boolean[5];

    public Boolean isSubTerritoryAssigned(String rowAMPM, String columnDay, String subTerritory) {
        String xpath = "//tr[" + rowAMPM + "]/td[" + columnDay + "]/div/div/div";
        return element(By.xpath(xpath)).getText().equals(subTerritory);
    }

    public void isAvailabilityAssigned(String index, String amPm) {
        String xpath = "//td[@class='table-cell avItem" + amPm + "']["+ index + "]/div[@class='row'][1]/div[1]/input[@class='availcheck']";
        if(!element(By.xpath(xpath)).findElement(By.xpath(xpath)).isSelected()){
            clickElement(element(By.xpath(xpath)));
        }
    }

    public void getDaySubTerritoryStatus(String subTerritory){
        clickElement(refreshButton);
        for(int i = 3; i <= 7; i++){
            daysAMStatus[i - 3] = isSubTerritoryAssigned("3", Integer.toString(i), subTerritory);
        }
        for(int i = 3; i <= 7; i++){
            daysPMStatus[i - 3] = isSubTerritoryAssigned("4", Integer.toString(i), subTerritory);
        }
        clickElement(nextWeekDiaryButton);
    }

    public void assignDaysAsAvailableForCurrentWeek(){
        for (int i = 1; i < 5; i++) {
            isAvailabilityAssigned(Integer.toString(i), "AM");
        }
        for (int i = 1; i < 5; i++) {
            isAvailabilityAssigned(Integer.toString(i), "PM");
        }
        clickSaveButtonInSchedulingAvailability();
    }

    //England
    public void fillInAvailabilityForCurrentWeek() {
        if (daysAMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayAMAvailabilityAddButton);
            clickElement(mondayAMAvailabilityTerritoryDropDown);
            clickElement(mondayAMAvailabilityDropDownBir31Option);
            clickElement(mondayAMAvailabilityOKButton);
        }
        if (daysAMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayAMAvailabilityAddButton);
            clickElement(tuesdayAMAvailabilityTerritoryDropDown);
            clickElement(tuesdayAMAvailabilityDropDownBir31Option);
            clickElement(tuesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayAMAvailabilityAddButton);
            clickElement(wednesdayAMAvailabilityTerritoryDropDown);
            clickElement(wednesdayAMAvailabilityDropDownBir31Option);
            clickElement(wednesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayAMAvailabilityAddButton);
            clickElement(thursdayAMAvailabilityTerritoryDropDown);
            clickElement(thursdayAMAvailabilityDropDownBir31Option);
            clickElement(thursdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayAMAvailabilityAddButton);
            clickElement(fridayAMAvailabilityTerritoryDropDown);
            clickElement(fridayAMAvailabilityDropDownBir31Option);
            clickElement(fridayAMAvailabilityOKButton);
        }
        if (daysPMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayPMAvailabilityAddButton);
            clickElement(mondayPMAvailabilityTerritoryDropDown);
            clickElement(mondayPMAvailabilityDropDownBir31Option);
            clickElement(mondayPMAvailabilityOKButton);
        }
        if (daysPMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayPMAvailabilityAddButton);
            clickElement(tuesdayPMAvailabilityTerritoryDropDown);
            clickElement(tuesdayPMAvailabilityDropDownBir31Option);
            clickElement(tuesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayPMAvailabilityAddButton);
            clickElement(wednesdayPMAvailabilityTerritoryDropDown);
            clickElement(wednesdayPMAvailabilityDropDownBir31Option);
            clickElement(wednesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayPMAvailabilityAddButton);
            clickElement(thursdayPMAvailabilityTerritoryDropDown);
            clickElement(thursdayPMAvailabilityDropDownBir31Option);
            clickElement(thursdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayPMAvailabilityAddButton);
            clickElement(fridayPMAvailabilityTerritoryDropDown);
            clickElement(fridayPMAvailabilityDropDownBir31Option);
            clickElement(fridayPMAvailabilityOKButton);
        }
        clickSaveButtonInSchedulingAvailability();
        waitABit(3000);
        clickNextWeekButton();
    }
    //Scotland
    public void fillInAvailabilityForCurrentWeekScotland() {
        if (daysAMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayAMAvailabilityAddButton);
            clickElement(mondayAMAvailabilityTerritoryDropDown);
            clickElement(mondayAMAvailabilityDropDownGlasgow057Option);
            clickElement(mondayAMAvailabilityOKButton);
        }
        if (daysAMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayAMAvailabilityAddButton);
            clickElement(tuesdayAMAvailabilityTerritoryDropDown);
            clickElement(tuesdayAMAvailabilityDropDownGlasgow057Option);
            clickElement(tuesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayAMAvailabilityAddButton);
            clickElement(wednesdayAMAvailabilityTerritoryDropDown);
            clickElement(wednesdayAMAvailabilityDropDownGlasgow057Option);
            clickElement(wednesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayAMAvailabilityAddButton);
            clickElement(thursdayAMAvailabilityTerritoryDropDown);
            clickElement(thursdayAMAvailabilityDropDownGlasgow057Option);
            clickElement(thursdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayAMAvailabilityAddButton);
            clickElement(fridayAMAvailabilityTerritoryDropDown);
            clickElement(fridayAMAvailabilityDropDownGlasgow057Option);
            clickElement(fridayAMAvailabilityOKButton);
        }
        if (daysPMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayPMAvailabilityAddButton);
            clickElement(mondayPMAvailabilityTerritoryDropDown);
            clickElement(mondayPMAvailabilityDropDownGlasgow057Option);
            clickElement(mondayPMAvailabilityOKButton);
        }
        if (daysPMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayPMAvailabilityAddButton);
            clickElement(tuesdayPMAvailabilityTerritoryDropDown);
            clickElement(tuesdayPMAvailabilityDropDownGlasgow057Option);
            clickElement(tuesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayPMAvailabilityAddButton);
            clickElement(wednesdayPMAvailabilityTerritoryDropDown);
            clickElement(wednesdayPMAvailabilityDropDownGlasgow057Option);
            clickElement(wednesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayPMAvailabilityAddButton);
            clickElement(thursdayPMAvailabilityTerritoryDropDown);
            clickElement(thursdayPMAvailabilityDropDownGlasgow057Option);
            clickElement(thursdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayPMAvailabilityAddButton);
            clickElement(fridayPMAvailabilityTerritoryDropDown);
            clickElement(fridayPMAvailabilityDropDownGlasgow057Option);
            clickElement(fridayPMAvailabilityOKButton);
        }
        clickSaveButtonInSchedulingAvailability();
        waitABit(3000);
        clickNextWeekButton();
    }
    //Wales
    public void fillInAvailabilityForCurrentWeekWales() {
        if (daysAMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayAMAvailabilityAddButton);
            clickElement(mondayAMAvailabilityTerritoryDropDown);
            clickElement(mondayAMAvailabilityDropDownClwyd5Option);
            clickElement(mondayAMAvailabilityOKButton);
        }
        if (daysAMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayAMAvailabilityAddButton);
            clickElement(tuesdayAMAvailabilityTerritoryDropDown);
            clickElement(tuesdayAMAvailabilityDropDownClwyd5Option);
            clickElement(tuesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayAMAvailabilityAddButton);
            clickElement(wednesdayAMAvailabilityTerritoryDropDown);
            clickElement(wednesdayAMAvailabilityDropDownClwyd5Option);
            clickElement(wednesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayAMAvailabilityAddButton);
            clickElement(thursdayAMAvailabilityTerritoryDropDown);
            clickElement(thursdayAMAvailabilityDropDownClwyd5Option);
            clickElement(thursdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayAMAvailabilityAddButton);
            clickElement(fridayAMAvailabilityTerritoryDropDown);
            clickElement(fridayAMAvailabilityDropDownClwyd5Option);
            clickElement(fridayAMAvailabilityOKButton);
        }
        if (daysPMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayPMAvailabilityAddButton);
            clickElement(mondayPMAvailabilityTerritoryDropDown);
            clickElement(mondayPMAvailabilityDropDownClwyd5Option);
            clickElement(mondayPMAvailabilityOKButton);
        }
        if (daysPMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayPMAvailabilityAddButton);
            clickElement(tuesdayPMAvailabilityTerritoryDropDown);
            clickElement(tuesdayPMAvailabilityDropDownClwyd5Option);
            clickElement(tuesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayPMAvailabilityAddButton);
            clickElement(wednesdayPMAvailabilityTerritoryDropDown);
            clickElement(wednesdayPMAvailabilityDropDownClwyd5Option);
            clickElement(wednesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayPMAvailabilityAddButton);
            clickElement(thursdayPMAvailabilityTerritoryDropDown);
            clickElement(thursdayPMAvailabilityDropDownClwyd5Option);
            clickElement(thursdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayPMAvailabilityAddButton);
            clickElement(fridayPMAvailabilityTerritoryDropDown);
            clickElement(fridayPMAvailabilityDropDownClwyd5Option);
            clickElement(fridayPMAvailabilityOKButton);
        }
        clickSaveButtonInSchedulingAvailability();
        waitABit(3000);
        clickNextWeekButton();
    }

    //Northern Ireland
    public void fillInAvailabilityForCurrentWeekNorthernIreland() {
        if (daysAMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayAMAvailabilityAddButton);
            clickElement(mondayAMAvailabilityTerritoryDropDown);
            clickElement(mondayAMAvailabilityDropDownBelfast2Option);
            clickElement(mondayAMAvailabilityOKButton);
        }
        if (daysAMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayAMAvailabilityAddButton);
            clickElement(tuesdayAMAvailabilityTerritoryDropDown);
            clickElement(tuesdayAMAvailabilityDropDownBelfast2Option);
            clickElement(tuesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayAMAvailabilityAddButton);
            clickElement(wednesdayAMAvailabilityTerritoryDropDown);
            clickElement(wednesdayAMAvailabilityDropDownBelfast2Option);
            clickElement(wednesdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayAMAvailabilityAddButton);
            clickElement(thursdayAMAvailabilityTerritoryDropDown);
            clickElement(thursdayAMAvailabilityDropDownBelfast2Option);
            clickElement(thursdayAMAvailabilityOKButton);
        }
        if (daysAMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayAMAvailabilityAddButton);
            clickElement(fridayAMAvailabilityTerritoryDropDown);
            clickElement(fridayAMAvailabilityDropDownBelfast2Option);
            clickElement(fridayAMAvailabilityOKButton);
        }
        if (daysPMStatus[0]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(mondayPMAvailabilityAddButton);
            clickElement(mondayPMAvailabilityTerritoryDropDown);
            clickElement(mondayPMAvailabilityDropDownBelfast2Option);
            clickElement(mondayPMAvailabilityOKButton);
        }
        if (daysPMStatus[1]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(tuesdayPMAvailabilityAddButton);
            clickElement(tuesdayPMAvailabilityTerritoryDropDown);
            clickElement(tuesdayPMAvailabilityDropDownBelfast2Option);
            clickElement(tuesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[2]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(wednesdayPMAvailabilityAddButton);
            clickElement(wednesdayPMAvailabilityTerritoryDropDown);
            clickElement(wednesdayPMAvailabilityDropDownBelfast2Option);
            clickElement(wednesdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[3]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(thursdayPMAvailabilityAddButton);
            clickElement(thursdayPMAvailabilityTerritoryDropDown);
            clickElement(thursdayPMAvailabilityDropDownBelfast2Option);
            clickElement(thursdayPMAvailabilityOKButton);
        }
        if (daysPMStatus[4]) {
            System.out.println("Sub territory already assigned");
        } else {
            clickElement(fridayPMAvailabilityAddButton);
            clickElement(fridayPMAvailabilityTerritoryDropDown);
            clickElement(fridayPMAvailabilityDropDownBelfast2Option);
            clickElement(fridayPMAvailabilityOKButton);
        }
        clickSaveButtonInSchedulingAvailability();
        waitABit(3000);
        clickNextWeekButton();
    }
    public void clickSaveButtonInSchedulingAvailability(){clickElement(saveAvailabilityButton);}

    //Scheduling TickBoxes
    public void clickOptometristTickBoxAvailability(String optomName) {
        String xpath = "//span[.='" + optomName + "']/../following-sibling::div[1]/input[contains(@id, 'optomFilterCheck')]";
        clickElement(element(By.xpath(xpath)));
    }
}
