package domiciliary.pages.CoreApplication;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryVenuesPage extends DomiciliaryCommonPage {
    private final Logger logger = LoggerFactory.getLogger(DomiciliaryVenuesPage.class);
    protected TestDataManager testDataManager = new TestDataManager();





    @FindBy(xpath = "//div[@class='ls_loption_title' and contains(.,'Venues')]")
    private WebElementFacade venuesTabTitle;
    @FindBy(xpath = "//input[@title='Venue Name']")
    private WebElementFacade venueNameSearchBox;
    @FindBy(xpath = "//input[@title='Primary Contact']")
    private WebElementFacade primaryContactSearchBox;
    @FindBy(xpath = "//form[contains(@action,'goldvision.aspx?page=accountlist')]/div[@id='mainlistbox']/p[@class='ls_counts']")
    private WebElementFacade searchResultsText;

    public void isVenuesTabTitlePresent() {
        correctTabTitleText(venuesTabTitle, "Venues:");
    }

    public void typeTextIntoAndEnterVenueNameSearchBox(String venueName) {
        element(venueNameSearchBox).waitUntilEnabled().typeAndEnter(venueName);
    }

    public void typeTextIntoAndEnterPrimaryContactSearchBox(String primaryContactName) {
        element(primaryContactSearchBox).waitUntilEnabled().typeAndEnter(primaryContactName);
        waitABit(3000);
    }
    public void assertSearchResultsTextContains(String text) {
        assertElementContainsText(searchResultsText, text);
    }

    public void assertVenueIsInList(String venueName) {
        final String venueXPath = String.format("//td[@title='%s']", venueName);
        WebElementFacade venue = findBy(venueXPath);
        assertPageObjectExists(venue);
    }
    public void assertVenueAndPrimaryContactAreInList(String venueName, String primaryContactName) {
        final String venueXPath = String.format("//td[@title='%s']", venueName);
        WebElementFacade venue = findBy(venueXPath);
        assertPageObjectExists(venue);
        final String primaryContactXPath = venueXPath + String.format("/../td[@title='%s']", primaryContactName);
        WebElementFacade primaryContact = findBy(primaryContactXPath);
        assertPageObjectExists(primaryContact);
    }

    public void clickOnVenueNameInList(String venueName) {
        final String venueXPath = String.format("//div[contains(@class,'gv-list-table-data-value') and @title='%s']", venueName);
        WebElementFacade venue = findBy(venueXPath);
        venue.click();
    }
    public void clickOnPrimaryContactInList(String primaryContactName) {
        final String primaryContactNameXPath = String.format("//td[@title='%s']", primaryContactName);
        WebElementFacade primaryContact = findBy(primaryContactNameXPath);
        primaryContact.click();
    }


}
