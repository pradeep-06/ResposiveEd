package domiciliary.pages.CoreApplication.Popups.VenuePopup;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryVenuePopupPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryVenuePopupPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//div[@id='CRMMenu_button']")
    private WebElementFacade venueTopLeftDropdown;
    @FindBy(xpath = "//div[@id='CRMMenu']/a[.='Make Dormant']")
    private WebElementFacade venueMakeRecordDormantOption;
    @FindBy(xpath = "//div[@id='CRMMenu']/a[.='Delete']")
    private WebElementFacade venueDeleteRecordOption;
    @FindBy(xpath = "//input[@id='msg_btn_0']")
    private WebElementFacade venuePopUpConfirmOption;
    @FindBy(xpath = "//a[.='Close Window']")
    private WebElementFacade venueCloseWindowOption;
    @FindBy(xpath = "//div[@class='gv-field-edit']/input[@type='text' and @class='gv-field-input' and @data-gv-is-required='true']")
    private WebElementFacade venueNameTextBox;
    @FindBy(id = "TYPE_1_VL")
    private WebElementFacade venueIDStatusDropDown;
    @FindBy(xpath = "//label[@title='Venue Type']/../following-sibling::div[@class='gv-field-edit']/select")
    private WebElementFacade venueTypeDropDown;
    @FindBy(xpath = "//select[@id='TYPE_1_VL']/option[.='Self Employed']")
    private WebElementFacade venueIDStatusDropDownSelfEmployedOption;
    @FindBy(xpath = "//select[@id='TYPE_2_VL']/option[.='OO Staff']")
    private WebElementFacade venueTypeDropDownOOStaffOption;
    @FindBy(xpath = "//label[@title='Venue Type']/../following-sibling::div[@class='gv-field-edit']/select/option[contains(.,'Care Home Only')]")
    private WebElementFacade venueTypeDropDownCareHomeOnlyOption;
    @FindBy(xpath = "//label[@title='Venue Type']/../following-sibling::div[@class='gv-field-edit']/select/option[contains(.,'Hospital')]")
    private WebElementFacade venueTypeDropDownHospitalOption;
    @FindBy(xpath = "//label[@title='Venue Type']/../following-sibling::div[@class='gv-field-edit']/select/option[contains(.,'Prison')]")
    private WebElementFacade venueTypeDropDownPrisonOption;

    @FindBy(xpath = "//td[@title='Details' and @onclick]/label[.='Details']")
    private WebElementFacade venueDetailsButton;

    public void clickVenueTopLeftDropdownButton() {
        clickElement(venueTopLeftDropdown);
    }
    public void clickVenueMakeRecordDormantOption() {
        clickElement(venueMakeRecordDormantOption);
    }
    public void clickVenueDeleteRecordOption() {
        clickElement(venueDeleteRecordOption);
    }
    public void clickVenuePopUpConfirmButton() {
        clickElement(venuePopUpConfirmOption);
    }
    public void clickVenueCloseWindowOption() {
        clickElement(venueCloseWindowOption);
    }

    public void enterTextIntoVenueName(String text) {
        enterGivenTextInTextField(venueNameTextBox, text);
    }

    public void clickIDStatusSelfEmployedDropDownOption() {
        clickDropDownOption(venueIDStatusDropDown, venueIDStatusDropDownSelfEmployedOption);
    }

    public void clickVenueDetailsButton() {
        clickElement(venueDetailsButton);
    }
    public void clickVenueTypeOOStaffDropDownOption() {
        clickDropDownOption(venueTypeDropDown, venueTypeDropDownOOStaffOption);
    }
    public void clickVenueTypeCareHomeOnlyDropDownOption() {
        clickDropDownOption(venueTypeDropDown, venueTypeDropDownCareHomeOnlyOption);
    }
    public void clickVenueTypeHospitalDropDownOption() {
        clickDropDownOption(venueTypeDropDown, venueTypeDropDownHospitalOption);
    }
    public void clickVenueTypePrisonDropDownOption() {
        clickDropDownOption(venueTypeDropDown, venueTypeDropDownPrisonOption);
    }

}
