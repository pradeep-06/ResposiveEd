package domiciliary.pages.CoreApplication;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryReportingPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryReportingPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//div[@class='ls_loption_title' and contains(.,'Reports')]")
    private WebElementFacade reportingTabTitle;
    @FindBy(xpath = "//div[@class='ls_title_wrapper']/div[contains(@onclick,'myreports') and contains(.,'My Reports')]")
    private WebElementFacade myReportsSubTabTitle;
    @FindBy(xpath = "//div[@class='ls_title_wrapper']/div[contains(@onclick,'standard') and contains(.,'Standard')]")
    private WebElementFacade standardSubTabTitle;
    @FindBy(xpath = "//div[@class='ls_title_wrapper']/div[contains(@onclick,'userdefined') and contains(.,'User Defined')]")
    private WebElementFacade userDefinedSubTabTitle;
    @FindBy(xpath = "//div[@class='ls_title_wrapper']/div[contains(@onclick,'AllReports') and contains(.,'All')]")
    private WebElementFacade allSubTabTitle;

    public void isReportingTabTitlePresent(){
        correctTabTitleText(reportingTabTitle, "Reports:");
    }
    public void isMyReportsSubTabPresent() {
        assertElementContainsText(myReportsSubTabTitle, "My Reports");
    }
    public void isStandardSubTabPresent() {
        assertElementContainsText(standardSubTabTitle, "Standard");
    }
    public void isUserDefinedSubTabPresent() {
        assertElementContainsText(userDefinedSubTabTitle, "User Defined");
    }
    public void isAllSubTabPresent() {
        assertElementContainsText(allSubTabTitle, "All");
    }

}
