package domiciliary.pages.CoreApplication.Popups.ContactPopup;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryContactPopupPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryContactPopupPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(id = "ACC_UD1_ID_VL")
    private WebElementFacade contactTypeDropDown;
    @FindBy(id = "ACC_UD5_ID_VL")
    private WebElementFacade fundingDropDown;
    @FindBy(xpath = "//select[@id='ACC_UD1_ID_VL']/option[.='Optometrist']")
    private WebElementFacade contactTypeDropDownOptometristOption;
    @FindBy(xpath = "//select[@id='ACC_UD5_ID_VL']/option[.='Staff']")
    private WebElementFacade fundingDropDownStaffOption;

    @FindBy(id = "CRMMenu2_button")
    private WebElementFacade contactRecordHeader2;

    @FindBy(xpath = "//a[contains(text(),'Details')]")
    private WebElementFacade detailsDropdown;

    @FindBy(xpath = "//a[contains(text(),'Additional Info')]")
    private WebElementFacade additionalInfoDropdown;

    @FindBy(id = "TITLE_VL")
    private WebElementFacade contactRecordTitle;

    @FindBy(xpath = "//option[@selected='true'][contains(text(),'Not Specified')]")
    private WebElementFacade contactRecordGenderNotSpecified;

    @FindBy(xpath = "//option[@selected='true'][contains(text(),'Neutral')]")
    private WebElementFacade contactRecordGenderNeutral;

    public void clickContactTypeOptometristOption() {
        clickDropDownOption(contactTypeDropDown,contactTypeDropDownOptometristOption);
    }
    public void clickFundingStaffOption() {
        clickDropDownOption(fundingDropDown, fundingDropDownStaffOption);
    }

    public void navigateToAdditionalInfo(){
        clickElement(contactRecordHeader2);
        moveTo("//a[contains(text(),'Details')]");
        clickElement(additionalInfoDropdown);
    }

    public Boolean assertTitleIs(String expectedTitle){
        if(contactRecordTitle.getValue().equals(expectedTitle)){
            return true;
        }
        else if(!contactRecordTitle.getValue().equals(expectedTitle)) {
            return false;
        }
        return false;
    }

    public Boolean assertGenderIsNotSpecified(String expectedGender){
        if(contactRecordGenderNotSpecified.getText().equals(expectedGender)){
            return true;
        }
        return false;
    }
    public Boolean assertGenderIsNeutral(String expectedGender){
        if(contactRecordGenderNeutral.getText().equals(expectedGender)){
            return true;
        }
        return false;
    }
}
