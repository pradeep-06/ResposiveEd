package domiciliary.pages.CustomerEntry;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

@DefaultUrl("page:domiciliary.CE.url")
public class DomiciliaryCustomerEntryPage extends DomiciliaryCommonPage {
    private final Logger logger = LoggerFactory.getLogger(DomiciliaryCustomerEntryPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    //Elements

    @FindBy(xpath = "//div[@class='rebrandingText' and .='Customer Entry']")
    private WebElementFacade customerEntryPageTitle;

    //Top of page green elements

    @FindBy(xpath = "//div[@id='ScriptButtonDesktop']")
    private WebElementFacade showScriptButton;
    @FindBy(xpath = "//div[@id='SearchPatientButtonDesktop']")
    private WebElementFacade searchPatientVenueButton;
    @FindBy(xpath = "//div[@id='SearchPostcodeButtonDesktop']")
    private WebElementFacade postcodeAddressLookupButton;
    @FindBy(xpath = "//div[@id='AvailableButtonDesktop']")
    private WebElementFacade checkAvailabilityButton;
    @FindBy(xpath = "//div[@id='CancelButtonDesktop']")
    private WebElementFacade cancelButton;
    @FindBy(xpath = "//div[@id='BackButtonDesktop']")
    private WebElementFacade backButton;
    @FindBy(xpath = "//div[@id='ContinueButtonDesktop']")
    private WebElementFacade continueButton;

    //Main CEP elements
    @FindBy(id = "Title")
    private WebElementFacade patientTitleDropDownBox;
    @FindBy(id = "Gender")
    private WebElementFacade genderDropDownBox;
    @FindBy(id = "firstname")
    private WebElementFacade patientFirstNameTextBox;
    @FindBy(id = "surname")
    private WebElementFacade patientSurnameTextBox;
    @FindBy(id = "postcode")
    private WebElementFacade postcodeTextBox;
    @FindBy(id = "country")
    private WebElementFacade countryDropDownBox;
    @FindBy(id = "DomicilaryElig")
    private WebElementFacade domiciliaryEligibilityDropDownBox;
    @FindBy(id = "PreviousOptician")
    private WebElementFacade previousOpticianDropDownBox;
    @FindBy(id = "DateOfLastSightTest")
    private WebElementFacade dateOfLastSightTestPicker;
    @FindBy(id = "DateOfLastSightTestNotKnown")
    private WebElementFacade dateOfLastSightTestNotKnownCheckBox;
    @FindBy(id = "DateOfBirth")
    private WebElementFacade dateOfBirthPicker;
    @FindBy(id = "Condition")
    private WebElementFacade conditionDropDownBox;
    @FindBy(id = "Funding")
    private WebElementFacade fundingDropDownBox;
    @FindBy(id = "hometelno")
    private WebElementFacade patientHomeTelephoneNumberTextBox;
    @FindBy(id = "mobiletelno")
    private WebElementFacade patientMobileTelephoneNumberTextBox;
    @FindBy(xpath = "//input[@type='radio'][@value='PatientHome']")
    private WebElementFacade patientHomeTelephoneNumberPrimaryContactRadioButton;
    @FindBy(xpath = "//input[@type='radio'][@value='PatientMobile']")
    private WebElementFacade patientMobileTelephoneNumberPrimaryContactRadioButton;
    @FindBy(id = "AdvertisingMethod")
    private WebElementFacade advertisingMethodDropDownBox;
    @FindBy(id = "AltContactDrop")
    private WebElementFacade alternativeContactDropDownBox;
    @FindBy(id = "AltConTitle")
    private WebElementFacade alternativeContactTitleDropDownBox;
    @FindBy(id = "AltConType")
    private WebElementFacade alternativeContactTypeDropDownBox;
    @FindBy(id = "AltConFirstname")
    private WebElementFacade alternativeContactFirstNameTextBox;
    @FindBy(id = "AltConSurname")
    private WebElementFacade alternativeContactSurnameTextBox;
    @FindBy(id = "AltConHomeTel")
    private WebElementFacade alternativeContactHomeTelephoneNumberTextBox;
    @FindBy(id = "AltConMobileTel")
    private WebElementFacade alternativeContactMobileTelephoneNumberTextBox;
    @FindBy(xpath = "//input[@type='radio'][@value='AltHome']")
    private WebElementFacade alternativeContactHomeTelephoneNumberPrimaryContactRadioButton;
    @FindBy(xpath = "//input[@type='radio'][@value='AltMobile']")
    private WebElementFacade alternativeContactMobileTelephoneNumberPrimaryContactRadioButton;
    @FindBy(id = "CreateVisitOptionYes")
    private WebElementFacade assignToExistingVisitRadioButton;
    @FindBy(id = "CreateVisitOptionNo")
    private WebElementFacade createNewVisitRadioButton;
    @FindBy(id = "VisitTimeAnytime")
    private WebElementFacade anytimeCheckBox;
    @FindBy(id = "VisitType")
    private WebElementFacade visitTypeDropDownBox;
    @FindBy(id = "VisitDate")
    private WebElementFacade visitDateTextBox;
    @FindBy(xpath = "//a[@href='JavaScript:ShowFutureOptomList()']")
    private WebElementFacade visitTimeslotPicker;
    @FindBy(xpath = "//td[contains(@class,'ui-datepicker-current-day')]")
    private WebElementFacade visitDatePickerCurrentDay;
    @FindBy(id = "VisitOptom")
    private WebElementFacade visitOptometristDropDownBox;
    @FindBy(xpath = "//option[contains(.,'1-Automation-Optometrist OO-Automation-Bot1')]")
    private WebElementFacade visitOptometristDropDownBoxAutomationOptomOption;
    @FindBy(xpath = "//option[contains(.,'Steve The Optom')]")
    private WebElementFacade visitOptometristDropDownBoxSteveTheOptomOption;
    @FindBy(xpath = "//option[contains(.,'Keith The Optom')]")
    private WebElementFacade visitOptometristDropDownBoxKeithTheOptomOption;
    @FindBy(id = "CreateVisitOptionNoneAvailable")
    private WebElementFacade noAppointmentAvailableRadioButton;
    @FindBy(id = "NoAppointmentAvailableReason")
    private WebElementFacade noAppointmentAvailableReasonDropDownBox;
    @FindBy(id = "NoteSubject")
    private WebElementFacade additionalNotesSubjectTextBox;
    @FindBy(id = "VisitNotes")
    private WebElementFacade additionalNotesMainTextBox;

    //Consent and Permissions elements

    @FindBy(xpath = "//section[@id='page2_home']/section[@id='content-main']/div[@class='mainrow content_sep']/div/div[1]/div/h5[.='Data Processing Consent']")
    private WebElementFacade dataProcessingConsentTitle;
    @FindBy(xpath = "//a[@onclick='ToggleServiceCommunications()']")
    private WebElementFacade serviceCommunicationsTitle;
    @FindBy(id = "ContentGiven_Yes_Home")
    private WebElementFacade dataProcessingConsentYesRadioButton;
    @FindBy(id = "ContentGiven_No_Home")
    private WebElementFacade dataProcessingConsentNoRadioButton;
    @FindBy(id = "MarketingServiceComms_Email_Yes")
    private WebElementFacade marketingInServiceRelatedCommunicationsEmailYesRadioButton;
    @FindBy(id = "MarketingServiceComms_Email_No")
    private WebElementFacade marketingInServiceRelatedCommunicationsEmailNoRadioButton;
    @FindBy(id = "MarketingServiceComms_Post_Yes")
    private WebElementFacade marketingInServiceRelatedCommunicationsPostYesRadioButton;
    @FindBy(id = "MarketingServiceComms_Post_No")
    private WebElementFacade marketingInServiceRelatedCommunicationsPostNoRadioButton;
    @FindBy(id = "MarketingServiceComms_Sms_Yes")
    private WebElementFacade marketingInServiceRelatedCommunicationsSMSYesRadioButton;
    @FindBy(id = "MarketingServiceComms_Sms_No")
    private WebElementFacade marketingInServiceRelatedCommunicationsSMSNoRadioButton;
    @FindBy(id = "MarketingServiceComms_Phone_Yes")
    private WebElementFacade marketingInServiceRelatedCommunicationsTelephoneYesRadioButton;
    @FindBy(id = "MarketingServiceComms_Phone_No")
    private WebElementFacade marketingInServiceRelatedCommunicationsTelephoneNoRadioButton;
    @FindBy(id = "MarketingComms_Email_Yes")
    private WebElementFacade marketingPermissionsEmailYesRadioButton;
    @FindBy(id = "MarketingComms_Email_No")
    private WebElementFacade marketingPermissionsEmailNoRadioButton;
    @FindBy(id = "MarketingComms_Post_Yes")
    private WebElementFacade marketingPermissionsPostYesRadioButton;
    @FindBy(id = "MarketingComms_Post_No")
    private WebElementFacade marketingPermissionsPostNoRadioButton;
    @FindBy(id = "MarketingComms_Sms_Yes")
    private WebElementFacade marketingPermissionsSMSYesRadioButton;
    @FindBy(id = "MarketingComms_Sms_No")
    private WebElementFacade marketingPermissionsSMSNoRadioButton;
    @FindBy(id = "MarketingComms_Phone_Yes")
    private WebElementFacade marketingPermissionsTelephoneYesRadioButton;
    @FindBy(id = "MarketingComms_Phone_No")
    private WebElementFacade marketingPermissionsTelephoneNoRadioButton;
    @FindBy(xpath = "//div[@class='buttonise'][contains(@onclick, 'Confirm')]")
    private WebElementFacade marketingConsentConfirmButton;
    @FindBy(id = "ContinueButtonDesktop")
    private WebElementFacade marketingConsentSaveButton;
    @FindBy(xpath = "//div[@class='buttonise'][contains(@onclick, 'CareHome') and .='Confirm']")
    private WebElementFacade marketingCareHomeDataProcessingConsentConfirmButton;
    @FindBy(id = "ContentGiven_Yes")
    private WebElementFacade marketingCareHomeDataProcessingConsentYesButton;
    @FindBy(id = "ContentGiven_No")
    private WebElementFacade marketingCareHomeDataProcessingConsentNoButton;
    @FindBy(id = "RecordSavedConfirm")
    private WebElementFacade detailsSavedSuccessfullyContinueButton;
    @FindBy(id = "btnAddNewPatient")
    private WebElementFacade addNewPatientButton;
    @FindBy(id = "btnAddExistingPatients")
    private WebElementFacade addExistingPatientButton;
    @FindBy(id = "CheckSaveDialogMessage")
    private WebElementFacade addAnotherPatientPopUpText;
    @FindBy(xpath = "//button[.='Add to Booking']")
    private WebElementFacade addToBookingButton;
    @FindBy(id = "btnFinish")
    private WebElementFacade finishButton;

    //Patient title drop down options
    @FindBy(xpath = "//select[@id='Title']/option[@value='Not Set']")
    private WebElementFacade patientTitleDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Mr']")
    private WebElementFacade patientTitleDropDownMrButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Miss']")
    private WebElementFacade patientTitleDropDownMissButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Mrs']")
    private WebElementFacade patientTitleDropDownMrsButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Ms']")
    private WebElementFacade patientTitleDropDownMsButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Master']")
    private WebElementFacade patientTitleDropDownMasterButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Rev']")
    private WebElementFacade patientTitleDropDownRevButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Sister']")
    private WebElementFacade patientTitleDropDownSisterButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Fr']")
    private WebElementFacade patientTitleDropDownFrButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Dr']")
    private WebElementFacade patientTitleDropDownDrButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Atty']")
    private WebElementFacade patientTitleDropDownAttyButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Prof']")
    private WebElementFacade patientTitleDropDownProfButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Hon']")
    private WebElementFacade patientTitleDropDownHonButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Pres']")
    private WebElementFacade patientTitleDropDownPresButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Gov']")
    private WebElementFacade patientTitleDropDownGovButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Coach']")
    private WebElementFacade patientTitleDropDownCoachButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Ofc']")
    private WebElementFacade patientTitleDropDownOfcButton;
    @FindBy(xpath = "//select[@id='Title']/option[@value='Mx']")
    private WebElementFacade patientTitleDropDownMxButton;

    //Gender drop down options
    @FindBy(xpath = "//select[@id='Gender']/option[@value='Not Set']")
    private WebElementFacade genderDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='Gender']/option[@value='Male']")
    private WebElementFacade genderDropDownMaleButton;
    @FindBy(xpath = "//select[@id='Gender']/option[@value='Female']")
    private WebElementFacade genderDropDownFemaleButton;
    @FindBy(xpath = "//select[@id='Gender']/option[@value='Neutral']")
    private WebElementFacade genderDropDownNeutralButton;
    @FindBy(xpath = "//select[@id='Gender']/option[@value='Not Specified']")
    private WebElementFacade genderDropDownNotSpecifiedButton;

    //Country drop down options
    @FindBy(xpath = "//select[@id='country']/option[@value='']")
    private WebElementFacade countryDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='country']/option[@value='England']")
    private WebElementFacade countryDropDownEnglandButton;
    @FindBy(xpath = "//select[@id='country']/option[@value='Scotland']")
    private WebElementFacade countryDropDownScotlandButton;
    @FindBy(xpath = "//select[@id='country']/option[@value='Wales']")
    private WebElementFacade countryDropDownWalesButton;
    @FindBy(xpath = "//select[@id='country']/option[@value='Northern Ireland']")
    private WebElementFacade countryDropDownNorthernIrelandButton;
    @FindBy(xpath = "//select[@id='country']/option[@value='Republic of Ireland']")
    private WebElementFacade countryDropDownRepublicOfIrelandButton;

    //Domiciliary eligibility drop down options
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='']")
    private WebElementFacade domiciliaryEligibilityDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Agrophobic']")
    private WebElementFacade domiciliaryEligibilityDropDownAgrophobicButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Alzheimer']")
    private WebElementFacade domiciliaryEligibilityDropDownAlzheimerButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Amputee']")
    private WebElementFacade domiciliaryEligibilityDropDownAmputeeButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Arthritis']")
    private WebElementFacade domiciliaryEligibilityDropDownArthritisButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Autism']")
    private WebElementFacade domiciliaryEligibilityDropDownAutismButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Cancer']")
    private WebElementFacade domiciliaryEligibilityDropDownCancerButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='COPD']")
    private WebElementFacade domiciliaryEligibilityDropDownCOPDButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Coronary Heart Disease']")
    private WebElementFacade domiciliaryEligibilityDropDownCoronaryHeartDiseaseButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='CVA (Stroke)']")
    private WebElementFacade domiciliaryEligibilityDropDownCVAStrokeButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Dementia']")
    private WebElementFacade domiciliaryEligibilityDropDownDementiaButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Down's Syndrome']")
    private WebElementFacade domiciliaryEligibilityDropDownDownsSyndromeButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Learning Disabilities']")
    private WebElementFacade domiciliaryEligibilityDropDownLearningDisabilitiesButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='M/S']")
    private WebElementFacade domiciliaryEligibilityDropDownMSButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Morbid Obesity']")
    private WebElementFacade domiciliaryEligibilityDropDownMorbidObesityButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Motor Neurone']")
    private WebElementFacade domiciliaryEligibilityDropDownMotorNeuroneButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Osteoporosis']")
    private WebElementFacade domiciliaryEligibilityDropDownOsteoporosisButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Other']")
    private WebElementFacade domiciliaryEligibilityDropDownOtherButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Paralysis']")
    private WebElementFacade domiciliaryEligibilityDropDownParalysisButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Parkinsons Disease']")
    private WebElementFacade domiciliaryEligibilityDropDownParkinsonsDiseaseButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Peripheral Nerupathy']")
    private WebElementFacade domiciliaryEligibilityDropDownPeripheralNerupathyButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Respiratory Disease']")
    private WebElementFacade domiciliaryEligibilityDropDownRespiratoryDiseaseButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Severe Leg Ulcers']")
    private WebElementFacade domiciliaryEligibilityDropDownSevereLegUlcersButton;
    @FindBy(xpath = "//select[@id='DomicilaryElig']/option[@value='Spinal Degeneration']")
    private WebElementFacade domiciliaryEligibilityDropDownSpinalDegenerationButton;

    //Previous optician drop down elements
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Not Set']")
    private WebElementFacade previousOpticianDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Asda']")
    private WebElementFacade previousOpticianDropDownAsdaButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='At Home']")
    private WebElementFacade previousOpticianDropDownAtHomeButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Boots']")
    private WebElementFacade previousOpticianDropDownBootsButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Eyecare Oncall']")
    private WebElementFacade previousOpticianDropDownEyecareOncallButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Homecall']")
    private WebElementFacade previousOpticianDropDownHomecallButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Local']")
    private WebElementFacade previousOpticianDropDownLocalButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Local Domiciliary Provider']")
    private WebElementFacade previousOpticianDropDownLocalDomiciliaryProviderButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Local High Street Provider']")
    private WebElementFacade previousOpticianDropDownLocalHighStreetProviderButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Not Known']")
    private WebElementFacade previousOpticianDropDownNotKnownButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Optical Express']")
    private WebElementFacade previousOpticianDropDownOpticalExpressButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Other']")
    private WebElementFacade previousOpticianDropDownOtherButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Specsavers']")
    private WebElementFacade previousOpticianDropDownSpecsaversButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Tesco']")
    private WebElementFacade previousOpticianDropDownTescoButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='The Outside Clinic']")
    private WebElementFacade previousOpticianDropDownTheOutsideClinicButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Vision Express']")
    private WebElementFacade previousOpticianDropDownVisionExpressButton;
    @FindBy(xpath = "//select[@id='PreviousOptician']/option[@value='Visioncall']")
    private WebElementFacade previousOpticianDropDownVisioncallButton;

    //Condition drop down options
    @FindBy(xpath = "//select[@id='Condition']/option[@value='']")
    private WebElementFacade conditionDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Diabetic']")
    private WebElementFacade conditionDropDownDiabeticButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Diabetic & Blind/Partially Sighted']")
    private WebElementFacade conditionDropDownDiabeticAndBlindPartiallySightedButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Diabetic & Family Glaucoma']")
    private WebElementFacade conditionDropDownDiabeticAndFamilyGlaucomaButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Diabetic & Glacoma & Blind/Partially Sighted']")
    private WebElementFacade conditionDropDownDiabeticAndGlaucomaAndBlindPartiallySightedButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Diabetic & Glaucoma']")
    private WebElementFacade conditionDropDownDiabeticAndGlaucomaButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Family History of Glaucoma']")
    private WebElementFacade conditionDropDownFamilyHistoryOfGlaucomaButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Glaucoma']")
    private WebElementFacade conditionDropDownGlaucomaButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Glaucoma & Blind/Partially Sighted']")
    private WebElementFacade conditionDropDownGlaucomaAndBlindPartiallySightedButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Newmedica Px']")
    private WebElementFacade conditionDropDownNewmedicaPxButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Newmedica/Diabetic']")
    private WebElementFacade conditionDropDownNewmedicaDiabeticButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Newmedica/Diabetic/Glaucoma']")
    private WebElementFacade conditionDropDownNewmedicaDiabeticGlaucomaButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Newmedica/Glaucoma']")
    private WebElementFacade conditionDropDownNewmedicaGlaucomaButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Newmedica/Glaucoma/Diabetes/Visual Impairment']")
    private WebElementFacade conditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Not Known']")
    private WebElementFacade conditionDropDownNotKnownButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Not Relevant']")
    private WebElementFacade conditionDropDownNotRelevantButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Nothing reported']")
    private WebElementFacade conditionDropDownNothingReportedButton;
    @FindBy(xpath = "//select[@id='Condition']/option[@value='Reg Blind or Partially Sighted']")
    private WebElementFacade conditionDropDownRegBlindOrPartiallySightedButton;

    //Funding drop down options
    @FindBy(xpath = "//select[@id='Funding']/option[@value='']")
    private WebElementFacade fundingDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Income Support']")
    private WebElementFacade fundingDropDownIncomeSupportButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Universal Credit']")
    private WebElementFacade fundingDropDownUniversalCreditButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='HC2 Certificate']")
    private WebElementFacade fundingDropDownHC2CertificateButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='HC3 Certificate']")
    private WebElementFacade fundingDropDownHC3CertificateButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Privately Funded']")
    private WebElementFacade fundingDropDownPrivatelyFundedButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Income Based Job Seekers Allowance [JSA (IB)]']")
    private WebElementFacade fundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Not Known']")
    private WebElementFacade fundingDropDownNotKnownButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='NHS Tax Credit Exemption']")
    private WebElementFacade fundingDropDownNHSTaxCreditExemptionButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Guarantee Pension Credit']")
    private WebElementFacade fundingDropDownGuaranteePensionCreditButton;
    @FindBy(xpath = "//select[@id='Funding']/option[@value='Income retated ESA']")
    private WebElementFacade fundingDropDownIncomeRetatedESAButton;

    //Advertising method drop down options
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='']")
    private WebElementFacade advertisingMethodDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Advert - Local']")
    private WebElementFacade advertisingMethodDropDownAdvertLocalButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Advert - National']")
    private WebElementFacade advertisingMethodDropDownAdvertNationalButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Age Concern Referral']")
    private WebElementFacade advertisingMethodDropDownAgeConcernReferralButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Art & Design']")
    private WebElementFacade advertisingMethodDropDownArtAndDesignButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Automotive']")
    private WebElementFacade advertisingMethodDropDownAutomotiveButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Aviation']")
    private WebElementFacade advertisingMethodDropDownAviationButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Banking & Finance']")
    private WebElementFacade advertisingMethodDropDownBankingAndFinanceButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Bedlist']")
    private WebElementFacade advertisingMethodDropDownBedlistButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Bio-technology']")
    private WebElementFacade advertisingMethodDropDownBiotechnologyButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Bowen's Opticians']")
    private WebElementFacade advertisingMethodDropDownBowensOpticiansButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Brewing']")
    private WebElementFacade advertisingMethodDropDownBrewingButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='CareData Import']")
    private WebElementFacade advertisingMethodDropDownCareDataImportButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Carer']")
    private WebElementFacade advertisingMethodDropDownCarerButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Central / Local Government']")
    private WebElementFacade advertisingMethodDropDownCentralLocalGovernmentButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Charity']")
    private WebElementFacade advertisingMethodDropDownCharityButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Chemist']")
    private WebElementFacade advertisingMethodDropDownChemistButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Defence']")
    private WebElementFacade advertisingMethodDropDownDefenceButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Diabetic Screening Clinic']")
    private WebElementFacade advertisingMethodDropDownDiabeticScreeningClinicButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Distribution & Logistics']")
    private WebElementFacade advertisingMethodDropDownDistributionAndLogisticsButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Education & Training']")
    private WebElementFacade advertisingMethodDropDownEducationAndTrainingButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Emergency Services']")
    private WebElementFacade advertisingMethodDropDownEmergencyServicesButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Entertainment & Media']")
    private WebElementFacade advertisingMethodDropDownEntertainmentAndMediaButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Environmental']")
    private WebElementFacade advertisingMethodDropDownEnvironmentalButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Equipment Distribution']")
    private WebElementFacade advertisingMethodDropDownEquipmentDistributionButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Farming & Agriculture']")
    private WebElementFacade advertisingMethodDropDownFarmingAndAgricultureButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Friend / Family']")
    private WebElementFacade advertisingMethodDropDownFriendFamilyButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Furniture & Fittings']")
    private WebElementFacade advertisingMethodDropDownFurnitureAndFittingsButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Gaming']")
    private WebElementFacade advertisingMethodDropDownGamingButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='GP Surgery / Doctor']")
    private WebElementFacade advertisingMethodDropDownGPSurgeryDoctorButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Healthcall Staff']")
    private WebElementFacade advertisingMethodDropDownHealthcallStaffButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Healthcare']")
    private WebElementFacade advertisingMethodDropDownHealthcareButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Hire Services']")
    private WebElementFacade advertisingMethodDropDownHireServicesButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Hotel & Catering']")
    private WebElementFacade advertisingMethodDropDownHotelAndCateringButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Housing, Building & Construction']")
    private WebElementFacade advertisingMethodDropDownHousingBuildingAndConstructionButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Information Technology']")
    private WebElementFacade advertisingMethodDropDownInformationTechnologyButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Insurance']")
    private WebElementFacade advertisingMethodDropDownInsuranceButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Knowledge Management']")
    private WebElementFacade advertisingMethodDropDownKnowledgeManagementButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Leaflet Through The Door']")
    private WebElementFacade advertisingMethodDropDownLeafletThroughTheDoorButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Legal']")
    private WebElementFacade advertisingMethodDropDownLegalButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Manufacturing & Engineering']")
    private WebElementFacade advertisingMethodDropDownManufacturingAndEngineeringButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Mouseability Website']")
    private WebElementFacade advertisingMethodDropDownMouseabilityWebsiteButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='N/A - Care Home']")
    private WebElementFacade advertisingMethodDropDownNACareHomeButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Nurse']")
    private WebElementFacade advertisingMethodDropDownNurseButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Optician']")
    private WebElementFacade advertisingMethodDropDownOpticianButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Other']")
    private WebElementFacade advertisingMethodDropDownOtherButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Other Non-Profit making']")
    private WebElementFacade advertisingMethodDropDownOtherNonProfitMakingButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Other Recommendation']")
    private WebElementFacade advertisingMethodDropDownOtherRecommendationButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Personalised Letter']")
    private WebElementFacade advertisingMethodDropDownPersonalisedLetterButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Pharmaceutical']")
    private WebElementFacade advertisingMethodDropDownPharmaceuticalButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Previous Record']")
    private WebElementFacade advertisingMethodDropDownPreviousRecordButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Printing & Design']")
    private WebElementFacade advertisingMethodDropDownPrintingAndDesignButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Professional Body']")
    private WebElementFacade advertisingMethodDropDownProfessionalBodyButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Property Management']")
    private WebElementFacade advertisingMethodDropDownPropertyManagementButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Public Transport']")
    private WebElementFacade advertisingMethodDropDownPublicTransportButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Publishing & Newspapers']")
    private WebElementFacade advertisingMethodDropDownPublishingAndNewspapersButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Radio']")
    private WebElementFacade advertisingMethodDropDownRadioButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Recruitment']")
    private WebElementFacade advertisingMethodDropDownRecruitmentButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Reply Slip From Leaflet']")
    private WebElementFacade advertisingMethodDropDownReplySlipFromLeafletButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Retail']")
    private WebElementFacade advertisingMethodDropDownRetailButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Sales / Advertising / Marketing']")
    private WebElementFacade advertisingMethodDropDownSalesAdvertisingMarketingButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Security']")
    private WebElementFacade advertisingMethodDropDownSecurityButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Service Management']")
    private WebElementFacade advertisingMethodDropDownServiceManagementButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Sheltered - Warden Recommendation']")
    private WebElementFacade advertisingMethodDropDownShelteredWardenRecommendationButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Sheltered Accommodation Existing']")
    private WebElementFacade advertisingMethodDropDownShelteredAccommodationExistingButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Specsavers']")
    private WebElementFacade advertisingMethodDropDownSpecsaversButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Sport & Leisure']")
    private WebElementFacade advertisingMethodDropDownSportAndLeisureButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Telecoms & Communications']")
    private WebElementFacade advertisingMethodDropDownTelecomsAndCommunicationsButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Television Advert']")
    private WebElementFacade advertisingMethodDropDownTelevisionAdvertButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Translation Services']")
    private WebElementFacade advertisingMethodDropDownTranslationServicesButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Travel']")
    private WebElementFacade advertisingMethodDropDownTravelButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Utilities']")
    private WebElementFacade advertisingMethodDropDownUtilitiesButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Waste Management']")
    private WebElementFacade advertisingMethodDropDownWasteManagementButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Website']")
    private WebElementFacade advertisingMethodDropDownWebsiteButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Website – online test request']")
    private WebElementFacade advertisingMethodDropDownWebsiteOnlineTestRequestButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='Wholesale & Distribution']")
    private WebElementFacade advertisingMethodDropDownWholesaleAndDistributionButton;
    @FindBy(xpath = "//select[@id='AdvertisingMethod']/option[@value='WRVS Partnership']")
    private WebElementFacade advertisingMethodDropDownWRVSPartnershipButton;

    @FindBy(id = "NHSHAndCNumber")
    private WebElementFacade HAndCNumber;
    //Alternative contact main drop down options
    @FindBy(xpath = "//select[@id='AltContactDrop']/option[@value='none']")
    private WebElementFacade alternativeContactMainDropDownNoneButton;
    @FindBy(xpath = "//select[@id='AltContactDrop']/option[@value='new']")
    private WebElementFacade alternativeContactMainDropDownNewContactButton;

    //Alternative contact title drop down options
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Not Set']")
    private WebElementFacade alternativeContactTitleDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Mr']")
    private WebElementFacade alternativeContactTitleDropDownMrButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Miss']")
    private WebElementFacade alternativeContactTitleDropDownMissButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Mrs']")
    private WebElementFacade alternativeContactTitleDropDownMrsButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Ms']")
    private WebElementFacade alternativeContactTitleDropDownMsButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Master']")
    private WebElementFacade alternativeContactTitleDropDownMasterButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Rev']")
    private WebElementFacade alternativeContactTitleDropDownRevButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Sister']")
    private WebElementFacade alternativeContactTitleDropDownSisterButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Fr']")
    private WebElementFacade alternativeContactTitleDropDownFrButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Dr']")
    private WebElementFacade alternativeContactTitleDropDownDrButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Atty']")
    private WebElementFacade alternativeContactTitleDropDownAttyButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Prof']")
    private WebElementFacade alternativeContactTitleDropDownProfButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Hon']")
    private WebElementFacade alternativeContactTitleDropDownHonButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Pres']")
    private WebElementFacade alternativeContactTitleDropDownPresButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Gov']")
    private WebElementFacade alternativeContactTitleDropDownGovButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Coach']")
    private WebElementFacade alternativeContactTitleDropDownCoachButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Ofc']")
    private WebElementFacade alternativeContactTitleDropDownOfcButton;
    @FindBy(xpath = "//select[@id='AltConTitle']/option[@value='Mx']")
    private WebElementFacade alternativeContactTitleDropDownMxButton;

    //Alternative Contact Type drop down options
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Not Set']")
    private WebElementFacade alternativeContactTypeDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Administrator']")
    private WebElementFacade alternativeContactTypeDropDownAdministratorButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Venue Manager']")
    private WebElementFacade alternativeContactTypeDropDownVenueManagerButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Deputy Manager']")
    private WebElementFacade alternativeContactTypeDropDownDeputyManagerButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Matron']")
    private WebElementFacade alternativeContactTypeDropDownMatronButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Opticians Organiser']")
    private WebElementFacade alternativeContactTypeDropDownOpticiansOrganiserButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Patient Carer']")
    private WebElementFacade alternativeContactTypeDropDownPatientCarerButton;
    @FindBy(xpath = "//select[@id='AltConType']/option[@value='Patient Family']")
    private WebElementFacade alternativeContactTypeDropDownPatientFamilyButton;

    //Create new visit - visit type drop down options
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='']")
    private WebElementFacade visitTypeDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Home Visit New']")
    private WebElementFacade visitTypeDropDownHomeVisitNewButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Care Home Visit']")
    private WebElementFacade visitTypeDropDownCareHomeVisitButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Home Visit Existing']")
    private WebElementFacade visitTypeDropDownHomeVisitExistingButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Retest']")
    private WebElementFacade visitTypeDropDownRetestButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Corporate Eyecare']")
    private WebElementFacade visitTypeDropDownCorporateEyecareButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Prison Visit']")
    private WebElementFacade visitTypeDropDownPrisonVisitButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Hospital Visit']")
    private WebElementFacade visitTypeDropDownHospitalVisitButton;
    @FindBy(xpath = "//select[@id='VisitType']/option[@value='Private Sight Test']")
    private WebElementFacade visitTypeDropDownPrivateSightTestButton;

    //No appointment available - reason drop down options
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='']")
    private WebElementFacade noAppointmentAvailableReasonDropDownNotSetButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='No appointment available']")
    private WebElementFacade noAppointmentAvailableReasonDropDownNoAppointmentAvailableButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='Aftercare']")
    private WebElementFacade noAppointmentAvailableReasonDropDownAftercareButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='Dispense Only']")
    private WebElementFacade noAppointmentAvailableReasonDropDownDispenseOnlyButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='Early sight test requested']")
    private WebElementFacade noAppointmentAvailableReasonDropDownEarlySightTestRequestedButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='Domiciliary reason given vague']")
    private WebElementFacade noAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='Partially sighted or severely partially sighted']")
    private WebElementFacade noAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton;
    @FindBy(xpath = "//select[@id='NoAppointmentAvailableReason']/option[@value='Untick to save']")
    private WebElementFacade noAppointmentAvailableReasonDropDownUntickToSaveButton;

    //Error pop up elements
    @FindBy(id = "messageModalContinue")
    private WebElementFacade errorPopUpContinueButton;

    //Search patient/venue pop up
    @FindBy(xpath = "//h4[.='Search for Patient/Venue']")
    private WebElementFacade searchPatientVenuePopUpTitle;
    @FindBy(id = "Search_Name")
    private WebElementFacade patientNameSearchTextBox;
    @FindBy(xpath = "//button[@class='buttonise small-button'][@onclick='PerformSearch()']")
    private WebElementFacade patientVenueSearchButton;
    @FindBy(id = "Search_VenueName")
    private WebElementFacade venueNameSearchTextBox;
    @FindBy(id = "Search_Postcode")
    private WebElementFacade postcodeSearchTextBox;
    @FindBy(xpath = "//button[@onclick='Cancel_Search()']")
    private WebElementFacade searchPatientVenueCancelButton;
    @FindBy(xpath = "//h4[.='Patients']/../div[2]/div[1]/div[2]/a")
    private WebElementFacade patientVenueSearchFirstPatientInList;
    @FindBy(xpath = "//h4[.='Venues']/../div[4]/div[1]/div[1]/a")
    private WebElementFacade patientVenueSearchFirstVenueInList;
    @FindBy(xpath = "//h4[.='Venues']/../div[4]/div[1]/div[2]")
    private WebElementFacade patientVenueSearchFirstVenueInListAddress;

    //Postcode lookup pop up

    @FindBy(id = "Address_Search_Line")
    private WebElementFacade postcodeLookupInputBox;
    @FindBy(id = "Address_Search_Country")
    private WebElementFacade postcodeLookupCountryDropDown;
    @FindBy(xpath = "//option[.='United Kingdom']")
    private WebElementFacade postcodeLookupCountryDropDownUKOption;
    @FindBy(xpath = "//button[@onclick='PerformAddressSearch()']")
    private WebElementFacade postcodeLookupSearchButton;

    //Details saved successfully pop up
    @FindBy(id = "RecordSavedMessage")
    private WebElementFacade detailsSavedSuccessfullyPopUpText;

    //Clicks

    //Main CEP page clicks

    //Top of page green elements clicks
    public void clickShowScriptButton() {
        clickElement(showScriptButton);
    }
    public void clickSearchPatientVenueButton() {
        clickElement(searchPatientVenueButton);
    }
    public void clickPostcodeAddressLookupButton() {
        postcodeAddressLookupButton.waitUntilClickable();
        clickElement(postcodeAddressLookupButton);
    }
    public void clickCheckAvailabilityButton() {
        clickElement(checkAvailabilityButton);
    }
    public void clickCancelButton() {
        clickElement(cancelButton);
    }
    public void clickBackButton() {
        clickElement(backButton);
    }
    public void clickContinueButton() {
        element(continueButton).waitUntilPresent().waitUntilClickable().click();
    }

    //Drop down box clicks


    //Patient title drop down box clicks
    public void clickPatientTitleDropDownNotSetButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownNotSetButton);
    }
    public void clickPatientTitleDropDownMrButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownMrButton);
    }
    public void clickPatientTitleDropDownMissButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownMissButton);
    }
    public void clickPatientTitleDropDownMrsButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownMrsButton);
    }
    public void clickPatientTitleDropDownMsButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownMsButton);
    }
    public void clickPatientTitleDropDownMasterButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownMasterButton);
    }
    public void clickPatientTitleDropDownRevButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownRevButton);
    }
    public void clickPatientTitleDropDownSisterButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownSisterButton);
    }
    public void clickPatientTitleDropDownFrButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownFrButton);
    }
    public void clickPatientTitleDropDownDrButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownDrButton);
    }
    public void clickPatientTitleDropDownAttyButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownAttyButton);
    }
    public void clickPatientTitleDropDownProfButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownProfButton);
    }
    public void clickPatientTitleDropDownHonButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownHonButton);
    }
    public void clickPatientTitleDropDownPresButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownPresButton);
    }
    public void clickPatientTitleDropDownGovButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownGovButton);
    }
    public void clickPatientTitleDropDownCoachButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownCoachButton);
    }
    public void clickPatientTitleDropDownOfcButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownOfcButton);
    }
    public void clickPatientTitleDropDownMxButton() {
        clickDropDownOption(patientTitleDropDownBox, patientTitleDropDownMxButton);
    }

    //Gender drop down box clicks

    public void clickGenderDropDownNotSetButton() {
        clickDropDownOption(genderDropDownBox, genderDropDownNotSetButton);
    }
    public void clickGenderDropDownMaleButton() {
        clickDropDownOption(genderDropDownBox, genderDropDownMaleButton);
    }
    public void clickGenderDropDownFemaleButton() {
        clickDropDownOption(genderDropDownBox, genderDropDownFemaleButton);
    }
    public void clickGenderDropDownNeutralButton() {
        clickDropDownOption(genderDropDownBox, genderDropDownNeutralButton);
    }
    public void clickGenderDropDownNotSpecifiedButton() {
        clickDropDownOption(genderDropDownBox, genderDropDownNotSpecifiedButton);
    }

    //Country drop down box clicks
    public void clickCountryDropDownNotSetButton() {
        clickDropDownOption(countryDropDownBox, countryDropDownNotSetButton);
    }
    public void clickCountryDropDownEnglandButton() {
        clickDropDownOption(countryDropDownBox, countryDropDownEnglandButton);
    }
    public void clickCountryDropDownScotlandButton() {
        clickDropDownOption(countryDropDownBox, countryDropDownScotlandButton);
    }
    public void clickCountryDropDownWalesButton() {
        clickDropDownOption(countryDropDownBox, countryDropDownWalesButton);
    }
    public void clickCountryDropDownNorthernIrelandButton() {
        clickDropDownOption(countryDropDownBox, countryDropDownNorthernIrelandButton);
    }
    public void clickCountryDropDownRepublicOfIrelandButton() {
        clickDropDownOption(countryDropDownBox, countryDropDownRepublicOfIrelandButton);
    }

    //Domiciliary eligibility drop down clicks
    public void clickDomiciliaryEligibilityDropDownNotSetButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownNotSetButton);
    }
    public void clickDomiciliaryEligibilityDropDownAgrophobicButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownAgrophobicButton);
    }
    public void clickDomiciliaryEligibilityDropDownAlzheimerButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownAlzheimerButton);
    }
    public void clickDomiciliaryEligibilityDropDownAmputeeButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownAmputeeButton);
    }
    public void clickDomiciliaryEligibilityDropDownArthritisButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownArthritisButton);
    }
    public void clickDomiciliaryEligibilityDropDownAutismButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownAutismButton);
    }
    public void clickDomiciliaryEligibilityDropDownCancerButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownCancerButton);
    }
    public void clickDomiciliaryEligibilityDropDownCOPDButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownCOPDButton);
    }
    public void clickDomiciliaryEligibilityDropDownCoronaryHeartDiseaseButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownCoronaryHeartDiseaseButton);
    }
    public void clickDomiciliaryEligibilityDropDownCVAStrokeButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownCVAStrokeButton);
    }
    public void clickDomiciliaryEligibilityDropDownDementiaButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownDementiaButton);
    }
    public void clickDomiciliaryEligibilityDropDownDownsSyndromeButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownDownsSyndromeButton);
    }
    public void clickDomiciliaryEligibilityDropDownLearningDisabilitiesButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownLearningDisabilitiesButton);
    }
    public void clickDomiciliaryEligibilityDropDownMSButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownMSButton);
    }
    public void clickDomiciliaryEligibilityDropDownMorbidObesityButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownMorbidObesityButton);
    }
    public void clickDomiciliaryEligibilityDropDownMotorNeuroneButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownMotorNeuroneButton);
    }
    public void clickDomiciliaryEligibilityDropDownOsteoporosisButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownOsteoporosisButton);
    }
    public void clickDomiciliaryEligibilityDropDownOtherButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownOtherButton);
    }
    public void clickDomiciliaryEligibilityDropDownParalysisButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownParalysisButton);
    }
    public void clickDomiciliaryEligibilityDropDownParkinsonsDiseaseButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownParkinsonsDiseaseButton);
    }
    public void clickDomiciliaryEligibilityDropDownPeripheralNerupathyButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownPeripheralNerupathyButton);
    }
    public void clickDomiciliaryEligibilityDropDownRespiratoryDiseaseButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownRespiratoryDiseaseButton);
    }
    public void clickDomiciliaryEligibilityDropDownSevereLegUlcersButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownSevereLegUlcersButton);
    }
    public void clickDomiciliaryEligibilityDropDownSpinalDegenerationButton() {
        clickDropDownOption(countryDropDownBox, domiciliaryEligibilityDropDownSpinalDegenerationButton);
    }

    //Previous optician drop down clicks
    public void clickPreviousOpticianDropDownNotSetButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownNotSetButton);
    }
    public void clickPreviousOpticianDropDownAsdaButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownAsdaButton);
    }
    public void clickPreviousOpticianDropDownAtHomeButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownAtHomeButton);
    }
    public void clickPreviousOpticianDropDownBootsButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownBootsButton);
    }
    public void clickPreviousOpticianDropDownEyecareOncallButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownEyecareOncallButton);
    }
    public void clickPreviousOpticianDropDownHomecallButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownHomecallButton);
    }
    public void clickPreviousOpticianDropDownLocalButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownLocalButton);
    }
    public void clickPreviousOpticianDropDownLocalDomiciliaryProviderButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownLocalDomiciliaryProviderButton);
    }
    public void clickPreviousOpticianDropDownLocalHighStreetProviderButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownLocalHighStreetProviderButton);
    }
    public void clickPreviousOpticianDropDownNotKnownButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownNotKnownButton);
    }
    public void clickPreviousOpticianDropDownOpticalExpressButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownOpticalExpressButton);
    }
    public void clickPreviousOpticianDropDownOtherButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownOtherButton);
    }
    public void clickPreviousOpticianDropDownSpecsaversButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownSpecsaversButton);
    }
    public void clickPreviousOpticianDropDownTescoButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownTescoButton);
    }
    public void clickPreviousOpticianDropDownTheOutsideClinicButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownTheOutsideClinicButton);
    }
    public void clickPreviousOpticianDropDownVisionExpressButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownVisionExpressButton);
    }
    public void clickPreviousOpticianDropDownVisioncallButton() {
        clickDropDownOption(previousOpticianDropDownBox, previousOpticianDropDownVisioncallButton);
    }

    //Conditions drop down clicks
    public void clickConditionDropDownNotSetButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNotSetButton);
    }
    public void clickConditionDropDownDiabeticButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownDiabeticButton);
    }
    public void clickConditionDropDownDiabeticAndBlindPartiallySightedButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownDiabeticAndBlindPartiallySightedButton);
    }
    public void clickConditionDropDownDiabeticAndFamilyGlaucomaButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownDiabeticAndFamilyGlaucomaButton);
    }
    public void clickConditionDropDownDiabeticAndGlacomaAndBlindPartiallySightedButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownDiabeticAndGlaucomaAndBlindPartiallySightedButton);
    }
    public void clickConditionDropDownDiabeticAndGlaucomaButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownDiabeticAndGlaucomaButton);
    }
    public void clickConditionDropDownFamilyHistoryOfGlaucomaButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownFamilyHistoryOfGlaucomaButton);
    }
    public void clickConditionDropDownGlaucomaButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownGlaucomaButton);
    }
    public void clickConditionDropDownGlaucomaAndBlindPartiallySightedButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownGlaucomaAndBlindPartiallySightedButton);
    }
    public void clickConditionDropDownNewmedicaPxButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNewmedicaPxButton);
    }
    public void clickConditionDropDownNewmedicaDiabeticButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNewmedicaDiabeticButton);
    }
    public void clickConditionDropDownNewmedicaDiabeticGlaucomaButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNewmedicaDiabeticGlaucomaButton);
    }
    public void clickConditionDropDownNewmedicaGlaucomaButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNewmedicaGlaucomaButton);
    }
    public void clickConditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton);
    }
    public void clickConditionDropDownNotKnownButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNotKnownButton);
    }
    public void clickConditionDropDownNotRelevantButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNotRelevantButton);
    }
    public void clickConditionDropDownNothingReportedButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownNothingReportedButton);
    }
    public void clickConditionDropDownRegBlindOrPartiallySightedButton() {
        clickDropDownOption(conditionDropDownBox, conditionDropDownRegBlindOrPartiallySightedButton);
    }

    //Funding drop down clicks
    public void clickFundingDropDownNotSetButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownNotSetButton);
    }
    public void clickFundingDropDownIncomeSupportButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownIncomeSupportButton);
    }
    public void clickFundingDropDownUniversalCreditButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownUniversalCreditButton);
    }
    public void clickFundingDropDownHC2CertificateButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownHC2CertificateButton);
    }
    public void clickFundingDropDownHC3CertificateButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownHC3CertificateButton);
    }
    public void clickFundingDropDownPrivatelyFundedButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownPrivatelyFundedButton);
    }
    public void clickFundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton);
    }
    public void clickFundingDropDownNotKnownButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownNotKnownButton);
    }
    public void clickFundingDropDownNHSTaxCreditExemptionButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownNHSTaxCreditExemptionButton);
    }
    public void clickFundingDropDownGuaranteePensionCreditButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownGuaranteePensionCreditButton);
    }
    public void clickFundingDropDownIncomeRetatedESAButton() {
        clickDropDownOption(fundingDropDownBox, fundingDropDownIncomeRetatedESAButton);
    }

    //Patient primary contact radio button clicks
    public void clickPatientHomeTelephoneNumberPrimaryContactRadioButton() {
        if (patientHomeTelephoneNumberPrimaryContactRadioButton.isEnabled()) {
            clickElement(patientHomeTelephoneNumberPrimaryContactRadioButton);
        }
    }
    public void clickPatientMobileTelephoneNumberPrimaryContactRadioButton() {
        clickElement(patientMobileTelephoneNumberPrimaryContactRadioButton);
    }

    //Advertising method drop down clicks
    public void clickAdvertisingMethodDropDownNotSetButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownNotSetButton);
    }
    public void clickAdvertisingMethodDropDownAdvertLocalButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownAdvertLocalButton);
    }
    public void clickAdvertisingMethodDropDownAdvertNationalButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownAdvertNationalButton);
    }
    public void clickAdvertisingMethodDropDownAgeConcernReferralButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownAgeConcernReferralButton);
    }
    public void clickAdvertisingMethodDropDownArtAndDesignButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownArtAndDesignButton);
    }
    public void clickAdvertisingMethodDropDownAutomotiveButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownAutomotiveButton);
    }
    public void clickAdvertisingMethodDropDownAviationButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownAviationButton);
    }
    public void clickAdvertisingMethodDropDownBankingAndFinanceButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownBankingAndFinanceButton);
    }
    public void clickAdvertisingMethodDropDownBedlistButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownBedlistButton);
    }
    public void clickAdvertisingMethodDropDownBiotechnologyButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownBiotechnologyButton);
    }
    public void clickAdvertisingMethodDropDownBowensOpticiansButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownBowensOpticiansButton);
    }
    public void clickAdvertisingMethodDropDownBrewingButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownBrewingButton);
    }
    public void clickAdvertisingMethodDropDownCareDataImportButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownCareDataImportButton);
    }
    public void clickAdvertisingMethodDropDownCarerButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownCarerButton);
    }
    public void clickAdvertisingMethodDropDownCentralLocalGovernmentButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownCentralLocalGovernmentButton);
    }
    public void clickAdvertisingMethodDropDownCharityButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownCharityButton);
    }
    public void clickAdvertisingMethodDropDownChemistButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownChemistButton);
    }
    public void clickAdvertisingMethodDropDownDefenceButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownDefenceButton);
    }
    public void clickAdvertisingMethodDropDownDiabeticScreeningClinicButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownDiabeticScreeningClinicButton);
    }
    public void clickAdvertisingMethodDropDownDistributionAndLogisticsButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownDistributionAndLogisticsButton);
    }
    public void clickAdvertisingMethodDropDownEducationAndTrainingButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownEducationAndTrainingButton);
    }
    public void clickAdvertisingMethodDropDownEmergencyServicesButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownEmergencyServicesButton);
    }
    public void clickAdvertisingMethodDropDownEntertainmentAndMediaButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownEntertainmentAndMediaButton);
    }
    public void clickAdvertisingMethodDropDownEnvironmentalButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownEnvironmentalButton);
    }

    public void clickAdvertisingMethodDropDownEquipmentDistributionButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownEquipmentDistributionButton);
    }
    public void clickAdvertisingMethodDropDownFarmingAndAgricultureButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownFarmingAndAgricultureButton);
    }
    public void clickAdvertisingMethodDropDownFriendFamilyButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownFriendFamilyButton);
    }
    public void clickAdvertisingMethodDropDownFurnitureAndFittingsButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownFurnitureAndFittingsButton);
    }
    public void clickAdvertisingMethodDropDownGamingButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownGamingButton);
    }
    public void clickAdvertisingMethodDropDownGPSurgeryDoctorButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownGPSurgeryDoctorButton);
    }
    public void clickAdvertisingMethodDropDownHealthcallStaffButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownHealthcallStaffButton);
    }
    public void clickAdvertisingMethodDropDownHealthcareButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownHealthcareButton);
    }
    public void clickAdvertisingMethodDropDownHireServicesButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownHireServicesButton);
    }
    public void clickAdvertisingMethodDropDownHotelAndCateringButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownHotelAndCateringButton);
    }
    public void clickAdvertisingMethodDropDownHousingBuildingAndConstructionButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownHousingBuildingAndConstructionButton);
    }
    public void clickAdvertisingMethodDropDownInformationTechnologyButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownInformationTechnologyButton);
    }
    public void clickAdvertisingMethodDropDownInsuranceButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownInsuranceButton);
    }
    public void clickAdvertisingMethodDropDownKnowledgeManagementButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownKnowledgeManagementButton);
    }
    public void clickAdvertisingMethodDropDownLeafletThroughTheDoorButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownLeafletThroughTheDoorButton);
    }
    public void clickAdvertisingMethodDropDownLegalButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownLegalButton);
    }
    public void clickAdvertisingMethodDropDownManufacturingAndEngineeringButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownManufacturingAndEngineeringButton);
    }
    public void clickAdvertisingMethodDropDownMouseabilityWebsiteButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownMouseabilityWebsiteButton);
    }
    public void clickAdvertisingMethodDropDownNACareHomeButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownNACareHomeButton);
    }
    public void clickAdvertisingMethodDropDownNurseButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownNurseButton);
    }
    public void clickAdvertisingMethodDropDownOpticianButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownOpticianButton);
    }
    public void clickAdvertisingMethodDropDownOtherButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownOtherButton);
    }
    public void clickAdvertisingMethodDropDownOtherNonProfitMakingButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownOtherNonProfitMakingButton);
    }
    public void clickAdvertisingMethodDropDownOtherRecommendationButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownOtherRecommendationButton);
    }
    public void clickAdvertisingMethodDropDownPersonalisedLetterButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPersonalisedLetterButton);
    }
    public void clickAdvertisingMethodDropDownPharmaceuticalButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPharmaceuticalButton);
    }
    public void clickAdvertisingMethodDropDownPreviousRecordButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPreviousRecordButton);
    }
    public void clickAdvertisingMethodDropDownPrintingAndDesignButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPrintingAndDesignButton);
    }
    public void clickAdvertisingMethodDropDownProfessionalBodyButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownProfessionalBodyButton);
    }
    public void clickAdvertisingMethodDropDownPropertyManagementButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPropertyManagementButton);
    }
    public void clickAdvertisingMethodDropDownPublicTransportButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPublicTransportButton);
    }
    public void clickAdvertisingMethodDropDownPublishingAndNewspapersButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownPublishingAndNewspapersButton);
    }
    public void clickAdvertisingMethodDropDownRadioButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownRadioButton);
    }
    public void clickAdvertisingMethodDropDownRecruitmentButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownRecruitmentButton);
    }
    public void clickAdvertisingMethodDropDownReplySlipFromLeafletButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownReplySlipFromLeafletButton);
    }
    public void clickAdvertisingMethodDropDownRetailButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownRetailButton);
    }
    public void clickAdvertisingMethodDropDownSalesAdvertisingMarketingButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownSalesAdvertisingMarketingButton);
    }
    public void clickAdvertisingMethodDropDownSecurityButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownSecurityButton);
    }
    public void clickAdvertisingMethodDropDownServiceManagementButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownServiceManagementButton);
    }
    public void clickAdvertisingMethodDropDownShelteredWardenRecommendationButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownShelteredWardenRecommendationButton);
    }
    public void clickAdvertisingMethodDropDownShelteredAccommodationExistingButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownShelteredAccommodationExistingButton);
    }
    public void clickAdvertisingMethodDropDownSpecsaversButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownSpecsaversButton);
    }
    public void clickAdvertisingMethodDropDownSportAndLeisureButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownSportAndLeisureButton);
    }
    public void clickAdvertisingMethodDropDownTelecomsAndCommunicationsButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownTelecomsAndCommunicationsButton);
    }
    public void clickAdvertisingMethodDropDownTelevisionAdvertButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownTelevisionAdvertButton);
    }
    public void clickAdvertisingMethodDropDownTranslationServicesButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownTranslationServicesButton);
    }
    public void clickAdvertisingMethodDropDownTravelButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownTravelButton);
    }
    public void clickAdvertisingMethodDropDownUtilitiesButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownUtilitiesButton);
    }
    public void clickAdvertisingMethodDropDownWasteManagementButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownWasteManagementButton);
    }
    public void clickAdvertisingMethodDropDownWebsiteButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownWebsiteButton);
    }
    public void clickAdvertisingMethodDropDownWebsiteOnlineTestRequestButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownWebsiteOnlineTestRequestButton);
    }
    public void clickAdvertisingMethodDropDownWholesaleAndDistributionButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownWholesaleAndDistributionButton);
    }
    public void clickAdvertisingMethodDropDownWRVSPartnershipButton() {
        clickDropDownOption(advertisingMethodDropDownBox, advertisingMethodDropDownWRVSPartnershipButton);
    }

    //Alternative contact main drop down clicks
    public void clickAlternativeContactMainDropDownNoneButton() {
        clickDropDownOption(alternativeContactDropDownBox, alternativeContactMainDropDownNoneButton);
    }
    public void clickAlternativeContactMainDropDownNewContactButton() {
        clickDropDownOption(alternativeContactDropDownBox, alternativeContactMainDropDownNewContactButton);
    }

    //Alternative contact title drop down clicks
    public void clickAlternativeContactTitleDropDownNotSetButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownNotSetButton);
    }
    public void clickAlternativeContactTitleDropDownMrButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownMrButton);
    }
    public void clickAlternativeContactTitleDropDownMissButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownMissButton);
    }
    public void clickAlternativeContactTitleDropDownMrsButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownMrsButton);
    }
    public void clickAlternativeContactTitleDropDownMsButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownMsButton);
    }
    public void clickAlternativeContactTitleDropDownMasterButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownMasterButton);
    }
    public void clickAlternativeContactTitleDropDownRevButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownRevButton);
    }
    public void clickAlternativeContactTitleDropDownSisterButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownSisterButton);
    }
    public void clickAlternativeContactTitleDropDownFrButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownFrButton);
    }
    public void clickAlternativeContactTitleDropDownDrButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownDrButton);
    }
    public void clickAlternativeContactTitleDropDownAttyButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownAttyButton);
    }
    public void clickAlternativeContactTitleDropDownProfButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownProfButton);
    }
    public void clickAlternativeContactTitleDropDownHonButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownHonButton);
    }
    public void clickAlternativeContactTitleDropDownPresButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownPresButton);
    }
    public void clickAlternativeContactTitleDropDownGovButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownGovButton);
    }
    public void clickAlternativeContactTitleDropDownCoachButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownCoachButton);
    }
    public void clickAlternativeContactTitleDropDownOfcButton() {
        clickDropDownOption(alternativeContactTitleDropDownBox, alternativeContactTitleDropDownOfcButton);
    }

    //Alternative contact type drop down clicks
    public void clickAlternativeContactTypeDropDownNotSetButton() {
        clickElement(alternativeContactTypeDropDownNotSetButton);
    }
    public void clickAlternativeContactTypeDropDownAdministratorButton() {
        clickElement(alternativeContactTypeDropDownAdministratorButton);
    }
    public void clickAlternativeContactTypeDropDownVenueManagerButton() {
        clickElement(alternativeContactTypeDropDownVenueManagerButton);
    }
    public void clickAlternativeContactTypeDropDownDeputyManagerButton() {
        clickElement(alternativeContactTypeDropDownDeputyManagerButton);
    }
    public void clickAlternativeContactTypeDropDownMatronButton() {
        clickElement(alternativeContactTypeDropDownMatronButton);
    }
    public void clickAlternativeContactTypeDropDownOpticiansOrganiserButton() {
        clickElement(alternativeContactTypeDropDownOpticiansOrganiserButton);
    }
    public void clickAlternativeContactTypeDropDownPatientCarerButton() {
        clickElement(alternativeContactTypeDropDownPatientCarerButton);
    }
    public void clickAlternativeContactTypeDropDownPatientFamilyButton() {
        clickElement(alternativeContactTypeDropDownPatientFamilyButton);
    }


    //Alternative contact primary contact radio button clicks
    public void clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton() {
        clickElement(alternativeContactHomeTelephoneNumberPrimaryContactRadioButton);
    }
    public void clickAlternativeContactMobileTelephoneNumberPrimaryContactRadioButton() {
        clickElement(alternativeContactMobileTelephoneNumberPrimaryContactRadioButton);
    }

    //Visit information clicks
    public void clickCreateNewVisitRadioButton() {
        clickElement(createNewVisitRadioButton);
    }
    public void clickAnytimeCheckBox() {
        clickElement(anytimeCheckBox);
    }
    public void clickNoAppointmentAvailableRadioButton() {
        clickElement(noAppointmentAvailableRadioButton);
    }

    //Create new visit clicks
    public void clickVisitTypeDropDownNotSetButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownNotSetButton);
    }
    public void clickVisitTypeDropDownHomeVisitNewButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownHomeVisitNewButton);
    }
    public void clickVisitTypeDropDownCareHomeVisitButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownCareHomeVisitButton);
    }
    public void clickVisitTypeDropDownHomeVisitExistingButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownHomeVisitExistingButton);
    }
    public void clickVisitTypeDropDownRetestButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownRetestButton);
    }
    public void clickVisitTypeDropDownCorporateEyecareButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownCorporateEyecareButton);
    }
    public void clickVisitTypeDropDownPrisonVisitButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownPrisonVisitButton);
    }
    public void clickVisitTypeDropDownHospitalVisitButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownHospitalVisitButton);
    }
    public void clickVisitTypeDropDownPrivateSightTestButton() {
        clickDropDownOption(visitTypeDropDownBox, visitTypeDropDownPrivateSightTestButton);
    }

    //Visit date picker click
    public void clickVisitTimeslotPicker() {
        clickElement(visitTimeslotPicker);
    }

    public void chooseAppointmentTimeslot(String optomName, String date, String amPm) {
        String xpath;
        if (amPm.toLowerCase().equals("am")) {
            xpath = "//div[contains(.,'" + optomName + "') and contains(.,'" + date + "') and contains(@class,'listrow')]/div[@class='column large-3 medium-3 small-3']/button[contains(@onclick,'true')]";
        } else {
            xpath = "//div[contains(.,'" + optomName + "') and contains(.,'" + date + "') and contains(@class,'listrow')]/div[@class='column large-3 medium-3 small-3']/button[contains(@onclick,'false')]";
        }
        scrollToView(element(By.xpath(xpath)));
        element(By.xpath(xpath)).waitUntilPresent().waitUntilClickable().click();
        waitABit(2500);
    }

    public void enterDateIntoVisitDateTextBox(String date) {
        element(visitDateTextBox).typeAndEnter(date);
        clickElement(visitDatePickerCurrentDay);
        waitABit(10000);
    }
    public void clickAutomationOptomInOptometristDropDown() {
        clickOptomInOptometristDropDown("1-Automation-Optometrist OO-Automation-Bot1");
    }
    public void clickAutomationOptom5InOptometristDropDown() {
        this.clickOptomInOptometristDropDown("5-Automation-Optometrist OO-Automation-Scotland");
    }
    public void clickAutomationOptom6InOptometristDropDown() {
        this.clickOptomInOptometristDropDown("6-Automation-Optometrist OO-Automation-Wales");
    }
    public void clickAutomationOptom7InOptometristDropDown() {
        this.clickOptomInOptometristDropDown("7-Automation-Optometrist OO-Automation-NI");
    }
    public void clickOptomInOptometristDropDown(String optomName) {
        String xpath = "//option[contains(.,'" + optomName + "')]";
        clickDropDownOption(visitOptometristDropDownBox, element(By.xpath(xpath)));
    }

    //No appointment available reason drop down clicks
    public void clickNoAppointmentAvailableReasonDropDownNotSetButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownNotSetButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownNoAppointmentAvailableButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownNoAppointmentAvailableButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownAftercareButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownAftercareButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownDispenseOnlyButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownDispenseOnlyButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownEarlySightTestRequestedButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownEarlySightTestRequestedButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton);
    }
    public void clickNoAppointmentAvailableReasonDropDownUntickToSaveButton() {
        clickDropDownOption(noAppointmentAvailableReasonDropDownBox, noAppointmentAvailableReasonDropDownUntickToSaveButton);
    }

    //Consent and permissions page clicks
    public void clickDataProcessingConsentYesRadioButton() {
        element(dataProcessingConsentYesRadioButton).waitUntilPresent().waitUntilClickable().click();
    }
    public void clickDataProcessingConsentNoRadioButton() {
        clickElement(dataProcessingConsentNoRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsEmailYesRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsEmailYesRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsEmailNoRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsEmailNoRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsPostYesRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsPostYesRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsPostNoRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsPostNoRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsSMSYesRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsSMSYesRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsSMSNoRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsSMSNoRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsTelephoneYesRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsTelephoneYesRadioButton);
    }
    public void clickMarketingInServiceRelatedCommunicationsTelephoneNoRadioButton() {
        clickElement(marketingInServiceRelatedCommunicationsTelephoneNoRadioButton);
    }
    public void clickMarketingPermissionsEmailYesRadioButton() {
        clickElement(marketingPermissionsEmailYesRadioButton);
    }
    public void clickMarketingPermissionsEmailNoRadioButton() {
        clickElement(marketingPermissionsEmailNoRadioButton);
    }
    public void clickMarketingPermissionsPostYesRadioButton() {
        clickElement(marketingPermissionsPostYesRadioButton);
    }
    public void clickMarketingPermissionsPostNoRadioButton() {
        clickElement(marketingPermissionsPostNoRadioButton);
    }
    public void clickMarketingPermissionsSMSYesRadioButton() {
        clickElement(marketingPermissionsSMSYesRadioButton);
    }
    public void clickMarketingPermissionsSMSNoRadioButton() {
        clickElement(marketingPermissionsSMSNoRadioButton);
    }
    public void clickMarketingPermissionsTelephoneYesRadioButton() {
        clickElement(marketingPermissionsTelephoneYesRadioButton);
    }
    public void clickMarketingPermissionsTelephoneNoRadioButton() {
        clickElement(marketingPermissionsTelephoneNoRadioButton);
    }
    public void clickMarketingConsentConfirmButton() {
        clickElement(marketingConsentConfirmButton);
    }
    public void clickMarketingConsentSaveButton() {
        clickElement(marketingConsentSaveButton);
    }
    public void clickMarketingCareHomeDataProcessingConsentConfirmButton() {
        clickElement(marketingCareHomeDataProcessingConsentConfirmButton);
    }
    public void clickMarketingCareHomeDataProcessingConsentYesButton() {
        clickElement(marketingCareHomeDataProcessingConsentYesButton);
    }
    public void clickMarketingCareHomeDataProcessingConsentNoButton() {
        clickElement(marketingCareHomeDataProcessingConsentNoButton);
    }

    public void clickDetailsSavedSuccessfullyContinue() {
        element(detailsSavedSuccessfullyContinueButton).waitUntilPresent().waitUntilClickable().click();
    }
    public void clickAddNewPatientButton() {
        clickElement(addNewPatientButton);
    }
    public void clickAddExistingPatientButton() {
        clickElement(addExistingPatientButton);
    }
    public void addPatientsToExistingCareHomeVisit(List<String> patientSurnames) {
        for (String surname : patientSurnames) {
            String xpath = "//a[contains(@href,'contact') and contains(@href,'javascript') and contains(.,'Patient-" + surname + "')]/../following-sibling::div[contains(@style,'padding-top')]/input[@name='SelectedExistingPatients']";
            scrollToView(element(By.xpath(xpath)));
            element(By.xpath(xpath)).click();
        }
    }
    public void addPatientsToExistingHomeVisit(List<String> patientSurnames) {
        int i = 0;
        while (i < patientSurnames.size()) {
            String xpath = "//a[contains(@href,'contact') and contains(@href,'javascript') and contains(.,'Patient-" + patientSurnames.get(i) + "')]/../following-sibling::div[contains(@style,'padding-top')]/button";
            scrollToView(element(By.xpath(xpath)));
            element(By.xpath(xpath)).click();
            clickContinueButton();
            clickDataProcessingConsentYesRadioButton();
            clickMarketingConsentConfirmButton();
            clickMarketingConsentSaveButton();
            clickDetailsSavedSuccessfullyContinue();
            i++;
            if (!(i >= patientSurnames.size())) {
                clickAddExistingPatientButton();
            }
        }
    }
    public void clickAddToBookingButton() {
        clickElement(addToBookingButton);
    }
    public void clickFinishButton() {
        element(finishButton).waitUntilPresent().waitUntilClickable().click();
    }

    //Error pop up click
    public void clickErrorPopUpContinueButton() {
        clickElement(errorPopUpContinueButton);
    }

    //Enter text

    //Text Input Functions

    //Patient Information
    public void enterTextInPatientFirstNameBox(String firstName){
        enterGivenTextInTextField(patientFirstNameTextBox, firstName);
    }
    public void enterTextInPatientSurnameNameBox(String surname){
        enterGivenTextInTextField(patientSurnameTextBox, surname);
    }
    public void enterTextInPatientPostcodeBox(String postcode){
        enterGivenTextInTextField(postcodeTextBox, postcode);
    }
    public void enterTextInPatientHomeTelephoneBox(String homeTelephone){
        enterGivenTextInTextField(patientHomeTelephoneNumberTextBox, homeTelephone);
    }
    public void enterTextInPatientMobileTelephoneBox(String mobileTelephone){
        enterGivenTextInTextField(patientMobileTelephoneNumberTextBox, mobileTelephone);
    }
    public void enterTextInDateOfLastSightTestPicker(String dateOfLastSightTest) {
        enterGivenTextInTextField(dateOfLastSightTestPicker, dateOfLastSightTest);
    }
    public void enterTextInDateOfBirthPicker(String dateOfBirth) {
        enterGivenTextInTextField(dateOfBirthPicker, dateOfBirth);
    }

    //Alternate Contact Information
    public void enterTextInAlternateContactFirstNameBox(String firstName){
        enterGivenTextInTextField(alternativeContactFirstNameTextBox, firstName);
    }
    public void enterTextInAlternateContactSurnameNameBox(String surname){
        enterGivenTextInTextField(alternativeContactSurnameTextBox, surname);
    }
    public void enterTextInAlternateContactHomeTelephoneBox(String homeTelephone){
        enterGivenTextInTextField(alternativeContactHomeTelephoneNumberTextBox, homeTelephone);
    }
    public void enterTextInAlternateContactMobileTelephoneBox(String mobileTelephone){
        enterGivenTextInTextField(alternativeContactMobileTelephoneNumberTextBox, mobileTelephone);
    }

    public void clickDateOfLastSightTestNotKnownCheckBox() {
        clickElement(dateOfLastSightTestNotKnownCheckBox);
    }


    //Search patient/venue pop up

    public void enterTextIntoPatientSearchTextBox(String text) {
        waitABit(1500);
        enterGivenTextInTextField(patientNameSearchTextBox, text);
    }

    public void enterTextIntoVenueNameSearchTextBox(String text) {
        waitABit(1500);
        enterGivenTextInTextField(venueNameSearchTextBox, text);
    }

    public void enterTextIntoPostcodeSearchTextBox(String postcode) {
        waitABit(1500);
        enterGivenTextInTextField(postcodeSearchTextBox, postcode);
    }

    public void clearTextFromSearchPatientVenueTextBoxes() {
        element(patientNameSearchTextBox).clear();
        element(venueNameSearchTextBox).clear();
        element(postcodeSearchTextBox).clear();
    }

    public void searchPatientVenueClickCancelButton() {
        clickElement(searchPatientVenueCancelButton);
    }

    public void clickPatientVenueSearchButtonAndAssertPatientIsPresent(String name) {
        clickElement(patientVenueSearchButton);
        waitABit(5000);
        element(patientVenueSearchFirstPatientInList).waitUntilPresent();
        assertElementContainsText(patientVenueSearchFirstPatientInList, name);
    }

    public void clickPatientVenueSearchButtonAndAssertVenueIsPresent(String name) {
        clickElement(patientVenueSearchButton);
        element(patientVenueSearchFirstVenueInList).waitUntilPresent();
        assertElementContainsText(patientVenueSearchFirstVenueInList, name);
    }

    public void clickPatientVenueSearchButtonAndAssertPostcodeIsPresent(String postcode) {
        clickElement(patientVenueSearchButton);
        element(patientVenueSearchFirstVenueInListAddress).waitUntilPresent();
        assertElementContainsText(patientVenueSearchFirstVenueInListAddress, postcode);
    }
    public void clickPatientSelectButton(String surname) {
        String xpath = "//a[contains(.,'" + surname + "')  and contains(@href,'contact')]/../following-sibling::div[6]/button";
        clickElement(element(By.xpath(xpath)));
    }
    public void clickVenueSelectButton(String surname) {
        String xpath = "//a[contains(.,'" + surname + "') and contains(@href,'venue')]/../following-sibling::div[2]/button";
        clickElement(element(By.xpath(xpath)));
    }
    public void enterHAndCNumber(String HAndC){
        enterGivenTextInTextField(HAndCNumber, HAndC);
    }
    //Assertions

    public void assertDataProcessingConsentTitleIsPresent() {
        waitABit(5000);
        assertElementText(dataProcessingConsentTitle, "Data Processing Consent");
    }

    public void assertServiceCommunicationsTitleIsPresent() {
        assertElementText(serviceCommunicationsTitle, "Service communications");
    }

    public void assertDetailsSavedSuccessfullyPopUpIsPresent() {
        element(detailsSavedSuccessfullyPopUpText).waitUntilPresent();
        assertElementText(detailsSavedSuccessfullyPopUpText, "Details Saved Successfully");
    }
    public void assertAddAnotherPatientPopUpTextIsPresent() {
        element(addAnotherPatientPopUpText).waitUntilPresent();
        assertElementText(addAnotherPatientPopUpText, "Do you wish to add another Patient or complete the booking?");
    }

    public void assertCustomerEntryPageTitleIsPresent() {
        element(customerEntryPageTitle).waitUntilPresent();
        assertElementText(customerEntryPageTitle, "Customer Entry");
    }

    public void assertSearchPatientVenuePopUpIsPresent() {
        element(searchPatientVenuePopUpTitle).waitUntilPresent();
        assertElementText(searchPatientVenuePopUpTitle, "Search for Patient/Venue");
    }

    //Test data prep
    public void clickSteveTheOptomInOptometristDropDown() {
        clickDropDownOption(visitOptometristDropDownBox, visitOptometristDropDownBoxSteveTheOptomOption);
    }
    public void clickKeithTheOptomInOptometristDropDown() {
        clickDropDownOption(visitOptometristDropDownBox, visitOptometristDropDownBoxKeithTheOptomOption);
    }

    //Postcode lookup pop up

    public void enterPostcodeIntoPostcodeLookup(String postcode) {
        enterGivenTextInTextField(postcodeLookupInputBox, postcode);
    }

    public void chooseUKFromPostcodeLookupCountryDropdown() {
        clickDropDownOption(postcodeLookupCountryDropDown, postcodeLookupCountryDropDownUKOption);
    }

    public void clickPostcodeLookupSearchButton() {
        clickElement(postcodeLookupSearchButton);
    }

    public void selectFirstAddressPostcodeLookup(String postcode) {
        String xpath = "//div[contains(.,'" + postcode + "') and @class='column large-10 medium-10 small-10']/following-sibling::div/a[.='Select']";
        clickElement(element(By.xpath(xpath)));
    }



}
