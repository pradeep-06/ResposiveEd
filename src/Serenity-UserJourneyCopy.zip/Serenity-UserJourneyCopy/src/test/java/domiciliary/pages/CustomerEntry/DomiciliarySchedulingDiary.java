package domiciliary.pages.CustomerEntry;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliarySchedulingDiary extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliarySchedulingDiary.class);
    protected TestDataManager testDataManager = new TestDataManager();

    //Banner Selection
    @FindBy(xpath = "//button[.='Previous']")
    private WebElementFacade previousWeekButton;
    @FindBy(xpath = "//button[.='Next']")
    private WebElementFacade nextWeekButton;
    @FindBy(xpath = "//button[@data-reveal-id='optomModal']")
    private WebElementFacade optometristSelectedButton;
    @FindBy(xpath = "//button[contains(text(),'Submit')]")
    private WebElementFacade submitOptometristSelectedButton;

    public void clickPreviousWeekButton(){
        clickElement(previousWeekButton);
    }
    public void clickNextWeekButton(){clickElement(nextWeekButton);}
    public void clickOptometristSelectedButton(){clickElement(optometristSelectedButton);}
    public void clickSubmitOptometristSelectedButton(){clickElement(submitOptometristSelectedButton);}

    //Scheduling TickBoxes
    @FindBy(css = "#visitDate")
    private WebElementFacade visitPopupDateTextBox;
    public void clickVisitInSchedulingDiary(String surname) {
        String xpath = "//div[contains(text(),'HV-Automation-Patient-" + surname + "')]";
        clickElement(findFirst(xpath).get());
        waitABit(6000);
    }
    public void clickTheAutomationOptometristBot1TickBoxDiary(){
        this.clickOptometristTickBoxDiary("1-Automation-Optometrist OO-Automation-Bot1");
    }
    public void clickOptometristTickBoxDiary(String optomName) {
        String xpath = "//span[.='" + optomName + "']/../following-sibling::div[1]/input[contains(@id, 'optomFilterCheck')]";
        clickElement(element(By.xpath(xpath)));
    }
    public void assertVisitDateIsCorrect(String date) {
        assertElementValue(visitPopupDateTextBox, date);
    }
}
