package domiciliary.pages.CoreApplication.Popups.ContactPopup;

import Framework.DataManager.TestDataManager;
import domiciliary.extentions.DomiciliaryCommonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DefaultUrl("page:domiciliary.GVLoggedIn.url")
public class DomiciliaryOptometristDiaryEntriesPopupPage extends DomiciliaryCommonPage {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryOptometristDiaryEntriesPopupPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//table[@id='tblContent']/tbody/tr[@id='r1']/td[@onclick]/span")
    private WebElementFacade firstDiaryEntryDate;

    public void isFirstDiaryEntryDateCorrect(String date) {
        assertElementText(firstDiaryEntryDate, date + " 00:00:00");
    }


}
