package domiciliary.tests.Navigation;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_NAVIGATION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")

@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryNavigationToolsTabTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void goToHomePage() {
        domiciliary.openHomePage();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675138", projectId = "110919", testCaseName = "GV7 Tools Tab: Reporting.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsReporting() {
        domiciliary.navigateToToolsReporting();
        domiciliary.assertReportingSubTabsArePresent();
    }
    @DOMICILIARY_SMOKE
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675139", projectId = "110919", testCaseName = "GV7 Tools Tab: Patient Signature Capture User Management.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsPatientSignatureCaptureUserManagement() {
        domiciliary.navigateToToolsPatientSignatureCaptureUserManagement();
        domiciliary.switchTabsAndAssertCorrectURL("https://patientsignaturecaptureadmin-uat.healthcalloptical.co.uk/ui/user");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675140", projectId = "110919", testCaseName = "GV7 Tools Tab: Recent Events.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsRecentEvents() {
        domiciliary.navigateToToolsRecentEvents();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675141", projectId = "110919", testCaseName = "GV7 Tools Tab: Scheduling- Diary Entries.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSchedulingDiaryEntries() {
        domiciliary.navigateToToolsSchedulingDiaryEntries();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675142", projectId = "110919", testCaseName = "GV7 Tools Tab: Home Visit Appointment Letter Batch Printing.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsHomeVisitAppointmentLetterBatchPrinting() {
        domiciliary.navigateToToolsHomeVisitAppointmentLetterBatchPrinting();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675143", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Email.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSearchEmail() {
        domiciliary.navigateToToolsSearchEmail();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675144", projectId = "110919", testCaseName = "GV7 Tools Tab: Scheduling- Diary Entries- Assigned Sub Territories. ", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories() {
        domiciliary.navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675145", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Attachments.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSearchAttachments() {
        domiciliary.navigateToToolsSearchAttachments();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675146", projectId = "110919", testCaseName = "GV7 Tools Tab: Scheduling- Availability.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSchedulingAvailability() {
        domiciliary.navigateToToolsSchedulingAvailability();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Scheduling - Availability");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675147", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Notes.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSearchNotes() {
        domiciliary.navigateToToolsSearchNotes();
        domiciliary.switchTabsAndAssertSearchNotesTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675148", projectId = "110919", testCaseName = "GV7 Tools Tab: Scheduling- Diary.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSchedulingDiary() {
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Scheduling - Diary");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675149", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Notes- Notice Board.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSearchNotesNoticeBoard() {
        domiciliary.navigateToToolsSearchNotesNoticeBoard();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675150", projectId = "110919", testCaseName = "GV7 Tools Tab: Customer Entry.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsCustomerEntry() {
        domiciliary.navigateToToolsCustomerEntry();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Specsavers Customer Entry");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675151", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Documents.", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void navigateToToolsSearchDocuments() {
        domiciliary.navigateToToolsSearchDocuments();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675152", projectId = "110919", testCaseName = "GV7 Tools Tab: Bulk Documents Creation.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsBulkDocumentsCreation() {
        domiciliary.navigateToToolsBulkDocumentsCreation();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Specsavers ROI Document Production");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675153", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Calls.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSearchCalls() {
        domiciliary.navigateToToolsSearchCalls();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675154", projectId = "110919", testCaseName = "GV7 Tools Tab: Search Links.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsSearchLinks() {
        domiciliary.navigateToToolsSearchLinks();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675155", projectId = "110919", testCaseName = "GV7 Tools Tab: Administration.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToToolsAdministration() {
        domiciliary.navigateToToolsAdministration();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Gold-Vision Administration Console");
    }
}
