package domiciliary.tests.TestDataPrep;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_DIARYPREP;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")

@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliarySchedulingAvailabilityPrep {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void openHomePage() {domiciliary.openHomePage();}

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_DIARYPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Populate Optometrist Sub Territory (X weeks)", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void populateOptometristSubTerritoryForXWeeks() {
        domiciliary.goToCorrectLoginURL();
        domiciliary.navigateToToolsSchedulingAvailability();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickOptometristTickBoxAvailability("1-Automation-Optometrist OO-Automation-Bot1");
        domiciliary.clickTheSubmitOptometristSelectedButtonInScheduling();
        for(int i = 0; i < 8; i++) {
            domiciliary.assignDaysAsAvailableForCurrentWeek();
            domiciliary.fillInAvailabilityForCurrentWeek();
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DIARYPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Populate Optometrist Sub Territory (X weeks)", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void populateOptometristSubTerritoryForXWeeksScotland() {
        domiciliary.navigateToToolsSchedulingAvailability();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickOptometristTickBoxAvailability("5-Automation-Optometrist OO-Automation-Scotland");
        domiciliary.clickTheSubmitOptometristSelectedButtonInScheduling();
        domiciliary.switchToNextTab();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickOptometristTickBoxAvailability("5-Automation-Optometrist OO-Automation-Scotland");
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        domiciliary.switchToNextTab();
        for(int i = 0; i < 8; i++) {
            domiciliary.assignDaysAsAvailableForCurrentWeek();
            domiciliary.switchToOriginalTab();
            domiciliary.switchToNextTab();
            domiciliary.getDaySubTerritoryStatus("Glasgow 057-7");
            domiciliary.switchToNextTab();
            domiciliary.fillInAvailabilityForCurrentWeekScotland();
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DIARYPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Populate Optometrist Sub Territory (X weeks)", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void populateOptometristSubTerritoryForXWeeksWales() {
        domiciliary.navigateToToolsSchedulingAvailability();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickOptometristTickBoxAvailability("6-Automation-Optometrist OO-Automation-Wales");
        domiciliary.clickTheSubmitOptometristSelectedButtonInScheduling();
        domiciliary.switchToNextTab();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickOptometristTickBoxAvailability("6-Automation-Optometrist OO-Automation-Wales");
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        domiciliary.switchToNextTab();
        for(int i = 0; i < 8; i++) {
            domiciliary.assignDaysAsAvailableForCurrentWeek();
            domiciliary.switchToOriginalTab();
            domiciliary.switchToNextTab();
            domiciliary.getDaySubTerritoryStatus("Clwyd-5");
            domiciliary.switchToNextTab();
            domiciliary.fillInAvailabilityForCurrentWeekWales();
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DIARYPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Populate Optometrist Sub Territory (X weeks)", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void populateOptometristSubTerritoryForXWeeksNorthernIreland() {
        domiciliary.navigateToToolsSchedulingAvailability();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickOptometristTickBoxAvailability("7-Automation-Optometrist OO-Automation-NI");
        domiciliary.clickTheSubmitOptometristSelectedButtonInScheduling();
        domiciliary.switchToNextTab();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickOptometristTickBoxAvailability("7-Automation-Optometrist OO-Automation-NI");
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        domiciliary.switchToNextTab();
        for(int i = 0; i < 8; i++) {
            domiciliary.assignDaysAsAvailableForCurrentWeek();
            domiciliary.switchToOriginalTab();
            domiciliary.switchToNextTab();
            domiciliary.getDaySubTerritoryStatus("Belfast-2");
            domiciliary.switchToNextTab();
            domiciliary.fillInAvailabilityForCurrentWeekNorthernIreland();
        }
    }
}
