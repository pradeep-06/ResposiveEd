package domiciliary.tests.CustomerEntry;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.extentions.DomiciliaryHelpers;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryCustomerEntryTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    DomiciliaryStepDefinitions domiciliary;

    String randomSurname;
    String randomDateOfBirth;
    String randomDateOfLastSightTest;
    String firstDiaryEntryDate;
    String visitDate;


    @BeforeEach
    public void openCustomerEntry() {
        domiciliary.openCustomerEntry();
    }

    @BeforeEach
    public void generateStrings() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        firstDiaryEntryDate = DomiciliaryHelpers.getDiaryEntriesDate();
        visitDate = DomiciliaryHelpers.getVisitDateXDaysAhead(7);
    }


    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546382", projectId = "110919", testCaseName = "Create New Patient & Add Visit", testType = SSTestType.SMOKE, testCaseVersion = "0.1")
    public void createAPatientAndAddAVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHomeVisitNewButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43533217", projectId = "110919", testCaseName = "Create New Patient & Add Visit - Scotland", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void createAPatientAndAddAVisitThroughCEPForScotland() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientForScotland("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHomeVisitNewButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptom5InOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickOptometristTickBoxAvailability("5-Automation-Optometrist OO-Automation-Scotland");
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43533293", projectId = "110919", testCaseName = "Create New Patient & Add Visit - Wales", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void createAPatientAndAddAVisitThroughCEPForWales() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientForWales("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHomeVisitNewButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptom6InOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickOptometristTickBoxAvailability("6-Automation-Optometrist OO-Automation-Wales");
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43533470", projectId = "110919", testCaseName = "Create New Patient & Add Visit - Northern Ireland", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void createAPatientAndAddAVisitThroughCEPForNorthernIreland() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientForNorthernIreland("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHomeVisitNewButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptom7InOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickOptometristTickBoxAvailability("7-Automation-Optometrist OO-Automation-NI");
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);

    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42635205", projectId = "110919", testCaseName = "Create New Patient & Add Care Home Visit", testType = SSTestType.SMOKE, testCaseVersion = "8.0")
    public void createAPatientAndAddACareHomeVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownCareHomeVisitButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546384", projectId = "110919", testCaseName = "Create New Patient & Add Existing Home Visit", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void createAPatientAndAddAExistingHomeVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHomeVisitExistingButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546658", projectId = "110919", testCaseName = "Create New Patient & Add Retest Visit", testType = SSTestType.SMOKE, testCaseVersion = "8.0")
    public void createAPatientAndAddARetestVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownRetestButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546660", projectId = "110919", testCaseName = "Create New Patient & Add Corporate Eyecare Visit", testType = SSTestType.SMOKE, testCaseVersion = "8.0")
    public void createAPatientAndAddACorporateEyecareVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownCorporateEyecareButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546659", projectId = "110919", testCaseName = "Create New Patient & Add Care Home Visit", testType = SSTestType.SMOKE, testCaseVersion = "8.0")
    public void createAPatientAndAddAPrisonVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownPrisonVisitButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546663", projectId = "110919", testCaseName = "Create New Patient & Add Hospital Visit", testType = SSTestType.SMOKE, testCaseVersion = "8.0")
    public void createAPatientAndAddAHospitalVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHospitalVisitButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43546666", projectId = "110919", testCaseName = "Create New Patient & Add Private Test Visit", testType = SSTestType.SMOKE, testCaseVersion = "8.0")
    public void createAPatientAndAddAPrivateTestVisitThroughCEP() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient(randomSurname);
        domiciliary.clickPatientSelectButton(randomSurname);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownPrivateSightTestButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.enterDateIntoVisitDateTextBox(visitDate);
        domiciliary.clickAutomationOptomInOptometristDropDown();
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInScheduling();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit();
        domiciliary.clickTheNextWeekButtonInScheduling();
        domiciliary.clickVisitInSchedulingDiary(randomSurname, visitDate);
    }


    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42662510", projectId = "110919", testCaseName = "Create New Optometrist", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void createAnOptometristAndPopulateDiaryEntries() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinueOptometrist( "Automation-Optom-" + randomSurname, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Optom-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Optom-" + randomSurname);
        domiciliary.switchToRecordPopUp();
        domiciliary.clickVenueDetailsButton();
        domiciliary.clickRecordEditButton();
        domiciliary.changeVenueDetailsForOptometrist("OO-Automation-Optom-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickRecordCloseButton();
        domiciliary.switchBackToGoldvision();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("OO-Automation-Optom-" + randomSurname);
        domiciliary.clickPrimaryContactInPrimaryContactColumnVenuesPage("Automation-Optom Automation-Optom-" + randomSurname);
        domiciliary.switchToRecordPopUp();
        domiciliary.clickRecordEditButton();
        domiciliary.changePrimaryContactDetailsForOptometrist();
        domiciliary.clickRecordSaveButton();
        domiciliary.navigateToOptometristInfo();
        domiciliary.clickRecordEditButton();
        domiciliary.tickOptometristInfoTickBoxes();
        domiciliary.clickRecordSaveButton();
        domiciliary.navigateToOptometristDiaryEntriesAndAssertFirstDateIsCorrect(firstDiaryEntryDate);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42662521", projectId = "110919", testCaseName = "Create A Patient", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void createAPatient() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient( "Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewContactsAll();
        domiciliary.enterNameIntoNameColumnAndAssertPatientInListContactsPage("Automation-Patient Automation-Patient-" + randomSurname);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42681556", projectId = "110919", testCaseName = "Search Patient/Venue button - combinations", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void searchPatientVenueCombinations() {
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientSearch(randomDateOfBirth, randomDateOfLastSightTest);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.clickSearchPatientVenueButtonAndSearchForPatient("AutomationSearch PatientVenue");
        domiciliary.clearTextFromSearchPatientVenueTextBoxes();
        domiciliary.searchPatientVenueSearchForVenue("AutomationSearch PatientVenue", "HV-PatientVenue");
        domiciliary.clearTextFromSearchPatientVenueTextBoxes();
        domiciliary.searchPatientVenueSearchForPostcode("M28 1AG");
        domiciliary.clearTextFromSearchPatientVenueTextBoxes();
        domiciliary.searchPatientVenueSearchForPatientAndVenue("AutomationSearch PatientVenue", "HV-PatientVenue");
        domiciliary.clearTextFromSearchPatientVenueTextBoxes();
        domiciliary.searchPatientVenueSearchForPatientAndPostcode("AutomationSearch PatientVenue", "M28 1AG");
        domiciliary.clearTextFromSearchPatientVenueTextBoxes();
        domiciliary.searchPatientVenueSearchForVenueAndPostcode("AutomationSearch PatientVenue", "HV-PatientVenue", "M28 1AG");
        domiciliary.clearTextFromSearchPatientVenueTextBoxes();
        domiciliary.searchPatientVenueSearchForPatientVenueAndPostcode("AutomationSearch PatientVenue", "HV-PatientVenue", "M28 1AG");
        domiciliary.searchPatientVenueClickCancelButton();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-PatientVenue");
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-PatientVenue");
        domiciliary.switchToRecordPopUp();
        domiciliary.clickVenueTopLeftDropdownButton();
        domiciliary.clickVenueDeleteRecordOption();
        domiciliary.clickVenuePopUpConfirmButton();
        domiciliary.clickVenueCloseWindowOption();
        domiciliary.switchBackToGoldvision();
        domiciliary.enterVenueNameIntoVenueNameColumnAndAssertTheSearchReturnedNoResultsIsPresentVenuesPage("HV-Venue-" + randomSurname);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43478642", projectId = "110919", testCaseName = "Create A Patient: Mx & Not Specified", testType = SSTestType.SMOKE, testCaseVersion = "3.0")
    public void createAPatientMxAndNotSpecified() {
        domiciliary.fillInAllMandatoryFieldsAndMxAndNotSpecifiedAndClickContinuePatient( "Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewContactsAll();
        domiciliary.enterNameIntoNameColumnAndAssertPatientInListContactsPage("Automation-Patient Automation-Patient-" + randomSurname);
        domiciliary.clickNameInNameColumnContactsPage("Automation-Patient Automation-Patient-" + randomSurname);
        domiciliary.switchToNextTab();
        domiciliary.navigateToAdditionalInfo();
        domiciliary.verifyTitleIs("Mx");
        domiciliary.verifyGenderIsNotSpecified("Not Specified");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "43478643", projectId = "110919", testCaseName = "Create A Patient: Mx & Neutral", testType = SSTestType.SMOKE, testCaseVersion = "3.0")
    public void createAPatientMxAndNeutral() {
        domiciliary.fillInAllMandatoryFieldsAndMxAndNeutralAndClickContinuePatient( "Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewContactsAll();
        domiciliary.enterNameIntoNameColumnAndAssertPatientInListContactsPage("Automation-Patient Automation-Patient-" + randomSurname);
        domiciliary.clickNameInNameColumnContactsPage("Automation-Patient Automation-Patient-" + randomSurname);
        domiciliary.switchToNextTab();
        domiciliary.navigateToAdditionalInfo();
        domiciliary.verifyTitleIs("Mx");
        domiciliary.verifyGenderIsNeutral("Neutral");
    }
}
