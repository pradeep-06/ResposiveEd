package domiciliary.tests.Navigation;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_NAVIGATION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")

@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryNavigationHelpTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void goToHomePage() {
        domiciliary.openHomePage();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675157", projectId = "110919", testCaseName = "GV7 Help Tab: Online Help.", testType = SSTestType.SMOKE, testCaseVersion = "3.0")
    public void navigateToHelpOnlineHelp() {
        domiciliary.navigateToHelpOnlineHelp();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Gold-Vision Help");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675158", projectId = "110919", testCaseName = "GV7 Help Tab: Support Enquiry.", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void navigateToHelpSupportEnquiry() {
        domiciliary.navigateToHelpSupportEnquiry();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Homepage - Gold Vision Help Centre");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675159", projectId = "110919", testCaseName = "GV7 Help Tab: Gold Vision Admins.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToHelpGoldVisionAdmins() {
        domiciliary.navigateToHelpGoldVisionAdminsAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675160", projectId = "110919", testCaseName = "GV7 Help Tab: Remote Assist.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToHelpRemoteAssist() {
        domiciliary.navigateToHelpRemoteAssist();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Gold-Vision Help");
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675161", projectId = "110919", testCaseName = "GV7 Help Tab: Chat with Support.", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void navigateToHelpChatWithSupport() {
        domiciliary.navigateToHelpChatWithSupport();
        domiciliary.switchTabsAndAssertCorrectPageTitle("Chat with Gold-Vision Support");
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675162", projectId = "110919", testCaseName = "GV7 Help Tab: About.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToHelpAbout() {
        domiciliary.navigateToHelpAbout();
        domiciliary.switchTabsAndAssertCorrectPageTitle("About - Gold-Vision");
    }

}
