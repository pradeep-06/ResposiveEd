package domiciliary.tests.Venues;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.extentions.DomiciliaryHelpers;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")
@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryVenueTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void goToHomePage() {
        domiciliary.openHomePage();
    }

    String randomSurname;
    String randomDateOfBirth;
    String randomDateOfLastSightTest;
    String firstDiaryEntryDate;
    @BeforeEach
    public void generateRandomStrings() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42677452", projectId = "110919", testCaseName = "Create Venue: Through Customer Entry", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void createAVenueThroughCE() {
        domiciliary.navigateToToolsCustomerEntry();
        domiciliary.switchToNextTab();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinueVenue(randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.switchToOriginalTab();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterPrimaryContactNameIntoPrimaryContactColumnAndAssertVenueNameAndPrimaryContactAreCorrectVenuesPage("Automation-Patient Venue-" + randomSurname, "HV-Venue-" + randomSurname);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42677453", projectId = "110919", testCaseName = "Delete Venue", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void deleteAVenue() {
        domiciliary.navigateToToolsCustomerEntry();
        domiciliary.switchToNextTab();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinueVenue(randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.switchToOriginalTab();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-Venue-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Venue-" + randomSurname);
        domiciliary.switchToRecordPopUp();
        domiciliary.clickVenueTopLeftDropdownButton();
        domiciliary.clickVenueDeleteRecordOption();
        domiciliary.clickVenuePopUpConfirmButton();
        domiciliary.clickVenueCloseWindowOption();
        domiciliary.switchBackToGoldvision();
        domiciliary.enterVenueNameIntoVenueNameColumnAndAssertTheSearchReturnedNoResultsIsPresentVenuesPage("HV-Venue-" + randomSurname);
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42677454", projectId = "110919", testCaseName = "Rename Venue", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void renameAVenue() {
        domiciliary.navigateToToolsCustomerEntry();
        domiciliary.switchToNextTab();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinueVenue(randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.switchToOriginalTab();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterPrimaryContactNameIntoPrimaryContactColumnVenuesPage("Automation-Patient Venue-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Venue-" + randomSurname);
        domiciliary.switchToNextTab();
        domiciliary.clickRecordEditButton();
        domiciliary.enterTextIntoVenueName("AV-Automation-Patient-VenueRenameTest-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickRecordCloseButton();
        domiciliary.switchToOriginalTab();
        domiciliary.enterVenueNameIntoVenueNameColumnAndAssertTheVenueIsPresentVenuesPage("AV-Automation-Patient-VenueRenameTest-" + randomSurname);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42716383", projectId = "110919", testCaseName = "Make a Venue Dormant and Reactivate", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void makeAVenueDormantAndReactivate() {
        domiciliary.navigateToToolsCustomerEntry();
        domiciliary.switchToNextTab();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinueVenue(randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.switchToOriginalTab();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterPrimaryContactNameIntoPrimaryContactColumnVenuesPage("Automation-Patient Venue-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Venue-" + randomSurname);
        domiciliary.switchToNextTab();
        domiciliary.clickRecordEditButton();
        domiciliary.enterTextIntoVenueName("AV-Automation-Patient-VenueDormantTest-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickVenueTopLeftDropdownButton();
        domiciliary.clickVenueMakeRecordDormantOption();
        domiciliary.clickVenuePopUpConfirmButton();
        domiciliary.clickVenueCloseWindowOption();
        domiciliary.switchToOriginalTab();
        domiciliary.enterVenueNameIntoVenueNameColumnAndAssertTheSearchReturnedNoResultsIsPresentVenuesPage("AV-Automation-Patient-VenueDormantTest-" + randomSurname);
        domiciliary.navigateToViewVenuesDormant();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("AV-Automation-Patient-VenueDormantTest-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("AV-Automation-Patient-VenueDormantTest-" + randomSurname);
        domiciliary.clickVenuePopUpConfirmButton();
        domiciliary.switchToNextTab();
        domiciliary.clickRecordCloseButton();
        domiciliary.switchBackToGoldvision();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnAndAssertTheVenueIsPresentVenuesPage("AV-Automation-Patient-VenueDormantTest-" + randomSurname);
    }
}
