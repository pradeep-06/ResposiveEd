package domiciliary.tests.Login;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")
@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryLoginTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42582098", projectId = "110919", testCaseName = "Login to Gold Vision Service - automation", testType = SSTestType.SMOKE, testCaseVersion = "2.0")
    public void loginToGoldVisionService() {
//        //Username wrong, password wrong - won't log in
//        domiciliary.goToIncorrectLoginURLUsernameAndPasswordWrong();
//        //Username wrong, password correct - won't log in
//        domiciliary.goToIncorrectLoginURLUsernameWrong();
//        //Username correct, password wrong - won't log in
//        domiciliary.goToIncorrectLoginURLPasswordWrong();
        //Username and password correct - will log in
        domiciliary.goToCorrectLoginURL();
    }


}
