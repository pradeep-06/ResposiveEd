package domiciliary.tests.TestDataPrep;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_DATAPREP;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import Framework.extensions.StafUtils;
import domiciliary.extentions.DomiciliaryHelpers;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")
@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryCEPrep {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    String randomSurname;
    String randomDateOfBirth;
    String randomDateOfLastSightTest;
    String visitDate;
    String optomName;
    String venueName;

    @BeforeEach
    public void login() {
        domiciliary.goToCorrectLoginURL();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    public void createPatientAndVisitWithPicker(String optomName, String amPm, int amountOfDaysAhead) {
        visitDate = DomiciliaryHelpers.getVisitDateXDaysAhead(amountOfDaysAhead);
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsPatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickCreateNewVisitRadioButton();
        domiciliary.clickVisitTypeDropDownHomeVisitNewButton();
        domiciliary.clickAnytimeCheckBox();
        domiciliary.clickVisitTimeslotPicker();
        domiciliary.chooseAppointmentTimeslot(optomName, visitDate, amPm);
        domiciliary.clickContinueButton();
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
    }
    public void createHomeVisitPatientAndVenue() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Home Visit Patient/Venue"}});
    }
    public void createHomeVisitPatientAndVenueUnder16() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = "12/12/2010";
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Home Visit Patient/Venue Under 16"}});
    }
    public void createHomeVisitVenueWith2Patients() {
        domiciliary.openCustomerEntry();
        for (int i=0;i<2;i++) {
            randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
            randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
            domiciliary.clickDataProcessingConsentYesRadioButton();
            domiciliary.completeGDPRAllYesAndSave();
            domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            if (i==0) {
                domiciliary.clickAddNewPatientButton();
                venueName = randomSurname;
            }
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, venueName, randomDateOfBirth, "N/A", "Home Visit Venue with 2 patients"}});
        }
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
    }
    public void createHomeVisitVenueWith3Patients() {
        domiciliary.openCustomerEntry();
        for (int i=0;i<3;i++) {
            randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
            randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
            domiciliary.clickDataProcessingConsentYesRadioButton();
            domiciliary.completeGDPRAllYesAndSave();
            domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            if (i<2) {
                domiciliary.clickAddNewPatientButton();
                venueName = randomSurname;
            }
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, venueName, randomDateOfBirth, "N/A", "Home Visit Venue with 3 patients"}});
        }
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
    }
    public void createCareHomePatientAndVenue() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordEditButton();
        domiciliary.changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickRecordCloseButton();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Care Home Patient/Venue"}});
    }
    public void createCareHomePatientAndVenueWithPrimaryContact() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAlternativeContactInformationForCareHomeVenueManager(randomSurname);
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordEditButton();
        domiciliary.changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickRecordCloseButton();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Care Home Patient/Venue with Primary Contact"}});
    }
    public void createHomeVisitPatientAndVenueWithPrimaryContact() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAlternativeContactInformationForHomeVisitPrimaryContact(randomSurname);
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Home Visit Patient/Venue with Primary Contact"}});
    }
    public void createCareHomeVenueWith3Patients() {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<3; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createCareHomeVenueWithPatients(surnames, "3");
    }
    public void createCareHomeVenueWith3PatientsAndVenueManager() {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<3; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, surnames.get(0), "N/A", "Care Home Venue with 3 patients and venue manager"}});
        }
        domiciliary.createCareHomeVenueWithPatientsAndVenueManager(surnames, "3");
    }
    public void createCareHomeVenueWith10Patients() {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<10; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, surnames.get(0), "N/A", "Care Home Venue with 10 patients"}});
        }
        domiciliary.createCareHomeVenueWithPatients(surnames, "10");
    }
    public void createHospitalVenue() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordEditButton();
        domiciliary.changeVenueDetailsForHospital("Hospital-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickRecordCloseButton();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Hospital Venue"}});
    }
    public void createPrisonVenue() {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        domiciliary.openCustomerEntry();
        domiciliary.fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + randomSurname, randomDateOfLastSightTest, randomDateOfBirth);
        domiciliary.clickDataProcessingConsentYesRadioButton();
        domiciliary.completeGDPRAllYesAndSave();
        domiciliary.clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        domiciliary.clickFinishButton();
        domiciliary.clickDetailsSavedSuccessfullyContinueToFinish();
        domiciliary.navigateToViewVenuesAll();
        domiciliary.enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordEditButton();
        domiciliary.changeVenueDetailsForPrison("Prison-Automation-Patient-" + randomSurname);
        domiciliary.clickRecordSaveButton();
        domiciliary.clickRecordCloseButton();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, "N/A", "Prison Venue"}});
    }

    public void createCareHomeVisitFor1Patient(String optomName) {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        domiciliary.createCareHomeVisitFor1Patient(randomSurname, optomName);
    }
    public void createCareHomeVisitFor2Patients(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<2; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createCareHomeVisitFor2Patients(surnames, optomName);
    }
    public void createCareHomeVisitFor3Patients(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<3; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createCareHomeVisitFor3Patients(surnames, optomName);
    }
    public void createCareHomeVisitFor10Patients(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<10; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createCareHomeVisitFor10Patients(surnames, optomName);
    }

    public void createCareHomeVisitFor2PatientsInvalidDateOfBirth(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<2; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createCareHomeVisitFor2PatientsInvalidDateOfBirth(surnames, optomName);
    }
    public void createHomeVisitFor1Patient(String optomName) {
        visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        domiciliary.createHomeVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, optomName);
    }
    public void createHomeVisitFor2Patients(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<2; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createHomeVisitFor2Patients(surnames, optomName);
    }
    public void createHomeVisitFor3Patients(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<3; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createHomeVisitFor3Patients(surnames, optomName);
    }
    public void createHomeVisitFor5Patients(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<5; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createHomeVisitFor5Patients(surnames, optomName);
    }
    public void create5HomeVisitsForSameVenue1WeekAhead(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<5; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        domiciliary.createHomeVisitsForPatientsInSameVenue(surnames, optomName, "5");
    }

    public void createRetestVisitFor1Patient(String optomName) {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        domiciliary.createRetestVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, optomName);
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, visitDate, "Retest Visit for 1 patient"}});
    }
    public void createHomeVisitFor1PatientWithSpecialCharacter(String optomName) {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6) + "@";
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        domiciliary.createHomeVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, optomName);
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, visitDate, "Home Visit for 1 patient - special character in name"}});
    }
    public void create2HomeVisitsFor1Patient1AWeekAhead(String optomName) {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        domiciliary.createHomeVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, optomName);
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, visitDate, "2 Home Visits for 1 patient - 1 a week ahead"}});
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        visitDate = DomiciliaryHelpers.getVisitDateXDaysAhead(7);
        domiciliary.createHomeVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, optomName);
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{randomSurname, randomSurname, randomDateOfBirth, visitDate, "2 Home Visits for 1 patient - 1 a week ahead"}});
    }
    public void create2HomeVisitsFor1Patient1AWeekAheadDifferentOptoms(String firstOptomName, String secondOptomName) {
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        domiciliary.createHomeVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, firstOptomName);
        randomSurname = DomiciliaryHelpers.generateRandomSurname(6);
        randomDateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        randomDateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        visitDate = DomiciliaryHelpers.getVisitDateXDaysAhead(7);
        domiciliary.createHomeVisitFor1Patient(randomSurname, randomDateOfLastSightTest, randomDateOfBirth, visitDate, secondOptomName);
    }
    public void create2CareHomeVisitsFor5Patients4WeeksAnd5WeeksAhead(String optomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<5; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        visitDate = DomiciliaryHelpers.getVisitDateWith4WeeksNotice();
        domiciliary.createCareHomeVisitFor5Patients(surnames, optomName, visitDate);
        for (int i = 0; i<5; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        visitDate = DomiciliaryHelpers.getVisitDateWith5WeeksNotice();
        domiciliary.createCareHomeVisitFor5Patients(surnames, optomName, visitDate);
    }
    public void create2CareHomeVisitsFor5Patients4WeeksAnd5WeeksAheadDifferentOptoms(String firstOptomName, String secondOptomName) {
        List<String> surnames = new ArrayList<>();
        for (int i = 0; i<5; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        visitDate = DomiciliaryHelpers.getVisitDateWith4WeeksNotice();
        domiciliary.createCareHomeVisitFor5Patients(surnames, firstOptomName, visitDate);
        for (int i = 0; i<5; i++) {
            surnames.add(DomiciliaryHelpers.generateRandomSurname(6));
        }
        visitDate = DomiciliaryHelpers.getVisitDateWith5WeeksNotice();
        domiciliary.createCareHomeVisitFor5Patients(surnames, secondOptomName, visitDate);
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create HV patients and venues (under 16)", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHVPatientsAndVenuesUnder16() {
        createHomeVisitPatientAndVenueUnder16();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create HV patients and venues", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHVPatientsAndVenues() {
        for (int i=0;i<25;i++) {
            createHomeVisitPatientAndVenue();
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH patients and venues", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHPatientsAndVenues() {
        for (int i=0;i<5;i++) {
            createCareHomePatientAndVenue();
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH patients and venues with primary contact", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHPatientsAndVenuesWithPrimaryContact() {
        createCareHomePatientAndVenueWithPrimaryContact();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH visits - 2 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHVisits2Patients() {
        createCareHomeVisitFor2Patients("1-Automation");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create home visits - 2 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHomeVisits2Patients() {
        for (int i=0;i<3;i++) {
            createHomeVisitFor2Patients("1-Automation");
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create home visits - 5 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHomeVisits5Patients() {
        createHomeVisitFor5Patients("1-Automation");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH visits - 1 patient", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHVisits1Patient() {
        createCareHomeVisitFor1Patient("1-Automation");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH visits - 3 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHVisits3Patients() {
        createCareHomeVisitFor3Patients("1-Automation");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH visits - 10 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHVisits10Patients() {
        for (int i=0;i<2;i++) {
            createCareHomeVisitFor10Patients("1-Automation");
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create CH venues - 3 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHVenues3Patients() {
        createCareHomeVenueWith3Patients();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create HV venues - 2 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHVVenues2Patients() {
        createHomeVisitVenueWith2Patients();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create 2 home visits - 1 patient, 1 a week ahead", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void create2HV1Patient1AWeekAhead() {
        create2HomeVisitsFor1Patient1AWeekAhead("1-Automation");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create hospital venues", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHospitalVenues() {
        createHospitalVenue();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create prison venues", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createPrisonVenues() {
        createPrisonVenue();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create home visits - 1 patient", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHomeVisits1Patient() {
        for (int i=0;i<40;i++) {
            createHomeVisitFor1Patient("1-Automation");
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create HV patients and venues with primary contact", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHVPatientsAndVenuesWithPrimaryContact() {
        for (int i=0;i<2;i++) {
            createHomeVisitPatientAndVenueWithPrimaryContact();
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create 5 home visits - same venue a week ahead", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void create5HVSameVenueAWeekAhead() {
        for (int i=0;i<2;i++) {
            create5HomeVisitsForSameVenue1WeekAhead("1-Automation");
        }
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create care home venues - 3 patients and venue manager", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createCHVenue3PatientsAndVenueManager() {
        createCareHomeVenueWith3PatientsAndVenueManager();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_DATAPREP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Create home visit venues - 3 patients", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void createHVVenue3Patients() {
        createHomeVisitVenueWith3Patients();
    }




}
