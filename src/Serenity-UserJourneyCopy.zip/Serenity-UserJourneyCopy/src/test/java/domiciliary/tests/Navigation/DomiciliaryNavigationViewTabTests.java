package domiciliary.tests.Navigation;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_NAVIGATION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;
import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")
@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryNavigationViewTabTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void goToHomePage() {
        domiciliary.openHomePage();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675120", projectId = "110919", testCaseName = "GV7 View Tab: Contacts- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewContactsAll() {
        domiciliary.navigateToViewContactsAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675121", projectId = "110919", testCaseName = "GV7 View Tab: Venues- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewVenuesAll() {
        domiciliary.navigateToViewVenuesAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675122", projectId = "110919", testCaseName = "GV7 View Tab: Campaigns- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewCampaignsAll() {
        domiciliary.navigateToViewCampaignsAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675123", projectId = "110919", testCaseName = "GV7 View Tab: Appointments- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewAppointmentsAll() {
        domiciliary.navigateToViewAppointmentsAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675124", projectId = "110919", testCaseName = "GV7 View Tab: Seminars- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewSeminarsAll() {
        domiciliary.navigateToViewSeminarsAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675125", projectId = "110919", testCaseName = "GV7 View Tab: Actions- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewActionsAll() {
        domiciliary.navigateToViewActionsAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675126", projectId = "110919", testCaseName = "GV7 View Tab: Users- Users List.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewUsersUsersList() {
        domiciliary.navigateToViewUsersUsersList();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675127", projectId = "110919", testCaseName = "GV7 View Tab: Dispenses- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewDispensesAll() {
        domiciliary.navigateToViewDispensesAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675128", projectId = "110919", testCaseName = "GV7 View Tab: Sales- Sales.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewSalesSales() {
        domiciliary.navigateToViewSalesSales();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675129", projectId = "110919", testCaseName = "GV7 View Tab: Acuitas Feeds- Acuitas Patient Import.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewAcuitasFeedsAcuitasPatientImport() {
        domiciliary.navigateToViewAcuitasFeedsAcuitasPatientImport();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675130", projectId = "110919", testCaseName = "GV7 View Tab: Opportunities- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewOpportunitiesAll() {
        domiciliary.navigateToViewOpportunitiesAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675131", projectId = "110919", testCaseName = "GV7 View Tab: Care Home Penetration.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewCareHomePenetration() {
        domiciliary.navigateToViewCareHomePenetration();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675132", projectId = "110919", testCaseName = "GV7 View Tab: Quotes- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewQuotesAll() {
        domiciliary.navigateToViewQuotesAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675133", projectId = "110919", testCaseName = "GV7 View Tab: Home Visit Venues With No Patients.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewHomeVisitVenuesWithNoPatients() {
        domiciliary.navigateToViewHomeVisitVenuesWithNoPatients();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675134", projectId = "110919", testCaseName = "GV7 View Tab: Products- Product List.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewProductsProductList() {
        domiciliary.navigateToViewProductsProductList();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675135", projectId = "110919", testCaseName = "GV7 View Tab: Territories- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewTerritoriesAll() {
        domiciliary.navigateToViewTerritoriesAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675136", projectId = "110919", testCaseName = "GV7 View Tab: Covid- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewCovidAll() {
        domiciliary.navigateToViewCovidAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675137", projectId = "110919", testCaseName = "GV7 View Tab: Visits- All.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewVisitsAll() {
        domiciliary.navigateToViewVisitsAll();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42677069", projectId = "110919", testCaseName = "GV7 View Tab: Venues- Dormant.", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    public void navigateToViewVenuesDormant() {
        domiciliary.navigateToViewVenuesDormant();
    }
}
