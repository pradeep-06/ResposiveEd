package domiciliary.tests.Navigation;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_NAVIGATION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_REGRESSION;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")

@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryNavigationIconsTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;


    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void goToHomePage() {
        domiciliary.openHomePage();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675163", projectId = "110919", testCaseName = "GV7 Contacts icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7ContactsIcon() {
        domiciliary.clickContactsIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675164", projectId = "110919", testCaseName = "GV7 Home icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7HomeIcon() {
        domiciliary.navigateToViewVenuesAll();
        domiciliary.clickHomeIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675165", projectId = "110919", testCaseName = "GV7 Seminars icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7SeminarsIcon() {
        domiciliary.clickSeminarsIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675166", projectId = "110919", testCaseName = "GV7 Appointments icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.9")
    public void GV7AppointmentsIcon() {
        domiciliary.clickAppointmentsIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675167", projectId = "110919", testCaseName = "GV7 Venues icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.9")
    public void GV7VenuesIcon() {
        domiciliary.clickVenuesIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675168", projectId = "110919", testCaseName = "GV7 Actions icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7ActionsIcon() {
        domiciliary.clickActionsIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675169", projectId = "110919", testCaseName = "GV7 Opportunities icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.8")
    public void GV7OpportunitiesIcon() {
        domiciliary.clickOpportunitiesIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675170", projectId = "110919", testCaseName = "GV7 Quotes icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7QuotesIcon() {
        domiciliary.clickQuotesIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675171", projectId = "110919", testCaseName = "GV7 Covid icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7CovidIcon() {
        domiciliary.clickCovidIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675172", projectId = "110919", testCaseName = "GV7 Visits icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.7")
    public void GV7VisitsIcon() {
        domiciliary.clickVisitsIconAndAssertTabTitleIsPresent();
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_NAVIGATION
    @DOMICILIARY_REGRESSION
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42675173", projectId = "110919", testCaseName = "GV7 Campaigns icon.", testType = SSTestType.SMOKE, testCaseVersion = "0.8")
    public void GV7CampaignsIcon() {
        domiciliary.clickCampaignsIconAndAssertTabTitleIsPresent();
    }




}
