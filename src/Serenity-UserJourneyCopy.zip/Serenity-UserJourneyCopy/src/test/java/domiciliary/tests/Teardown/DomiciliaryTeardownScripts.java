package domiciliary.tests.Teardown;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_TEARDOWN;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")
@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliaryTeardownScripts {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    DomiciliaryStepDefinitions domiciliary;

    String randomSurname;
    String randomDateOfLastSightTest;
    String randomDateOfBirth;

    @BeforeEach
    public void openCustomerEntry() {
        domiciliary.openHomePage();
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    /*@DOMICILIARY_SMOKE
    @DOMICILIARY_TEARDOWN
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Delete all patients with automation tag", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void automationPatientCleanup() {
        int counter = 0;
        domiciliary.navigateToViewContactsAll();
        domiciliary.switchToIFrameWithID("IFrame1");
        domiciliary.enterTextIntoDataSearchColumn1("Automation-Patient");
        while (!domiciliary.assertTheSearchReturnedNoResultsIsPresent()) {
            domiciliary.clickFirstInCol1List();
            domiciliary.switchToNextTab();
            domiciliary.deleteCurrentOpenRecord();
            domiciliary.closeCurrentDeletedRecord();
            counter++;
            domiciliary.switchToOriginalTab();
            domiciliary.switchToIFrameWithID("IFrame1");
        }
        System.out.println(counter + " patient records deleted");
    }

    @DOMICILIARY_SMOKE
    @DOMICILIARY_TEARDOWN
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Delete all optometrists with automation tag", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void automationOptometristCleanup() {
        int counter = 0;
        domiciliary.navigateToViewContactsAll();
        domiciliary.switchToIFrameWithID("IFrame1");
        domiciliary.enterTextIntoDataSearchColumn1("Automation-Optom");
        while (!domiciliary.assertTheSearchReturnedNoResultsIsPresent()) {
            domiciliary.clickFirstInCol1List();
            domiciliary.switchToNextTab();
            domiciliary.deleteCurrentOpenRecord();
            domiciliary.closeCurrentDeletedRecord();
            counter++;
            domiciliary.switchToOriginalTab();
            domiciliary.switchToIFrameWithID("IFrame1");
        }
        System.out.println(counter + " optometrist records deleted");
    }
    @DOMICILIARY_SMOKE
    @DOMICILIARY_TEARDOWN
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "Delete all venues with automation tag", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void automationVenueCleanup() {
        int counter = 0;
        domiciliary.navigateToViewVenuesAll();
        domiciliary.switchToIFrameWithID("IFrame1");
        domiciliary.enterTextIntoDataSearchColumn0("HV-Automation-Patient");
        while (!domiciliary.assertTheSearchReturnedNoResultsIsPresent()) {
            domiciliary.clickFirstInCol0List();
            domiciliary.switchToNextTab();
            domiciliary.deleteCurrentOpenRecord();
            domiciliary.closeCurrentDeletedRecord();
            counter++;
            domiciliary.switchToOriginalTab();
            domiciliary.switchToIFrameWithID("IFrame1");
        }
        domiciliary.enterTextIntoDataSearchColumn0("OO-Automation-Optom");
        while (!domiciliary.assertTheSearchReturnedNoResultsIsPresent()) {
            domiciliary.clickFirstInCol0List();
            domiciliary.switchToNextTab();
            domiciliary.deleteCurrentOpenRecord();
            domiciliary.closeCurrentDeletedRecord();
            counter++;
            domiciliary.switchToOriginalTab();
            domiciliary.switchToIFrameWithID("IFrame1");
        }
        domiciliary.enterTextIntoDataSearchColumn0("AV-Automation-Patient");
        while (!domiciliary.assertTheSearchReturnedNoResultsIsPresent()) {
            domiciliary.clickFirstInCol0List();
            domiciliary.switchToNextTab();
            domiciliary.deleteCurrentOpenRecord();
            domiciliary.closeCurrentDeletedRecord();
            counter++;
            domiciliary.switchToOriginalTab();
            domiciliary.switchToIFrameWithID("IFrame1");
        }
        System.out.println(counter + " venue records deleted");
    } */
}
