package domiciliary.tests.TestDataPrep;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_DATAPREP;
import Framework.Annotations.DOMICILIARY.DOMICILIARY_SMOKE;
import domiciliary.stepDefinitions.DomiciliaryStepDefinitions;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@SuppressWarnings("SpellCheckingInspection")

@Tag("domiciliary")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DomiciliarySchedulingDiaryPrep {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    DomiciliaryStepDefinitions domiciliary;

    @BeforeEach
    public void openCustomerEntry() {domiciliary.openHomePage();}

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

    @DOMICILIARY_SMOKE
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "", projectId = "", testCaseName = "View Selected Optometrist Appointments (4 weeks)", testType = SSTestType.SMOKE, testCaseVersion = "")
    public void viewSelectedOptometristAppointmentsForFourWeeks() {
        domiciliary.navigateToToolsSchedulingDiary();
        domiciliary.switchToNextTab();
        domiciliary.clickTheOptometristSelectedButtonInSchedulingDiary();
        domiciliary.clickTheAutomationOptometristBot1TickBoxInSchedulingDiary();
        domiciliary.clickTheSubmitOptometristSelectedButtonInSchedulingDiary();
        for(int i = 0; i < 4; i++) {
            domiciliary.clickTheNextWeekButtonInSchedulingDiary();
        }
    }
}
