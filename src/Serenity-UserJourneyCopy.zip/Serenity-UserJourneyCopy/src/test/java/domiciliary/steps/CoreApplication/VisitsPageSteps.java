package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryVisitsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VisitsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(VisitsPageSteps.class);

    DomiciliaryVisitsPage domiciliaryVisitsPage;

    public void assertVisitsTabTitleIsPresent() {
        domiciliaryVisitsPage.isVisitsTabPresent();
    }
}