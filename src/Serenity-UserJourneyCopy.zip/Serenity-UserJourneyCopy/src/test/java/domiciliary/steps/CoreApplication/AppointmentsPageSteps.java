package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryAppointmentsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppointmentsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(AppointmentsPageSteps.class);

    DomiciliaryAppointmentsPage domiciliaryAppointmentsPage;

    public void assertAppointmentsTabTitleIsPresent() {
        domiciliaryAppointmentsPage.isAppointmentsTabPresent();
    }
}