package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryOpportunitiesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OpportunitiesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(OpportunitiesPageSteps.class);

    DomiciliaryOpportunitiesPage domiciliaryOpportunitiesPage;

    public void assertOpportunitiesTabTitleIsPresent() {
        domiciliaryOpportunitiesPage.isOpportunitiesTabPresent();
    }
}