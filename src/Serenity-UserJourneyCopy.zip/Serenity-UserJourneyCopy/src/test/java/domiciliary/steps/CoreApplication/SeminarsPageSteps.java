package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySeminarsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SeminarsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SeminarsPageSteps.class);

    DomiciliarySeminarsPage domiciliarySeminarsPage;

    public void assertSeminarsTabTitleIsPresent() {
        domiciliarySeminarsPage.isSeminarsTabPresent();
    }
}