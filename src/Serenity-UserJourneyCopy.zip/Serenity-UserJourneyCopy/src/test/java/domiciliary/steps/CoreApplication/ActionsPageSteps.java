package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryActionsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ActionsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(ActionsPageSteps.class);

    DomiciliaryActionsPage domiciliaryActionsPage;

    public void assertActionsTabTitleIsPresent() {
        domiciliaryActionsPage.isActionsTabPresent();
    }
}