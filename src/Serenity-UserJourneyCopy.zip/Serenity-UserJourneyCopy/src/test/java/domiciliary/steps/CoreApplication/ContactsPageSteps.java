package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryContactsPage;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ContactsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(ContactsPageSteps.class);

    DomiciliaryContactsPage domiciliaryContactsPage;

    public void assertContactsTabTitleIsPresent() {
        domiciliaryContactsPage.isContactsTabPresent();
    }

    public void typeTextIntoAndEnterContactNameSearchBox(String contactName) {
        domiciliaryContactsPage.typeTextIntoAndEnterContactNameSearchBox(contactName);
    }

    public void assertSearchResultsTextContains(String text) {
        domiciliaryContactsPage.assertSearchResultsTextContains(text);
    }

    public void assertContactIsInList(String contactName) {
        domiciliaryContactsPage.assertContactIsInList(contactName);
    }

    public void clickOnNameInList(String contactName) {
        domiciliaryContactsPage.clickOnNameInList(contactName);
    }
}