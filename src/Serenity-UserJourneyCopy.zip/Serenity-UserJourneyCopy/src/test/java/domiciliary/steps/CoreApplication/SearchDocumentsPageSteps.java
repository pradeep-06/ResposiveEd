package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchDocumentsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchDocumentsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchDocumentsPageSteps.class);

    DomiciliarySearchDocumentsPage domiciliarySearchDocumentsPage;

    public void assertSearchDocumentsTabTitleIsPresent() {domiciliarySearchDocumentsPage.isSearchDocumentsTabPresent();}
}