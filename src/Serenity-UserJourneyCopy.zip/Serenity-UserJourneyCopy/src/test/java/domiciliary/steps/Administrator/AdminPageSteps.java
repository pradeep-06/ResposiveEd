package domiciliary.steps.Administrator;

import domiciliary.pages.Administrator.DomiciliaryAdminPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class AdminPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(AdminPageSteps.class);
    DomiciliaryAdminPage domiciliaryAdminPage;

    public void openAdmin() {
        domiciliaryAdminPage.open();
    }
}
