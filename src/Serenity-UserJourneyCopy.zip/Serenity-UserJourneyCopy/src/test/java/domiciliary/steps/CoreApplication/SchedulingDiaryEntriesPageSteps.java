package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySchedulingDiaryEntriesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedulingDiaryEntriesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SchedulingDiaryEntriesPageSteps.class);

    DomiciliarySchedulingDiaryEntriesPage domiciliarySchedulingDiaryEntriesPage;

    public void assertSchedulingDiaryEntriesTabTitleIsPresent() {
        domiciliarySchedulingDiaryEntriesPage.isSchedulingDiaryEntriesTabTitlePresent();
    }
}