package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchNotesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchNotesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchNotesPageSteps.class);

    DomiciliarySearchNotesPage domiciliarySearchNotesPage;

    public void assertSearchNotesTabTitleIsPresent() {domiciliarySearchNotesPage.isSearchNotesTabPresent();}
}