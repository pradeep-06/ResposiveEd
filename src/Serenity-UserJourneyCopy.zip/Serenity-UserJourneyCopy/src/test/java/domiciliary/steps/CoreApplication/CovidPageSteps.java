package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryCovidPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CovidPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(CovidPageSteps.class);

    DomiciliaryCovidPage domiciliaryCovidPage;

    public void assertCovidTabTitleIsPresent() {
        domiciliaryCovidPage.isCovidTabPresent();
    }
}