package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryUsersPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UsersPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(UsersPageSteps.class);

    DomiciliaryUsersPage domiciliaryUsersPage;

    public void assertUsersTabTitleIsPresent() {
        domiciliaryUsersPage.isUsersTabPresent();
    }
}