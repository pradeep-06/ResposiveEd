package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchAttachmentsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchAttachmentsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchAttachmentsPageSteps.class);

    DomiciliarySearchAttachmentsPage domiciliarySearchAttachmentsPage;

    public void assertSearchAttachmentsTabTitleIsPresent() {domiciliarySearchAttachmentsPage.isSearchAttachmentsTabPresent();}
}