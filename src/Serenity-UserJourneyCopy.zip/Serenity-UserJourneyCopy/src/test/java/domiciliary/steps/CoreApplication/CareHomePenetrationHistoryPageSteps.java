package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryCareHomePenetrationHistoryPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CareHomePenetrationHistoryPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(CareHomePenetrationHistoryPageSteps.class);

    DomiciliaryCareHomePenetrationHistoryPage domiciliaryCareHomePenetrationHistoryPage;

    public void assertCareHomePenetrationHistoryTabTitleIsPresent() {
        domiciliaryCareHomePenetrationHistoryPage.isCareHomePenetrationHistoryTabPresent();
    }
}