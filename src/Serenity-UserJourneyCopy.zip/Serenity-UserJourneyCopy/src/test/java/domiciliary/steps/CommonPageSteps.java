package domiciliary.steps;

import domiciliary.extentions.DomiciliaryCommonPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CommonPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(CommonPageSteps.class);
    DomiciliaryCommonPage domiciliaryCommonPage;

    //Category options drop down
    public void selectAllFromCategoryDropDown() {
        domiciliaryCommonPage.selectAllFromCategoryDropDown();
    }


    //Navigation

    //Navigation - View drop down

    public void navigateToViewVenuesAll(){
        domiciliaryCommonPage.navigateToViewVenuesAll();
    }
    public void navigateToViewVenuesDormant(){
        domiciliaryCommonPage.navigateToViewVenuesDormant();
    }
    public void navigateToViewContactsAll(){
        domiciliaryCommonPage.navigateToViewContactsAll();
    }
    public void navigateToViewAppointmentsAll() {
        domiciliaryCommonPage.navigateToViewAppointmentsAll();
    }
    public void navigateToViewActionsAll() {
        domiciliaryCommonPage.navigateToViewActionsAll();
    }
    public void navigateToViewSalesSales() {
        domiciliaryCommonPage.navigateToViewSalesSales();
    }
    public void navigateToViewOpportunitiesAll() {
        domiciliaryCommonPage.navigateToViewOpportunitiesAll();
    }
    public void navigateToViewQuotesAll() {
        domiciliaryCommonPage.navigateToViewQuotesAll();
    }
    public void navigateToViewProductsProductList() {
        domiciliaryCommonPage.navigateToViewProductsProductList();
    }
    public void navigateToViewCovidAll() {
        domiciliaryCommonPage.navigateToViewCovidAll();
    }
    public void navigateToViewVisitsAll() {
        domiciliaryCommonPage.navigateToViewVisitsAll();
    }
    public void navigateToViewCampaignsAll() {
        domiciliaryCommonPage.navigateToViewCampaignsAll();
    }
    public void navigateToViewSeminarsAll() {
        domiciliaryCommonPage.navigateToViewSeminarsAll();
    }
    public void navigateToViewUsersUsersList() {
        domiciliaryCommonPage.navigateToViewUsersUsersList();
    }
    public void navigateToViewDispensesAll() {
        domiciliaryCommonPage.navigateToViewDispensesAll();
    }
    public void navigateToViewAcuitasFeedsAcuitasPatientImport() { domiciliaryCommonPage.navigateToViewAcuitasFeedsAcuitasPatientImport(); }
    public void navigateToViewCareHomePenetration() {
        domiciliaryCommonPage.navigateToViewCareHomePenetration();
    }
    public void navigateToViewHomeVisitVenuesWithNoPatients() {
        domiciliaryCommonPage.navigateToViewHomeVisitVenuesWithNoPatients();
    }
    public void navigateToViewTerritoriesAll() {
        domiciliaryCommonPage.navigateToViewTerritoriesAll();
    }

    //Navigation - Tools drop down
    public void navigateToToolsReporting() {domiciliaryCommonPage.navigateToToolsReporting();}
    public void navigateToToolsRecentEvents() {domiciliaryCommonPage.navigateToToolsRecentEvents();}
    public void navigateToToolsSearchEmail() {domiciliaryCommonPage.navigateToToolsSearchEmail();}
    public void navigateToToolsSearchAttachments() {domiciliaryCommonPage.navigateToToolsSearchAttachments();}
    public void navigateToToolsSearchNotes() {domiciliaryCommonPage.navigateToToolsSearchNotes();}
    public void navigateToToolsSearchNotesNoticeBoard() {domiciliaryCommonPage.navigateToToolsSearchNotesNoticeBoard();}
    public void navigateToToolsSearchDocuments() {domiciliaryCommonPage.navigateToToolsSearchDocuments();}
    public void navigateToToolsSearchCalls() {domiciliaryCommonPage.navigateToToolsSearchCalls();}
    public void navigateToToolsSearchLinks() {domiciliaryCommonPage.navigateToToolsSearchLinks();}
    public void navigateToToolsAdministration() {
        domiciliaryCommonPage.navigateToToolsAdministration();
    }
    public void navigateToToolsPatientSignatureCaptureUserManagement() {domiciliaryCommonPage.navigateToToolsPatientSignatureCaptureUserManagement();}
    public void navigateToToolsSchedulingDiaryEntries() {domiciliaryCommonPage.navigateToToolsSchedulingDiaryEntries();}
    public void navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories() {domiciliaryCommonPage.navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories();}
    public void navigateToToolsSchedulingAvailability() { domiciliaryCommonPage.navigateToToolsSchedulingAvailability(); }
    public void navigateToToolsSchedulingDiary() {
        domiciliaryCommonPage.navigateToToolsSchedulingDiary();
    }
    public void navigateToToolsCustomerEntry() {
        domiciliaryCommonPage.navigateToToolsCustomerEntry();
    }
    public void navigateToToolsBulkDocumentsCreation() {
        domiciliaryCommonPage.navigateToToolsBulkDocumentsCreation();
    }
    public void navigateToToolsHomeVisitAppointmentLetterBatchPrinting() {
        domiciliaryCommonPage.navigateToToolsHomeVisitAppointmentLetterBatchPrinting();
    }

    //Navigation - Help drop down
    public void navigateToHelpOnlineHelp() {domiciliaryCommonPage.navigateToHelpOnlineHelp();}
    public void navigateToHelpSupportEnquiry(){domiciliaryCommonPage.navigateToHelpSupportEnquiry();}
    public void navigateToHelpGoldVisionAdmins(){domiciliaryCommonPage.navigateToHelpGoldVisionAdmins();}
    public void navigateToHelpRemoteAssist(){domiciliaryCommonPage.navigateToHelpRemoteAssist();}
    public void navigateToHelpChatWithSupport(){domiciliaryCommonPage.navigateToHelpChatWithSupport();}
    public void navigateToHelpAbout(){domiciliaryCommonPage.navigateToHelpAbout();}

    //Navigation - records

    public void navigateToOptometristInfo() {
        domiciliaryCommonPage.navigateToOptometristInfo();
    }
    public void navigateToOptometristDiaryEntries() {
        domiciliaryCommonPage.navigateToOptometristDiaryEntries();
    }

    //Clicks

    //Click icons
    public void clickHomeIcon() {
        domiciliaryCommonPage.clickHomeIcon();
    }
    public void clickVenuesIcon() {
        domiciliaryCommonPage.clickVenuesIcon();
    }
    public void clickContactsIcon() {
        domiciliaryCommonPage.clickContactsIcon();
    }
    public void clickAppointmentsIcon() {
        domiciliaryCommonPage.clickAppointmentsIcon();
    }
    public void clickActionsIcon() {
        domiciliaryCommonPage.clickActionsIcon();
    }
    public void clickOpportunitiesIcon() {
        domiciliaryCommonPage.clickOpportunitiesIcon();
    }
    public void clickQuotesIcon() {
        domiciliaryCommonPage.clickQuotesIcon();
    }
    public void clickCovidIcon() {
        domiciliaryCommonPage.clickCovidIcon();
    }
    public void clickVisitsIcon() {
        domiciliaryCommonPage.clickVisitsIcon();
    }
    public void clickCampaignsIcon() {
        domiciliaryCommonPage.clickCampaignsIcon();
    }
    public void clickSeminarsIcon() {
        domiciliaryCommonPage.clickSeminarsIcon();
    }

    //Assertions

    //Page title assertions
    public void assertCorrectPageTitle(String title) {
        domiciliaryCommonPage.correctTitle(title);
    }
    public void assertIncorrectPageTitle(String title) {
        domiciliaryCommonPage.incorrectTitle(title);
    }

    //URL assertions
    public void assertCorrectURL(String expectedURL) {
        domiciliaryCommonPage.correctURL(expectedURL);
    }
    public void assertIncorrectURL(String expectedURL) {
        domiciliaryCommonPage.incorrectURL(expectedURL);
    }

    //Data table assertions

    public void assertCorrectPatientNameInRow1(String patientName) {
        domiciliaryCommonPage.correctEntryInRow1Column1(patientName);
    }
    public void assertCorrectPrimaryContactInRow1(String primaryContact) {
        domiciliaryCommonPage.correctEntryInRow1Column1(primaryContact);
    }
    public void assertCorrectVenueNameInRow1(String venueName) {
        domiciliaryCommonPage.correctEntryInRow1Column0(venueName);
    }

    //General

    //Clicking and entering text in data search field

    public void clickFirstInCol0List(){domiciliaryCommonPage.clickFirstInCol0List();}
    public void clickFirstInCol0VenueDormantRecordList(){domiciliaryCommonPage.clickFirstInCol0VenueDormantRecordList();}
    public void clickFirstInCol1List(){domiciliaryCommonPage.clickFirstInCol1List();}
    public void clickFirstInCol2List(){domiciliaryCommonPage.clickFirstInCol2List();}
    public void clickTheRefreshIcon(){
        domiciliaryCommonPage.clickTheRefreshIcon();
    }

    //Open Record Steps
    public void clickRecordEditButton() {
        domiciliaryCommonPage.clickRecordEditButton();
    }
    public void clickRecordSaveButton() {
        domiciliaryCommonPage.clickRecordSaveButton();
    }
    public void clickRecordCloseButton() {
        domiciliaryCommonPage.clickRecordCloseButton();
    }
    public void deleteCurrentOpenRecord(){
        domiciliaryCommonPage.deleteCurrentOpenRecord();
    }
    public void closeCurrentDeletedRecord(){
        domiciliaryCommonPage.closeCurrentDeletedRecord();
    }

    //Optometrist info tickboxes

    public void tickOptometristInfoTickBoxes() {
        domiciliaryCommonPage.tickOptometristInfoTickBoxes();
    }

    //Switch tabs
    public void switchToNextTab() {
        domiciliaryCommonPage.switchToNextTab();
    }
    public void switchToOriginalTab() {
        domiciliaryCommonPage.switchToOriginalTab();
    }
    public void closeTab() {
        domiciliaryCommonPage.closeTab();
    }

    //Scheduling pages

    public void clickOptometristSelectedButton() {
        domiciliaryCommonPage.clickOptometristSelectedButton();
    }
    public void clickSubmitOptometristSelectedButton() {
        domiciliaryCommonPage.clickSubmitOptometristSelectedButton();
    }
    public void clickNextWeekButton() {
        domiciliaryCommonPage.clickNextWeekButton();
    }


    //Log in scripts for GV8 OR if a text input function exists without element dependancy
    //public void navigateToGVAdmin() {navigateToGVAdmin.theGV7AdminPage();}
    //public void navigateToCustomerEntry() {navigateToCE.theCustomerEntryPage();}
    // public void enterLogInCredentials() {navigateToGV.LogInSteps();}
    //public void handlingTestData() {navigateToGV.handlingTestInputFromInputFile();}
}
