package domiciliary.steps.CustomerEntry;

import domiciliary.pages.CustomerEntry.DomiciliarySchedulingAvailability;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedulingAvailabilitySteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SchedulingAvailabilitySteps.class);

    DomiciliarySchedulingAvailability domiciliarySchedulingAvailability;

    public void openAvailabilityPage() {
        domiciliarySchedulingAvailability.open();
    }

    public void clickPreviousWeekButton() {
        domiciliarySchedulingAvailability.clickPreviousWeekButton();
    }
    public void clickNextWeekButton() {
        domiciliarySchedulingAvailability.clickNextWeekButton();
    }
    public void clickOptometristSelectedButton() {
        domiciliarySchedulingAvailability.clickOptometristSelectedButton();
    }
    public void clickOptometristTickBoxAvailability(String optomName) {
        domiciliarySchedulingAvailability.clickOptometristTickBoxAvailability(optomName);
    }
    public void clickSubmitOptometristSelectedButton() {
        domiciliarySchedulingAvailability.clickSubmitOptometristSelectedButton();
    }
    public void getDaySubTerritoryStatus(String subTerritory){domiciliarySchedulingAvailability.getDaySubTerritoryStatus(subTerritory);}
    public void assignDaysAsAvailableForCurrentWeek(){domiciliarySchedulingAvailability.assignDaysAsAvailableForCurrentWeek();}

    public void fillInAvailabilityForCurrentWeek(){domiciliarySchedulingAvailability.fillInAvailabilityForCurrentWeek();}
    public void fillInAvailabilityForCurrentWeekScotland(){domiciliarySchedulingAvailability.fillInAvailabilityForCurrentWeekScotland();}
    public void fillInAvailabilityForCurrentWeekWales(){domiciliarySchedulingAvailability.fillInAvailabilityForCurrentWeekWales();}
    public void fillInAvailabilityForCurrentWeekNorthernIreland(){domiciliarySchedulingAvailability.fillInAvailabilityForCurrentWeekNorthernIreland();}
    public void clickSaveButtonInSchedulingAvailability(){domiciliarySchedulingAvailability.clickSaveButtonInSchedulingAvailability();}

}