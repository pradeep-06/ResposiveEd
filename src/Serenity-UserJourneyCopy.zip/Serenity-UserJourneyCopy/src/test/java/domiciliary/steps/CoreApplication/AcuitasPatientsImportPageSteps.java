package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryAcuitasPatientsImportPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AcuitasPatientsImportPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(AcuitasPatientsImportPageSteps.class);

    DomiciliaryAcuitasPatientsImportPage domiciliaryAcuitasPatientsImportPage;

    public void assertAcuitasPatientsImportTabTitleIsPresent() {
        domiciliaryAcuitasPatientsImportPage.isAcuitasPatientsImportTabPresent();
    }
}