package domiciliary.steps.CoreApplication.Popups.ContactPopup;

import domiciliary.pages.CoreApplication.Popups.ContactPopup.DomiciliaryOptometristDiaryEntriesPopupPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OptometristDiaryEntriesPopupPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(OptometristDiaryEntriesPopupPageSteps.class);

    DomiciliaryOptometristDiaryEntriesPopupPage domiciliaryOptometristDiaryEntriesPopupPage;

    public void assertFirstDiaryEntryDateIsCorrect(String date) {
        domiciliaryOptometristDiaryEntriesPopupPage.isFirstDiaryEntryDateCorrect(date);
    }


}