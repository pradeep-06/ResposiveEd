package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryGoldVisionAdministratorsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GoldVisionAdministratorsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(GoldVisionAdministratorsPageSteps.class);

    DomiciliaryGoldVisionAdministratorsPage domiciliaryGoldVisionAdministratorsPage;

    public void assertGoldVisionAdministratorsTabTitleIsPresent() {
        domiciliaryGoldVisionAdministratorsPage.isGoldVisionAdministratorsTabPresent();
    }
}