package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchCallsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchCallsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchCallsPageSteps.class);

    DomiciliarySearchCallsPage domiciliarySearchCallsPage;

    public void assertSearchCallsTabTitleIsPresent() {
        domiciliarySearchCallsPage.isSearchCallsTabPresent();
    }
}