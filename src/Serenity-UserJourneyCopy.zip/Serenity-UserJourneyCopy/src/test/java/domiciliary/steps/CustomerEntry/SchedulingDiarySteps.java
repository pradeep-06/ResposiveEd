package domiciliary.steps.CustomerEntry;

import domiciliary.pages.CustomerEntry.DomiciliarySchedulingDiary;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedulingDiarySteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SchedulingDiarySteps.class);

    DomiciliarySchedulingDiary domiciliarySchedulingDiary;

    public void clickPreviousWeekButton() {
        domiciliarySchedulingDiary.clickPreviousWeekButton();
    }
    public void clickNextWeekButton() {
        domiciliarySchedulingDiary.clickNextWeekButton();
    }
    public void clickOptometristSelectedButton() {
        domiciliarySchedulingDiary.clickOptometristSelectedButton();
    }
    public void clickTheAutomationOptometristBot1TickBoxDiary(){
        domiciliarySchedulingDiary.clickTheAutomationOptometristBot1TickBoxDiary();
    }

    public void clickSubmitOptometristSelectedButton() {
        domiciliarySchedulingDiary.clickSubmitOptometristSelectedButton();
    }
    public void clickVisitInSchedulingDiary(String surname) {
        domiciliarySchedulingDiary.clickVisitInSchedulingDiary(surname);
    }
    public void assertVisitDateIsCorrect(String date) {
        domiciliarySchedulingDiary.assertVisitDateIsCorrect(date);
    }
}