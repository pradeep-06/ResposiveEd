package domiciliary.steps.CoreApplication.Popups.ContactPopup;

import domiciliary.pages.CoreApplication.Popups.ContactPopup.DomiciliaryContactPopupPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ContactPopupPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(ContactPopupPageSteps.class);

    DomiciliaryContactPopupPage domiciliaryContactPopupPage;

    public void clickContactTypeOptometristOption() {
        domiciliaryContactPopupPage.clickContactTypeOptometristOption();
    }
    public void clickFundingStaffOption() {
        domiciliaryContactPopupPage.clickFundingStaffOption();
    }
    public void navigateToAdditionalInfo(){domiciliaryContactPopupPage.navigateToAdditionalInfo();}
    public Boolean getContactTitle(String expectedTitle){return domiciliaryContactPopupPage.assertTitleIs(expectedTitle);}
    public Boolean getContactGenderNotSpecified(String expectedGender){return domiciliaryContactPopupPage.assertGenderIsNotSpecified(expectedGender);}
    public Boolean getContactGenderNeutral(String expectedGender){return domiciliaryContactPopupPage.assertGenderIsNeutral(expectedGender);}

}