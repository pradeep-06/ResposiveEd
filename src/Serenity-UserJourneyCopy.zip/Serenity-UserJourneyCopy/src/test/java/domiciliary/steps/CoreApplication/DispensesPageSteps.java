package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryDispensesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DispensesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(DispensesPageSteps.class);

    DomiciliaryDispensesPage domiciliaryDispensesPage;

    public void assertDispensesTabTitleIsPresent() {
        domiciliaryDispensesPage.isDispensesTabPresent();
    }
}