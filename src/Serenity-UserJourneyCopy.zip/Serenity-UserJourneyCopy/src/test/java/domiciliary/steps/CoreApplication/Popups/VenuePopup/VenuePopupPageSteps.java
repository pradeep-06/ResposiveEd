package domiciliary.steps.CoreApplication.Popups.VenuePopup;

import domiciliary.pages.CoreApplication.Popups.VenuePopup.DomiciliaryVenuePopupPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VenuePopupPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(VenuePopupPageSteps.class);

    DomiciliaryVenuePopupPage domiciliaryVenuePopupPage;
    public void clickVenueTopLeftDropdownButton() {
        domiciliaryVenuePopupPage.clickVenueTopLeftDropdownButton();
    }
    public void clickVenueMakeRecordDormantOption() {
        domiciliaryVenuePopupPage.clickVenueMakeRecordDormantOption();
    }
    public void clickVenueDeleteRecordOption() {
        domiciliaryVenuePopupPage.clickVenueDeleteRecordOption();
    }
    public void clickVenuePopUpConfirmButton() {
        domiciliaryVenuePopupPage.clickVenuePopUpConfirmButton();
    }
    public void clickVenueCloseWindowOption() {
        domiciliaryVenuePopupPage.clickVenueCloseWindowOption();
    }
    public void enterTextIntoVenueName(String text) {
        domiciliaryVenuePopupPage.enterTextIntoVenueName(text);
    }
    public void clickIDStatusSelfEmployedDropDownOption() {
        domiciliaryVenuePopupPage.clickIDStatusSelfEmployedDropDownOption();
    }
    public void clickVenueDetailsButton() {
        domiciliaryVenuePopupPage.clickVenueDetailsButton();
    }
    public void clickVenueTypeOOStaffDropDownOption() {
        domiciliaryVenuePopupPage.clickVenueTypeOOStaffDropDownOption();
    }
    public void clickVenueTypeCareHomeOnlyDropDownOption() {
        domiciliaryVenuePopupPage.clickVenueTypeCareHomeOnlyDropDownOption();
    }
    public void clickVenueTypeHospitalDropDownOption() {
        domiciliaryVenuePopupPage.clickVenueTypeHospitalDropDownOption();
    }
    public void clickVenueTypePrisonDropDownOption() {
        domiciliaryVenuePopupPage.clickVenueTypePrisonDropDownOption();
    }
}