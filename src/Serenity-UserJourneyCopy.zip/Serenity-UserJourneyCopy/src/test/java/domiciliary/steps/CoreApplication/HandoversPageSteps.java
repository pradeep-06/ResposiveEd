package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryHandoversPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HandoversPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(HandoversPageSteps.class);

    DomiciliaryHandoversPage domiciliaryHandoversPage;

    public void assertHandoversTabTitleIsPresent() {
        domiciliaryHandoversPage.isHandoversTabPresent();
    }
}