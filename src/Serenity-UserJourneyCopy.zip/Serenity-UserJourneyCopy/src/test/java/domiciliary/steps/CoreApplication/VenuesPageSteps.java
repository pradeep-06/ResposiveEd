package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryVenuesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VenuesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(VenuesPageSteps.class);
    DomiciliaryVenuesPage domiciliaryVenuesPage;

    public void assertVenuesTabTitleIsPresent() {
        domiciliaryVenuesPage.isVenuesTabTitlePresent();
    }

    public void typeTextIntoAndEnterVenueNameSearchBox(String venueName) {
        domiciliaryVenuesPage.typeTextIntoAndEnterVenueNameSearchBox(venueName);
    }
    public void typeTextIntoAndEnterPrimaryContactSearchBox(String primaryContactName) {
        domiciliaryVenuesPage.switchToIFrame("IFrame1");
        domiciliaryVenuesPage.typeTextIntoAndEnterPrimaryContactSearchBox(primaryContactName);
    }

    public void assertSearchResultsTextContains(String text) {
        domiciliaryVenuesPage.assertSearchResultsTextContains(text);
    }
    public void assertVenueIsInList(String venueName) {
        domiciliaryVenuesPage.assertVenueIsInList(venueName);
    }
    public void assertVenueAndPrimaryContactAreInList(String venueName, String primaryContactName) {
        domiciliaryVenuesPage.assertVenueAndPrimaryContactAreInList(venueName, primaryContactName);
    }
    public void clickOnVenueNameInList(String venueName) {
        domiciliaryVenuesPage.clickOnVenueNameInList(venueName);
    }
    public void clickOnPrimaryContactInList(String primaryContactName) {
        domiciliaryVenuesPage.clickOnPrimaryContactInList(primaryContactName);
    }
}
