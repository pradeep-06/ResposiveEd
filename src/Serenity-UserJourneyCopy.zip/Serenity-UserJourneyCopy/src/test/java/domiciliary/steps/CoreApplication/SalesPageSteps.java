package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySalesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SalesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SalesPageSteps.class);

    DomiciliarySalesPage domiciliarySalesPage;

    public void assertSalesTabTitleIsPresent() {
        domiciliarySalesPage.isSalesTabPresent();
    }
}