package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchEmailPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchEmailPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchEmailPageSteps.class);

    DomiciliarySearchEmailPage domiciliarySearchEmailPage;

    public void assertSearchEmailTabTitleIsPresent() {domiciliarySearchEmailPage.isSearchEmailTabPresent();}
}