package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryReportingPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportingPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(ReportingPageSteps.class);

    DomiciliaryReportingPage domiciliaryReportingPage;

    public void assertReportingTabTitleIsPresent() {domiciliaryReportingPage.isReportingTabTitlePresent();}

    public void assertMyReportsSubTabIsPresent() {
        domiciliaryReportingPage.isMyReportsSubTabPresent();
    }
    public void assertStandardSubTabIsPresent() {
        domiciliaryReportingPage.isStandardSubTabPresent();
    }
    public void assertUserDefinedSubTabIsPresent() {
        domiciliaryReportingPage.isUserDefinedSubTabPresent();
    }
    public void assertAllSubTabIsPresent() {
        domiciliaryReportingPage.isAllSubTabPresent();
    }
}