package domiciliary.steps;

import domiciliary.pages.DomiciliaryHomePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomePageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(HomePageSteps.class);

    DomiciliaryHomePage domiciliaryHomePage;

    //Login with provided credentials
    public void loginWithCredentials(String username, String password) {
        domiciliaryHomePage.open();
        domiciliaryHomePage.loginWithCredentials(username, password);
    }

    //Open home page
    public void openHomePage() {
        domiciliaryHomePage.open();
    }

    //Assert tab title is present
    public void assertHomePageTabTitleIsPresent() {
        domiciliaryHomePage.isHomePageTabTitlePresent();
    }
}