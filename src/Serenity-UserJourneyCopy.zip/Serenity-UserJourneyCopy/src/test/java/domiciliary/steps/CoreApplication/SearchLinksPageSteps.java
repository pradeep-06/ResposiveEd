package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchLinksPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchLinksPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchLinksPageSteps.class);

    DomiciliarySearchLinksPage domiciliarySearchLinksPage;

    public void assertSearchLinksTabTitleIsPresent() {
        domiciliarySearchLinksPage.isSearchLinksTabPresent();
    }
}