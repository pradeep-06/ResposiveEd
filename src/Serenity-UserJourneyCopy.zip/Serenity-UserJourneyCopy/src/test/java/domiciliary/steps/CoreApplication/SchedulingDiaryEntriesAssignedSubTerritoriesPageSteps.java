package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySchedulingDiaryEntriesAssignedSubTerritoriesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedulingDiaryEntriesAssignedSubTerritoriesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SchedulingDiaryEntriesAssignedSubTerritoriesPageSteps.class);

    DomiciliarySchedulingDiaryEntriesAssignedSubTerritoriesPage domiciliarySchedulingDiaryEntriesAssignedSubTerritoriesPage;

    public void assertSchedulingDiaryEntriesAssignedSubTerritoriesTabTitleIsPresent() {
        domiciliarySchedulingDiaryEntriesAssignedSubTerritoriesPage.isSchedulingDiaryEntriesAssignedSubTerritoriesTabTitlePresent();
    }
}