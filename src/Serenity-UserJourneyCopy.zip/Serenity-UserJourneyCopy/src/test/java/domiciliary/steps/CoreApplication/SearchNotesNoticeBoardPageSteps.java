package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliarySearchNotesNoticeBoardPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchNotesNoticeBoardPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(SearchNotesNoticeBoardPageSteps.class);

    DomiciliarySearchNotesNoticeBoardPage domiciliarySearchNotesNoticeBoardPage;

    public void assertSearchNotesNoticesBoardTabTitleIsPresent() {domiciliarySearchNotesNoticeBoardPage.isSearchNotesNoticeBoardTabPresent();}
}