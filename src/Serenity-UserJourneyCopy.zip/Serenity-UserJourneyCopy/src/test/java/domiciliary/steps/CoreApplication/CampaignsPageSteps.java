package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryCampaignsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CampaignsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(CampaignsPageSteps.class);

    DomiciliaryCampaignsPage domiciliaryCampaignsPage;

    public void assertCampaignsTabTitleIsPresent() {
        domiciliaryCampaignsPage.isCampaignsTabPresent();
    }
}