package domiciliary.steps.CustomerEntry;

import domiciliary.pages.CustomerEntry.DomiciliaryCustomerEntryPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;


public class CustomerEntryPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(CustomerEntryPageSteps.class);
    DomiciliaryCustomerEntryPage domiciliaryCustomerEntryPage;

    //Open page
    public void openCustomerEntry() {
        domiciliaryCustomerEntryPage.open();
    }

    //Clicks

    //Top of page green elements clicks
    public void clickShowScriptButton() {
        domiciliaryCustomerEntryPage.clickShowScriptButton();
    }
    public void clickSearchPatientVenueButton() {
        domiciliaryCustomerEntryPage.clickSearchPatientVenueButton();
        domiciliaryCustomerEntryPage.assertSearchPatientVenuePopUpIsPresent();
    }
    public void clickPostcodeAddressLookupButton() {
        domiciliaryCustomerEntryPage.clickPostcodeAddressLookupButton();
    }
    public void clickCheckAvailabilityButton() {
        domiciliaryCustomerEntryPage.clickCheckAvailabilityButton();
    }
    public void clickCancelButton() {
        domiciliaryCustomerEntryPage.clickCancelButton();
    }
    public void clickBackButton() {
        domiciliaryCustomerEntryPage.clickBackButton();
    }
    public void clickContinueButton() {
        domiciliaryCustomerEntryPage.clickContinueButton();
    }

    //Patient title drop down clicks
    public void clickPatientTitleDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownNotSetButton();
    }
    public void clickPatientTitleDropDownMrButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMrButton();
    }
    public void clickPatientTitleDropDownMissButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMissButton();
    }
    public void clickPatientTitleDropDownMrsButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMrsButton();
    }
    public void clickPatientTitleDropDownMsButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMsButton();
    }
    public void clickPatientTitleDropDownMasterButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMasterButton();
    }
    public void clickPatientTitleDropDownRevButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownRevButton();
    }
    public void clickPatientTitleDropDownSisterButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownSisterButton();
    }
    public void clickPatientTitleDropDownFrButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownFrButton();
    }
    public void clickPatientTitleDropDownDrButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownDrButton();
    }
    public void clickPatientTitleDropDownAttyButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownAttyButton();
    }
    public void clickPatientTitleDropDownProfButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownProfButton();
    }
    public void clickPatientTitleDropDownHonButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownHonButton();
    }
    public void clickPatientTitleDropDownPresButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownPresButton();
    }
    public void clickPatientTitleDropDownGovButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownGovButton();
    }
    public void clickPatientTitleDropDownCoachButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownCoachButton();
    }
    public void clickPatientTitleDropDownOfcButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownOfcButton();
    }
    public void clickPatientTitleDropDownMxButton() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMxButton();
    }

    //Gender drop down clicks
    public void clickGenderDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickGenderDropDownNotSetButton();
    }
    public void clickGenderDropDownMaleButton() {
        domiciliaryCustomerEntryPage.clickGenderDropDownMaleButton();
    }
    public void clickGenderDropDownFemaleButton() {
        domiciliaryCustomerEntryPage.clickGenderDropDownFemaleButton();
    }
    public void clickGenderDropDownNeutralButton() {
        domiciliaryCustomerEntryPage.clickGenderDropDownNeutralButton();
    }
    public void clickGenderDropDownNotSpecifiedButton() {
        domiciliaryCustomerEntryPage.clickGenderDropDownNotSpecifiedButton();
    }

    //Country drop down clicks
    public void clickCountryDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickCountryDropDownNotSetButton();
    }
    public void clickCountryDropDownEnglandButton() {
        domiciliaryCustomerEntryPage.clickCountryDropDownEnglandButton();
    }
    public void clickCountryDropDownScotlandButton() {
        domiciliaryCustomerEntryPage.clickCountryDropDownScotlandButton();
    }
    public void clickCountryDropDownWalesButton() {
        domiciliaryCustomerEntryPage.clickCountryDropDownWalesButton();
    }
    public void clickCountryDropDownNorthernIrelandButton() {
        domiciliaryCustomerEntryPage.clickCountryDropDownNorthernIrelandButton();
    }
    public void clickCountryDropDownRepublicOfIrelandButton() {
        domiciliaryCustomerEntryPage.clickCountryDropDownRepublicOfIrelandButton();
    }

    //Domiciliary eligibility drop down clicks
    public void clickDomiciliaryEligibilityDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownNotSetButton();
    }
    public void clickDomiciliaryEligibilityDropDownAgrophobicButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownAgrophobicButton();
    }
    public void clickDomiciliaryEligibilityDropDownAlzheimerButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownAlzheimerButton();
    }
    public void clickDomiciliaryEligibilityDropDownAmputeeButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownAmputeeButton();
    }
    public void clickDomiciliaryEligibilityDropDownArthritisButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownArthritisButton();
    }
    public void clickDomiciliaryEligibilityDropDownAutismButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownAutismButton();
    }
    public void clickDomiciliaryEligibilityDropDownCancerButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownCancerButton();
    }
    public void clickDomiciliaryEligibilityDropDownCOPDButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownCOPDButton();
    }
    public void clickDomiciliaryEligibilityDropDownCoronaryHeartDiseaseButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownCoronaryHeartDiseaseButton();
    }
    public void clickDomiciliaryEligibilityDropDownCVAStrokeButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownCVAStrokeButton();
    }
    public void clickDomiciliaryEligibilityDropDownDementiaButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownDementiaButton();
    }
    public void clickDomiciliaryEligibilityDropDownDownsSyndromeButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownDownsSyndromeButton();
    }
    public void clickDomiciliaryEligibilityDropDownLearningDisabilitiesButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownLearningDisabilitiesButton();
    }
    public void clickDomiciliaryEligibilityDropDownMSButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownMSButton();
    }
    public void clickDomiciliaryEligibilityDropDownMorbidObesityButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownMorbidObesityButton();
    }
    public void clickDomiciliaryEligibilityDropDownMotorNeuroneButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownMotorNeuroneButton();
    }
    public void clickDomiciliaryEligibilityDropDownOsteoporosisButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownOsteoporosisButton();
    }
    public void clickDomiciliaryEligibilityDropDownOtherButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownOtherButton();
    }
    public void clickDomiciliaryEligibilityDropDownParalysisButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownParalysisButton();
    }
    public void clickDomiciliaryEligibilityDropDownParkinsonsDiseaseButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownParkinsonsDiseaseButton();
    }
    public void clickDomiciliaryEligibilityDropDownPeripheralNerupathyButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownPeripheralNerupathyButton();
    }
    public void clickDomiciliaryEligibilityDropDownRespiratoryDiseaseButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownRespiratoryDiseaseButton();
    }
    public void clickDomiciliaryEligibilityDropDownSevereLegUlcersButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownSevereLegUlcersButton();
    }
    public void clickDomiciliaryEligibilityDropDownSpinalDegenerationButton() {
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownSpinalDegenerationButton();
    }

    //Previous optician drop down clicks
    public void clickPreviousOpticianDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownNotSetButton();
    }
    public void clickPreviousOpticianDropDownAsdaButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownAsdaButton();
    }
    public void clickPreviousOpticianDropDownAtHomeButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownAtHomeButton();
    }
    public void clickPreviousOpticianDropDownBootsButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownBootsButton();
    }
    public void clickPreviousOpticianDropDownEyecareOncallButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownEyecareOncallButton();
    }
    public void clickPreviousOpticianDropDownHomecallButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownHomecallButton();
    }
    public void clickPreviousOpticianDropDownLocalButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownLocalButton();
    }
    public void clickPreviousOpticianDropDownLocalDomiciliaryProviderButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownLocalDomiciliaryProviderButton();
    }
    public void clickPreviousOpticianDropDownLocalHighStreetProviderButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownLocalHighStreetProviderButton();
    }
    public void clickPreviousOpticianDropDownNotKnownButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownNotKnownButton();
    }
    public void clickPreviousOpticianDropDownOpticalExpressButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownOpticalExpressButton();
    }
    public void clickPreviousOpticianDropDownOtherButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownOtherButton();
    }
    public void clickPreviousOpticianDropDownSpecsaversButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownSpecsaversButton();
    }
    public void clickPreviousOpticianDropDownTescoButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownTescoButton();
    }
    public void clickPreviousOpticianDropDownTheOutsideClinicButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownTheOutsideClinicButton();
    }
    public void clickPreviousOpticianDropDownVisionExpressButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownVisionExpressButton();
    }
    public void clickPreviousOpticianDropDownVisioncallButton() {
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownVisioncallButton();
    }

    //Conditions drop down clicks
    public void clickConditionDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNotSetButton();
    }
    public void clickConditionDropDownDiabeticButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownDiabeticButton();
    }
    public void clickConditionDropDownDiabeticAndBlindPartiallySightedButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownDiabeticAndBlindPartiallySightedButton();
    }
    public void clickConditionDropDownDiabeticAndFamilyGlaucomaButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownDiabeticAndFamilyGlaucomaButton();
    }
    public void clickConditionDropDownDiabeticAndGlacomaAndBlindPartiallySightedButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownDiabeticAndGlacomaAndBlindPartiallySightedButton();
    }
    public void clickConditionDropDownDiabeticAndGlaucomaButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownDiabeticAndGlaucomaButton();
    }
    public void clickConditionDropDownFamilyHistoryOfGlaucomaButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownFamilyHistoryOfGlaucomaButton();
    }
    public void clickConditionDropDownGlaucomaButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownGlaucomaButton();
    }
    public void clickConditionDropDownGlaucomaAndBlindPartiallySightedButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownGlaucomaAndBlindPartiallySightedButton();
    }
    public void clickConditionDropDownNewmedicaPxButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNewmedicaPxButton();
    }
    public void clickConditionDropDownNewmedicaDiabeticButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNewmedicaDiabeticButton();
    }
    public void clickConditionDropDownNewmedicaDiabeticGlaucomaButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNewmedicaDiabeticGlaucomaButton();
    }
    public void clickConditionDropDownNewmedicaGlaucomaButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNewmedicaGlaucomaButton();
    }
    public void clickConditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton();
    }
    public void clickConditionDropDownNotKnownButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNotKnownButton();
    }
    public void clickConditionDropDownNotRelevantButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNotRelevantButton();
    }
    public void clickConditionDropDownNothingReportedButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownNothingReportedButton();
    }
    public void clickConditionDropDownRegBlindOrPartiallySightedButton() {
        domiciliaryCustomerEntryPage.clickConditionDropDownRegBlindOrPartiallySightedButton();
    }

    //Funding drop down clicks
    public void clickFundingDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownNotSetButton();
    }
    public void clickFundingDropDownIncomeSupportButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownIncomeSupportButton();
    }
    public void clickFundingDropDownUniversalCreditButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownUniversalCreditButton();
    }
    public void clickFundingDropDownHC2CertificateButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownHC2CertificateButton();
    }
    public void clickFundingDropDownHC3CertificateButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownHC3CertificateButton();
    }
    public void clickFundingDropDownPrivatelyFundedButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownPrivatelyFundedButton();
    }
    public void clickFundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton();
    }
    public void clickFundingDropDownNotKnownButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownNotKnownButton();
    }
    public void clickFundingDropDownNHSTaxCreditExemptionButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownNHSTaxCreditExemptionButton();
    }
    public void clickFundingDropDownGuaranteePensionCreditButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownGuaranteePensionCreditButton();
    }
    public void clickFundingDropDownIncomeRetatedESAButton() {
        domiciliaryCustomerEntryPage.clickFundingDropDownIncomeRetatedESAButton();
    }

    //Patient primary contact radio button clicks
    public void clickPatientHomeTelephoneNumberPrimaryContactRadioButton() {
        domiciliaryCustomerEntryPage.clickPatientHomeTelephoneNumberPrimaryContactRadioButton();
    }
    public void clickPatientMobileTelephoneNumberPrimaryContactRadioButton() {
        domiciliaryCustomerEntryPage.clickPatientMobileTelephoneNumberPrimaryContactRadioButton();
    }

    //Advertising method drop down clicks
    public void clickAdvertisingMethodDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownNotSetButton();
    }
    public void clickAdvertisingMethodDropDownAdvertLocalButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownAdvertLocalButton();
    }
    public void clickAdvertisingMethodDropDownAdvertNationalButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownAdvertNationalButton();
    }
    public void clickAdvertisingMethodDropDownAgeConcernReferralButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownAgeConcernReferralButton();
    }
    public void clickAdvertisingMethodDropDownArtAndDesignButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownArtAndDesignButton();
    }
    public void clickAdvertisingMethodDropDownAutomotiveButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownAutomotiveButton();
    }
    public void clickAdvertisingMethodDropDownAviationButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownAviationButton();
    }
    public void clickAdvertisingMethodDropDownBankingAndFinanceButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownBankingAndFinanceButton();
    }
    public void clickAdvertisingMethodDropDownBedlistButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownBedlistButton();
    }
    public void clickAdvertisingMethodDropDownBiotechnologyButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownBiotechnologyButton();
    }
    public void clickAdvertisingMethodDropDownBowensOpticiansButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownBowensOpticiansButton();
    }
    public void clickAdvertisingMethodDropDownBrewingButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownBrewingButton();
    }
    public void clickAdvertisingMethodDropDownCareDataImportButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownCareDataImportButton();
    }
    public void clickAdvertisingMethodDropDownCarerButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownCarerButton();
    }
    public void clickAdvertisingMethodDropDownCentralLocalGovernmentButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownCentralLocalGovernmentButton();
    }
    public void clickAdvertisingMethodDropDownCharityButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownCharityButton();
    }
    public void clickAdvertisingMethodDropDownChemistButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownChemistButton();
    }
    public void clickAdvertisingMethodDropDownDefenceButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownDefenceButton();
    }
    public void clickAdvertisingMethodDropDownDiabeticScreeningClinicButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownDiabeticScreeningClinicButton();
    }
    public void clickAdvertisingMethodDropDownDistributionAndLogisticsButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownDistributionAndLogisticsButton();
    }
    public void clickAdvertisingMethodDropDownEducationAndTrainingButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownEducationAndTrainingButton();
    }
    public void clickAdvertisingMethodDropDownEmergencyServicesButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownEmergencyServicesButton();
    }
    public void clickAdvertisingMethodDropDownEntertainmentAndMediaButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownEntertainmentAndMediaButton();
    }
    public void clickAdvertisingMethodDropDownEnvironmentalButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownEnvironmentalButton();
    }

    public void clickAdvertisingMethodDropDownEquipmentDistributionButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownEquipmentDistributionButton();
    }
    public void clickAdvertisingMethodDropDownFarmingAndAgricultureButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownFarmingAndAgricultureButton();
    }
    public void clickAdvertisingMethodDropDownFriendFamilyButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownFriendFamilyButton();
    }
    public void clickAdvertisingMethodDropDownFurnitureAndFittingsButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownFurnitureAndFittingsButton();
    }
    public void clickAdvertisingMethodDropDownGamingButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownGamingButton();
    }
    public void clickAdvertisingMethodDropDownGPSurgeryDoctorButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownGPSurgeryDoctorButton();
    }
    public void clickAdvertisingMethodDropDownHealthcallStaffButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownHealthcallStaffButton();
    }
    public void clickAdvertisingMethodDropDownHealthcareButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownHealthcareButton();
    }
    public void clickAdvertisingMethodDropDownHireServicesButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownHireServicesButton();
    }
    public void clickAdvertisingMethodDropDownHotelAndCateringButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownHotelAndCateringButton();
    }
    public void clickAdvertisingMethodDropDownHousingBuildingAndConstructionButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownHousingBuildingAndConstructionButton();
    }
    public void clickAdvertisingMethodDropDownInformationTechnologyButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownInformationTechnologyButton();
    }
    public void clickAdvertisingMethodDropDownInsuranceButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownInsuranceButton();
    }
    public void clickAdvertisingMethodDropDownKnowledgeManagementButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownKnowledgeManagementButton();
    }
    public void clickAdvertisingMethodDropDownLeafletThroughTheDoorButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownLeafletThroughTheDoorButton();
    }
    public void clickAdvertisingMethodDropDownLegalButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownLegalButton();
    }
    public void clickAdvertisingMethodDropDownManufacturingAndEngineeringButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownManufacturingAndEngineeringButton();
    }
    public void clickAdvertisingMethodDropDownMouseabilityWebsiteButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownMouseabilityWebsiteButton();
    }
    public void clickAdvertisingMethodDropDownNACareHomeButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownNACareHomeButton();
    }
    public void clickAdvertisingMethodDropDownNurseButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownNurseButton();
    }
    public void clickAdvertisingMethodDropDownOpticianButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownOpticianButton();
    }
    public void clickAdvertisingMethodDropDownOtherButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownOtherButton();
    }
    public void clickAdvertisingMethodDropDownOtherNonProfitMakingButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownOtherNonProfitMakingButton();
    }
    public void clickAdvertisingMethodDropDownOtherRecommendationButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownOtherRecommendationButton();
    }
    public void clickAdvertisingMethodDropDownPersonalisedLetterButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPersonalisedLetterButton();
    }
    public void clickAdvertisingMethodDropDownPharmaceuticalButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPharmaceuticalButton();
    }
    public void clickAdvertisingMethodDropDownPreviousRecordButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPreviousRecordButton();
    }
    public void clickAdvertisingMethodDropDownPrintingAndDesignButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPrintingAndDesignButton();
    }
    public void clickAdvertisingMethodDropDownProfessionalBodyButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownProfessionalBodyButton();
    }
    public void clickAdvertisingMethodDropDownPropertyManagementButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPropertyManagementButton();
    }
    public void clickAdvertisingMethodDropDownPublicTransportButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPublicTransportButton();
    }
    public void clickAdvertisingMethodDropDownPublishingAndNewspapersButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownPublishingAndNewspapersButton();
    }
    public void clickAdvertisingMethodDropDownRadioButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownRadioButton();
    }
    public void clickAdvertisingMethodDropDownRecruitmentButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownRecruitmentButton();
    }
    public void clickAdvertisingMethodDropDownReplySlipFromLeafletButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownReplySlipFromLeafletButton();
    }
    public void clickAdvertisingMethodDropDownRetailButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownRetailButton();
    }
    public void clickAdvertisingMethodDropDownSalesAdvertisingMarketingButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownSalesAdvertisingMarketingButton();
    }
    public void clickAdvertisingMethodDropDownSecurityButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownSecurityButton();
    }
    public void clickAdvertisingMethodDropDownServiceManagementButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownServiceManagementButton();
    }
    public void clickAdvertisingMethodDropDownShelteredWardenRecommendationButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownShelteredWardenRecommendationButton();
    }
    public void clickAdvertisingMethodDropDownShelteredAccommodationExistingButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownShelteredAccommodationExistingButton();
    }
    public void clickAdvertisingMethodDropDownSpecsaversButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownSpecsaversButton();
    }
    public void clickAdvertisingMethodDropDownSportAndLeisureButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownSportAndLeisureButton();
    }
    public void clickAdvertisingMethodDropDownTelecomsAndCommunicationsButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownTelecomsAndCommunicationsButton();
    }
    public void clickAdvertisingMethodDropDownTelevisionAdvertButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownTelevisionAdvertButton();
    }
    public void clickAdvertisingMethodDropDownTranslationServicesButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownTranslationServicesButton();
    }
    public void clickAdvertisingMethodDropDownTravelButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownTravelButton();
    }
    public void clickAdvertisingMethodDropDownUtilitiesButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownUtilitiesButton();
    }
    public void clickAdvertisingMethodDropDownWasteManagementButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownWasteManagementButton();
    }
    public void clickAdvertisingMethodDropDownWebsiteButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownWebsiteButton();
    }
    public void clickAdvertisingMethodDropDownWebsiteOnlineTestRequestButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownWebsiteOnlineTestRequestButton();
    }
    public void clickAdvertisingMethodDropDownWholesaleAndDistributionButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownWholesaleAndDistributionButton();
    }
    public void clickAdvertisingMethodDropDownWRVSPartnershipButton() {
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownWRVSPartnershipButton();
    }

    //Alternative contact main drop down clicks
    public void clickAlternativeContactMainDropDownNoneButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactMainDropDownNoneButton();
    }
    public void clickAlternativeContactMainDropDownNewContactButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactMainDropDownNewContactButton();
    }

    //Alternative contact title drop down clicks
    public void clickAlternativeContactTitleDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownNotSetButton();
    }
    public void clickAlternativeContactTitleDropDownMrButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownMrButton();
    }
    public void clickAlternativeContactTitleDropDownMissButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownMissButton();
    }
    public void clickAlternativeContactTitleDropDownMrsButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownMrsButton();
    }
    public void clickAlternativeContactTitleDropDownMsButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownMsButton();
    }
    public void clickAlternativeContactTitleDropDownMasterButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownMasterButton();
    }
    public void clickAlternativeContactTitleDropDownRevButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownRevButton();
    }
    public void clickAlternativeContactTitleDropDownSisterButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownSisterButton();
    }
    public void clickAlternativeContactTitleDropDownFrButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownFrButton();
    }
    public void clickAlternativeContactTitleDropDownDrButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownDrButton();
    }
    public void clickAlternativeContactTitleDropDownAttyButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownAttyButton();
    }
    public void clickAlternativeContactTitleDropDownProfButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownProfButton();
    }
    public void clickAlternativeContactTitleDropDownHonButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownHonButton();
    }
    public void clickAlternativeContactTitleDropDownPresButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownPresButton();
    }
    public void clickAlternativeContactTitleDropDownGovButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownGovButton();
    }
    public void clickAlternativeContactTitleDropDownCoachButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownCoachButton();
    }
    public void clickAlternativeContactTitleDropDownOfcButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTitleDropDownOfcButton();
    }

    //Alternative contact type drop down clicks
    public void clickAlternativeContactTypeDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownNotSetButton();
    }
    public void clickAlternativeContactTypeDropDownAdministratorButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownAdministratorButton();
    }
    public void clickAlternativeContactTypeDropDownVenueManagerButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownVenueManagerButton();
    }
    public void clickAlternativeContactTypeDropDownDeputyManagerButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownDeputyManagerButton();
    }
    public void clickAlternativeContactTypeDropDownMatronButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownMatronButton();
    }
    public void clickAlternativeContactTypeDropDownOpticiansOrganiserButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownOpticiansOrganiserButton();
    }
    public void clickAlternativeContactTypeDropDownPatientCarerButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownPatientCarerButton();
    }
    public void clickAlternativeContactTypeDropDownPatientFamilyButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactTypeDropDownPatientFamilyButton();
    }


    //Alternative contact primary contact radio button clicks
    public void clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton();
    }
    public void clickAlternativeContactMobileTelephoneNumberPrimaryContactRadioButton() {
        domiciliaryCustomerEntryPage.clickAlternativeContactMobileTelephoneNumberPrimaryContactRadioButton();
    }

    //Visit information clicks
    public void clickCreateNewVisitRadioButton() {
        domiciliaryCustomerEntryPage.clickCreateNewVisitRadioButton();
    }
    public void clickNoAppointmentAvailableRadioButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableRadioButton();
    }

    //Create new visit clicks
    public void clickVisitTypeDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownNotSetButton();
    }
    public void clickVisitTypeDropDownHomeVisitNewButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownHomeVisitNewButton();
    }
    public void clickVisitTypeDropDownCareHomeVisitButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownCareHomeVisitButton();
    }
    public void clickVisitTypeDropDownHomeVisitExistingButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownHomeVisitExistingButton();
    }
    public void clickVisitTypeDropDownRetestButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownRetestButton();
    }
    public void clickVisitTypeDropDownCorporateEyecareButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownCorporateEyecareButton();
    }
    public void clickVisitTypeDropDownPrisonVisitButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownPrisonVisitButton();
    }
    public void clickVisitTypeDropDownHospitalVisitButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownHospitalVisitButton();
    }
    public void clickVisitTypeDropDownPrivateSightTestButton() {
        domiciliaryCustomerEntryPage.clickVisitTypeDropDownPrivateSightTestButton();
    }

    //Visit date picker
    public void clickVisitTimeslotPicker() {
        domiciliaryCustomerEntryPage.clickVisitTimeslotPicker();
    }

    public void chooseAppointmentTimeslot(String optomName, String date, String amPm) {
        domiciliaryCustomerEntryPage.chooseAppointmentTimeslot(optomName, date, amPm);
    }

    //No appointment available reason drop down clicks
    public void clickNoAppointmentAvailableReasonDropDownNotSetButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownNotSetButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownNoAppointmentAvailableButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownNoAppointmentAvailableButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownAftercareButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownAftercareButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownDispenseOnlyButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownDispenseOnlyButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownEarlySightTestRequestedButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownEarlySightTestRequestedButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton();
    }
    public void clickNoAppointmentAvailableReasonDropDownUntickToSaveButton() {
        domiciliaryCustomerEntryPage.clickNoAppointmentAvailableReasonDropDownUntickToSaveButton();
    }

    //Consent and permissions page clicks
    public void clickDataProcessingConsentNoRadioButton() {
        domiciliaryCustomerEntryPage.clickDataProcessingConsentNoRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsEmailYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsEmailYesRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsEmailNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsEmailNoRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsPostYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsPostYesRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsPostNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsPostNoRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsSMSYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsSMSYesRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsSMSNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsSMSNoRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsTelephoneYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsTelephoneYesRadioButton();
    }
    public void clickMarketingInServiceRelatedCommunicationsTelephoneNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsTelephoneNoRadioButton();
    }
    public void clickMarketingPermissionsEmailYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsEmailYesRadioButton();
    }
    public void clickMarketingPermissionsEmailNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsEmailNoRadioButton();
    }
    public void clickMarketingPermissionsPostYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsPostYesRadioButton();
    }
    public void clickMarketingPermissionsPostNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsPostNoRadioButton();
    }
    public void clickMarketingPermissionsSMSYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsSMSYesRadioButton();
    }
    public void clickMarketingPermissionsSMSNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsSMSNoRadioButton();
    }
    public void clickMarketingPermissionsTelephoneYesRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsTelephoneYesRadioButton();
    }
    public void clickMarketingPermissionsTelephoneNoRadioButton() {
        domiciliaryCustomerEntryPage.clickMarketingPermissionsTelephoneNoRadioButton();
    }
    public void clickMarketingConsentConfirmButton() {
        domiciliaryCustomerEntryPage.clickMarketingConsentConfirmButton();
    }
    public void clickMarketingConsentSaveButton() {
        domiciliaryCustomerEntryPage.clickMarketingConsentSaveButton();
        domiciliaryCustomerEntryPage.assertDetailsSavedSuccessfullyPopUpIsPresent();
    }
    public void clickDetailsSavedSuccessfullyContinueToAnotherPatient() {
        domiciliaryCustomerEntryPage.clickDetailsSavedSuccessfullyContinue();
        domiciliaryCustomerEntryPage.assertAddAnotherPatientPopUpTextIsPresent();
    }
    public void clickDetailsSavedSuccessfullyContinueToFinish() {
        domiciliaryCustomerEntryPage.clickDetailsSavedSuccessfullyContinue();
        domiciliaryCustomerEntryPage.assertCustomerEntryPageTitleIsPresent();
    }
    public void clickAddNewPatientButton() {
        domiciliaryCustomerEntryPage.clickAddNewPatientButton();
    }
    public void clickAddExistingPatientButton() {
        domiciliaryCustomerEntryPage.clickAddExistingPatientButton();
    }
    public void addPatientsToExistingCareHomeVisit(List<String> patientSurnames) {
        domiciliaryCustomerEntryPage.addPatientsToExistingCareHomeVisit(patientSurnames);
    }
    public void addPatientsToExistingHomeVisit(List<String> patientSurnames) {
        domiciliaryCustomerEntryPage.addPatientsToExistingHomeVisit(patientSurnames);
    }
    public void clickAddToBookingButton() {
        domiciliaryCustomerEntryPage.clickAddToBookingButton();
    }
    public void clickFinishButton() {
        domiciliaryCustomerEntryPage.clickFinishButton();
    }

    //Error pop up click
    public void clickErrorPopUpContinueButton() {
        domiciliaryCustomerEntryPage.clickErrorPopUpContinueButton();
    }

    //Enter text functions


    //Combination functions

    //Enter text all in one go
    public void enterPatientText(String firstName, String surname, String homeTelephoneNumber, String mobileTelephoneNumber, String dateOfLastSightTest, String dateOfBirth) {
        domiciliaryCustomerEntryPage.enterTextInPatientFirstNameBox(firstName);
        domiciliaryCustomerEntryPage.enterTextInPatientSurnameNameBox(surname);
        domiciliaryCustomerEntryPage.enterTextInPatientHomeTelephoneBox(homeTelephoneNumber);
        domiciliaryCustomerEntryPage.enterTextInPatientMobileTelephoneBox(mobileTelephoneNumber);
        domiciliaryCustomerEntryPage.enterTextInDateOfLastSightTestPicker(dateOfLastSightTest);
        domiciliaryCustomerEntryPage.enterTextInDateOfBirthPicker(dateOfBirth);
    }
    public void enterHAndC(String HAndC) {
        domiciliaryCustomerEntryPage.enterHAndCNumber(HAndC);
    }
    public void enterOptometristText(String firstName, String surname, String homeTelephoneNumber, String mobileTelephoneNumber, String dateOfBirth) {
        domiciliaryCustomerEntryPage.enterTextInPatientFirstNameBox(firstName);
        domiciliaryCustomerEntryPage.enterTextInPatientSurnameNameBox(surname);
        domiciliaryCustomerEntryPage.enterTextInPatientHomeTelephoneBox(homeTelephoneNumber);
        domiciliaryCustomerEntryPage.enterTextInPatientMobileTelephoneBox(mobileTelephoneNumber);
        domiciliaryCustomerEntryPage.clickDateOfLastSightTestNotKnownCheckBox();
        domiciliaryCustomerEntryPage.enterTextInDateOfBirthPicker(dateOfBirth);
    }
    public void enterAlternateContactText(String firstName, String surname, String homeTelephoneNumber, String mobileTelephoneNumber){
        domiciliaryCustomerEntryPage.enterTextInAlternateContactFirstNameBox(firstName);
        domiciliaryCustomerEntryPage.enterTextInAlternateContactSurnameNameBox(surname);
        domiciliaryCustomerEntryPage.enterTextInAlternateContactHomeTelephoneBox(homeTelephoneNumber);
        domiciliaryCustomerEntryPage.enterTextInAlternateContactMobileTelephoneBox(mobileTelephoneNumber);
    }

    //Click all mandatory drop downs/buttons in one go
    public void clickMandatoryDropDownsAndButtons() {
        domiciliaryCustomerEntryPage.clickPatientTitleDropDownMrButton();
        domiciliaryCustomerEntryPage.clickGenderDropDownMaleButton();
        domiciliaryCustomerEntryPage.clickCountryDropDownEnglandButton();
        domiciliaryCustomerEntryPage.clickDomiciliaryEligibilityDropDownOtherButton();
        domiciliaryCustomerEntryPage.clickPreviousOpticianDropDownNotKnownButton();
        domiciliaryCustomerEntryPage.clickConditionDropDownNotRelevantButton();
        domiciliaryCustomerEntryPage.clickFundingDropDownNotKnownButton();
        domiciliaryCustomerEntryPage.clickPatientHomeTelephoneNumberPrimaryContactRadioButton();
        domiciliaryCustomerEntryPage.clickAdvertisingMethodDropDownUtilitiesButton();
    }

    public void clickDataProcessingConsentYesRadioButton() {
        domiciliaryCustomerEntryPage.assertDataProcessingConsentTitleIsPresent();
        domiciliaryCustomerEntryPage.clickDataProcessingConsentYesRadioButton();
        domiciliaryCustomerEntryPage.assertServiceCommunicationsTitleIsPresent();
    }

    //Complete GDPR all yes in one go
    public void completeGDPRAllYes() {
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsEmailYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsPostYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsSMSYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingInServiceRelatedCommunicationsTelephoneYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingPermissionsEmailYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingPermissionsPostYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingPermissionsSMSYesRadioButton();
        domiciliaryCustomerEntryPage.clickMarketingPermissionsTelephoneYesRadioButton();
    }

    public void completeGDPRCareHome() {
        domiciliaryCustomerEntryPage.clickMarketingCareHomeDataProcessingConsentConfirmButton();
        domiciliaryCustomerEntryPage.clickMarketingCareHomeDataProcessingConsentYesButton();
    }

    //Search patient/venue pop up
    public void enterTextIntoPatientSearchTextBox(String text) {
        domiciliaryCustomerEntryPage.enterTextIntoPatientSearchTextBox(text);
    }
    public void enterTextIntoVenueNameSearchTextBox(String text) {
        domiciliaryCustomerEntryPage.enterTextIntoVenueNameSearchTextBox(text);
    }
    public void enterTextIntoPostcodeSearchTextBox(String text) {
        domiciliaryCustomerEntryPage.enterTextIntoPostcodeSearchTextBox(text);
    }
    public void clearTextFromSearchPatientVenueTextBoxes() {
        domiciliaryCustomerEntryPage.clearTextFromSearchPatientVenueTextBoxes();
    }
    public void clickPatientVenueSearchButtonAndAssertPatientIsPresent(String name) {
        domiciliaryCustomerEntryPage.clickPatientVenueSearchButtonAndAssertPatientIsPresent(name);
    }
    public void clickPatientVenueSearchButtonAndAssertVenueIsPresent(String name) {
        domiciliaryCustomerEntryPage.clickPatientVenueSearchButtonAndAssertVenueIsPresent(name);
    }

    public void clickPatientVenueSearchButtonAndAssertPostcodeIsPresent(String postcode) {
        domiciliaryCustomerEntryPage.clickPatientVenueSearchButtonAndAssertPostcodeIsPresent(postcode);
    }
    public void clickPatientVenueSearchButtonAndAssertPatientAndVenueArePresent(String patientName, String venueName) {
        domiciliaryCustomerEntryPage.clickPatientVenueSearchButtonAndAssertPatientIsPresent(patientName);
        domiciliaryCustomerEntryPage.clickPatientVenueSearchButtonAndAssertVenueIsPresent(venueName);
    }
    public void searchPatientVenueClickCancelButton() {
        domiciliaryCustomerEntryPage.searchPatientVenueClickCancelButton();
    }
    public void clickPatientSelectButton(String surname) {
        domiciliaryCustomerEntryPage.clickPatientSelectButton(surname);
    }
    public void clickVenueSelectButton(String surname) {
        domiciliaryCustomerEntryPage.clickVenueSelectButton(surname);
    }
    public void enterDateIntoVisitDateTextBox(String date) {
        domiciliaryCustomerEntryPage.enterDateIntoVisitDateTextBox(date);
    }
    public void clickAutomationOptomInOptometristDropDown() {
        domiciliaryCustomerEntryPage.clickAutomationOptomInOptometristDropDown();
    }
    public void clickAutomationOptom5InOptometristDropDown() {
        domiciliaryCustomerEntryPage.clickAutomationOptom5InOptometristDropDown();
    }
    public void clickAutomationOptom6InOptometristDropDown() {
        domiciliaryCustomerEntryPage.clickAutomationOptom6InOptometristDropDown();
    }
    public void clickAutomationOptom7InOptometristDropDown() {
        domiciliaryCustomerEntryPage.clickAutomationOptom7InOptometristDropDown();
    }
    public void clickSteveTheOptomInOptometristDropDown() {
        domiciliaryCustomerEntryPage.clickSteveTheOptomInOptometristDropDown();
    }
    public void clickKeithTheOptomInOptometristDropDown() {
        domiciliaryCustomerEntryPage.clickKeithTheOptomInOptometristDropDown();
    }
    public void clickOptomInOptometristDropDown(String optomName) {
        domiciliaryCustomerEntryPage.clickOptomInOptometristDropDown(optomName);
    }
    public void clickAnytimeCheckBox() {
        domiciliaryCustomerEntryPage.clickAnytimeCheckBox();
    }


    public void selectFirstAddressForPostcode(String postcode) {
        domiciliaryCustomerEntryPage.clickPostcodeAddressLookupButton();
        domiciliaryCustomerEntryPage.enterPostcodeIntoPostcodeLookup(postcode);
        domiciliaryCustomerEntryPage.chooseUKFromPostcodeLookupCountryDropdown();
        domiciliaryCustomerEntryPage.clickPostcodeLookupSearchButton();
        domiciliaryCustomerEntryPage.selectFirstAddressPostcodeLookup(postcode);
    }
}
