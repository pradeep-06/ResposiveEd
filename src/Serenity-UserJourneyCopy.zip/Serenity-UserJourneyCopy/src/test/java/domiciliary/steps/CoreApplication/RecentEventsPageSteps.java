package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryRecentEventsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RecentEventsPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(RecentEventsPageSteps.class);

    DomiciliaryRecentEventsPage domiciliaryRecentEventsPage;

    public void assertRecentEventsTabTitleIsPresent() {domiciliaryRecentEventsPage.isRecentEventsTabPresent();}
}