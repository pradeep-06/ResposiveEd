package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryTerritoriesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TerritoriesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(TerritoriesPageSteps.class);

    DomiciliaryTerritoriesPage domiciliaryTerritoriesPage;

    public void assertTerritoriesTabTitleIsPresent() {
        domiciliaryTerritoriesPage.isTerritoriesTabPresent();
    }
}