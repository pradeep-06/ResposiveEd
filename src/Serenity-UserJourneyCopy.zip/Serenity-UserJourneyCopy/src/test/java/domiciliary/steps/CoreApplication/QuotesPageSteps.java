package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryQuotesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QuotesPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(QuotesPageSteps.class);

    DomiciliaryQuotesPage domiciliaryQuotesPage;

    public void assertQuotesTabTitleIsPresent() {
        domiciliaryQuotesPage.isQuotesTabPresent();
    }
}