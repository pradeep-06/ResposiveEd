package domiciliary.steps.CoreApplication;

import domiciliary.pages.CoreApplication.DomiciliaryProductPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductPageSteps extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(ProductPageSteps.class);

    DomiciliaryProductPage domiciliaryProductPage;

    public void assertProductTabTitleIsPresent() {
        domiciliaryProductPage.isProductTabPresent();
    }
}