package domiciliary.extentions;

import Framework.BaseObject.BasePageObject;
import Framework.DataManager.TestDataManager;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DomiciliaryCommonPage extends BasePageObject {

    private final Logger logger = LoggerFactory.getLogger(DomiciliaryCommonPage.class);
    protected TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = ".gv-list-header-list-options")
    private WebElementFacade categoryOptionsDropDown;
    @FindBy(xpath = "//ul/li/span[@class='gv-toolbar-item-label' and .='all']/..")
    private WebElementFacade categoryOptionsDropDownAll;


    //Elements

    //Elements - Icons in top bar
    @FindBy(xpath = "//img[@class='home_icon' and @title='Home']")
    private WebElementFacade homeIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Venues']")
    private WebElementFacade venuesIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Contacts']")
    private WebElementFacade contactsIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Appointments']")
    private WebElementFacade appointmentsIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Actions']")
    private WebElementFacade actionsIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Opportunities']")
    private WebElementFacade opportunitiesIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Quotes']")
    private WebElementFacade quotesIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Covid']")
    private WebElementFacade covidIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Visits']")
    private WebElementFacade visitsIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Campaigns']")
    private WebElementFacade campaignsIcon;
    @FindBy(xpath = "//img[@class='home_icon' and @title='Seminars']")
    private WebElementFacade seminarsIcon;

    //Elements - View drop down
    @FindBy(css = ".gv-view-menu")
    private WebElementFacade viewDropdownButton;
    @FindBy(xpath = "//a[@title='Venues']")
    private WebElementFacade venuesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewAccounts']/a[.='All']")
    private WebElementFacade venuesAllButton;
    @FindBy(xpath = "//div[@id='pop_MainViewAccounts']/a[.='Dormant']")
    private WebElementFacade venuesDormantButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Contacts']")
    private WebElementFacade contactsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewContacts']/a[.='All']")
    private WebElementFacade contactsAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Appointments']")
    private WebElementFacade appointmentsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewAppointments']/a[.='All']")
    private WebElementFacade appointmentsAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Actions']")
    private WebElementFacade actionsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewActivities']/a[.='All']")
    private WebElementFacade actionsAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Sales']")
    private WebElementFacade salesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewSales']/a[.='Sales']")
    private WebElementFacade salesSalesButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Opportunities']")
    private WebElementFacade opportunitiesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewOpps']/a[.='All']")
    private WebElementFacade opportunitiesAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Quotes']")
    private WebElementFacade quotesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewQuotes']/a[.='All']")
    private WebElementFacade quotesAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Products']")
    private WebElementFacade productsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewProducts']/a[.='Product List']")
    private WebElementFacade productsProductListButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Covid']")
    private WebElementFacade covidButton;
    @FindBy(xpath = "//div[@id='pop_MainViewProfiles']/a[.='All']")
    private WebElementFacade covidAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Visits']")
    private WebElementFacade visitsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewProjects']/a[.='All']")
    private WebElementFacade visitsAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Campaigns']")
    private WebElementFacade campaignsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewCampaigns']/a[.='All']")
    private WebElementFacade campaignsAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Seminars']")
    private WebElementFacade seminarsButton;
    @FindBy(xpath = "//div[@id='pop_ViewSeminars']/a[.='All']")
    private WebElementFacade seminarsAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Users']")
    private WebElementFacade usersButton;
    @FindBy(xpath = "//div[@id='pop_MainViewUsers']/a[.='Users List']")
    private WebElementFacade usersUsersListButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Dispenses']")
    private WebElementFacade dispensesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewDispenseList']/a[.='All']")
    private WebElementFacade dispensesAllButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Acuitas Feeds']")
    private WebElementFacade acuitasFeedsButton;
    @FindBy(xpath = "//div[@id='pop_MainViewAcuitasFeeds']/a[.='Acuitas Patient Import']")
    private WebElementFacade acuitasFeedsAcuitasPatientImportButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Care Home Penetration']")
    private WebElementFacade careHomePenetrationButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Home Visit Venues with no Patients']")
    private WebElementFacade homeVisitVenuesWithNoPatientsButton;
    @FindBy(xpath = "//div[@id='MainViewMenu']/a[.='Territories']")
    private WebElementFacade territoriesButton;
    @FindBy(xpath = "//div[@id='pop_TerritoryMainMenu']/a[.='All']")
    private WebElementFacade territoriesAllButton;

    //Elements - Tools drop down
    @FindBy(id = "MainToolsMenu_button")
    private WebElementFacade toolsDropdownButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Reporting']")
    private WebElementFacade reportingButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Recent Events']")
    private WebElementFacade recentEventsButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Search Email']")
    private WebElementFacade searchEmailButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Search Attachments']")
    private WebElementFacade searchAttachmentsButton;
    @FindBy(xpath = "//div[@id='pop_MainToolsNotes']/a[.='Search Notes']")
    private WebElementFacade searchNotesSearchNotesButton;
    @FindBy(xpath = "//div[@id='pop_MainToolsNotes']/a[.='Notice Board']")
    private WebElementFacade searchNotesNoticeBoardButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Search Documents']")
    private WebElementFacade searchDocumentsButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Search Calls']")
    private WebElementFacade searchCallsButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Search Links']")
    private WebElementFacade searchLinksButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Administration']")
    private WebElementFacade administrationButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Patient Signature Capture User Management']")
    private WebElementFacade patientSignatureCaptureUserManagementButton;
    @FindBy(xpath = "//div[@id='pop_MainViewScheduling']/a[.='Diary Entries']")
    private WebElementFacade schedulingDiaryEntriesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewScheduling']/a[.='Diary Entries - Assigned Sub Territories']")
    private WebElementFacade schedulingDiaryEntriesAssignedSubTerritoriesButton;
    @FindBy(xpath = "//div[@id='pop_MainViewScheduling']/a[.='Availability']")
    private WebElementFacade schedulingAvailabilityButton;
    @FindBy(xpath = "//div[@id='pop_MainViewScheduling']/a[.='Diary']")
    private WebElementFacade schedulingDiaryButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Customer Entry']")
    private WebElementFacade customerEntryButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Bulk Documents Creation']")
    private WebElementFacade bulkDocumentsCreationButton;
    @FindBy(xpath = "//div[@id='MainToolsMenu']/a[.='Home Visit Appointment Letter Batch Printing']")
    private WebElementFacade homeVisitAppointmentLetterBatchPrintingButton;

    //Elements - Help drop down
    @FindBy(id = "MainMenuHelp_button")
    private WebElementFacade helpDropdownButton;
    @FindBy(xpath = "//div[@id='MainMenuHelp']/a[.='Online Help']")
    private WebElementFacade onlineHelpOption;
    @FindBy(xpath = "//div[@id='MainMenuHelp']/a[.='Support Enquiry']")
    private WebElementFacade supportEnquiryOption;
    @FindBy(xpath = "//div[@id='MainMenuHelp']/a[.='Gold-Vision Admins']")
    private WebElementFacade goldVisionAdminsOption;
    @FindBy(xpath = "//div[contains(text(),'Gold-Vision Administrators:')]")
    private WebElementFacade goldVisionAdministratorsTabTitle;
    @FindBy(xpath = "//div[@id='MainMenuHelp']/a[.='Remote Assist']")
    private WebElementFacade remoteAssistOption;
    @FindBy(xpath = "//div[@id='MainMenuHelp']/a[.='Chat with Support']")
    private WebElementFacade chatWithSupportOption;
    @FindBy(xpath = "//div[@id='MainMenuHelp']/a[.='About']")
    private WebElementFacade aboutOption;

    //Table elements
    @FindBy(css = "body.MainListBody:nth-child(2) div.ls_main:nth-child(48) table.ls_table tr.ls_e.ui-draggable.ui-draggable-handle:nth-child(7) td.ls_td:nth-child(1) div:nth-child(1) div:nth-child(1) > span.ls_link")
    private WebElementFacade row1Column0entry;
    @FindBy(css = "body.MainListBody:nth-child(2) div.ls_main:nth-child(48) table.ls_table tbody:nth-child(1) tr.ls_e.ui-draggable.ui-draggable-handle:nth-child(7) td.ls_td:nth-child(1) > span.ls_link")
    private WebElementFacade row1Column0entryDormantRecord;

    @FindBy(css = "body.MainListBody:nth-child(2) div.ls_main:nth-child(48) table.ls_table tr.ls_e.ui-draggable.ui-draggable-handle:nth-child(7) td.ls_td:nth-child(2) div:nth-child(1) div:nth-child(1) > span.ls_link")
    private WebElementFacade row1Column1entry;
    @FindBy(css = "body.MainListBody:nth-child(2) div.ls_main:nth-child(48) table.ls_table tr.ls_e.ui-draggable.ui-draggable-handle:nth-child(7) td.ls_td:nth-child(3) div:nth-child(1) div:nth-child(1) > span.ls_link")
    private WebElementFacade row1Column2entry;

    //Scheduling pages
    @FindBy(xpath = "//button[contains(text(),'Optometrist (Selected - 0)')]")
    private WebElementFacade optometristSelectedButton;
    @FindBy(xpath = "//button[contains(text(),'Submit')]")
    private WebElementFacade submitOptometristSelectedButton;
    @FindBy(xpath = "//button[contains(text(),'Next')]")
    private WebElementFacade nextWeekButton;

    //Navigation

    //Navigation - Tools drop down
    public void navigateToToolsReporting(){
        clickElement(toolsDropdownButton);
        clickElement(reportingButton);
    }
    public void navigateToToolsRecentEvents(){
        clickElement(toolsDropdownButton);
        clickElement(recentEventsButton);
    }
    public void navigateToToolsSearchEmail(){
        clickElement(toolsDropdownButton);
        clickElement(searchEmailButton);
    }
    public void navigateToToolsSearchAttachments(){
        clickElement(toolsDropdownButton);
        clickElement(searchAttachmentsButton);
    }
    public void navigateToToolsSearchNotes(){
        clickElement(toolsDropdownButton);
        moveTo("//div[@id='MainToolsMenu']/a[.='Search Notes']");
        clickElement(searchNotesSearchNotesButton);
    }
    public void navigateToToolsSearchNotesNoticeBoard(){
        clickElement(toolsDropdownButton);
        moveTo("//div[@id='MainToolsMenu']/a[.='Search Notes']");
        clickElement(searchNotesNoticeBoardButton);
    }
    public void navigateToToolsSearchDocuments(){
        clickElement(toolsDropdownButton);
        clickElement(searchDocumentsButton);
    }
    public void navigateToToolsSearchCalls(){
        clickElement(toolsDropdownButton);
        clickElement(searchCallsButton);
    }
    public void navigateToToolsSearchLinks(){
        clickElement(toolsDropdownButton);
        clickElement(searchLinksButton);
    }
    public void navigateToToolsAdministration(){
        clickElement(toolsDropdownButton);
        clickElement(administrationButton);
    }
    public void navigateToToolsPatientSignatureCaptureUserManagement(){
        clickElement(toolsDropdownButton);
        clickElement(patientSignatureCaptureUserManagementButton);
    }
    public void navigateToToolsSchedulingDiaryEntries(){
        clickElement(toolsDropdownButton);
        moveTo("//div[@id='MainToolsMenu']/a[.='Scheduling']");
        clickElement(schedulingDiaryEntriesButton);
    }
    public void navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories(){
        clickElement(toolsDropdownButton);
        moveTo("//div[@id='MainToolsMenu']/a[.='Scheduling']");
        clickElement(schedulingDiaryEntriesAssignedSubTerritoriesButton);
    }
    public void navigateToToolsSchedulingAvailability(){
        clickElement(toolsDropdownButton);
        moveTo("//div[@id='MainToolsMenu']/a[.='Scheduling']");
        clickElement(schedulingAvailabilityButton);
    }
    public void navigateToToolsSchedulingDiary(){
        clickElement(toolsDropdownButton);
        moveTo("//div[@id='MainToolsMenu']/a[.='Scheduling']");
        clickElement(schedulingDiaryButton);
    }
    public void navigateToToolsCustomerEntry(){
        clickElement(toolsDropdownButton);
        clickElement(customerEntryButton);
    }
    public void navigateToToolsBulkDocumentsCreation(){
        clickElement(toolsDropdownButton);
        clickElement(bulkDocumentsCreationButton);
    }
    public void navigateToToolsHomeVisitAppointmentLetterBatchPrinting(){
        clickElement(toolsDropdownButton);
        clickElement(homeVisitAppointmentLetterBatchPrintingButton);
    }

    //Navigation - View drop down
    public void navigateToViewVenuesAll(){
        moveTo(".gv-view-menu");
        clickElement(venuesButton);
    }
    public void navigateToViewVenuesDormant(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Venues']");
        clickElement(venuesDormantButton);
    }
    public void navigateToViewContactsAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Contacts']");
        clickElement(contactsAllButton);
    }
    public void navigateToViewAppointmentsAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Appointments']");
        clickElement(appointmentsAllButton);
    }
    public void navigateToViewActionsAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Actions']");
        clickElement(actionsAllButton);
    }
    public void navigateToViewSalesSales(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Sales']");
        clickElement(salesSalesButton);
    }
    public void navigateToViewOpportunitiesAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Opportunities']");
        clickElement(opportunitiesAllButton);
    }
    public void navigateToViewQuotesAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Quotes']");
        clickElement(quotesAllButton);
    }
    public void navigateToViewProductsProductList(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Products']");
        clickElement(productsProductListButton);
    }
    public void navigateToViewCovidAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Covid']");
        clickElement(covidAllButton);
    }
    public void navigateToViewVisitsAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Visits']");
        clickElement(visitsAllButton);
    }
    public void navigateToViewCampaignsAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Campaigns']");
        clickElement(campaignsAllButton);
    }
    public void navigateToViewSeminarsAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Seminars']");
        clickElement(seminarsAllButton);
    }
    public void navigateToViewUsersUsersList(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Users']");
        clickElement(usersUsersListButton);
    }
    public void navigateToViewDispensesAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Dispenses']");
        clickElement(dispensesAllButton);
    }
    public void navigateToViewAcuitasFeedsAcuitasPatientImport(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Acuitas Feeds']");
        clickElement(acuitasFeedsAcuitasPatientImportButton);
    }
    public void navigateToViewCareHomePenetration() {
        clickElement(viewDropdownButton);
        clickElement(careHomePenetrationButton);
    }
    public void navigateToViewHomeVisitVenuesWithNoPatients() {
        clickElement(viewDropdownButton);
        clickElement(homeVisitVenuesWithNoPatientsButton);
    }
    public void navigateToViewTerritoriesAll(){
        clickElement(viewDropdownButton);
        moveTo("//div[@id='MainViewMenu']/a[.='Territories']");
        clickElement(territoriesAllButton);
    }

    //Navigation - Help drop down
    public void navigateToHelpOnlineHelp(){
        clickElement(helpDropdownButton);
        clickElement(onlineHelpOption);
    }
    public void navigateToHelpSupportEnquiry(){
        clickElement(helpDropdownButton);
        clickElement(supportEnquiryOption);
    }
    public void navigateToHelpGoldVisionAdmins(){
        clickElement(helpDropdownButton);
        clickElement(goldVisionAdminsOption);
    }
    public void navigateToHelpRemoteAssist(){
        clickElement(helpDropdownButton);
        clickElement(remoteAssistOption);
    }
    public void navigateToHelpChatWithSupport(){
        clickElement(helpDropdownButton);
        clickElement(chatWithSupportOption);
    }
    public void navigateToHelpAbout(){
        clickElement(helpDropdownButton);
        clickElement(aboutOption);
    }

    //Record drop down navigation

    public void navigateToOptometristInfo() {
        twoStageDropDownClick(recordSecondDropDown, "//div[@id='CRMMenu2']/a[.='Details']", recordOptometristInfoDropDownOption);
    }

    public void navigateToOptometristDiaryEntries() {
        twoStageDropDownClick(recordSecondDropDown, "//div[@id='CRMMenu2']/a[.='Details']", recordDiaryEntriesDropDownOption);
    }



    //Clicks

    //Click icons
    public void clickHomeIcon() {
        clickElement(homeIcon);
    }
    public void clickVenuesIcon() {
        clickElement(venuesIcon);
    }
    public void clickContactsIcon() {
        clickElement(contactsIcon);
    }
    public void clickAppointmentsIcon() {
        clickElement(appointmentsIcon);
    }
    public void clickActionsIcon() {
        clickElement(actionsIcon);
    }
    public void clickOpportunitiesIcon() {
        clickElement(opportunitiesIcon);
    }
    public void clickQuotesIcon() {
        clickElement(quotesIcon);
    }
    public void clickCovidIcon() {
        clickElement(covidIcon);
    }
    public void clickVisitsIcon() {
        clickElement(visitsIcon);
    }
    public void clickCampaignsIcon() {
        clickElement(campaignsIcon);
    }
    public void clickSeminarsIcon() {
        clickElement(seminarsIcon);
    }

    //Assertions

    public void correctTitle(String title){
        waitABit(5000);
        assertEquals(true, getTitle().contains(title));
    }
    public void incorrectTitle(String title) {
        assertEquals(false, getTitle().contains(title));
    }

    public void correctURL(String expectedURL) {
        assertEquals(true, getDriver().getCurrentUrl().equals(expectedURL));
    }
    public void incorrectURL(String expectedURL) {
        assertEquals(false, getDriver().getCurrentUrl().equals(expectedURL));
    }

    public void correctTabTitleText(WebElementFacade tabTitleElement, String tabTitleText) {
        switchToIFrame("IFrame1");
        assertElementContainsText(tabTitleElement, tabTitleText);
    }
    public void switchIFrameAndAssertCorrectElementText(WebElementFacade element, String text) {
        switchToIFrame("IFrame1");
        assertElementContainsText(element, text);
    }

    public void correctHomePageTabTitleText(WebElementFacade homePageTabTitle, String homePageTabTitleText) {
        switchToIFrame("HomeFrame");
        assertElementContainsText(homePageTabTitle, homePageTabTitleText);
    }

    public void correctEntryInRow1Column0(String entry) {
        assertElementContainsText(row1Column0entry, entry);
    }
    public void correctEntryInRow1Column1(String entry) {
        assertElementContainsText(row1Column1entry, entry);
    }

    //General

    //Clicking and searching of core application data
    @FindBy(xpath = "//input[@id='col0']")
    private WebElementFacade column0SearchTextField;
    @FindBy(xpath = "//input[@id='col1']")
    private WebElementFacade column1SearchTextField;

    //Name search option (Usually)
    public void clickFirstInCol0List(){
        clickElement(row1Column0entry);
    }
    public void clickFirstInCol0VenueDormantRecordList(){
        clickElement(row1Column0entryDormantRecord);
    }
    public void clickFirstInCol1List(){
        clickElement(row1Column1entry);
    }
    public void clickFirstInCol2List(){
        clickElement(row1Column2entry);
    }
    @FindBy(css = "//td[@colspan='10']/div[@class='ls_title_wrapper']/div[@class='ls_loption' and contains(@title,'Refresh list')]")
    private WebElementFacade refreshRecordIcon;
    public void clickTheRefreshIcon(){
        clickElement(refreshRecordIcon);
        System.out.println("click refresh");
        waitABit(3000);
    }

    @FindBy(xpath = "//div[@id='CRMMenu_button']")
    private WebElementFacade contactRecordHeaderButton;
    @FindBy(xpath = "//ul[@class='gv-toolbar-items']/li[@data-gv-action='screen-edit']/span")
    private WebElementFacade recordEditButton;
    @FindBy(xpath = "//li[contains(@class,'gv-toolbar-item') and @title='Save']")
    private WebElementFacade recordSaveButton;
    @FindBy(xpath = "//div[@title='Close']/span[contains(@class,'gv-icon-close')]")
    private WebElementFacade recordCloseButton;

    @FindBy(xpath = "//div[@id='CRMMenu_button']")
    private WebElementFacade recordFirstDropDown;
    @FindBy(xpath = "//div[@id='CRMMenu2_button']")
    private WebElementFacade recordSecondDropDown;
    @FindBy(xpath = "//div[@id='CRMMenu2']/a[.='Details']")
    private WebElementFacade recordBusinessDetailsDropDownOption;
    @FindBy(xpath = "//div[@id='pop_ContactDetails']/a[.='Optometrist Info']")
    private WebElementFacade recordOptometristInfoDropDownOption;
    @FindBy(xpath = "//div[@id='pop_ContactDetails']/a[.='Diary Entries']")
    private WebElementFacade recordDiaryEntriesDropDownOption;

    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Monday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoMondayTickBox;
    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Tuesday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoTuesdayTickBox;
    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Wednesday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoWednesdayTickBox;
    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Thursday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoThursdayTickBox;
    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Friday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoFridayTickBox;
    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Saturday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoSaturdayTickBox;
    @FindBy(xpath = "//td[@class='itm_label_free' and contains(.,'Sunday')]/input[@type='checkbox']")
    private WebElementFacade optometristInfoSundayTickBox;

    @FindBy(xpath = "//a[contains(text(),'Delete')]")
    private WebElementFacade deleteRecordButton;
    @FindBy(xpath = "//input[@id='msg_btn_0']")
    private WebElementFacade confirmDeleteRecordButton;

    public void clickRecordEditButton() {
        clickElement(recordEditButton);
    }
    public void clickRecordSaveButton() {
        clickElement(recordSaveButton);
    }
    public void clickRecordCloseButton() {
        waitABit(6000);
        recordCloseButton.waitUntilClickable().click();
    }
    public void deleteCurrentOpenRecord(){
        clickElement(contactRecordHeaderButton);
        clickElement(deleteRecordButton);
        clickElement(confirmDeleteRecordButton);
    }
    @FindBy(xpath = "//a[contains(text(),'Close Window')]")
    private WebElementFacade closeDeletedRecordButton;
    public void closeCurrentDeletedRecord(){
        clickElement(closeDeletedRecordButton);
        waitABit(3000);
    }

    public void tickOptometristInfoTickBoxes() {
        clickElement(optometristInfoMondayTickBox);
        clickElement(optometristInfoTuesdayTickBox);
        clickElement(optometristInfoWednesdayTickBox);
        clickElement(optometristInfoThursdayTickBox);
        clickElement(optometristInfoFridayTickBox);
        clickElement(optometristInfoSaturdayTickBox);
        clickElement(optometristInfoSundayTickBox);
    }

    //Enter Text Function

    public void enterGivenTextInTextField(WebElementFacade textBox, String textInput){
        typeInto(textBox, textInput);
    }

    //Click drop down option functions
    public void clickDropDownOption(WebElementFacade box, WebElementFacade option) {
        clickElement(box);
        clickElement(option);
    }

    public void twoStageDropDownClick(WebElementFacade box, String hoverElementXPath, WebElementFacade optionToClick) {
        clickElement(box);
        moveTo(hoverElementXPath);
        clickElement(optionToClick);
    }
    public void threeStageDropDownClick(WebElementFacade box, String hoverElementXPath, String secondHoverElementXPath, WebElementFacade optionToClick) {
        clickElement(box);
        moveTo(hoverElementXPath);
        moveTo(secondHoverElementXPath);
        clickElement(optionToClick);
    }
    //Switch tab functions
    public void switchToNextTab() {
        switchToChildWindow();
    }
    public void switchToOriginalTab() {
        switchToOriginalWindow();
    }
    public void closeTab() {
        getDriver().close();
    }

    //Scheduling pages
    public void clickOptometristSelectedButton() {
        element(optometristSelectedButton).waitUntilPresent();
        clickElement(optometristSelectedButton);
    }
    public void clickSubmitOptometristSelectedButton(){clickElement(submitOptometristSelectedButton);}
    public void clickNextWeekButton(){clickElement(nextWeekButton);}


    public void selectAllFromCategoryDropDown() {
        categoryOptionsDropDown.click();
        categoryOptionsDropDownAll.click();
    }


}
