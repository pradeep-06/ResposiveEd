package domiciliary.extentions;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class DomiciliaryHelpers {
    static String randomSurname;
    static String randomDateOfLastSightTest;
    static String randomDateOfBirth;
    static int index;
    static char randomChar;
    static String[] months = {"01","02","03","04","05","06","07","08","09","10","11","12"};
    static String[] monthsWith30Days = {"01","03","04","05","06","07","08","09","10","11","12"};
    static String[] monthsWith31Days = {"01","03","05","07","08","10","12"};
    static String numbers = "0123456789";
    static String month = null;
    //Generate random strings

    public static String getDiaryEntriesDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime now = LocalDateTime.now();
        String dateNow = dtf.format(now);
        if (dateNow.charAt(3) == '1') {
            StringBuilder date = new StringBuilder(dateNow);
            date.setCharAt(3, '0');
            date.setCharAt(9, '4');
            if (dateNow.charAt(4) == '0') {
                date.setCharAt(4, '1');
                return date.toString();
            } else if (dateNow.charAt(4) == '1') {
                date.setCharAt(4, '2');
                return date.toString();
            } else {
                date.setCharAt(4, '3');
                return date.toString();
            }
        } else {
            dateNow = dtf.format(now.plusMonths(3));
            return dateNow;
        }
    }

    public static String getVisitDateXDaysAhead(int amountOfDaysAhead) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime datePlusX = LocalDateTime.now().plusDays(amountOfDaysAhead);
        return dtf.format(datePlusX);
    }

    public static String getVisitDateWith48HoursNotice() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DayOfWeek dayOfWeek = LocalDateTime.now().getDayOfWeek();
        if (dayOfWeek.toString().equals("WEDNESDAY") || dayOfWeek.toString().equals("THURSDAY") || dayOfWeek.toString().equals("FRIDAY")) {
            return dtf.format(LocalDateTime.now().plusDays(5));
        } else {
            return dtf.format(LocalDateTime.now().plusDays(3));
        }
    }
    public static String getVisitDateWith3WeeksNotice() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DayOfWeek dayOfWeek = LocalDateTime.now().getDayOfWeek();
        if (dayOfWeek.toString().equals("FRIDAY")) {
            return dtf.format(LocalDateTime.now().plusDays(24));
        } else {
            return dtf.format(LocalDateTime.now().plusDays(22));
        }
    }

    public static String getVisitDateWith4WeeksNotice() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DayOfWeek dayOfWeek = LocalDateTime.now().getDayOfWeek();
        if (dayOfWeek.toString().equals("FRIDAY")) {
            return dtf.format(LocalDateTime.now().plusDays(31));
        } else {
            return dtf.format(LocalDateTime.now().plusDays(29));
        }
    }
    public static String getVisitDateWith5WeeksNotice() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DayOfWeek dayOfWeek = LocalDateTime.now().getDayOfWeek();
        if (dayOfWeek.toString().equals("FRIDAY")) {
            return dtf.format(LocalDateTime.now().plusDays(38));
        } else {
            return dtf.format(LocalDateTime.now().plusDays(36));
        }
    }

    public static String generateRandomSurname(int length) {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder surnameSB = new StringBuilder();
        Random random = new Random();
        for(int i = 0; i < length; i++) {
            index = random.nextInt(alphabet.length());
            randomChar = alphabet.charAt(index);
            surnameSB.append(randomChar);
        }
        randomSurname = surnameSB.toString();
        System.out.println("Random Surname is: " + randomSurname);
        return randomSurname;
    }

    public static String generateRandomDateOfBirth() {
        StringBuilder dateOfBirthSB = new StringBuilder();
        Random random3 = new Random();
        index = random3.nextInt(numbers.substring(0, 4).length());
        randomChar = numbers.substring(0, 4).charAt(index);
        dateOfBirthSB.append(randomChar);
        if (dateOfBirthSB.toString().equals("3")) {
            index = random3.nextInt(numbers.substring(0,2).length());
            randomChar = numbers.substring(0, 2).charAt(index);
        } else if (dateOfBirthSB.toString().equals("0")) {
            index = random3.nextInt(numbers.substring(1, 10).length());
            randomChar = numbers.substring(1, 10).charAt(index);
        } else {
            index = random3.nextInt(numbers.length());
            randomChar = numbers.charAt(index);
        }

        dateOfBirthSB.append(randomChar).append("/");
        if (dateOfBirthSB.toString().equals("31/")) {
            index = random3.nextInt(monthsWith31Days.length);
            month = monthsWith31Days[index];
        } else if (dateOfBirthSB.toString().equals("29/") || dateOfBirthSB.toString().equals("30/")) {
            index = random3.nextInt(monthsWith30Days.length);
            month = monthsWith30Days[index];
        } else {
            index = random3.nextInt(months.length);
            month = months[index];
        }
        dateOfBirthSB.append(month).append("/19");
        index = random3.nextInt(numbers.substring(2,10).length());
        randomChar = numbers.substring(2,10).charAt(index);
        dateOfBirthSB.append(randomChar);
        index = random3.nextInt(numbers.length());
        randomChar = numbers.charAt(index);
        dateOfBirthSB.append(randomChar);
        randomDateOfBirth = dateOfBirthSB.toString();
        System.out.println("Date of birth is: " + randomDateOfBirth);
        return randomDateOfBirth;
    }

    public static String generateRandomDateOfLastSightTest() {
        StringBuilder dateOfLastSightTestSB = new StringBuilder();
        Random random2 = new Random();
        index = random2.nextInt(numbers.substring(0, 4).length());
        randomChar = numbers.substring(0, 4).charAt(index);
        dateOfLastSightTestSB.append(randomChar);
        if (dateOfLastSightTestSB.toString().equals("3")) {
            index = random2.nextInt(numbers.substring(0, 2).length());
            randomChar = numbers.substring(0, 2).charAt(index);
        } else if (dateOfLastSightTestSB.toString().equals("0")) {
            index = random2.nextInt(numbers.substring(1, 10).length());
            randomChar = numbers.substring(1, 10).charAt(index);
        } else {
            index = random2.nextInt(numbers.length());
            randomChar = numbers.charAt(index);
        }
        dateOfLastSightTestSB.append(randomChar).append("/");
        if (dateOfLastSightTestSB.toString().equals("31")) {
            index = random2.nextInt(monthsWith31Days.length);
            month = monthsWith31Days[index];
        } else if (dateOfLastSightTestSB.toString().equals("29") || dateOfLastSightTestSB.toString().equals("30")) {
            index = random2.nextInt(monthsWith30Days.length);
            month = monthsWith30Days[index];
        } else {
            index = random2.nextInt(months.length);
            month = months[index];
        }
        dateOfLastSightTestSB.append(month).append("/2021");
        randomDateOfLastSightTest = dateOfLastSightTestSB.toString();
        System.out.println("Date of last sight test is: " + randomDateOfLastSightTest);
        return randomDateOfLastSightTest;
    }
}
