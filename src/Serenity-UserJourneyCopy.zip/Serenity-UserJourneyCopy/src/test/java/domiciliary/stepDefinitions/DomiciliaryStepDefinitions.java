package domiciliary.stepDefinitions;

import Framework.DataManager.TestDataManager;
import Framework.extensions.StafUtils;
import domiciliary.extentions.DomiciliaryHelpers;
import domiciliary.steps.*;
import domiciliary.steps.Administrator.AdminPageSteps;
import domiciliary.steps.CoreApplication.*;
import domiciliary.steps.CoreApplication.Popups.ContactPopup.ContactPopupPageSteps;
import domiciliary.steps.CoreApplication.Popups.ContactPopup.OptometristDiaryEntriesPopupPageSteps;
import domiciliary.steps.CoreApplication.Popups.VenuePopup.VenuePopupPageSteps;
import domiciliary.steps.CustomerEntry.CustomerEntryPageSteps;
import domiciliary.steps.CustomerEntry.SchedulingAvailabilitySteps;
import domiciliary.steps.CustomerEntry.SchedulingDiarySteps;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class DomiciliaryStepDefinitions extends ScenarioSteps {


    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(DomiciliaryStepDefinitions.class);

    //Steps files instances
    @Steps
    CommonPageSteps commonPageSteps;
    @Steps
    ActionsPageSteps actionsPageSteps;
    @Steps
    AcuitasPatientsImportPageSteps acuitasPatientsImportPageSteps;
    @Steps
    AdminPageSteps adminPageSteps;
    @Steps
    AppointmentsPageSteps appointmentsPageSteps;
    @Steps
    CampaignsPageSteps campaignsPageSteps;
    @Steps
    CareHomePenetrationHistoryPageSteps careHomePenetrationHistoryPageSteps;
    @Steps
    ContactsPageSteps contactsPageSteps;
    @Steps
    CovidPageSteps covidPageSteps;
    @Steps
    CustomerEntryPageSteps customerEntryPageSteps;
    @Steps
    DispensesPageSteps dispensesPageSteps;
    @Steps
    GoldVisionAdministratorsPageSteps goldVisionAdministratorsPageSteps;
    @Steps
    HandoversPageSteps handoversPageSteps;
    @Steps
    HomePageSteps homePageSteps;
    @Steps
    OpportunitiesPageSteps opportunitiesPageSteps;
    @Steps
    ProductPageSteps productPageSteps;
    @Steps
    QuotesPageSteps quotesPageSteps;
    @Steps
    SalesPageSteps salesPageSteps;
    @Steps
    SchedulingDiaryEntriesPageSteps schedulingDiaryEntriesPageSteps;
    @Steps
    SchedulingDiaryEntriesAssignedSubTerritoriesPageSteps schedulingDiaryEntriesAssignedSubTerritoriesPageSteps;
    @Steps
    SchedulingAvailabilitySteps schedulingAvailabilitySteps;
    @Steps
    SchedulingDiarySteps schedulingDiarySteps;
    @Steps
    SearchLinksPageSteps searchLinksPageSteps;
    @Steps
    SearchCallsPageSteps searchCallsPageSteps;
    @Steps
    SearchDocumentsPageSteps searchDocumentsPageSteps;
    @Steps
    SearchNotesNoticeBoardPageSteps searchNotesNoticeBoardPageSteps;
    @Steps
    SearchNotesPageSteps searchNotesPageSteps;
    @Steps
    SearchAttachmentsPageSteps searchAttachmentsPageSteps;
    @Steps
    SearchEmailPageSteps searchEmailPageSteps;
    @Steps
    RecentEventsPageSteps recentEventsPageSteps;
    @Steps
    ReportingPageSteps reportingPageSteps;
    @Steps
    SeminarsPageSteps seminarsPageSteps;
    @Steps
    TerritoriesPageSteps territoriesPageSteps;
    @Steps
    UsersPageSteps usersPageSteps;
    @Steps
    VenuesPageSteps venuesPageSteps;
    @Steps
    VisitsPageSteps visitsPageSteps;
    @Steps
    VenuePopupPageSteps venuePopupPageSteps;
    @Steps
    ContactPopupPageSteps contactPopupPageSteps;
    @Steps
    OptometristDiaryEntriesPopupPageSteps optometristDiaryEntriesPopupPageSteps;



    //Login
    @Step("Go to incorrect login URL (username and password wrong)")
    public void goToIncorrectLoginURLUsernameAndPasswordWrong() {
        String username = testDataManager.getTestInputCommonData("credentials.incorrectUsername");
        String password = testDataManager.getTestInputCommonData("credentials.incorrectPassword");
        homePageSteps.loginWithCredentials(username, password);
        commonPageSteps.assertIncorrectPageTitle("Gold-Vision");
    }
    @Step("Go to incorrect login URL (username wrong)")
    public void goToIncorrectLoginURLUsernameWrong() {
        String username = testDataManager.getTestInputCommonData("credentials.incorrectUsername");
        String password = testDataManager.getTestInputCommonData("credentials.correctPassword");
        homePageSteps.loginWithCredentials(username, password);
        commonPageSteps.assertIncorrectPageTitle("Gold-Vision");
    }
    @Step("Go to incorrect login URL (password wrong)")
    public void goToIncorrectLoginURLPasswordWrong() {
        String username = testDataManager.getTestInputCommonData("credentials.correctUsername");
        String password = testDataManager.getTestInputCommonData("credentials.incorrectPassword");
        homePageSteps.loginWithCredentials(username, password);
        commonPageSteps.assertIncorrectPageTitle("Gold-Vision");
    }

    @Step("Go to correct login URL (home page is loaded)")
    public void goToCorrectLoginURL() {
        homePageSteps.openHomePage();
        homePageSteps.loginWithCredentials(System.getenv("GV8_AUTOMATION_EMAIL"), System.getenv("GV8_AUTOMATION_PASSWORD"));
        commonPageSteps.assertCorrectPageTitle("Gold-Vision");
    }

    //Open page

    @Step("Open home page")
    public void openHomePage() {
        homePageSteps.openHomePage();
    }
    @Step("Open customer entry")
    public void openCustomerEntry() {
        customerEntryPageSteps.openCustomerEntry();
    }
    @Step("Open admin")
    public void openAdmin() {
        adminPageSteps.openAdmin();
    }

    //Switch tabs
    @Step("Switch to the next tab")
    public void switchToNextTab() {
        commonPageSteps.switchToNextTab();
        waitABit(5000);
    }
    @Step("Switch to the record pop up")
    public void switchToRecordPopUp() {
        commonPageSteps.switchToNextTab();
    }
    @Step("Switch to the original tab")
    public void switchToOriginalTab() {
        commonPageSteps.switchToOriginalTab();
        waitABit(5000);
    }
    @Step("Close tab")
    public void closeTab() {
        commonPageSteps.closeTab();
    }
    @Step("Switch back to Goldvision")
    public void switchBackToGoldvision() {
        commonPageSteps.switchToOriginalTab();
    }
    @Step("Switch to next tab and assert correct page title")
    public void switchTabsAndAssertCorrectPageTitle(String pageTitle) {
        commonPageSteps.switchToNextTab();
        commonPageSteps.assertCorrectPageTitle(pageTitle);
    }
    @Step("Switch to next tab and assert correct URL")
    public void switchTabsAndAssertCorrectURL(String url) {
        commonPageSteps.switchToNextTab();
        commonPageSteps.assertCorrectURL(url);
    }

    //URL assertions

    @Step("Assert page URL is correct")
    public void assertCorrectURL(String expectedURL) {
        commonPageSteps.assertCorrectURL(expectedURL);
    }
    @Step("Assert page URL is incorrect")
    public void assertIncorrectURL(String expectedURL) {
        commonPageSteps.assertIncorrectURL(expectedURL);
    }

    //Data table assertions
    @Step("Assert patient name in row 1 is correct")
    public void assertCorrectPatientNameInRow1(String patientName) {
        commonPageSteps.assertCorrectPatientNameInRow1(patientName);
    }
    @Step("Assert primary contact in row 1 is correct")
    public void assertCorrectPrimaryContactInRow1(String primaryContact) {
        commonPageSteps.assertCorrectPrimaryContactInRow1(primaryContact);
    }
    @Step("Assert venue name in row 1 is correct")
    public void assertCorrectVenueNameInRow1(String venueName) {
        commonPageSteps.assertCorrectVenueNameInRow1(venueName);
    }
    //Tab title assertions
    @Step("Assert Actions tab title is present")
    public void assertActionsTabTitleIsPresent() {
        actionsPageSteps.assertActionsTabTitleIsPresent();
    }
    @Step("Assert Acuitas Patients Import title is present")
    public void assertAcuitasPatientsImportTabTitleIsPresent() {
        acuitasPatientsImportPageSteps.assertAcuitasPatientsImportTabTitleIsPresent();
    }
    @Step("Assert Appointments tab title is present")
    public void assertAppointmentsTabTitleIsPresent() {
        appointmentsPageSteps.assertAppointmentsTabTitleIsPresent();
    }
    @Step("Assert Campaigns tab title is present")
    public void assertCampaignsTabTitleIsPresent() {
        campaignsPageSteps.assertCampaignsTabTitleIsPresent();
    }
    @Step("Assert Care Home Penetration History tab title is present")
    public void assertCareHomePenetrationHistoryTabTitleIsPresent() {
        careHomePenetrationHistoryPageSteps.assertCareHomePenetrationHistoryTabTitleIsPresent();
    }
    @Step("Assert Contacts tab title is present")
    public void assertContactsTabTitleIsPresent() {
        contactsPageSteps.assertContactsTabTitleIsPresent();
    }
    @Step("Assert Covid tab title is present")
    public void assertCovidTabTitleIsPresent() {
        covidPageSteps.assertCovidTabTitleIsPresent();
    }
    @Step("Assert Dispenses tab title is present")
    public void assertDispensesTabTitleIsPresent() {
        dispensesPageSteps.assertDispensesTabTitleIsPresent();
    }
    @Step("Assert Gold-Vision Administrators tab title is present")
    public void assertGoldVisionAdministratorsTabTitleIsPresent() {
        goldVisionAdministratorsPageSteps.assertGoldVisionAdministratorsTabTitleIsPresent();
    }
    @Step("Assert Handovers tab title is present")
    public void assertHandoversTabTitleIsPresent() {
        handoversPageSteps.assertHandoversTabTitleIsPresent();
    }
    @Step("Assert Home page tab title is present")
    public void assertHomePageTabTitleIsPresent() {
        homePageSteps.assertHomePageTabTitleIsPresent();
    }
    @Step("Assert Opportunities tab title is present")
    public void assertOpportunitiesTabTitleIsPresent() {
        opportunitiesPageSteps.assertOpportunitiesTabTitleIsPresent();
    }
    @Step("Assert Product page tab title is present")
    public void assertProductTabTitleIsPresent() {
        productPageSteps.assertProductTabTitleIsPresent();
    }
    @Step("Assert Quotes page tab title is present")
    public void assertQuotesTabTitleIsPresent() {
        quotesPageSteps.assertQuotesTabTitleIsPresent();
    }
    @Step("Assert Sales page tab title is present")
    public void assertSalesTabTitleIsPresent() {
        salesPageSteps.assertSalesTabTitleIsPresent();
    }
    @Step("Assert Seminars page tab title is present")
    public void assertSeminarsTabTitleIsPresent() {
        seminarsPageSteps.assertSeminarsTabTitleIsPresent();
    }
    @Step("Assert Territories page tab title is present")
    public void assertTerritoriesTabTitleIsPresent() {
        territoriesPageSteps.assertTerritoriesTabTitleIsPresent();
    }
    @Step("Assert Venues tab title is present")
    public void assertVenuesTabTitleIsPresent() {
        venuesPageSteps.assertVenuesTabTitleIsPresent();
    }
    @Step("Assert Visits page tab title is present")
    public void assertVisitsTabTitleIsPresent() {
        visitsPageSteps.assertVisitsTabTitleIsPresent();
    }
    @Step("Assert Users page tab title is present")
    public void assertUsersTabTitleIsPresent() {
        usersPageSteps.assertUsersTabTitleIsPresent();
    }
    @Step("Assert Reporting tab title is present")
    public void switchTabsAndAssertReportingTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        reportingPageSteps.assertReportingTabTitleIsPresent();
    }
    @Step("Assert Reporting tab title is present")
    public void assertReportingTabTitleIsPresent() {
        reportingPageSteps.assertReportingTabTitleIsPresent();
    }
    @Step("Assert Recent Events tab title is present")
    public void switchTabsAndAssertRecentEventsTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        recentEventsPageSteps.assertRecentEventsTabTitleIsPresent();
    }
    @Step("Assert Search Email tab title is present")
    public void switchTabsAndAssertSearchEmailTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchEmailPageSteps.assertSearchEmailTabTitleIsPresent();
    }
    @Step("Assert Search Attachments tab title is present")
    public void switchTabsAndAssertSearchAttachmentsTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchAttachmentsPageSteps.assertSearchAttachmentsTabTitleIsPresent();
    }
    @Step("Assert Search Notes tab title is present")
    public void switchTabsAndAssertSearchNotesTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchNotesPageSteps.assertSearchNotesTabTitleIsPresent();
    }
    @Step("Assert Search Notes Notice Board tab title is present")
    public void switchTabsAndAssertSearchNotesNoticeBoardTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchNotesNoticeBoardPageSteps.assertSearchNotesNoticesBoardTabTitleIsPresent();
    }
    @Step("Assert Search Documents tab title is present")
    public void switchTabsAndAssertSearchDocumentsTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchDocumentsPageSteps.assertSearchDocumentsTabTitleIsPresent();
    }
    @Step("Assert Search Calls tab title is present")
    public void switchTabsAndAssertSearchCallsTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchCallsPageSteps.assertSearchCallsTabTitleIsPresent();
    }
    @Step("Assert Search Links tab title is present")
    public void switchTabsAndAssertSearchLinksTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        searchLinksPageSteps.assertSearchLinksTabTitleIsPresent();
    }
    @Step("Assert Optometrist Diary Entries tab title is present")
    public void switchTabsAndAssertOptometristDiaryEntriesTabTitleIsPresent() {
        commonPageSteps.switchToNextTab();
        schedulingDiaryEntriesPageSteps.assertSchedulingDiaryEntriesTabTitleIsPresent();
    }
    @Step("Assert Optometrist Diary Entries Assigned Sub Territories tab title is present")
    public void assertOptometristDiaryEntriesAssignedSubTerritoriesTabTitleIsPresent() {
        schedulingDiaryEntriesAssignedSubTerritoriesPageSteps.assertSchedulingDiaryEntriesAssignedSubTerritoriesTabTitleIsPresent();
    }
    //Reporting sub tab assertions
    @Step("Assert reporting sub tabs are present")
    public void assertReportingSubTabsArePresent() {
        reportingPageSteps.assertMyReportsSubTabIsPresent();
        reportingPageSteps.assertStandardSubTabIsPresent();
        reportingPageSteps.assertUserDefinedSubTabIsPresent();
        reportingPageSteps.assertAllSubTabIsPresent();
    }

    //Record assertions
    @Step("Assert first diary entry date is correct")
    public void assertFirstDiaryEntryDateIsCorrect(String date) {
        optometristDiaryEntriesPopupPageSteps.assertFirstDiaryEntryDateIsCorrect(date);
    }

    //Navigation

    //Navigation - Tools drop down
    @Step("Navigate to Tools -> Reporting")
    public void navigateToToolsReporting() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsReporting();
        reportingPageSteps.assertReportingTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Recent Events")
    public void navigateToToolsRecentEvents() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsRecentEvents();
        recentEventsPageSteps.assertRecentEventsTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Email")
    public void navigateToToolsSearchEmail() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchEmail();
        searchEmailPageSteps.assertSearchEmailTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Attachments")
    public void navigateToToolsSearchAttachments() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchAttachments();
        searchAttachmentsPageSteps.assertSearchAttachmentsTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Notes -> Search Notes")
    public void navigateToToolsSearchNotes() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchNotes();
        searchNotesPageSteps.assertSearchNotesTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Notes -> Notice Board")
    public void navigateToToolsSearchNotesNoticeBoard() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchNotesNoticeBoard();
        searchNotesNoticeBoardPageSteps.assertSearchNotesNoticesBoardTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Documents")
    public void navigateToToolsSearchDocuments() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchDocuments();
        searchDocumentsPageSteps.assertSearchDocumentsTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Calls")
    public void navigateToToolsSearchCalls() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchCalls();
        searchCallsPageSteps.assertSearchCallsTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Search Links")
    public void navigateToToolsSearchLinks() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSearchLinks();
        searchLinksPageSteps.assertSearchLinksTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Administration")
    public void navigateToToolsAdministration() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsAdministration();
    }
    @Step("Navigate to Tools -> Patient Signature Capture User Management")
    public void navigateToToolsPatientSignatureCaptureUserManagement() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsPatientSignatureCaptureUserManagement();
    }
    @Step("Navigate to Tools -> Scheduling -> Diary Entries")
    public void navigateToToolsSchedulingDiaryEntries() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSchedulingDiaryEntries();
    }
    @Step("Navigate to Tools -> Scheduling -> Diary Entries - Assigned Sub Territories")
    public void navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSchedulingDiaryEntriesAssignedSubTerritories();
        schedulingDiaryEntriesAssignedSubTerritoriesPageSteps.assertSchedulingDiaryEntriesAssignedSubTerritoriesTabTitleIsPresent();
    }
    @Step("Navigate to Tools -> Scheduling - Availability")
    public void navigateToToolsSchedulingAvailability() {
        schedulingAvailabilitySteps.openAvailabilityPage();
    }
    @Step("Navigate to Tools -> Scheduling - Diary")
    public void navigateToToolsSchedulingDiary() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsSchedulingDiary();
    }
    @Step("Navigate to Tools -> Customer Entry")
    public void navigateToToolsCustomerEntry() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsCustomerEntry();
    }
    @Step("Navigate to Tools -> Bulk Documents Creation")
    public void navigateToToolsBulkDocumentsCreation() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsBulkDocumentsCreation();
    }
    @Step("Navigate to Tools -> Home Visit Appointment Letter Batch Printing")
    public void navigateToToolsHomeVisitAppointmentLetterBatchPrinting() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToToolsHomeVisitAppointmentLetterBatchPrinting();
    }

    //Navigation - View drop down
    @Step("Navigate to View -> Venues -> All")
    public void navigateToViewVenuesAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewVenuesAll();
        commonPageSteps.selectAllFromCategoryDropDown();
    }
    @Step("Navigate to View -> Venues -> Dormant")
    public void navigateToViewVenuesDormant() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewVenuesDormant();
    }
    @Step("Navigate to View -> Contacts -> All")
    public void navigateToViewContactsAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewContactsAll();
        contactsPageSteps.assertContactsTabTitleIsPresent();
    }
    @Step("Navigate to View -> Appointments -> All")
    public void navigateToViewAppointmentsAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewAppointmentsAll();
        appointmentsPageSteps.assertAppointmentsTabTitleIsPresent();
    }
    @Step("Navigate to View -> Actions -> All")
    public void navigateToViewActionsAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewActionsAll();
        actionsPageSteps.assertActionsTabTitleIsPresent();
    }
    @Step("Navigate to View -> Sales -> Sales")
    public void navigateToViewSalesSales() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewSalesSales();
        salesPageSteps.assertSalesTabTitleIsPresent();
    }
    @Step("Navigate to View -> Opportunities -> All")
    public void navigateToViewOpportunitiesAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewOpportunitiesAll();
        opportunitiesPageSteps.assertOpportunitiesTabTitleIsPresent();
    }
    @Step("Navigate to View -> Quotes -> All")
    public void navigateToViewQuotesAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewQuotesAll();
        quotesPageSteps.assertQuotesTabTitleIsPresent();
    }
    @Step("Navigate to View -> Products -> Product List")
    public void navigateToViewProductsProductList() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewProductsProductList();
        productPageSteps.assertProductTabTitleIsPresent();
    }
    @Step("Navigate to View -> Covid -> All")
    public void navigateToViewCovidAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewCovidAll();
        covidPageSteps.assertCovidTabTitleIsPresent();
    }
    @Step("Navigate to View -> Visits -> All")
    public void navigateToViewVisitsAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewVisitsAll();
        visitsPageSteps.assertVisitsTabTitleIsPresent();
    }
    @Step("Navigate to View -> Campaigns -> All")
    public void navigateToViewCampaignsAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewCampaignsAll();
        campaignsPageSteps.assertCampaignsTabTitleIsPresent();
    }
    @Step("Navigate to View -> Seminars -> All")
    public void navigateToViewSeminarsAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewSeminarsAll();
        seminarsPageSteps.assertSeminarsTabTitleIsPresent();
    }
    @Step("Navigate to View -> Users -> Users List")
    public void navigateToViewUsersUsersList() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewUsersUsersList();
        usersPageSteps.assertUsersTabTitleIsPresent();
    }
    @Step("Navigate to View -> Dispenses -> All")
    public void navigateToViewDispensesAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewDispensesAll();
        dispensesPageSteps.assertDispensesTabTitleIsPresent();
    }
    @Step("Navigate to View -> Acuitas Feeds -> Acuitas Patient Import")
    public void navigateToViewAcuitasFeedsAcuitasPatientImport() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewAcuitasFeedsAcuitasPatientImport();
        acuitasPatientsImportPageSteps.assertAcuitasPatientsImportTabTitleIsPresent();
    }
    @Step("Navigate to View -> Care Home Penetration")
    public void navigateToViewCareHomePenetration() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewCareHomePenetration();
        careHomePenetrationHistoryPageSteps.assertCareHomePenetrationHistoryTabTitleIsPresent();
    }
    @Step("Navigate to View -> Home Visit Venues with no Patients")
    public void navigateToViewHomeVisitVenuesWithNoPatients() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewHomeVisitVenuesWithNoPatients();
        handoversPageSteps.assertHandoversTabTitleIsPresent();
    }
    @Step("Navigate to View -> Territories -> All")
    public void navigateToViewTerritoriesAll() {
        homePageSteps.openHomePage();
        commonPageSteps.navigateToViewTerritoriesAll();
        territoriesPageSteps.assertTerritoriesTabTitleIsPresent();
    }

    //Navigation - Help drop down
    @Step("Navigate to Help -> Online Help")
    public void navigateToHelpOnlineHelp(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpOnlineHelp();
    }
    @Step("Navigate to Help -> Support Enquiry")
    public void navigateToHelpSupportEnquiry(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpSupportEnquiry();
    }
    @Step("Navigate to Help -> Gold-Vision Admins")
    public void navigateToHelpGoldVisionAdmins(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpGoldVisionAdmins();
    }
    @Step("Navigate to Help -> Gold-Vision Admins and assert tab title is present")
    public void navigateToHelpGoldVisionAdminsAndAssertTabTitleIsPresent(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpGoldVisionAdmins();
        goldVisionAdministratorsPageSteps.assertGoldVisionAdministratorsTabTitleIsPresent();
    }
    @Step("Navigate to Help -> Remote Assist")
    public void navigateToHelpRemoteAssist(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpRemoteAssist();
    }
    @Step("Navigate to Help -> Chat with Support")
    public void navigateToHelpChatWithSupport(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpChatWithSupport();
    }
    @Step("Navigate to Help -> About")
    public void navigateToHelpAbout(){
        homePageSteps.openHomePage();
        commonPageSteps.navigateToHelpAbout();
    }

    //Clicks

    //Icons clicks
    @Step("Click home icon")
    public void clickHomeIcon() {
        commonPageSteps.clickHomeIcon();
    }
    @Step("Click venues icon")
    public void clickVenuesIcon() {
        commonPageSteps.clickVenuesIcon();
    }
    @Step("Click actions icon")
    public void clickActionsIcon() {
        commonPageSteps.clickActionsIcon();
    }
    @Step("Click Covid icon")
    public void clickCovidIcon() {
        commonPageSteps.clickCovidIcon();
    }
    @Step("Click campaigns icon")
    public void clickCampaignsIcon() {
        commonPageSteps.clickCampaignsIcon();
    }
    @Step("Click opportunities icon")
    public void clickOpportunitiesIcon() {
        commonPageSteps.clickOpportunitiesIcon();
    }
    @Step("Click quotes icon")
    public void clickQuotesIcon() {
        commonPageSteps.clickQuotesIcon();
    }
    @Step("Click seminars icon")
    public void clickSeminarsIcon() {
        commonPageSteps.clickSeminarsIcon();
    }
    @Step("Click contacts icon")
    public void clickContactsIcon() {
        commonPageSteps.clickContactsIcon();
    }
    @Step("Click appointments icon")
    public void clickAppointmentsIcon() {
        commonPageSteps.clickAppointmentsIcon();
    }
    @Step("Click visits icon")
    public void clickVisitsIcon() {
        commonPageSteps.clickVisitsIcon();
    }

    //Click icon and assert tab title is present
    @Step("Click home icon and assert tab title is present")
    public void clickHomeIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickHomeIcon();
        homePageSteps.assertHomePageTabTitleIsPresent();
    }
    @Step("Click venues icon and assert tab title is present")
    public void clickVenuesIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickVenuesIcon();
        venuesPageSteps.assertVenuesTabTitleIsPresent();
    }
    @Step("Click Actions icon and assert tab title is present")
    public void clickActionsIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickActionsIcon();
        actionsPageSteps.assertActionsTabTitleIsPresent();
    }
    @Step("Click Covid icon and assert tab title is present")
    public void clickCovidIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickCovidIcon();
        covidPageSteps.assertCovidTabTitleIsPresent();
    }
    @Step("Click Campaigns icon and assert tab title is present")
    public void clickCampaignsIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickCampaignsIcon();
        campaignsPageSteps.assertCampaignsTabTitleIsPresent();
    }
    @Step("Click Opportunities icon and assert tab title is present")
    public void clickOpportunitiesIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickOpportunitiesIcon();
        opportunitiesPageSteps.assertOpportunitiesTabTitleIsPresent();
    }
    @Step("Click Quotes icon and assert tab title is present")
    public void clickQuotesIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickQuotesIcon();
        quotesPageSteps.assertQuotesTabTitleIsPresent();
    }
    @Step("Click Seminars icon and assert tab title is present")
    public void clickSeminarsIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickSeminarsIcon();
        seminarsPageSteps.assertSeminarsTabTitleIsPresent();
    }
    @Step("Click Contacts icon and assert tab title is present")
    public void clickContactsIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickContactsIcon();
        contactsPageSteps.assertContactsTabTitleIsPresent();
    }
    @Step("Click Appointments icon and assert tab title is present")
    public void clickAppointmentsIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickAppointmentsIcon();
        appointmentsPageSteps.assertAppointmentsTabTitleIsPresent();
    }
    @Step("Click Visits icon and assert tab title is present")
    public void clickVisitsIconAndAssertTabTitleIsPresent() {
        commonPageSteps.clickVisitsIcon();
        visitsPageSteps.assertVisitsTabTitleIsPresent();
    }


    //Customer entry clicks

    //Top of page green elements clicks
    @Step("Click Show Script button")
    public void clickShowScriptButton() {
        customerEntryPageSteps.clickShowScriptButton();
    }
    @Step("Click Search Patient/Venue button")
    public void clickSearchPatientVenueButton() {
        customerEntryPageSteps.clickSearchPatientVenueButton();
    }
    @Step("Click Postcode/Address Lookup button")
    public void clickPostcodeAddressLookupButton() {
        customerEntryPageSteps.clickPostcodeAddressLookupButton();
    }
    @Step("Click Check Availability button")
    public void clickCheckAvailabilityButton() {
        customerEntryPageSteps.clickCheckAvailabilityButton();
    }
    @Step("Click Cancel button")
    public void clickCancelButton() {
        customerEntryPageSteps.clickCancelButton();
    }
    @Step("Click Back button")
    public void clickBackButton() {
        customerEntryPageSteps.clickBackButton();
    }
    @Step("Click Continue button")
    public void clickContinueButton() {
        customerEntryPageSteps.clickContinueButton();
    }

    //Patient title clicks
    @Step("Click Patient Title -> Not Set drop down button")
    public void clickPatientTitleDropDownNotSetButton() {
        customerEntryPageSteps.clickPatientTitleDropDownNotSetButton();
    }
    @Step("Click Patient Title -> Mr drop down button")
    public void clickPatientTitleDropDownMrButton() {
        customerEntryPageSteps.clickPatientTitleDropDownMrButton();
    }
    @Step("Click Patient Title -> Miss drop down button")
    public void clickPatientTitleDropDownMissButton() {
        customerEntryPageSteps.clickPatientTitleDropDownMissButton();
    }
    @Step("Click Patient Title -> Mrs drop down button")
    public void clickPatientTitleDropDownMrsButton() {
        customerEntryPageSteps.clickPatientTitleDropDownMrsButton();
    }
    @Step("Click Patient Title -> Ms drop down button")
    public void clickPatientTitleDropDownMsButton() {
        customerEntryPageSteps.clickPatientTitleDropDownMsButton();
    }
    @Step("Click Patient Title -> Master drop down button")
    public void clickPatientTitleDropDownMasterButton() {
        customerEntryPageSteps.clickPatientTitleDropDownMasterButton();
    }
    @Step("Click Patient Title -> Rev drop down button")
    public void clickPatientTitleDropDownRevButton() {
        customerEntryPageSteps.clickPatientTitleDropDownRevButton();
    }
    @Step("Click Patient Title -> Sister drop down button")
    public void clickPatientTitleDropDownSisterButton() {
        customerEntryPageSteps.clickPatientTitleDropDownSisterButton();
    }
    @Step("Click Patient Title -> Fr drop down button")
    public void clickPatientTitleDropDownFrButton() {
        customerEntryPageSteps.clickPatientTitleDropDownFrButton();
    }
    @Step("Click Patient Title -> Dr drop down button")
    public void clickPatientTitleDropDownDrButton() {
        customerEntryPageSteps.clickPatientTitleDropDownDrButton();
    }
    @Step("Click Patient Title -> Atty drop down button")
    public void clickPatientTitleDropDownAttyButton() {
        customerEntryPageSteps.clickPatientTitleDropDownAttyButton();
    }
    @Step("Click Patient Title -> Prof drop down button")
    public void clickPatientTitleDropDownProfButton() {
        customerEntryPageSteps.clickPatientTitleDropDownProfButton();
    }
    @Step("Click Patient Title -> Hon drop down button")
    public void clickPatientTitleDropDownHonButton() {
        customerEntryPageSteps.clickPatientTitleDropDownHonButton();
    }
    @Step("Click Patient Title -> Pres drop down button")
    public void clickPatientTitleDropDownPresButton() {
        customerEntryPageSteps.clickPatientTitleDropDownPresButton();
    }
    @Step("Click Patient Title -> Gov drop down button")
    public void clickPatientTitleDropDownGovButton() {
        customerEntryPageSteps.clickPatientTitleDropDownGovButton();
    }
    @Step("Click Patient Title -> Coach drop down button")
    public void clickPatientTitleDropDownCoachButton() {
        customerEntryPageSteps.clickPatientTitleDropDownCoachButton();
    }
    @Step("Click Patient Title -> Ofc drop down button")
    public void clickPatientTitleDropDownOfcButton() {
        customerEntryPageSteps.clickPatientTitleDropDownOfcButton();
    }
    @Step("Click Patient Title -> Mx drop down button")
    public void clickPatientTitleDropDownMxButton() {
        customerEntryPageSteps.clickPatientTitleDropDownMxButton();
    }

    //Gender clicks
    @Step("Click Gender -> Not Set drop down button")
    public void clickGenderDropDownNotSetButton() {
        customerEntryPageSteps.clickGenderDropDownNotSetButton();
    }
    @Step("Click Gender -> Male drop down button")
    public void clickGenderDropDownMaleButton() {
        customerEntryPageSteps.clickGenderDropDownMaleButton();
    }
    @Step("Click Gender -> Female drop down button")
    public void clickGenderDropDownFemaleButton() {
        customerEntryPageSteps.clickGenderDropDownFemaleButton();
    }
    @Step("Click Gender -> Neutral drop down button")
    public void clickGenderDropDownNeutralButton() {
        customerEntryPageSteps.clickGenderDropDownNeutralButton();
    }
    @Step("Click Gender -> Not Specified drop down button")
    public void clickGenderDropDownNotSpecifiedButton() {
        customerEntryPageSteps.clickGenderDropDownNotSpecifiedButton();
    }

    //Country drop down clicks
    @Step("Click Country -> Not Set drop down button")
    public void clickCountryDropDownNotSetButton() {
        customerEntryPageSteps.clickCountryDropDownNotSetButton();
    }
    @Step("Click Country -> England drop down button")
    public void clickCountryDropDownEnglandButton() {
        customerEntryPageSteps.clickCountryDropDownEnglandButton();
    }
    @Step("Click Country -> Scotland drop down button")
    public void clickCountryDropDownScotlandButton() {
        customerEntryPageSteps.clickCountryDropDownScotlandButton();
    }
    @Step("Click Country -> Wales drop down button")
    public void clickCountryDropDownWalesButton() {
        customerEntryPageSteps.clickCountryDropDownWalesButton();
    }
    @Step("Click Country -> Northern Ireland drop down button")
    public void clickCountryDropDownNorthernIrelandButton() {
        customerEntryPageSteps.clickCountryDropDownNorthernIrelandButton();
    }
    @Step("Click Country -> Republic Of Ireland drop down button")
    public void clickCountryDropDownRepublicOfIrelandButton() {
        customerEntryPageSteps.clickCountryDropDownRepublicOfIrelandButton();
    }

    //Domiciliary eligibility clicks
    @Step("Click Domiciliary Eligibility -> NotSet button")
    public void clickDomiciliaryEligibilityDropDownNotSetButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownNotSetButton();
    }
    @Step("Click Domiciliary Eligibility -> Agrophobic button")
    public void clickDomiciliaryEligibilityDropDownAgrophobicButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownAgrophobicButton();
    }
    @Step("Click Domiciliary Eligibility -> Alzheimer button")
    public void clickDomiciliaryEligibilityDropDownAlzheimerButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownAlzheimerButton();
    }
    @Step("Click Domiciliary Eligibility -> Amputee button")
    public void clickDomiciliaryEligibilityDropDownAmputeeButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownAmputeeButton();
    }
    @Step("Click Domiciliary Eligibility -> Arthritis button")
    public void clickDomiciliaryEligibilityDropDownArthritisButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownArthritisButton();
    }
    @Step("Click Domiciliary Eligibility -> Autism button")
    public void clickDomiciliaryEligibilityDropDownAutismButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownAutismButton();
    }
    @Step("Click Domiciliary Eligibility -> Cancer button")
    public void clickDomiciliaryEligibilityDropDownCancerButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownCancerButton();
    }
    @Step("Click Domiciliary Eligibility -> COPD button")
    public void clickDomiciliaryEligibilityDropDownCOPDButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownCOPDButton();
    }
    @Step("Click Domiciliary Eligibility -> Coronary Heart Disease button")
    public void clickDomiciliaryEligibilityDropDownCoronaryHeartDiseaseButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownCoronaryHeartDiseaseButton();
    }
    @Step("Click Domiciliary Eligibility -> CVA (Stroke) button")
    public void clickDomiciliaryEligibilityDropDownCVAStrokeButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownCVAStrokeButton();
    }
    @Step("Click Domiciliary Eligibility -> Dementia button")
    public void clickDomiciliaryEligibilityDropDownDementiaButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownDementiaButton();
    }
    @Step("Click Domiciliary Eligibility -> Down's Syndrome button")
    public void clickDomiciliaryEligibilityDropDownDownsSyndromeButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownDownsSyndromeButton();
    }
    @Step("Click Domiciliary Eligibility -> Learning Disabilities button")
    public void clickDomiciliaryEligibilityDropDownLearningDisabilitiesButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownLearningDisabilitiesButton();
    }
    @Step("Click Domiciliary Eligibility -> M/S button")
    public void clickDomiciliaryEligibilityDropDownMSButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownMSButton();
    }
    @Step("Click Domiciliary Eligibility -> Morbid Obesity button")
    public void clickDomiciliaryEligibilityDropDownMorbidObesityButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownMorbidObesityButton();
    }
    @Step("Click Domiciliary Eligibility -> Motor Neurone button")
    public void clickDomiciliaryEligibilityDropDownMotorNeuroneButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownMotorNeuroneButton();
    }
    @Step("Click Domiciliary Eligibility -> Osteoporosis button")
    public void clickDomiciliaryEligibilityDropDownOsteoporosisButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownOsteoporosisButton();
    }
    @Step("Click Domiciliary Eligibility -> Other button")
    public void clickDomiciliaryEligibilityDropDownOtherButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownOtherButton();
    }
    @Step("Click Domiciliary Eligibility -> Paralysis button")
    public void clickDomiciliaryEligibilityDropDownParalysisButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownParalysisButton();
    }
    @Step("Click Domiciliary Eligibility -> Parkinsons Disease button")
    public void clickDomiciliaryEligibilityDropDownParkinsonsDiseaseButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownParkinsonsDiseaseButton();
    }
    @Step("Click Domiciliary Eligibility -> Peripheral Nerupathy button")
    public void clickDomiciliaryEligibilityDropDownPeripheralNerupathyButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownPeripheralNerupathyButton();
    }
    @Step("Click Domiciliary Eligibility -> Respiratory Disease button")
    public void clickDomiciliaryEligibilityDropDownRespiratoryDiseaseButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownRespiratoryDiseaseButton();
    }
    @Step("Click Domiciliary Eligibility -> Severe Leg Ulcers button")
    public void clickDomiciliaryEligibilityDropDownSevereLegUlcersButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownSevereLegUlcersButton();
    }
    @Step("Click Domiciliary Eligibility -> Spinal Degeneration button")
    public void clickDomiciliaryEligibilityDropDownSpinalDegenerationButton() {
        customerEntryPageSteps.clickDomiciliaryEligibilityDropDownSpinalDegenerationButton();
    }

    //Previous optician clicks
    @Step("Click Previous Optician -> Not Set button")
    public void clickPreviousOpticianDropDownNotSetButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownNotSetButton();
    }
    @Step("Click Previous Optician -> Asda button")
    public void clickPreviousOpticianDropDownAsdaButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownAsdaButton();
    }
    @Step("Click Previous Optician -> At Home button")
    public void clickPreviousOpticianDropDownAtHomeButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownAtHomeButton();
    }
    @Step("Click Previous Optician -> Boots button")
    public void clickPreviousOpticianDropDownBootsButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownBootsButton();
    }
    @Step("Click Previous Optician -> Eyecare Oncall button")
    public void clickPreviousOpticianDropDownEyecareOncallButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownEyecareOncallButton();
    }
    @Step("Click Previous Optician -> Homecall button")
    public void clickPreviousOpticianDropDownHomecallButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownHomecallButton();
    }
    @Step("Click Previous Optician -> Local button")
    public void clickPreviousOpticianDropDownLocalButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownLocalButton();
    }
    @Step("Click Previous Optician -> Local Domiciliary Provider button")
    public void clickPreviousOpticianDropDownLocalDomiciliaryProviderButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownLocalDomiciliaryProviderButton();
    }
    @Step("Click Previous Optician -> Local High Street Provider button")
    public void clickPreviousOpticianDropDownLocalHighStreetProviderButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownLocalHighStreetProviderButton();
    }
    @Step("Click Previous Optician -> Not Known button")
    public void clickPreviousOpticianDropDownNotKnownButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownNotKnownButton();
    }
    @Step("Click Previous Optician -> Optical Express button")
    public void clickPreviousOpticianDropDownOpticalExpressButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownOpticalExpressButton();
    }
    @Step("Click Previous Optician -> Other button")
    public void clickPreviousOpticianDropDownOtherButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownOtherButton();
    }
    @Step("Click Previous Optician -> Specsavers button")
    public void clickPreviousOpticianDropDownSpecsaversButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownSpecsaversButton();
    }
    @Step("Click Previous Optician -> Tesco button")
    public void clickPreviousOpticianDropDownTescoButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownTescoButton();
    }
    @Step("Click Previous Optician -> The Outside Clinic button")
    public void clickPreviousOpticianDropDownTheOutsideClinicButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownTheOutsideClinicButton();
    }
    @Step("Click Previous Optician -> Vision Express button")
    public void clickPreviousOpticianDropDownVisionExpressButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownVisionExpressButton();
    }
    @Step("Click Previous Optician -> Visioncall button")
    public void clickPreviousOpticianDropDownVisioncallButton() {
        customerEntryPageSteps.clickPreviousOpticianDropDownVisioncallButton();
    }

    //Conditions drop down clicks
    @Step("Click Condition -> Not Set button")
    public void clickConditionDropDownNotSetButton() {
        customerEntryPageSteps.clickConditionDropDownNotSetButton();
    }
    @Step("Click Condition -> Diabetic button")
    public void clickConditionDropDownDiabeticButton() {
        customerEntryPageSteps.clickConditionDropDownDiabeticButton();
    }
    @Step("Click Condition -> Diabetic & Blind/Partially Sighted button")
    public void clickConditionDropDownDiabeticAndBlindPartiallySightedButton() {
        customerEntryPageSteps.clickConditionDropDownDiabeticAndBlindPartiallySightedButton();
    }
    @Step("Click Condition -> Diabetic & Family Glaucoma button")
    public void clickConditionDropDownDiabeticAndFamilyGlaucomaButton() {
        customerEntryPageSteps.clickConditionDropDownDiabeticAndFamilyGlaucomaButton();
    }
    @Step("Click Condition -> Diabetic & Glacoma & Blind/Partially Sighted button")
    public void clickConditionDropDownDiabeticAndGlacomaAndBlindPartiallySightedButton() {
        customerEntryPageSteps.clickConditionDropDownDiabeticAndGlacomaAndBlindPartiallySightedButton();
    }
    @Step("Click Condition -> Diabetic & Glaucoma button")
    public void clickConditionDropDownDiabeticAndGlaucomaButton() {
        customerEntryPageSteps.clickConditionDropDownDiabeticAndGlaucomaButton();
    }
    @Step("Click Condition -> Family History of Glaucoma button")
    public void clickConditionDropDownFamilyHistoryOfGlaucomaButton() {
        customerEntryPageSteps.clickConditionDropDownFamilyHistoryOfGlaucomaButton();
    }
    @Step("Click Condition -> Glaucoma button")
    public void clickConditionDropDownGlaucomaButton() {
        customerEntryPageSteps.clickConditionDropDownGlaucomaButton();
    }
    @Step("Click Condition -> Glaucoma & Blind/Partially Sighted button")
    public void clickConditionDropDownGlaucomaAndBlindPartiallySightedButton() {
        customerEntryPageSteps.clickConditionDropDownGlaucomaAndBlindPartiallySightedButton();
    }
    @Step("Click Condition -> Newmedica Px button")
    public void clickConditionDropDownNewmedicaPxButton() {
        customerEntryPageSteps.clickConditionDropDownNewmedicaPxButton();
    }
    @Step("Click Condition -> Newmedica/Diabetic button")
    public void clickConditionDropDownNewmedicaDiabeticButton() {
        customerEntryPageSteps.clickConditionDropDownNewmedicaDiabeticButton();
    }
    @Step("Click Condition -> Newmedica/Diabetic/Glaucoma button")
    public void clickConditionDropDownNewmedicaDiabeticGlaucomaButton() {
        customerEntryPageSteps.clickConditionDropDownNewmedicaDiabeticGlaucomaButton();
    }
    @Step("Click Condition -> Newmedica/Glaucoma button")
    public void clickConditionDropDownNewmedicaGlaucomaButton() {
        customerEntryPageSteps.clickConditionDropDownNewmedicaGlaucomaButton();
    }
    @Step("Click Condition -> Newmedica/Glaucoma/Diabetes/Visual Impairment button")
    public void clickConditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton() {
        customerEntryPageSteps.clickConditionDropDownNewmedicaGlaucomaDiabetesVisualImpairmentButton();
    }
    @Step("Click Condition -> Not Known button")
    public void clickConditionDropDownNotKnownButton() {
        customerEntryPageSteps.clickConditionDropDownNotKnownButton();
    }
    @Step("Click Condition -> Not Relevant button")
    public void clickConditionDropDownNotRelevantButton() {
        customerEntryPageSteps.clickConditionDropDownNotRelevantButton();
    }
    @Step("Click Condition -> Nothing reported button")
    public void clickConditionDropDownNothingReportedButton() {
        customerEntryPageSteps.clickConditionDropDownNothingReportedButton();
    }
    @Step("Click Condition -> Reg Blind or Partially Sighted button")
    public void clickConditionDropDownRegBlindOrPartiallySightedButton() {
        customerEntryPageSteps.clickConditionDropDownRegBlindOrPartiallySightedButton();
    }

    //Funding drop down clicks
    @Step("Click Funding -> Not Set button")
    public void clickFundingDropDownNotSetButton() {
        customerEntryPageSteps.clickFundingDropDownNotSetButton();
    }
    @Step("Click Funding -> Income Support button")
    public void clickFundingDropDownIncomeSupportButton() {
        customerEntryPageSteps.clickFundingDropDownIncomeSupportButton();
    }
    @Step("Click Funding -> Universal Credit button")
    public void clickFundingDropDownUniversalCreditButton() {
        customerEntryPageSteps.clickFundingDropDownUniversalCreditButton();
    }
    @Step("Click Funding -> HC2 Certificate button")
    public void clickFundingDropDownHC2CertificateButton() {
        customerEntryPageSteps.clickFundingDropDownHC2CertificateButton();
    }
    @Step("Click Funding -> HC3 Certificate button")
    public void clickFundingDropDownHC3CertificateButton() {
        customerEntryPageSteps.clickFundingDropDownHC3CertificateButton();
    }
    @Step("Click Funding -> Privately Funded button")
    public void clickFundingDropDownPrivatelyFundedButton() {
        customerEntryPageSteps.clickFundingDropDownPrivatelyFundedButton();
    }
    @Step("Click Funding -> Income Based Job Seekers Allowance [JSA (IB)] button")
    public void clickFundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton() {
        customerEntryPageSteps.clickFundingDropDownIncomeBasedJobSeekersAllowanceJSAIBButton();
    }
    @Step("Click Funding -> Not Known button")
    public void clickFundingDropDownNotKnownButton() {
        customerEntryPageSteps.clickFundingDropDownNotKnownButton();
    }
    @Step("Click Funding -> NHS Tax Credit Exemption button")
    public void clickFundingDropDownNHSTaxCreditExemptionButton() {
        customerEntryPageSteps.clickFundingDropDownNHSTaxCreditExemptionButton();
    }
    @Step("Click Funding -> Guarantee Pension Credit button")
    public void clickFundingDropDownGuaranteePensionCreditButton() {
        customerEntryPageSteps.clickFundingDropDownGuaranteePensionCreditButton();
    }
    @Step("Click Funding -> Income retated ESA button")
    public void clickFundingDropDownIncomeRetatedESAButton() {
        customerEntryPageSteps.clickFundingDropDownIncomeRetatedESAButton();
    }

    //Patient primary contact radio button clicks
    @Step("Click Patient Home Tel. No Primary Contact radio button")
    public void clickPatientHomeTelephoneNumberPrimaryContactRadioButton() {
        customerEntryPageSteps.clickPatientHomeTelephoneNumberPrimaryContactRadioButton();
    }
    @Step("Click Patient Mobile Tel. No Primary Contact radio button")
    public void clickPatientMobileTelephoneNumberPrimaryContactRadioButton() {
        customerEntryPageSteps.clickPatientMobileTelephoneNumberPrimaryContactRadioButton();
    }

    //Advertising method drop down clicks
    @Step("Click Advertising Method -> Not Set button")
    public void clickAdvertisingMethodDropDownNotSetButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownNotSetButton();
    }
    @Step("Click Advertising Method -> Advert - Local button")
    public void clickAdvertisingMethodDropDownAdvertLocalButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownAdvertLocalButton();
    }
    @Step("Click Advertising Method -> Advert - National button")
    public void clickAdvertisingMethodDropDownAdvertNationalButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownAdvertNationalButton();
    }
    @Step("Click Advertising Method -> Age Concern Referral button")
    public void clickAdvertisingMethodDropDownAgeConcernReferralButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownAgeConcernReferralButton();
    }
    @Step("Click Advertising Method -> Art & Design button")
    public void clickAdvertisingMethodDropDownArtAndDesignButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownArtAndDesignButton();
    }
    @Step("Click Advertising Method -> Automotive button")
    public void clickAdvertisingMethodDropDownAutomotiveButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownAutomotiveButton();
    }
    @Step("Click Advertising Method -> Aviation button")
    public void clickAdvertisingMethodDropDownAviationButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownAviationButton();
    }
    @Step("Click Advertising Method -> Banking & Finance button")
    public void clickAdvertisingMethodDropDownBankingAndFinanceButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownBankingAndFinanceButton();
    }
    @Step("Click Advertising Method -> Bedlist button")
    public void clickAdvertisingMethodDropDownBedlistButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownBedlistButton();
    }
    @Step("Click Advertising Method -> Bio-technology button")
    public void clickAdvertisingMethodDropDownBiotechnologyButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownBiotechnologyButton();
    }
    @Step("Click Advertising Method -> Bowen's Opticians button")
    public void clickAdvertisingMethodDropDownBowensOpticiansButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownBowensOpticiansButton();
    }
    @Step("Click Advertising Method -> Brewing button")
    public void clickAdvertisingMethodDropDownBrewingButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownBrewingButton();
    }
    @Step("Click Advertising Method -> CareData Import button")
    public void clickAdvertisingMethodDropDownCareDataImportButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownCareDataImportButton();
    }
    @Step("Click Advertising Method -> Carer button")
    public void clickAdvertisingMethodDropDownCarerButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownCarerButton();
    }
    @Step("Click Advertising Method -> Central / Local Government button")
    public void clickAdvertisingMethodDropDownCentralLocalGovernmentButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownCentralLocalGovernmentButton();
    }
    @Step("Click Advertising Method -> Charity button")
    public void clickAdvertisingMethodDropDownCharityButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownCharityButton();
    }
    @Step("Click Advertising Method -> Chemist button")
    public void clickAdvertisingMethodDropDownChemistButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownChemistButton();
    }
    @Step("Click Advertising Method -> Defence button")
    public void clickAdvertisingMethodDropDownDefenceButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownDefenceButton();
    }
    @Step("Click Advertising Method -> Diabetic Screening Clinic button")
    public void clickAdvertisingMethodDropDownDiabeticScreeningClinicButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownDiabeticScreeningClinicButton();
    }
    @Step("Click Advertising Method -> Distribution & Logistics button")
    public void clickAdvertisingMethodDropDownDistributionAndLogisticsButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownDistributionAndLogisticsButton();
    }
    @Step("Click Advertising Method -> Education & Training button")
    public void clickAdvertisingMethodDropDownEducationAndTrainingButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownEducationAndTrainingButton();
    }
    @Step("Click Advertising Method -> Emergency Services button")
    public void clickAdvertisingMethodDropDownEmergencyServicesButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownEmergencyServicesButton();
    }
    @Step("Click Advertising Method -> Entertainment & Media button")
    public void clickAdvertisingMethodDropDownEntertainmentAndMediaButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownEntertainmentAndMediaButton();
    }
    @Step("Click Advertising Method -> Environmental button")
    public void clickAdvertisingMethodDropDownEnvironmentalButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownEnvironmentalButton();
    }
    @Step("Click Advertising Method -> Equipment Distribution button")

    public void clickAdvertisingMethodDropDownEquipmentDistributionButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownEquipmentDistributionButton();
    }
    @Step("Click Advertising Method -> Farming & Agriculture button")
    public void clickAdvertisingMethodDropDownFarmingAndAgricultureButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownFarmingAndAgricultureButton();
    }
    @Step("Click Advertising Method -> Friend / Family button")
    public void clickAdvertisingMethodDropDownFriendFamilyButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownFriendFamilyButton();
    }
    @Step("Click Advertising Method -> Furniture & Fittings button")
    public void clickAdvertisingMethodDropDownFurnitureAndFittingsButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownFurnitureAndFittingsButton();
    }
    @Step("Click Advertising Method -> Gaming button")
    public void clickAdvertisingMethodDropDownGamingButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownGamingButton();
    }
    @Step("Click Advertising Method -> GP Surgery / Doctor button")
    public void clickAdvertisingMethodDropDownGPSurgeryDoctorButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownGPSurgeryDoctorButton();
    }
    @Step("Click Advertising Method -> Healthcall Staff button")
    public void clickAdvertisingMethodDropDownHealthcallStaffButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownHealthcallStaffButton();
    }
    @Step("Click Advertising Method -> Healthcare button")
    public void clickAdvertisingMethodDropDownHealthcareButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownHealthcareButton();
    }
    @Step("Click Advertising Method -> Hire Services button")
    public void clickAdvertisingMethodDropDownHireServicesButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownHireServicesButton();
    }
    @Step("Click Advertising Method -> Hotel & Catering button")
    public void clickAdvertisingMethodDropDownHotelAndCateringButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownHotelAndCateringButton();
    }
    @Step("Click Advertising Method -> Housing, Building & Construction button")
    public void clickAdvertisingMethodDropDownHousingBuildingAndConstructionButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownHousingBuildingAndConstructionButton();
    }
    @Step("Click Advertising Method -> Information Technology button")
    public void clickAdvertisingMethodDropDownInformationTechnologyButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownInformationTechnologyButton();
    }
    @Step("Click Advertising Method -> Insurance button")
    public void clickAdvertisingMethodDropDownInsuranceButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownInsuranceButton();
    }
    @Step("Click Advertising Method -> Knowledge Management button")
    public void clickAdvertisingMethodDropDownKnowledgeManagementButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownKnowledgeManagementButton();
    }
    @Step("Click Advertising Method -> Leaflet Through The Door button")
    public void clickAdvertisingMethodDropDownLeafletThroughTheDoorButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownLeafletThroughTheDoorButton();
    }
    @Step("Click Advertising Method -> Legal button")
    public void clickAdvertisingMethodDropDownLegalButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownLegalButton();
    }
    @Step("Click Advertising Method -> Manufacturing & Engineering button")
    public void clickAdvertisingMethodDropDownManufacturingAndEngineeringButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownManufacturingAndEngineeringButton();
    }
    @Step("Click Advertising Method -> Mouseability Website button")
    public void clickAdvertisingMethodDropDownMouseabilityWebsiteButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownMouseabilityWebsiteButton();
    }
    @Step("Click Advertising Method -> N/A - Care Home button")
    public void clickAdvertisingMethodDropDownNACareHomeButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownNACareHomeButton();
    }
    @Step("Click Advertising Method -> Nurse button")
    public void clickAdvertisingMethodDropDownNurseButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownNurseButton();
    }
    @Step("Click Advertising Method -> Optician button")
    public void clickAdvertisingMethodDropDownOpticianButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownOpticianButton();
    }
    @Step("Click Advertising Method -> Other button")
    public void clickAdvertisingMethodDropDownOtherButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownOtherButton();
    }
    @Step("Click Advertising Method -> Other Non-Profit making button")
    public void clickAdvertisingMethodDropDownOtherNonProfitMakingButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownOtherNonProfitMakingButton();
    }
    @Step("Click Advertising Method -> Other Recommendation button")
    public void clickAdvertisingMethodDropDownOtherRecommendationButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownOtherRecommendationButton();
    }
    @Step("Click Advertising Method -> Personalised Letter button")
    public void clickAdvertisingMethodDropDownPersonalisedLetterButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPersonalisedLetterButton();
    }
    @Step("Click Advertising Method -> Pharmaceutical button")
    public void clickAdvertisingMethodDropDownPharmaceuticalButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPharmaceuticalButton();
    }
    @Step("Click Advertising Method -> Previous Record button")
    public void clickAdvertisingMethodDropDownPreviousRecordButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPreviousRecordButton();
    }
    @Step("Click Advertising Method -> Printing & Design button")
    public void clickAdvertisingMethodDropDownPrintingAndDesignButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPrintingAndDesignButton();
    }
    @Step("Click Advertising Method -> Professional Body button")
    public void clickAdvertisingMethodDropDownProfessionalBodyButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownProfessionalBodyButton();
    }
    @Step("Click Advertising Method -> Property Management button")
    public void clickAdvertisingMethodDropDownPropertyManagementButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPropertyManagementButton();
    }
    @Step("Click Advertising Method -> Public Transport button")
    public void clickAdvertisingMethodDropDownPublicTransportButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPublicTransportButton();
    }
    @Step("Click Advertising Method -> Publishing & Newspapers button")
    public void clickAdvertisingMethodDropDownPublishingAndNewspapersButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownPublishingAndNewspapersButton();
    }
    @Step("Click Advertising Method -> Radio button")
    public void clickAdvertisingMethodDropDownRadioButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownRadioButton();
    }
    @Step("Click Advertising Method -> Recruitment button")
    public void clickAdvertisingMethodDropDownRecruitmentButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownRecruitmentButton();
    }
    @Step("Click Advertising Method -> Reply Slip From Leaflet button")
    public void clickAdvertisingMethodDropDownReplySlipFromLeafletButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownReplySlipFromLeafletButton();
    }
    @Step("Click Advertising Method -> Retail button")
    public void clickAdvertisingMethodDropDownRetailButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownRetailButton();
    }
    @Step("Click Advertising Method -> Sales / Advertising / Marketing button")
    public void clickAdvertisingMethodDropDownSalesAdvertisingMarketingButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownSalesAdvertisingMarketingButton();
    }
    @Step("Click Advertising Method -> Security button")
    public void clickAdvertisingMethodDropDownSecurityButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownSecurityButton();
    }
    @Step("Click Advertising Method -> Service Management button")
    public void clickAdvertisingMethodDropDownServiceManagementButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownServiceManagementButton();
    }
    @Step("Click Advertising Method -> Sheltered - Warden Recommendation button")
    public void clickAdvertisingMethodDropDownShelteredWardenRecommendationButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownShelteredWardenRecommendationButton();
    }
    @Step("Click Advertising Method -> Sheltered Accommodation Existing button")
    public void clickAdvertisingMethodDropDownShelteredAccommodationExistingButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownShelteredAccommodationExistingButton();
    }
    @Step("Click Advertising Method -> Specsavers button")
    public void clickAdvertisingMethodDropDownSpecsaversButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownSpecsaversButton();
    }
    @Step("Click Advertising Method -> Sport & Leisure button")
    public void clickAdvertisingMethodDropDownSportAndLeisureButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownSportAndLeisureButton();
    }
    @Step("Click Advertising Method -> Telecoms & Communications button")
    public void clickAdvertisingMethodDropDownTelecomsAndCommunicationsButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownTelecomsAndCommunicationsButton();
    }
    @Step("Click Advertising Method -> Television Advert button")
    public void clickAdvertisingMethodDropDownTelevisionAdvertButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownTelevisionAdvertButton();
    }
    @Step("Click Advertising Method -> Translation Services button")
    public void clickAdvertisingMethodDropDownTranslationServicesButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownTranslationServicesButton();
    }
    @Step("Click Advertising Method -> Travel button")
    public void clickAdvertisingMethodDropDownTravelButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownTravelButton();
    }
    @Step("Click Advertising Method -> Utilities button")
    public void clickAdvertisingMethodDropDownUtilitiesButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownUtilitiesButton();
    }
    @Step("Click Advertising Method -> Waste Management button")
    public void clickAdvertisingMethodDropDownWasteManagementButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownWasteManagementButton();
    }
    @Step("Click Advertising Method -> Website button")
    public void clickAdvertisingMethodDropDownWebsiteButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownWebsiteButton();
    }
    @Step("Click Advertising Method -> Website – online test request button")
    public void clickAdvertisingMethodDropDownWebsiteOnlineTestRequestButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownWebsiteOnlineTestRequestButton();
    }
    @Step("Click Advertising Method -> Wholesale & Distribution button")
    public void clickAdvertisingMethodDropDownWholesaleAndDistributionButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownWholesaleAndDistributionButton();
    }
    @Step("Click Advertising Method -> WRVS Partnership button")
    public void clickAdvertisingMethodDropDownWRVSPartnershipButton() {
        customerEntryPageSteps.clickAdvertisingMethodDropDownWRVSPartnershipButton();
    }

    //Alternative contact main drop down clicks
    @Step("Click Alternative Contact -> None button")
    public void clickAlternativeContactMainDropDownNoneButton() {
        customerEntryPageSteps.clickAlternativeContactMainDropDownNoneButton();
    }
    @Step("Click Alternative Contact -> New contact button")
    public void clickAlternativeContactMainDropDownNewContactButton() {
        customerEntryPageSteps.clickAlternativeContactMainDropDownNewContactButton();
    }

    //Alternative contact title drop down clicks
    @Step("Click Alternative Contact Title -> Not Set button")
    public void clickAlternativeContactTitleDropDownNotSetButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownNotSetButton();
    }
    @Step("Click Alternative Contact Title -> Mr button")
    public void clickAlternativeContactTitleDropDownMrButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMrButton();
    }
    @Step("Click Alternative Contact Title -> Miss button")
    public void clickAlternativeContactTitleDropDownMissButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMissButton();
    }
    @Step("Click Alternative Contact Title -> Mrs button")
    public void clickAlternativeContactTitleDropDownMrsButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMrsButton();
    }
    @Step("Click Alternative Contact Title -> Ms button")
    public void clickAlternativeContactTitleDropDownMsButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMsButton();
    }
    @Step("Click Alternative Contact Title -> Master button")
    public void clickAlternativeContactTitleDropDownMasterButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMasterButton();
    }
    @Step("Click Alternative Contact Title -> Rev button")
    public void clickAlternativeContactTitleDropDownRevButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownRevButton();
    }
    @Step("Click Alternative Contact Title -> Sister button")
    public void clickAlternativeContactTitleDropDownSisterButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownSisterButton();
    }
    @Step("Click Alternative Contact Title -> Fr button")
    public void clickAlternativeContactTitleDropDownFrButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownFrButton();
    }
    @Step("Click Alternative Contact Title -> Dr button")
    public void clickAlternativeContactTitleDropDownDrButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownDrButton();
    }
    @Step("Click Alternative Contact Title -> Atty button")
    public void clickAlternativeContactTitleDropDownAttyButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownAttyButton();
    }
    @Step("Click Alternative Contact Title -> Prof button")
    public void clickAlternativeContactTitleDropDownProfButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownProfButton();
    }
    @Step("Click Alternative Contact Title -> Hon button")
    public void clickAlternativeContactTitleDropDownHonButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownHonButton();
    }
    @Step("Click Alternative Contact Title -> Pres button")
    public void clickAlternativeContactTitleDropDownPresButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownPresButton();
    }
    @Step("Click Alternative Contact Title -> Gov button")
    public void clickAlternativeContactTitleDropDownGovButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownGovButton();
    }
    @Step("Click Alternative Contact Title -> Coach button")
    public void clickAlternativeContactTitleDropDownCoachButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownCoachButton();
    }
    @Step("Click Alternative Contact Title -> Ofc button")
    public void clickAlternativeContactTitleDropDownOfcButton() {
        customerEntryPageSteps.clickAlternativeContactTitleDropDownOfcButton();
    }

    //Alternative contact type drop down clicks
    @Step("Click Alternative Contact Type -> Not Set button")
    public void clickAlternativeContactTypeDropDownNotSetButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownNotSetButton();
    }
    @Step("Click Alternative Contact Type -> Administrator button")
    public void clickAlternativeContactTypeDropDownAdministratorButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownAdministratorButton();
    }
    @Step("Click Alternative Contact Type -> Venue Manager button")
    public void clickAlternativeContactTypeDropDownVenueManagerButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownVenueManagerButton();
    }
    @Step("Click Alternative Contact Type -> Deputy Manager button")
    public void clickAlternativeContactTypeDropDownDeputyManagerButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownDeputyManagerButton();
    }
    @Step("Click Alternative Contact Type -> Matron button")
    public void clickAlternativeContactTypeDropDownMatronButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownMatronButton();
    }
    @Step("Click Alternative Contact Type -> Opticians Organiser button")
    public void clickAlternativeContactTypeDropDownOpticiansOrganiserButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownOpticiansOrganiserButton();
    }
    @Step("Click Alternative Contact Type -> Patient Carer button")
    public void clickAlternativeContactTypeDropDownPatientCarerButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownPatientCarerButton();
    }
    @Step("Click Alternative Contact Type -> Patient Family button")
    public void clickAlternativeContactTypeDropDownPatientFamilyButton() {
        customerEntryPageSteps.clickAlternativeContactTypeDropDownPatientFamilyButton();
    }

    //Alternative contact primary contact radio button clicks
    @Step("Click Alternative Contact Home Tel. No Primary Contact radio button")
    public void clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton() {
        customerEntryPageSteps.clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton();
    }
    @Step("Click Alternative Contact Mobile Tel. No Primary Contact radio button")
    public void clickAlternativeContactMobileTelephoneNumberPrimaryContactRadioButton() {
        customerEntryPageSteps.clickAlternativeContactMobileTelephoneNumberPrimaryContactRadioButton();
    }

    //Visit information clicks
    @Step("Click anytime check box")
    public void clickAnytimeCheckBox() {
        customerEntryPageSteps.clickAnytimeCheckBox();
    }
    @Step("Click Create New Visit radio button")
    public void clickCreateNewVisitRadioButton() {
        customerEntryPageSteps.clickCreateNewVisitRadioButton();
    }
    @Step("Click No appointment available radio button")
    public void clickNoAppointmentAvailableRadioButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableRadioButton();
    }

    //Create new visit clicks
    @Step("Click Visit Type -> Not Set button")
    public void clickVisitTypeDropDownNotSetButton() {
        customerEntryPageSteps.clickVisitTypeDropDownNotSetButton();
    }
    @Step("Click Visit Type -> Home Visit New button")
    public void clickVisitTypeDropDownHomeVisitNewButton() {
        customerEntryPageSteps.clickVisitTypeDropDownHomeVisitNewButton();
    }
    @Step("Click Visit Type -> Care Home Visit button")
    public void clickVisitTypeDropDownCareHomeVisitButton() {
        customerEntryPageSteps.clickVisitTypeDropDownCareHomeVisitButton();
    }
    @Step("Click Visit Type -> Home Visit Existing button")
    public void clickVisitTypeDropDownHomeVisitExistingButton() {
        customerEntryPageSteps.clickVisitTypeDropDownHomeVisitExistingButton();
    }
    @Step("Click Visit Type -> Retest button")
    public void clickVisitTypeDropDownRetestButton() {
        customerEntryPageSteps.clickVisitTypeDropDownRetestButton();
    }
    @Step("Click Visit Type -> Corporate Eyecare button")
    public void clickVisitTypeDropDownCorporateEyecareButton() {
        customerEntryPageSteps.clickVisitTypeDropDownCorporateEyecareButton();
    }
    @Step("Click Visit Type -> Prison Visit button")
    public void clickVisitTypeDropDownPrisonVisitButton() {
        customerEntryPageSteps.clickVisitTypeDropDownPrisonVisitButton();
    }
    @Step("Click Visit Type -> Hospital Visit button")
    public void clickVisitTypeDropDownHospitalVisitButton() {
        customerEntryPageSteps.clickVisitTypeDropDownHospitalVisitButton();
    }
    @Step("Click Visit Type -> Private Sight Test button")
    public void clickVisitTypeDropDownPrivateSightTestButton() {
        customerEntryPageSteps.clickVisitTypeDropDownPrivateSightTestButton();
    }

    //Visit date picker
    @Step("Click visit timeslot picker")
    public void clickVisitTimeslotPicker() {
        customerEntryPageSteps.clickVisitTimeslotPicker();
    }

    @Step("Choose appointment timeslot")
    public void chooseAppointmentTimeslot(String optomName, String date, String amPm) {
        customerEntryPageSteps.chooseAppointmentTimeslot(optomName, date, amPm);
    }

    //No appointment available reason drop down clicks
    @Step("Click No appointment available: Reason -> Not Set button")
    public void clickNoAppointmentAvailableReasonDropDownNotSetButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownNotSetButton();
    }
    @Step("Click No appointment available: Reason -> No appointment available button")
    public void clickNoAppointmentAvailableReasonDropDownNoAppointmentAvailableButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownNoAppointmentAvailableButton();
    }
    @Step("Click No appointment available: Reason -> Aftercare button")
    public void clickNoAppointmentAvailableReasonDropDownAftercareButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownAftercareButton();
    }
    @Step("Click No appointment available: Reason -> Dispense only button")
    public void clickNoAppointmentAvailableReasonDropDownDispenseOnlyButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownDispenseOnlyButton();
    }
    @Step("Click No appointment available: Reason -> Early sight test required button")
    public void clickNoAppointmentAvailableReasonDropDownEarlySightTestRequestedButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownEarlySightTestRequestedButton();
    }
    @Step("Click No appointment available: Reason -> Domiciliary reason given vague button")
    public void clickNoAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownDomiciliaryReasonGivenVagueButton();
    }
    @Step("Click No appointment available: Reason -> Partially sighted or severely partially sighted button")
    public void clickNoAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownPartiallySightedOrSeverelyPartiallySightedButton();
    }
    @Step("Click No appointment available: Reason -> Untick to save button")
    public void clickNoAppointmentAvailableReasonDropDownUntickToSaveButton() {
        customerEntryPageSteps.clickNoAppointmentAvailableReasonDropDownUntickToSaveButton();
    }

    //Consent and permissions page clicks
    @Step("Click Data Processing Consent Yes radio button")
    public void clickDataProcessingConsentYesRadioButton() {
        customerEntryPageSteps.clickDataProcessingConsentYesRadioButton();
    }
    @Step("Click Data Processing Consent No radio button")
    public void clickDataProcessingConsentNoRadioButton() {
        customerEntryPageSteps.clickDataProcessingConsentNoRadioButton();
    }
    @Step("Click Marketing in service related communcations: Email - Yes radio button")
    public void clickMarketingInServiceRelatedCommunicationsEmailYesRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsEmailYesRadioButton();
    }
    @Step("Click Marketing in service related communcations: Email - No radio button")
    public void clickMarketingInServiceRelatedCommunicationsEmailNoRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsEmailNoRadioButton();
    }
    @Step("Click Marketing in service related communcations: Post - Yes radio button")
    public void clickMarketingInServiceRelatedCommunicationsPostYesRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsPostYesRadioButton();
    }
    @Step("Click Marketing in service related communcations: Post - No radio button")
    public void clickMarketingInServiceRelatedCommunicationsPostNoRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsPostNoRadioButton();
    }
    @Step("Click Marketing in service related communcations: SMS - Yes radio button")
    public void clickMarketingInServiceRelatedCommunicationsSMSYesRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsSMSYesRadioButton();
    }
    @Step("Click Marketing in service related communcations: SMS - No radio button")
    public void clickMarketingInServiceRelatedCommunicationsSMSNoRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsSMSNoRadioButton();
    }
    @Step("Click Marketing in service related communcations: Telephone - Yes radio button")
    public void clickMarketingInServiceRelatedCommunicationsTelephoneYesRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsTelephoneYesRadioButton();
    }
    @Step("Click Marketing in service related communcations: Telephone - No radio button")
    public void clickMarketingInServiceRelatedCommunicationsTelephoneNoRadioButton() {
        customerEntryPageSteps.clickMarketingInServiceRelatedCommunicationsTelephoneNoRadioButton();
    }
    @Step("Click Marketing permissions: Email - Yes radio button")
    public void clickMarketingPermissionsEmailYesRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsEmailYesRadioButton();
    }
    @Step("Click Marketing permissions: Email - No radio button")
    public void clickMarketingPermissionsEmailNoRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsEmailNoRadioButton();
    }
    @Step("Click Marketing permissions: Post - Yes radio button")
    public void clickMarketingPermissionsPostYesRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsPostYesRadioButton();
    }
    @Step("Click Marketing permissions: Post - No radio button")
    public void clickMarketingPermissionsPostNoRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsPostNoRadioButton();
    }
    @Step("Click Marketing permissions: SMS - Yes radio button")
    public void clickMarketingPermissionsSMSYesRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsSMSYesRadioButton();
    }
    @Step("Click Marketing permissions: SMS - No radio button")
    public void clickMarketingPermissionsSMSNoRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsSMSNoRadioButton();
    }
    @Step("Click Marketing permissions: Telephone - Yes radio button")
    public void clickMarketingPermissionsTelephoneYesRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsTelephoneYesRadioButton();
    }
    @Step("Click Marketing permissions: Telephone - No radio button")
    public void clickMarketingPermissionsTelephoneNoRadioButton() {
        customerEntryPageSteps.clickMarketingPermissionsTelephoneNoRadioButton();
    }
    @Step("Click marketing consent confirm button")
    public void clickMarketingConsentConfirmButton() {
        customerEntryPageSteps.clickMarketingConsentConfirmButton();
    }
    @Step("Click marketing consent save button")
    public void clickMarketingConsentSaveButton() {
        customerEntryPageSteps.clickMarketingConsentSaveButton();
    }
    @Step("Click Details Saved Successfully continue button - add another patient pop up")
    public void clickDetailsSavedSuccessfullyContinueToAnotherPatient() {
        customerEntryPageSteps.clickDetailsSavedSuccessfullyContinueToAnotherPatient();

    }
    @Step("Click Details Saved Successfully continue button - finish pop up")
    public void clickDetailsSavedSuccessfullyContinueToFinish() {
        customerEntryPageSteps.clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Click Add New Patient button")
    public void clickAddNewPatientButton() {
        customerEntryPageSteps.clickAddNewPatientButton();
    }
    @Step("Click Add Existing Patient button")
    public void clickAddExistingPatientButton() {
        customerEntryPageSteps.clickAddExistingPatientButton();
    }
    @Step("Add patients to existing Care Home visit")
    public void addPatientsToExistingCareHomeVisit(List<String> patientSurnames) {
        customerEntryPageSteps.addPatientsToExistingCareHomeVisit(patientSurnames);
    }
    @Step("Add patients to existing home visit")
    public void addPatientsToExistingHomeVisit(List<String> patientSurnames) {
        customerEntryPageSteps.addPatientsToExistingHomeVisit(patientSurnames);
    }
    @Step("Click Add to booking button")
    public void clickAddToBookingButton() {
        customerEntryPageSteps.clickAddToBookingButton();
    }
    @Step("Click Finish button")
    public void clickFinishButton() {
        customerEntryPageSteps.clickFinishButton();
    }

    //Error pop up click
    @Step("Click error pop up continue button")
    public void clickErrorPopUpContinueButton() {
        customerEntryPageSteps.clickErrorPopUpContinueButton();
    }

    //Combination functions

    //Enter text into mandatory fields in one go
    @Step("Enter text into mandatory CE elements - patient")
    public void enterPatientMandatoryCETextFields(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
    }
    @Step("Enter text into mandatory CE elements - Venue")
    public void enterVenuePatientMandatoryCETextFields(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String lastName = testDataManager.getTestInputRegionData("venueConstants.lastName");
        lastName+=surname;
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.enterPatientText(firstName, lastName, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
    }
    @Step("Enter text into mandatory CE elements - optometrist")
    public void enterOptomMandatoryCETextFields(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("optomConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
    }
    @Step("Fill in all mandatory fields and drop downs - patient")
    public void fillInAllMandatoryFieldsAndDropDownsPatient(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }
    @Step("Fill in all mandatory fields and drop downs - patient for Scotland")
    public void fillInAllMandatoryFieldsAndDropDownsPatientForScotland(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcodeScotland");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }
    @Step("Fill in all mandatory fields and drop downs - patient for Wales")
    public void fillInAllMandatoryFieldsAndDropDownsPatientForWales(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcodeWales");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }
    @Step("Fill in all mandatory fields and drop downs - patient for NorthernIreland")
    public void fillInAllMandatoryFieldsAndDropDownsPatientForNorthernIreland(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcodeNI");
        String HAndC = testDataManager.getTestInputCommonData("customerEntryConstants.HAndCNumber");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterHAndC(HAndC);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }

    @Step("Fill in all mandatory fields and drop downs and click continue - patient")
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient(String surname, String dateOfLastSightTest, String dateOfBirth) {
        fillInAllMandatoryFieldsAndDropDownsPatient(surname, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and drop downs and click continue - patient for Scotland")
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientForScotland(String surname, String dateOfLastSightTest, String dateOfBirth) {
        this.fillInAllMandatoryFieldsAndDropDownsPatientForScotland(surname, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and drop downs and click continue - patient for Wales")
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientForWales(String surname, String dateOfLastSightTest, String dateOfBirth) {
        this.fillInAllMandatoryFieldsAndDropDownsPatientForWales(surname, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and drop downs and click continue - patient for Northern Ireland")
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientForNorthernIreland(String surname, String dateOfLastSightTest, String dateOfBirth) {
        this.fillInAllMandatoryFieldsAndDropDownsPatientForNorthernIreland(surname, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickContinueButton();
    }
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatientSearch(String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("searchPatientVenuePatient.firstName");
        String surname = testDataManager.getTestInputRegionData("searchPatientVenuePatient.lastName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and drop downs and click continue - venue")
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinueVenue(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("patientConstants.firstName");
        String lastName = testDataManager.getTestInputRegionData("venueConstants.lastName");
        lastName+=surname;
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, lastName, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and drop downs and click continue - optometrist")
    public void fillInAllMandatoryFieldsAndDropDownsAndClickContinueOptometrist(String surname, String dateOfBirth) {
        String firstName = testDataManager.getTestInputRegionData("optomConstants.firstName");
        String postcode = testDataManager.getTestInputCommonData("customerEntryConstants.postcode");
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterOptometristText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and Mx and Not Specified and drop downs and click continue - patient")
    public void fillInAllMandatoryFieldsAndMxAndNotSpecifiedAndClickContinuePatient(String surname, String dateOfLastSightTest, String dateOfBirth) {
        this.fillInAllMandatoryFieldsAndDropDownsPatient(surname, dateOfLastSightTest, dateOfBirth);
        this.clickPatientTitleDropDownMxButton();
        this.clickGenderDropDownNotSpecifiedButton();
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in all mandatory fields and Mx and Neutral and drop downs and click continue - patient")
    public void fillInAllMandatoryFieldsAndMxAndNeutralAndClickContinuePatient(String surname, String dateOfLastSightTest, String dateOfBirth) {
        this.fillInAllMandatoryFieldsAndDropDownsPatient(surname, dateOfLastSightTest, dateOfBirth);
        this.clickPatientTitleDropDownMxButton();
        this.clickGenderDropDownNeutralButton();
        customerEntryPageSteps.clickContinueButton();
    }
    @Step("Fill in alternative contact information for care home venue manager")
    public void fillInAlternativeContactInformationForCareHomeVenueManager(String surname) {
        customerEntryPageSteps.clickAlternativeContactMainDropDownNewContactButton();
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMrButton();
        customerEntryPageSteps.clickAlternativeContactTypeDropDownVenueManagerButton();
        customerEntryPageSteps.enterAlternateContactText("Care Home Manager", surname, "01243240", "012432404023");
        //customerEntryPageSteps.clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton();
    }
    @Step("Fill in alternative contact information for home visit primary contact")
    public void fillInAlternativeContactInformationForHomeVisitPrimaryContact(String surname) {
        customerEntryPageSteps.clickAlternativeContactMainDropDownNewContactButton();
        customerEntryPageSteps.clickAlternativeContactTitleDropDownMrButton();
        customerEntryPageSteps.clickAlternativeContactTypeDropDownPatientFamilyButton();
        customerEntryPageSteps.enterAlternateContactText("Patient Family", surname, "01243240", "012432404023");
        //customerEntryPageSteps.clickAlternativeContactHomeTelephoneNumberPrimaryContactRadioButton();
    }

    //Search data function
    @Step("Enter contact name into name column and hit enter - assert patient appears in the list - contacts page")
    public void enterNameIntoNameColumnAndAssertPatientInListContactsPage(String contactName){
        contactsPageSteps.typeTextIntoAndEnterContactNameSearchBox(contactName);
        contactsPageSteps.assertContactIsInList(contactName);
    }
    @Step("Click the contact name in the Name column - contacts page")
    public void clickNameInNameColumnContactsPage(String contactName) {
        contactsPageSteps.clickOnNameInList(contactName);
    }
    @Step("Enter venue name into venue name column and hit enter - venues page")
    public void enterVenueNameIntoVenueNameColumnVenuesPage(String venueName){
        venuesPageSteps.typeTextIntoAndEnterVenueNameSearchBox(venueName);
    }
    @Step("Enter venue name into venue name column and hit enter, and assert search returned no results - venues page")
    public void enterVenueNameIntoVenueNameColumnAndAssertTheSearchReturnedNoResultsIsPresentVenuesPage(String venueName){
        venuesPageSteps.typeTextIntoAndEnterVenueNameSearchBox(venueName);
        venuesPageSteps.assertSearchResultsTextContains("The search returned no results.");
    }
    @Step("Enter venue name into venue name column and hit enter, and assert venue is present - venues page")
    public void enterVenueNameIntoVenueNameColumnAndAssertTheVenueIsPresentVenuesPage(String venueName){
        venuesPageSteps.typeTextIntoAndEnterVenueNameSearchBox(venueName);
        venuesPageSteps.assertVenueIsInList(venueName);
    }
    @Step("Enter primary contact name into primary contact column and hit enter - venues page")
    public void enterPrimaryContactNameIntoPrimaryContactColumnVenuesPage(String primaryContactName){
        venuesPageSteps.typeTextIntoAndEnterPrimaryContactSearchBox(primaryContactName);
    }
    @Step("Enter primary contact name into primary contact column and hit enter and assert venue name and primary contact are correct - venues page")
    public void enterPrimaryContactNameIntoPrimaryContactColumnAndAssertVenueNameAndPrimaryContactAreCorrectVenuesPage(String primaryContactName, String venueName){
        venuesPageSteps.typeTextIntoAndEnterPrimaryContactSearchBox(primaryContactName);
        venuesPageSteps.assertVenueAndPrimaryContactAreInList(venueName, primaryContactName);
    }
    @Step("Click the venue name in the Venue Name column - venues page")
    public void clickVenueNameInVenueNameColumnVenuesPage(String venueName) {
        venuesPageSteps.clickOnVenueNameInList(venueName);
    }
    @Step("Click the primary contact in the primary contact column - venues page")
    public void clickPrimaryContactInPrimaryContactColumnVenuesPage(String primaryContactName){
        venuesPageSteps.clickOnPrimaryContactInList(primaryContactName);
    }
    @Step("Click the refresh records button")
    public void clickTheRefreshIcon() {
        commonPageSteps.clickTheRefreshIcon();
    }

    //Open Record Steps

    @Step("Click the record edit button")
    public void clickRecordEditButton() {
        commonPageSteps.clickRecordEditButton();
    }
    @Step("Click the record save button")
    public void clickRecordSaveButton() {
        commonPageSteps.clickRecordSaveButton();
    }
    @Step("Click the record close button")
    public void clickRecordCloseButton() {
        commonPageSteps.clickRecordCloseButton();
    }

    @Step("Delete the current record being viewed")
    public void deleteCurrentOpenRecord(){
        commonPageSteps.deleteCurrentOpenRecord();
    }
    @Step("Verify Title is [Title]")
    public void verifyTitleIs(String expectedTitle){
        System.out.println(contactPopupPageSteps.getContactTitle(expectedTitle));
        assert contactPopupPageSteps.getContactTitle(expectedTitle).equals(true);
    }

    @Step("Verify Gender is [Gender]")
    public void verifyGenderIsNotSpecified(String expectedGender){
        assert contactPopupPageSteps.getContactGenderNotSpecified(expectedGender).equals(true);
    }
    @Step("Verify Gender is [Gender]")
    public void verifyGenderIsNeutral(String expectedGender){
        assert contactPopupPageSteps.getContactGenderNeutral(expectedGender).equals(true);
    }

    @Step("Navigate to Additional Info")
    public void navigateToAdditionalInfo() { contactPopupPageSteps.navigateToAdditionalInfo();
    }

    @Step("Close the current record being viewed")
    public void closeCurrentDeletedRecord(){
        commonPageSteps.closeCurrentDeletedRecord();
    }

    //Venue record steps
    @Step("Click Venue Top Left Dropdown button")
    public void clickVenueTopLeftDropdownButton() {
        venuePopupPageSteps.clickVenueTopLeftDropdownButton();
    }
    @Step("Click the 'Make Dormant' record option")
    public void clickVenueMakeRecordDormantOption() {
        venuePopupPageSteps.clickVenueMakeRecordDormantOption();
    }
    @Step("Click Venue 'Delete' record option")
    public void clickVenueDeleteRecordOption() {
        venuePopupPageSteps.clickVenueDeleteRecordOption();
    }
    @Step("Click confirmation on record pop up option")
    public void clickVenuePopUpConfirmButton() {
        venuePopupPageSteps.clickVenuePopUpConfirmButton();
    }
    @Step("Click the 'Close Window' record option")
    public void clickVenueCloseWindowOption() {
        venuePopupPageSteps.clickVenueCloseWindowOption();
    }

    @Step("Change the venue details for an optometrist")
    public void changeVenueDetailsForOptometrist(String text) {
        venuePopupPageSteps.enterTextIntoVenueName(text);
        venuePopupPageSteps.clickIDStatusSelfEmployedDropDownOption();
        venuePopupPageSteps.clickVenueTypeOOStaffDropDownOption();
    }
    @Step("Change venue details for a care home")
    public void changeVenueDetailsForCareHome(String newVenueName) {
        venuePopupPageSteps.enterTextIntoVenueName(newVenueName);
        venuePopupPageSteps.clickVenueTypeCareHomeOnlyDropDownOption();
    }
    @Step("Change venue details for a hospital")
    public void changeVenueDetailsForHospital(String newVenueName) {
        venuePopupPageSteps.enterTextIntoVenueName(newVenueName);
        venuePopupPageSteps.clickVenueTypeHospitalDropDownOption();
    }
    @Step("Change venue details for a prison")
    public void changeVenueDetailsForPrison(String newVenueName) {
        venuePopupPageSteps.enterTextIntoVenueName(newVenueName);
        venuePopupPageSteps.clickVenueTypePrisonDropDownOption();
    }
    @Step("Enter text into venue name field")
    public void enterTextIntoVenueName(String text) {
        venuePopupPageSteps.enterTextIntoVenueName(text);
    }
    @Step("Click ID/Status -> Self Employed option")
    public void clickIDStatusSelfEmployedDropDownOption() {
        venuePopupPageSteps.clickIDStatusSelfEmployedDropDownOption();
    }
    @Step("Click Venue Type -> OO Staff option")
    public void clickVenueTypeOOStaffDropDownOption() {
        venuePopupPageSteps.clickVenueTypeOOStaffDropDownOption();
    }
    @Step("Click Venue details button")
    public void clickVenueDetailsButton() {
        venuePopupPageSteps.clickVenueDetailsButton();
    }

    //Contact record steps
    @Step("Click contact type -> Optometrist option")
    public void clickContactTypeOptometristOption() {
        contactPopupPageSteps.clickContactTypeOptometristOption();
    }
    @Step("Click Funding -> Staff option")
    public void clickFundingStaffOption() {
        contactPopupPageSteps.clickFundingStaffOption();
    }
    @Step("Change optometrist primary contact details")
    public void changePrimaryContactDetailsForOptometrist() {
        contactPopupPageSteps.clickContactTypeOptometristOption();
        contactPopupPageSteps.clickFundingStaffOption();
    }

    //Optometrist info
    @Step("Tick all optometrist info tick boxes")
    public void tickOptometristInfoTickBoxes() {
        commonPageSteps.tickOptometristInfoTickBoxes();
    }

    //Record navigation
    @Step("Record - navigate to Details -> Optometrist Info")
    public void navigateToOptometristInfo() {
        commonPageSteps.navigateToOptometristInfo();
    }
    @Step("Record - navigate to Details -> Diary Entries")
    public void navigateToOptometristDiaryEntries() {
        commonPageSteps.navigateToOptometristDiaryEntries();
    }
    @Step("Record - navigate to Details -> Diary Entries and assert first diary entry date is correct")
    public void navigateToOptometristDiaryEntriesAndAssertFirstDateIsCorrect(String date) {
        commonPageSteps.navigateToOptometristDiaryEntries();
        optometristDiaryEntriesPopupPageSteps.assertFirstDiaryEntryDateIsCorrect(date);
    }


    //Scheduling - Availability
    @Step("Click the 'Previous' week button")
    public void clickThePreviousWeekButtonInSchedulingAvailability() {
        schedulingAvailabilitySteps.clickPreviousWeekButton();
    }
    @Step("Click the 'Next' week button")
    public void clickTheNextWeekButtonInScheduling() {
       commonPageSteps.clickNextWeekButton();
    }
    @Step("Click the 'Optometrist (Selected - 0)' button")
    public void clickTheOptometristSelectedButtonInScheduling() {
        commonPageSteps.clickOptometristSelectedButton();
    }
    @Step("Click the '1-Automation-Optometrist OO-Automation-Bot1' tick box in Scheduling - Diary")
    public void clickTheAutomationOptometristBot1TickBoxInSchedulingDiary() {
        schedulingDiarySteps.clickTheAutomationOptometristBot1TickBoxDiary();
    }
    @Step("Click the 'Submit' button (Scheduling - Availability)")
    public void clickTheSubmitOptometristSelectedButtonInScheduling() {
        commonPageSteps.clickSubmitOptometristSelectedButton();
    }
    @Step("Click the '1-Automation-Optometrist OO-Automation-Bot1' tick box in Scheduling - Diary and submit")
    public void clickTheAutomationOptometristBot1TickBoxInSchedulingDiaryAndSubmit() {
        schedulingDiarySteps.clickTheAutomationOptometristBot1TickBoxDiary();
        commonPageSteps.clickSubmitOptometristSelectedButton();
    }


    @Step("Click visit in Scheduling - Diary")
    public void clickVisitInSchedulingDiary(String surname, String date) {
        schedulingDiarySteps.clickVisitInSchedulingDiary(surname);
        schedulingDiarySteps.assertVisitDateIsCorrect(date);
    }
    @Step("Retrieve availability for current week")
    public void getDaySubTerritoryStatus(String subTerritory) {
        schedulingAvailabilitySteps.getDaySubTerritoryStatus(subTerritory);
    }
    @Step("Fill in availability for current week")
    public void assignDaysAsAvailableForCurrentWeek() {
        schedulingAvailabilitySteps.assignDaysAsAvailableForCurrentWeek();
    }

    @Step("Fill in availability for current week - England")
    public void fillInAvailabilityForCurrentWeek() {
        schedulingAvailabilitySteps.fillInAvailabilityForCurrentWeek();
    }
    @Step("Fill in availability for current week - Scotland")
    public void fillInAvailabilityForCurrentWeekScotland() {
        schedulingAvailabilitySteps.fillInAvailabilityForCurrentWeekScotland();
    }
    @Step("Fill in availability for current week - Wales")
    public void fillInAvailabilityForCurrentWeekWales() {
        schedulingAvailabilitySteps.fillInAvailabilityForCurrentWeekWales();
    }
    @Step("Fill in availability for current week - Northern Ireland")
    public void fillInAvailabilityForCurrentWeekNorthernIreland() {
        schedulingAvailabilitySteps.fillInAvailabilityForCurrentWeekNorthernIreland();
    }
    @Step("Click the 'Save' button in Scheduling - Availability")
    public void clickSaveButtonInSchedulingAvailability() {
        schedulingAvailabilitySteps.clickSaveButtonInSchedulingAvailability();
    }

    //Scheduling - Diary
    @Step("Click the 'Previous' week button")
    public void clickThePreviousWeekButtonInSchedulingDiary() {
        schedulingDiarySteps.clickPreviousWeekButton();
    }
    @Step("Click the 'Next' week button")
    public void clickTheNextWeekButtonInSchedulingDiary() {
        schedulingDiarySteps.clickNextWeekButton();
    }
    @Step("Click the 'Optometrist (Selected - 0)' button")
    public void clickTheOptometristSelectedButtonInSchedulingDiary() {
        schedulingDiarySteps.clickOptometristSelectedButton();
    }
    @Step("Click the optometrist's tick box in Scheduling - Availability")
    public void clickOptometristTickBoxAvailability(String optomName) {
        schedulingAvailabilitySteps.clickOptometristTickBoxAvailability(optomName);
    }
    @Step("Click the 'Submit' button (Scheduling - Diary)")
    public void clickTheSubmitOptometristSelectedButtonInSchedulingDiary() {
        schedulingDiarySteps.clickSubmitOptometristSelectedButton();
    }

    //Click all mandatory drop downs and buttons in one go
    @Step("Click all mandatory drop downs and buttons in one go")
    public void clickMandatoryDropDownsAndButtons() {
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }

    //Complete GDPR all yes in one go
    @Step("Complete GDPR all yes in one go")
    public void completeGDPRAllYesAndSave() {
        customerEntryPageSteps.completeGDPRAllYes();
        customerEntryPageSteps.clickMarketingConsentConfirmButton();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        waitABit(10000);
    }

    //Search patient/venue pop up
    @Step("Enter text into patient search text box")
    public void enterTextIntoPatientSearchTextBox(String text) {
        customerEntryPageSteps.enterTextIntoPatientSearchTextBox(text);
    }
    @Step("Click patient/venue Search button and search for patient")
    public void clickSearchPatientVenueButtonAndSearchForPatient(String text) {
        customerEntryPageSteps.clickSearchPatientVenueButton();
        customerEntryPageSteps.enterTextIntoPatientSearchTextBox(text);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientIsPresent(text);
    }
    @Step("Click patient/venue Search button and search for venue")
    public void clickSearchPatientVenueButtonAndSearchForVenue(String venueName) {
        customerEntryPageSteps.clickSearchPatientVenueButton();
        customerEntryPageSteps.enterTextIntoVenueNameSearchTextBox(venueName);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertVenueIsPresent(venueName);
    }
    @Step("Click patient/venue Search button and search for venue")
    public void clickSearchPatientVenueButtonAndSearchForPostcode(String postcode) {
        customerEntryPageSteps.clickSearchPatientVenueButton();
        customerEntryPageSteps.enterTextIntoPostcodeSearchTextBox(postcode);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPostcodeIsPresent(postcode);
    }
    @Step("Search patient/venue search for patient")
    public void searchPatientVenueSearchForPatient(String patientName) {
        customerEntryPageSteps.enterTextIntoPatientSearchTextBox(patientName);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientIsPresent(patientName);
    }
    @Step("Search patient/venue search for venue")
    public void searchPatientVenueSearchForVenue(String patientName, String venueName) {
        customerEntryPageSteps.enterTextIntoVenueNameSearchTextBox(venueName);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientAndVenueArePresent(patientName, venueName);
    }
    @Step("Search patient/venue search for postcode")
    public void searchPatientVenueSearchForPostcode(String postcode) {
        customerEntryPageSteps.enterTextIntoPostcodeSearchTextBox(postcode);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPostcodeIsPresent(postcode);
    }
    @Step("Search patient/venue search for patient and venue")
    public void searchPatientVenueSearchForPatientAndVenue(String patientName, String venueName) {
        customerEntryPageSteps.enterTextIntoPatientSearchTextBox(patientName);
        customerEntryPageSteps.enterTextIntoVenueNameSearchTextBox(venueName);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientAndVenueArePresent(patientName, venueName);
    }
    @Step("Search patient/venue search for patient and postcode")
    public void searchPatientVenueSearchForPatientAndPostcode(String patientName, String postcode) {
        customerEntryPageSteps.enterTextIntoPatientSearchTextBox(patientName);
        customerEntryPageSteps.enterTextIntoPostcodeSearchTextBox(postcode);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientIsPresent(patientName);
    }
    @Step("Search patient/venue search for venue and postcode")
    public void searchPatientVenueSearchForVenueAndPostcode(String patientName, String venueName, String postcode) {
        customerEntryPageSteps.enterTextIntoVenueNameSearchTextBox(venueName);
        customerEntryPageSteps.enterTextIntoPostcodeSearchTextBox(postcode);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientAndVenueArePresent(patientName, venueName);
    }
    @Step("Search patient/venue search for patient, venue and postcode")
    public void searchPatientVenueSearchForPatientVenueAndPostcode(String patientName, String venueName, String postcode) {
        customerEntryPageSteps.enterTextIntoPatientSearchTextBox(patientName);
        customerEntryPageSteps.enterTextIntoVenueNameSearchTextBox(venueName);
        customerEntryPageSteps.enterTextIntoPostcodeSearchTextBox(postcode);
        customerEntryPageSteps.clickPatientVenueSearchButtonAndAssertPatientAndVenueArePresent(patientName, venueName);
    }
    @Step("Clear text from Search Patient/Venue text boxes")
    public void clearTextFromSearchPatientVenueTextBoxes() {
        customerEntryPageSteps.clearTextFromSearchPatientVenueTextBoxes();
    }
    @Step("Search patient/venue - click cancel button")
    public void searchPatientVenueClickCancelButton() {
        customerEntryPageSteps.searchPatientVenueClickCancelButton();
    }
    @Step("Click patient Select button")
    public void clickPatientSelectButton(String surname) {
        customerEntryPageSteps.clickPatientSelectButton(surname);
    }
    @Step("Click venue Select button")
    public void clickVenueSelectButton(String surname) {
        customerEntryPageSteps.clickVenueSelectButton(surname);
    }

    @Step("Enter date into visit date text box")
    public void enterDateIntoVisitDateTextBox(String date) {
        customerEntryPageSteps.enterDateIntoVisitDateTextBox(date);
    }
    @Step("Choose the automation optometrist from the optometrists drop down")
    public void clickAutomationOptomInOptometristDropDown() {
        customerEntryPageSteps.clickAutomationOptomInOptometristDropDown();
    }
    @Step("Choose the automation optometrist from the optometrists drop down")
    public void clickAutomationOptom5InOptometristDropDown() {
        customerEntryPageSteps.clickAutomationOptom5InOptometristDropDown();
    }
    @Step("Choose the automation optometrist from the optometrists drop down")
    public void clickAutomationOptom6InOptometristDropDown() {
        customerEntryPageSteps.clickAutomationOptom6InOptometristDropDown();
    }
    @Step("Choose the automation optometrist from the optometrists drop down")
    public void clickAutomationOptom7InOptometristDropDown() {
        customerEntryPageSteps.clickAutomationOptom7InOptometristDropDown();
    }
    @Step("Choose Steve The Optom from the optometrists drop down")
    public void clickSteveTheOptomInOptometristDropDown() {
        customerEntryPageSteps.clickSteveTheOptomInOptometristDropDown();
    }
    @Step("Choose Keith The Optom from the optometrists drop down")
    public void clickKeithTheOptomInOptometristDropDown() {
        customerEntryPageSteps.clickKeithTheOptomInOptometristDropDown();
    }
    @Step("Choose optometrist from the optometrists drop down")
    public void clickOptomInOptometristDropDown(String optomName) {
        customerEntryPageSteps.clickOptomInOptometristDropDown(optomName);
    }

    //Test data prep
    @Step("Create home visit for 1 patient")
    public void createHomeVisitFor1Patient(String surname, String dateOfLastSightTest, String dateOfBirth, String visitDate, String optomName) {
        openCustomerEntry();
        fillInAllMandatoryFieldsAndDropDownsPatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownHomeVisitNewButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surname, dateOfBirth, visitDate, "Home Visit for 1 patient"}});
    }
    @Step("Create home visit for 2 patients")
    public void createHomeVisitFor2Patients(List<String> surnames, String optomName) {
        String visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        openCustomerEntry();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Home Visit for 2 patients"}});
        }
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownHomeVisitNewButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingHomeVisit(patientsToBeAddedSurnames);
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create home visits for patients in the same venue")
    public void createHomeVisitsForPatientsInSameVenue(List<String> surnames, String optomName, String numberOfVisits) {
        String visitDate = DomiciliaryHelpers.getVisitDateXDaysAhead(7);
        openCustomerEntry();
        for (String surname : surnames) {
            if (!surname.equals(surnames.get(0))) {
                clickSearchPatientVenueButtonAndSearchForVenue(surnames.get(0));
                clickVenueSelectButton(surnames.get(0));
            }
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsPatient(surname, dateOfLastSightTest, dateOfBirth);
            clickCreateNewVisitRadioButton();
            clickVisitTypeDropDownHomeVisitNewButton();
            enterDateIntoVisitDateTextBox(visitDate);
            clickOptomInOptometristDropDown(optomName);
            clickContinueButton();
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickFinishButton();
            clickDetailsSavedSuccessfullyContinueToFinish();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, numberOfVisits + " home visits in same venue"}});
        }
    }
    @Step("Create home visit for 3 patients")
    public void createHomeVisitFor3Patients(List<String> surnames, String optomName) {
        String visitDate = DomiciliaryHelpers.getVisitDateWith3WeeksNotice();
        openCustomerEntry();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Home Visit for 3 patients"}});
        }
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownHomeVisitNewButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        patientsToBeAddedSurnames.add(surnames.get(2));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingHomeVisit(patientsToBeAddedSurnames);
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create home visit for 5 patients")
    public void createHomeVisitFor5Patients(List<String> surnames, String optomName) {
        openCustomerEntry();
        String visitDate = DomiciliaryHelpers.getVisitDateWith3WeeksNotice();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Home Visit for 5 patients"}});
        }
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownHomeVisitNewButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        patientsToBeAddedSurnames.add(surnames.get(2));
        patientsToBeAddedSurnames.add(surnames.get(3));
        patientsToBeAddedSurnames.add(surnames.get(4));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingHomeVisit(patientsToBeAddedSurnames);
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create care home visit for 1 patient")
    public void createCareHomeVisitFor1Patient(String surname, String optomName) {
        String visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        openCustomerEntry();
        fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddNewPatientButton();
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surname);
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surname);
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surname);
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surname);
        clickPatientSelectButton(surname);
        fillInAlternativeContactInformationForCareHomeVenueManager(surname);
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownCareHomeVisitButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surname, dateOfBirth, visitDate, "Care Home Visit for 1 patient"}});
    }
    @Step("Create care home visit for 2 patients")
    public void createCareHomeVisitFor2Patients(List<String> surnames, String optomName) {
        String visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        openCustomerEntry();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Care Home Visit for 2 patients"}});
        }
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        fillInAlternativeContactInformationForCareHomeVenueManager(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownCareHomeVisitButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingCareHomeVisit(patientsToBeAddedSurnames);
        clickAddToBookingButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create care home visit for 3 patients")
    public void createCareHomeVisitFor3Patients(List<String> surnames, String optomName) {
        openCustomerEntry();
        String visitDate = DomiciliaryHelpers.getVisitDateWith3WeeksNotice();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Care Home Visit for 3 patients"}});
        }
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        fillInAlternativeContactInformationForCareHomeVenueManager(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownCareHomeVisitButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        patientsToBeAddedSurnames.add(surnames.get(2));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingCareHomeVisit(patientsToBeAddedSurnames);
        clickAddToBookingButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create care home visit for 10 patients")
    public void createCareHomeVisitFor10Patients(List<String> surnames, String optomName) {
        openCustomerEntry();
        String visitDate = DomiciliaryHelpers.getVisitDateWith3WeeksNotice();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Care Home Visit for 10 patients"}});
        }
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        fillInAlternativeContactInformationForCareHomeVenueManager(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownCareHomeVisitButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        patientsToBeAddedSurnames.add(surnames.get(2));
        patientsToBeAddedSurnames.add(surnames.get(3));
        patientsToBeAddedSurnames.add(surnames.get(4));
        patientsToBeAddedSurnames.add(surnames.get(5));
        patientsToBeAddedSurnames.add(surnames.get(6));
        patientsToBeAddedSurnames.add(surnames.get(7));
        patientsToBeAddedSurnames.add(surnames.get(8));
        patientsToBeAddedSurnames.add(surnames.get(9));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingCareHomeVisit(patientsToBeAddedSurnames);
        clickAddToBookingButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create care home venue with patients")
    public void createCareHomeVenueWithPatients(List<String> surnames, String numberOfPatients) {
        openCustomerEntry();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, "N/A", "Care Home Venue with " + numberOfPatients + " patients"}});
        }
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
    }
    @Step("Create care home venue with patients")
    public void createCareHomeVenueWithPatientsAndVenueManager(List<String> surnames, String numberOfPatients) {
        openCustomerEntry();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, "N/A", "Care Home Venue with venue manager - " + numberOfPatients + " patients"}});
        }
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        fillInAlternativeContactInformationForCareHomeVenueManager(surnames.get(0));
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }

    @Step("Create Care Home Visit for 2 patients, 1 with invalid date of birth")
    public void createCareHomeVisitFor2PatientsInvalidDateOfBirth(List<String> surnames, String optomName) {
        String visitDate = DomiciliaryHelpers.getVisitDateWith48HoursNotice();
        String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
        String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        openCustomerEntry();
        fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surnames.get(0), dateOfLastSightTest, dateOfBirth);
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddNewPatientButton();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surnames.get(0), surnames.get(0), dateOfBirth, visitDate, "Care Home Visit for 2 patients - 1 invalid DOB"}});
        dateOfBirth = "31/02/1945";
        dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
        fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surnames.get(1), dateOfLastSightTest, dateOfBirth);
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
        StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surnames.get(1), surnames.get(0), dateOfBirth, visitDate, "Care Home Visit for 2 patients - 1 invalid DOB"}});
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        fillInAlternativeContactInformationForCareHomeVenueManager(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownCareHomeVisitButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        addPatientsToExistingCareHomeVisit(patientsToBeAddedSurnames);
        clickAddToBookingButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }
    @Step("Create retest visit for 1 patient")
    public void createRetestVisitFor1Patient(String surname, String dateOfLastSightTest, String dateOfBirth, String visitDate, String optomName) {
        openCustomerEntry();
        fillInAllMandatoryFieldsAndDropDownsPatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownRetestButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }

    @Step("Create care home visit for 5 patients")
    public void createCareHomeVisitFor5Patients(List<String> surnames, String optomName, String visitDate) {
        openCustomerEntry();
        for (String surname : surnames) {
            String dateOfBirth = DomiciliaryHelpers.generateRandomDateOfBirth();
            String dateOfLastSightTest = DomiciliaryHelpers.generateRandomDateOfLastSightTest();
            fillInAllMandatoryFieldsAndDropDownsAndClickContinuePatient("Automation-Patient-" + surname, dateOfLastSightTest, dateOfBirth);
            clickDataProcessingConsentYesRadioButton();
            completeGDPRAllYesAndSave();
            clickDetailsSavedSuccessfullyContinueToAnotherPatient();
            clickAddNewPatientButton();
            StafUtils.appendToCsv("src/test/resources/TestData/domiciliary/CSV/testData.csv", new String[][]{{surname, surnames.get(0), dateOfBirth, visitDate, "Care Home Visit for 5 patients"}});
        }
        navigateToViewVenuesAll();
        enterVenueNameIntoVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickVenueNameInVenueNameColumnVenuesPage("HV-Automation-Patient-" + surnames.get(0));
        clickRecordEditButton();
        changeVenueDetailsForCareHome("Care Home-Automation-Patient-" + surnames.get(0));
        clickRecordSaveButton();
        clickRecordCloseButton();
        openCustomerEntry();
        clickSearchPatientVenueButtonAndSearchForPatient(surnames.get(0));
        clickPatientSelectButton(surnames.get(0));
        fillInAlternativeContactInformationForCareHomeVenueManager(surnames.get(0));
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownCareHomeVisitButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        customerEntryPageSteps.completeGDPRCareHome();
        customerEntryPageSteps.clickMarketingConsentSaveButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickAddExistingPatientButton();
        List<String> patientsToBeAddedSurnames = new ArrayList<>();
        patientsToBeAddedSurnames.add(surnames.get(1));
        patientsToBeAddedSurnames.add(surnames.get(2));
        patientsToBeAddedSurnames.add(surnames.get(3));
        patientsToBeAddedSurnames.add(surnames.get(4));
        System.out.println(patientsToBeAddedSurnames);
        addPatientsToExistingCareHomeVisit(patientsToBeAddedSurnames);
        clickAddToBookingButton();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }

    @Step("Create home visit for 1 patient - Toby")
    public void createHomeVisitFor1PatientTobyBir2(String surname, String dateOfLastSightTest, String dateOfBirth, String visitDate, String optomName) {
        openCustomerEntry();
        fillInAllMandatoryFieldsAndDropDownsPatientTobyBir2(surname, dateOfLastSightTest, dateOfBirth);
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownHomeVisitNewButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }

    @Step("Fill in all mandatory fields and drop downs - patient")
    public void fillInAllMandatoryFieldsAndDropDownsPatientTobyBir2(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = "Example";
        String postcode = "M28 1AD";
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        openCustomerEntry();
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }

    @Step("Create home visit for 1 patient - Toby")
    public void createHomeVisitFor1PatientTobyBir3(String surname, String dateOfLastSightTest, String dateOfBirth, String visitDate, String optomName) {
        openCustomerEntry();
        fillInAllMandatoryFieldsAndDropDownsPatientTobyBir3(surname, dateOfLastSightTest, dateOfBirth);
        clickCreateNewVisitRadioButton();
        clickVisitTypeDropDownHomeVisitNewButton();
        enterDateIntoVisitDateTextBox(visitDate);
        clickOptomInOptometristDropDown(optomName);
        clickContinueButton();
        clickDataProcessingConsentYesRadioButton();
        completeGDPRAllYesAndSave();
        clickDetailsSavedSuccessfullyContinueToAnotherPatient();
        clickFinishButton();
        clickDetailsSavedSuccessfullyContinueToFinish();
    }

    @Step("Fill in all mandatory fields and drop downs - patient")
    public void fillInAllMandatoryFieldsAndDropDownsPatientTobyBir3(String surname, String dateOfLastSightTest, String dateOfBirth) {
        String firstName = "Example";
        String postcode = "M28 1AG";
        String homeTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.homeTelephoneNumber");
        String mobileTelephoneNumber = testDataManager.getTestInputCommonData("customerEntryConstants.mobileTelephoneNumber");
        openCustomerEntry();
        customerEntryPageSteps.selectFirstAddressForPostcode(postcode);
        customerEntryPageSteps.enterPatientText(firstName, surname, homeTelephoneNumber, mobileTelephoneNumber, dateOfLastSightTest, dateOfBirth);
        customerEntryPageSteps.clickMandatoryDropDownsAndButtons();
    }
}
