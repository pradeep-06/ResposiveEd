package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.checkerframework.common.value.qual.EnsuresMinLenIf;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import static Framework.Staf.wait;

public class b2bEyeCareMultiUserPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareMultiUserPage.class);
    @FindBy(xpath = "(//h3[normalize-space()='NO'])")
    private WebElementFacade NO;
    @FindBy(xpath = "(//h3[normalize-space()='SE'])")
    private WebElementFacade SE;

    @FindBy(xpath = "(//h3[normalize-space()='GB'])")
    private WebElementFacade GB;

    @FindBy(xpath = "(//h3[normalize-space()='pleaseSelectAnyRole'])")
    private WebElementFacade PleaseSelectAnyRole;


    @FindBy(xpath = "(//h3[normalize-space()='SE']/following::h6[@class='role'][normalize-space()='B2BSTOREMANAGER'])")
    private WebElementFacade SEStoreManager;
    @FindBy(xpath = "(//h3[normalize-space()='NO']/following::h6[@class='role'][normalize-space()='B2BSTOREMANAGER'])")
    private WebElementFacade NOStoreManager;


    @FindBy(xpath = "(//h3[normalize-space()='SE']/following::h6[@class='role'][normalize-space()='B2BSTOREUSER'])")
    private WebElementFacade SEStoreUser;
    @FindBy(xpath = "(//h3[normalize-space()='NO']/following::h6[@class='role'][normalize-space()='B2BSTOREUSER'])")
    private WebElementFacade NOStoreUser;






    public void waituntillSelectRegionisDisplayed() {
        PleaseSelectAnyRole.waitUntilVisible();
    }


    public void selectTheRegion() {

        //wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".specs-card")));
        //wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".specs-card")));


       /* new WebDriverWait(getDriver(), Duration.ofSeconds(30)).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(60));
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".specs-card")));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".specs-card")));*/


        // Ensure the page is fully loaded
        //new WebDriverWait(getDriver(), Duration.ofSeconds(30)).until(
                //webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        //WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(60));
        //wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".specs-card")));
        //wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".specs-card")));

        FluentWait<WebDriver> wait = new FluentWait<>(getDriver())
                .withTimeout(Duration.ofSeconds(60)) // Total timeout
                .pollingEvery(Duration.ofSeconds(1)) // Polling interval
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".specs-card")));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".specs-card")));


        if (Staf.getTargetRegion().equals("no")) {
            NO.waitUntilVisible();
            clickElement(NO);
            logger.info("User Click on NO Region");
        } else if (Staf.getTargetRegion().equals("se")) {
            SE.waitUntilVisible();
            clickElement(SE);
            logger.info("User Click on SE Region");
        }else if (Staf.getTargetRegion().equals("uk")) {
            GB.waitUntilVisible();
            clickElement(GB);
            logger.info("User Click on GB Region");
        }
    }

    public void selectTheRegionAsStoreManager() {
        if (Staf.getTargetRegion().equals("no")) {
            clickElement(NOStoreManager);
            logger.info("User Click on NO Region");
        } else if (Staf.getTargetRegion().equals("se")) {
            clickElement(SEStoreManager);
            logger.info("User Click on SE Region");
        }
    }


    public void selectTheRegionAsStoreUser() {
        if (Staf.getTargetRegion().equals("no")) {
            clickElement(NOStoreUser);
            logger.info("User Click on NO Region");
        } else if (Staf.getTargetRegion().equals("se")) {
            clickElement(SEStoreUser);
            logger.info("User Click on SE Region");
        }
    }
}


