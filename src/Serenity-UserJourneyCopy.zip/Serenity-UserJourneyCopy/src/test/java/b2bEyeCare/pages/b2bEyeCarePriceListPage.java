package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.rest.Ensure;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static Framework.Staf.wait;

public class b2bEyeCarePriceListPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCarePriceListPage.class);


    @FindBy(xpath = "//*[contains(text(), 'Automation')]")
    private WebElementFacade selectTemplate;



    @FindBy(css = "button[class='specs-button specs-button--size-extrasmall specs-button--outlined specs-button--align-right specs-button--outlined-default specs-button--underline-hover bg-white editbutton']")
    private WebElementFacade editTemplate;


    @FindBy(css = "input.specs-input.specs-input--large.specs-input--align-left")
    private WebElementFacade nameofPriceList;

    @FindBy(css = "svg.svg-inline--fa.fa-trash-can.grid-icon")
    private WebElementFacade deleteTemplate;

    @FindBy(xpath = "//button[normalize-space()='Add Item']")
    private WebElementFacade addItem;


    @FindBy(css = ".dropDownMenuWrapper.w-100.item_container")
    private WebElementFacade clickdropdown;


    @FindBy(xpath = "//p[normalize-space()='SightTest']")
    private WebElementFacade SightTest;

    @FindBy(xpath = "//p[normalize-space()='Digital']")
    private WebElementFacade Digital;


    @FindBy(xpath = "//p[normalize-space()='SafetyS']")
    private WebElementFacade SafetyS;

    @FindBy(xpath = "//p[normalize-space()='SafetyF']")
    private WebElementFacade SafetyF;

    @FindBy(xpath = "//p[normalize-space()='Bespoke']")
    private WebElementFacade Bespoke;


    @FindBy(xpath = "//p[normalize-space()='795']")
    private WebElementFacade noframe;


    @FindBy(xpath = "//p[normalize-space()='395']")
    private WebElementFacade seframe;


    @FindBy(xpath = "//p[normalize-space()='Enstyrke - S']")
    private WebElementFacade noLens;

    @FindBy(xpath = "//p[normalize-space()='Access HD']")
    private WebElementFacade seLens;


    @FindBy(xpath = "//p[normalize-space()='Fargeskiftende']")
    private WebElementFacade noCoating;

    @FindBy(xpath = "//p[normalize-space()='Ultra Clear']")
    private WebElementFacade seCoating;


    @FindBy(xpath = "//button[normalize-space()='Update']")
    private WebElementFacade Update;


    @FindBy(css = ".article:nth-child(1) > .item_container")
    private WebElementFacade clickonfirstDropdown;


    @FindBy(css = ".article:nth-child(1) > .dropDownMenuWrapper")
    private WebElementFacade sightTestDropdown;


    @FindBy(css = "div:nth-child(1) > .menuItem p")
    private WebElementFacade selectSight;

    @FindBy(css = "div:nth-child(2) > .menuItem p")
    private WebElementFacade selectDigital;


    @FindBy(xpath = "//div[@id='1']/div/div/div[2]/section")
    private WebElementFacade clickonDSecondDropdown;

    @FindBy(xpath = "//div[@id='1']/div/div/div[3]/section")
    private WebElementFacade clickonDThirdDropdown;

    @FindBy(xpath = "//div[@id='1']/div/div/div[4]/section")
    private WebElementFacade clickonDFourthDropdown;

    @FindBy(xpath = "//div[@id='1']/div/div/div[5]/section")
    private WebElementFacade clickonDFifthDropdown;

    @FindBy(css = "div:nth-child(3) > .menuItem p")
    private WebElementFacade selectSafetyS;
    @FindBy(xpath = "//div[@id='2']/div/div/div[2]/section")
    private WebElementFacade clickonSSecondDropdown;

    @FindBy(xpath = "//div[@id='2']/div/div/div[3]/section")
    private WebElementFacade clickonSThirdDropdown;

    @FindBy(xpath = "//div[@id='2']/div/div/div[4]/section")
    private WebElementFacade clickonSFourthDropdown;

    @FindBy(xpath = "//div[@id='2']/div/div/div[5]/section")
    private WebElementFacade clickonSFifthDropdown;
    @FindBy(css = "div:nth-child(4) > .menuItem p")
    private WebElementFacade selectSafetyF;
    @FindBy(xpath = "//div[@id='3']/div/div/div[2]/section")
    private WebElementFacade clickonFSecondDropdown;

    @FindBy(xpath = "//div[@id='3']/div/div/div[3]/section")
    private WebElementFacade clickonFThirdDropdown;

    @FindBy(xpath = "//div[@id='3']/div/div/div[4]/section")
    private WebElementFacade clickonFFourthDropdown;

    @FindBy(xpath = "//div[@id='3']/div/div/div[5]/section")
    private WebElementFacade clickonFFifthDropdown;
    @FindBy(css = "div:nth-child(5) > .menuItem p")
    private WebElementFacade Bespokes;
    @FindBy(xpath = "//div[@id='4']/div/div/div[2]/section")
    private WebElementFacade clickonBSecondDropdown;

    @FindBy(xpath = "//div[@id='4']/div/div/div[3]/section")
    private WebElementFacade clickonBThirdDropdown;

    @FindBy(xpath = "//div[@id='4']/div/div/div[4]/section")
    private WebElementFacade clickonBFourthDropdown;

    @FindBy(xpath = "//div[@id='4']/div/div/div[5]/section")
    private WebElementFacade clickonBFifthDropdown;


    @FindBy(css = "div:nth-child(1) > .menuItem p")
    private WebElementFacade selectvalue;


    @FindBy(css = ".fa-trash-can > path")
    private WebElementFacade deleteIcon;


    public void selectTheTemplate() {

        clickElement(selectTemplate);

    }

    public void clickOnEdit() {

        clickElement(editTemplate);

    }

    public void getTheTemplateName() {
        clickElement(nameofPriceList);
        String nameOfPriceList = nameofPriceList.getText();
        logger.info("User get the Template name:" + nameOfPriceList);
    }



    public void deleteTemplate() {
        try {
            while (deleteIcon.isDisplayed()) {
                clickElement(deleteIcon);
                logger.info("User clicked the Delete icon");
                waitABit(1000);
                //Thread.sleep(1000);
            }
        } catch (NoSuchElementException e) {
            logger.error("Delete icon not found: " + e.getMessage());
        } catch (Exception e) {
            logger.error("An unexpected error occurred: " + e.getMessage());
        }
    }



    public void clickdropdown() {
        clickElement(clickdropdown);
        logger.info("User click on drop down");
    }

    public void clickAddItem() {
        clickElement(addItem);

    }

    public void selectSightTest() {
        clickElement(SightTest);
        logger.info("Select the sight Test");

    }

    public void selectBespoke() {
        clickElement(Bespoke);
        logger.info("Select the Bespoke");

    }

    public void selectDigital() {
        clickElement(Digital);
        logger.info("Select the Digital");

    }

    public void selectSafetyS() {
        clickElement(SafetyS);
        logger.info("Select the SafetyS");

    }

    public void selectSafetyF() {
        clickElement(SafetyF);
        logger.info("Select the SafetyF");

    }

    public void selectNoframes() {
        clickElement(noframe);
        logger.info("Select the Frame");

    }

    public void selectSeframes() {
        clickElement(seframe);
        logger.info("Select the Frame");

    }


    public void selectNoLens() {
        clickElement(noLens);
        logger.info("Select the Lens");

    }

    public void selectSeLens() {
        clickElement(seLens);
        logger.info("Select the Lens");

    }

    public void selectNoCoating1() {
        clickElement(noCoating);
        logger.info("Select the Coating");

    }

    public void selectSeCoating1() {
        clickElement(seCoating);
        logger.info("Select the Coating");

    }


    public void selectUpdate() {
        clickElement(Update);
        logger.info("Select the Update");

    }
    public void userWaituntillupdated() {
        editTemplate.isCurrentlyVisible();
        editTemplate.isClickable();
        logger.info("Select the Update");

    }





    public boolean isAddItemRowMessageDisplayed() {
        try {
            WebElement addItemRowMessage = getDriver().findElement(By.tagName("h6"));
            return addItemRowMessage.isDisplayed() && addItemRowMessage.getText().equals("Please add one Item row");
        } catch (NoSuchElementException e) {
            logger.error("Element not found: " + e.getMessage());
            return false;
        } catch (Exception e) {
            logger.error("An unexpected error occurred: " + e.getMessage());
            return false;
        }
    }

    public void addsighttestItemtoTemplate() {

        clickElement(sightTestDropdown);
        logger.info("click on 1st Drop down");
        clickElement(selectSight);
        logger.info("Select the Sight test");

    }
    public void adddigitalItemtoTemplate() {
        clickElement(clickonfirstDropdown);
        logger.info("click on 1st Drop down");
        clickElement(selectDigital);
        logger.info("Select the digital");
        clickElement(clickonDSecondDropdown);
        logger.info("click on 2nd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Frames values");
        clickElement(clickonDThirdDropdown);
        logger.info("click on 3rd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Lesnses values");
        clickElement(clickonDFourthDropdown);
        logger.info("click on 4th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Index values");
        clickElement(clickonDFifthDropdown);
        logger.info("click on 5th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Coating values");
    }

    public void addsafetysItemtoTemplate() {
        clickElement(clickonfirstDropdown);
        logger.info("click on 1st Drop down");
        clickElement(selectSafetyS);
        logger.info("Select the digital");
        clickElement(clickonSSecondDropdown);
        logger.info("click on 2nd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Frames values");
        clickElement(clickonSThirdDropdown);
        logger.info("click on 3rd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Lesnses values");
        clickElement(clickonSFourthDropdown);
        logger.info("click on 4th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Index values");
        clickElement(clickonSFifthDropdown);
        logger.info("click on 5th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Coating values");
    }

    public void addsafetyfItemtoTemplate() {
        clickElement(clickonfirstDropdown);
        logger.info("click on 1st Drop down");
        clickElement(selectSafetyF);
        logger.info("Select the digital");
        clickElement(clickonFSecondDropdown);
        logger.info("click on 2nd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Frames values");
        clickElement(clickonFThirdDropdown);
        logger.info("click on 3rd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Lesnses values");
        clickElement(clickonFFourthDropdown);
        logger.info("click on 4th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Index values");
        clickElement(clickonFFifthDropdown);
        logger.info("click on 5th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Coating values");
    }

    public void addbespokeItemtoTemplate() {
        clickElement(clickonfirstDropdown);
        logger.info("click on 1st Drop down");
        clickElement(Bespokes);
        logger.info("Select the digital");
        clickElement(clickonBSecondDropdown);
        logger.info("click on 2nd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Frames values");
        clickElement(clickonBThirdDropdown);
        logger.info("click on 3rd Drop down");
        clickElement(selectvalue);
        logger.info("Select the Lesnses values");
        clickElement(clickonBFourthDropdown);
        logger.info("click on 4th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Index values");
        clickElement(clickonBFifthDropdown);
        logger.info("click on 5th Drop down");
        clickElement(selectvalue);
        logger.info("Select the Coating values");
    }

}





