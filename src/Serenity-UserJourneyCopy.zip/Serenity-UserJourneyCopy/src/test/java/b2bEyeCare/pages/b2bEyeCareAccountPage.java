package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static Framework.Staf.wait;

public class b2bEyeCareAccountPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareAccountPage.class);

    String generateSubAccName = b2bEyeCareBase.generateSubAccName();

    String actualAccountName;
    @FindBy(css = "div[id^=accountList]")
    private WebElementFacade national;

    @FindBy(css = "#addRequisition")
    private WebElementFacade assignRequisition;


    @FindBy(css = "#addSubOrganisation")
    private WebElementFacade subOrganisation;

    @FindBy(css = "#addAccount")
    private WebElementFacade addnewAccount;

    @FindBy(xpath = "//div[@class='col-md-3']//button[@id='accountEdit']")
    private WebElementFacade EditPriceList;

    @FindBy(css = ".specs-button.specs-button--size-medium.specs-button--outlined.specs-button--align-left.specs-button--outlined-default.specs-button--underline-hover")
    private WebElementFacade replaceAgreement;


    @FindBy(xpath = "//input[@id='accountName']")
    private WebElementFacade enterAccountName;

    @FindBy(css = "#createAccount")
    private WebElementFacade createAccount;


    @FindBy(xpath = "//div[@class='specs-card acctcards tab specs-card-active']//div[@class='iconBox icon--align-horizontal icon--primary']")
    private WebElementFacade createdSubAccount;


    public void clickAssignRequisition() {
        clickElement(assignRequisition);

    }

    public void assignRequisitionVisible() {
        //waitForCondition().until(ExpectedConditions.visibilityOf(assignRequisition));
        assignRequisition.waitUntilVisible().isClickable();

    }


    public void clickAddAccount() {
        clickElement(addnewAccount);

    }

    public void clickSunOrganisationt() {
        clickElement(subOrganisation);

    }


    public void enterNewSubAccountName() {
        enterAccountName.clear();
        setText(enterAccountName, generateSubAccName);
        logger.info("Sub Organisation Name is : " + generateSubAccName);
    }


    public void clickCreateAccount() {
        clickElement(createAccount);

    }

    public void createdAccountValidation() {

        actualAccountName = "(//h3[normalize-space()='" + generateSubAccName + "'])";
        logger.info(("clicking on dynamic xpath" + actualAccountName));
        evaluateScriptClick($(By.xpath(actualAccountName)));

        String createdAccountName = createdSubAccount.getText();
        logger.info("Created New Account Name is: " + createdAccountName);

        generateSubAccName = generateSubAccName.replaceAll("\\[\\d+\\]", "");
        actualAccountName = createdAccountName.replaceAll("\\[\\d+\\]", "");


        Assert.assertEquals(generateSubAccName, actualAccountName);
    }


    public void clickEditPriceList() {
        clickElement(EditPriceList);

    }

    public void clickReplaceAgreement() {
        clickElement(replaceAgreement);

    }

}


