package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@DefaultUrl("page:b2bEyeCare.home.url")
public class b2bEyeCareLoginPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareLoginPage.class);


    //@FindBy(xpath = "(//a[@class='nav-link dropdown-toggle'])[2]")
    //private WebElementFacade signOutDropDown;

    @FindBy(css = "#lightbox")
    private WebElementFacade signOutvalidate;

    @FindBy(css = "#otherTileText")
    private WebElementFacade Useanotheraccount;

    @FindBy(css = ".login-form")
    private WebElementFacade LoginPage;

    @FindBy(css = ".signin-user-logo")
    private WebElementFacade ClickSSOLogin;



    @FindBy(css = ".nav-link.dropdown-toggle.align-item-center")
    private WebElementFacade signOutDropDown;




    @FindBy(linkText = "Sign Out")
    private WebElementFacade signOut;


    public void clickSignOutDropDown() {

        clickElement(signOutDropDown);

    }

    public void clickSignOut() {
        clickElement(signOut);

    }


    public void clickSsoLogin() {
        clickElement(ClickSSOLogin);
        logger.info("User Click on SSO Login");
    }


    public void clickUseOtherAccount() {
        clickElement(Useanotheraccount);
    }

    public void loginFormVisible() {
        LoginPage.waitUntilVisible();
    }
}
