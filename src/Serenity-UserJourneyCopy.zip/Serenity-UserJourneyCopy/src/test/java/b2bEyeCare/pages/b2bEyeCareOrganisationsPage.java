package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static Framework.Staf.wait;

public class b2bEyeCareOrganisationsPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareOrganisationsPage.class);

    b2bEyeCareBase.AddressDetails addressDetails = b2bEyeCareBase.generateAddress();
    b2bEyeCareRequisitionsPage reqpage;

    @FindBy(id = "addOrganisation")
    private WebElementFacade AddOrganisation;

    @FindBy(id = "organisationLocal")
    private WebElementFacade AddOrganisationlocal;


    @FindBy(css = ".accordion-button.collapsed")
    private WebElementFacade collapseEditAccount;

    @FindBy(css = " .Vue-Toastification__toast.Vue-Toastification__toast--success.top-right.my-custom-toast-class")
    private WebElementFacade SucessToastificationtoast;


    @FindBy(css = "button.specs-button.editAccountBtn[type='button']")
    private WebElementFacade editAccount;

    @FindBy(css = "#editInfo")
    private WebElementFacade editInfo;


    @FindBy(xpath = "(//input[@id='editApprovalLimit'])[1]")
    private WebElementFacade setApproveLimit;

    @FindBy(css = "#saveAll")
    private WebElementFacade saveEditAccount;

    @FindBy(id = "organisationNational")
    private WebElementFacade organisationNational;

    @FindBy(xpath = "//input[@id='orgOrgNo']")
    private WebElementFacade OrgNumber;

    @FindBy(xpath = "//input[@id='suborgOrgNo']")
    private WebElementFacade subOrganisationId;

    @FindBy(xpath = "//section[@id='orgOrgNo']//button[@id='searchButton']")
    private WebElementFacade organisationSearch;

    @FindBy(xpath = "//section[@id='suborgOrgNo']//button[@id='searchButton']")
    private WebElementFacade subOrganisationSearch;
    @FindBy(id = "orgOrgName")
    private WebElementFacade organisationName;

    @FindBy(id = "suborgOrgName")
    private WebElementFacade organisationSubName;

    @FindBy(id = "orgAddress")
    private WebElementFacade organisationAddress;

    @FindBy(id = "orgCity")
    private WebElementFacade organisationCity;

    @FindBy(id = "orgZipCode")
    private WebElementFacade organisationZipCode;

    @FindBy(id = "orgOrgNotes")
    private WebElementFacade organisationNotes;

    @FindBy(id = "approveInfo")
    private WebElementFacade approvalInfoButton;

    @FindBy(id = "nextButton")
    private WebElementFacade next;


    @FindBy(css = "#nextButton.specs-button--disabled")
    private WebElementFacade nextButton;


    @FindBy(xpath = " //button[normalize-space()='Next']")
    private WebElementFacade editNext;


    @FindBy(xpath = "//input[@id='orgSearchAdmin']")
    private WebElementFacade InputEmail;

    @FindBy(xpath = "//input[@id='suborgSearchAdmin']")
    private WebElementFacade subInputEmail;

    @FindBy(xpath = "//section[@id='orgSearchAdmin']//button[@id='searchButton']")
    private WebElementFacade emailSearch;

    @FindBy(xpath = "//section[@id='suborgSearchAdmin']//button[@id='searchButton']")
    private WebElementFacade emailsubSearch;


    @FindBy(xpath = "//input[@id='orgAdminFirstName']")
    private WebElementFacade adminFirstName;

    @FindBy(xpath = "//input[@id='suborgAdminFirstName']")
    private WebElementFacade adminsSubFirstName;
    @FindBy(xpath = "//input[@id='orgAdminLastName']")
    private WebElementFacade adminLastName;

    @FindBy(xpath = "//input[@id='suborgAdminLastName']")
    private WebElementFacade adminSubLastName;

    @FindBy(xpath = "//input[@id='orgAdminTitle']")
    private WebElementFacade adminTitle;


    @FindBy(xpath = "//input[@id='suborgAdminTitle']")
    private WebElementFacade adminSubTitle;
    @FindBy(xpath = "//input[@id='orgAdminPhoneNo']")
    private WebElementFacade mobileNo;

    @FindBy(xpath = "//input[@id='orgAdminPhoneNo']")
    private WebElementFacade mobileSubNo;

    @FindBy(id = "agreementSize_1-25")
    private WebElementFacade orgSize200;


    @FindBy(id = "agreementSize_25-100")
    private WebElementFacade orgSize200Plus;
    @FindBy(id = "agreementSize_100-500")
    private WebElementFacade orgSize700Plus;
    @FindBy(xpath = "//h3[normalize-space()='500+']")
    private WebElementFacade orgSize500p;

    @FindBy(xpath = "(//div[@class='iconContainer icon--align-vertical icon--white'])[1]")
    private WebElementFacade agreementType;

    @FindBy(css = "#agreement-0")
    private WebElementFacade replacetheAgreement;


    @FindBy(css = "button[class='specs-button specs-button--size-small specs-button--contained specs-button--align-right specs-button--contained-default specs-button--underline-hover']")
    private WebElementFacade addchange;

    @FindBy(id = "useAgreementButton")
    private WebElementFacade useAgreement;

    @FindBy(xpath = "//button[@id='customerPayment']")
    private WebElementFacade customerPayment;
    @FindBy(xpath = "//button[@id='centralInvoice']")
    private WebElementFacade centralInvoice;
    @FindBy(xpath = "//button[@id='storeInvoice']")
    private WebElementFacade storeInvoice;


    @FindAll({@FindBy(css = "input[role='combobox']"), @FindBy(css = "input[role='listbox']")})
    private WebElementFacade contactMenu;


    @FindBy(xpath = "//div[@class='dropdown-textbox']//input[@id='accountName']")
    private WebElementFacade provideFinanceId;


    @FindBy(xpath = "//span[normalize-space()='SVCP B2B-NE Automation']")
    private WebElementFacade orgSpecContact;

    @FindBy(xpath = "//span[normalize-space()='SVCP B2B NE Automation 02']")
    private WebElementFacade orgSpecContactmanager;


    @FindBy(xpath = "//span[normalize-space()='SVCP B2B-NE Automation']")
    private WebElementFacade accSpecContact;

    @FindBy(id = "specTypeDigitalAllowed")
    private WebElementFacade digitalSpec;

    @FindBy(id = "specTypeSafetyAllowed")
    private WebElementFacade safetySpec;

    @FindBy(id = "specTypeBespokeAllowed")
    private WebElementFacade bespoke;


    @FindBy(xpath = "//input[@id='primaryReference']")
    private WebElementFacade primaryReference;
    @FindBy(xpath = "//input[@id='secondaryReference']")
    private WebElementFacade secondaryReference;
    @FindBy(css = "#comments")
    private WebElementFacade comments;


    @FindBy(css = "#orgOrgNotes")
    private WebElementFacade notes;

    @FindBy(css = "#suborgOrgNotes")
    private WebElementFacade subOrgNotes;


    @FindBy(id = "requisitionValidPeriod-0")
    private WebElementFacade requisitionPeriod30days;

    @FindBy(id = "requisitionValidPeriod-1")
    private WebElementFacade requisitionPeriod60days;

    @FindBy(id = "requisitionValidPeriod-3")
    private WebElementFacade requisitionPeriod90days;


    @FindBy(css = "#invoiceDescription")
    private WebElementFacade invoiceComments;

    @FindBy(id = "createButton")
    private WebElementFacade createButton;

    @FindBy(className = "specs-list")
    private List<WebElementFacade> specsListElements;


    @FindBy(css = "div[id^=accountList-]")
    private List<WebElementFacade> createdAcc;

    @FindBy(css = ".OrgInfoTile")
    private WebElementFacade createdOrg;


    @FindBy(css = ".specs-list-label.address-align")
    private WebElementFacade getOrgid;


    @FindBy(css = ".account-info.row")
    private WebElementFacade orgexistsMessage;

    @FindBy(id = "cancelAccount")
    private WebElementFacade cancelAccount;


    @FindBy(css = "label[class='checkboxstyle mt-4'] span[class='checkmark']")
    private WebElementFacade requisitionApprovalRequired;

    @FindBy(css = "label[class='checkboxstyle mt-3rem'] span[class='checkmark']")
    private WebElementFacade approvalRequired;


    @FindBy(xpath = " //input[@id='approvalLimit']")
    private WebElementFacade approvalLimit;

    @FindBy(xpath = "(//div[@class='responsive-table'])[1]")
    private WebElementFacade nationals;


    @FindBy(css = "#orgOrgName")
    private WebElementFacade orgName;


    @FindBy(css = "#orgName")
    private WebElementFacade EditOrgName;
    @FindBy(xpath = "//input[@id='accountName']")
    private WebElementFacade accountName;


    @FindBy(css = "#suborgOrgName")
    private WebElementFacade suborgOrgName;


    @FindBy(css = "#organisationEdit")
    private WebElementFacade editorg;

    @FindBy(css = "#orgNotes")
    private WebElementFacade editcomments;


    @FindBy(css = "#saveAll")
    private WebElementFacade saveAll;

    @FindBy(css = "label[class='checkboxstyle'] span[class='checkmark']")
    private WebElementFacade sparePairDigital;


    public void clickeditOrganisation() {
        clickElement(editorg);

    }


    public void clickOnAddOrganisation() {
        clickElement(AddOrganisation);

    }


    public void clickRequisitionApprovalRequired() {
        clickElement(requisitionApprovalRequired);

    }

    public void clickApprovalRequired() {
        clickElement(approvalRequired);

    }


    public void clickCollapse() {
        clickElement(collapseEditAccount);

    }

    public void clickEditAccount() {
        clickElement(editAccount);

    }


    public void seteditApprovalLimit(String limit) {
        setApproveLimit.clear();
        setText(setApproveLimit, limit);


    }


    public void saveTheEditedtAcount() {
        clickElement(saveEditAccount);

    }


    public void enterSubOrganisationId(String generatedNumber) {
        subOrganisationId.clear();
        setText(subOrganisationId, generatedNumber);

    }


    public void enterOrganisationId(String orgnumber) {
        OrgNumber.clear();
        setText(OrgNumber, orgnumber);
    }


    public void performOrganisationNumberSearch() {
        clickElement(organisationSearch);
    }


    public void performSubOrganisationNumberSearch() {
        clickElement(subOrganisationSearch);
    }


    public void validateOrganisationNumber(String generatedNumber) {
        boolean isOrgNamePresent = orgName.isPresent();

        while (!isOrgNamePresent) {
            if (accountName.isPresent()) {
                logger.info("Already exists Message: " + orgexistsMessage.getText());
                clickElement(cancelAccount);
                OrgNumber.clear();
                generatedNumber = String.valueOf(resetGeneratedNumber());
                logger.info("User Enters new organisationId: " + generatedNumber);
                setText(OrgNumber, generatedNumber);
                clickElement(organisationSearch);
                logger.info("User Clicked on OrganisationSearch");
            }

            isOrgNamePresent = orgName.isPresent();
        }

        logger.info("Unique Org no is generated");
    }


    public void validateSubOrganisationNumber(String generatedNumber) {
        boolean isOrgNamePresent = suborgOrgName.isPresent();

        while (!isOrgNamePresent) {
            if (accountName.isPresent()) {
                logger.info("Already exists Message: " + orgexistsMessage.getText());
                clickElement(cancelAccount);
                subOrganisationId.clear();
                generatedNumber = String.valueOf(resetGeneratedNumber());
                logger.info("User Enters new organisationId: " + generatedNumber);
                setText(subOrganisationId, generatedNumber);
                clickElement(subOrganisationSearch);
                logger.info("User Clicked on OrganisationSearch");
            }

            isOrgNamePresent = suborgOrgName.isPresent();
        }

        logger.info("Unique Sub Org no is generated");
    }


    public void enterCompanyName(String generatedName) {
        organisationName.clear();
        setText(this.organisationName, generatedName);
    }


    public void enterSubOrgName(String generatedSubOrgName) {
        organisationSubName.clear();
        setText(this.organisationSubName, generatedSubOrgName);
    }


    public void enterAddress(String organisationAddress) {
        setText(this.organisationAddress, organisationAddress);
    }

    public void enterCity(String organisationCity) {
        setText(this.organisationCity, organisationCity);
    }

    public void enterZip(String organisationZip) {
        setText(this.organisationZipCode, organisationZip);
    }

    public void enterNotes(String organisationNotes) {
        setText(this.notes, organisationNotes);
    }


    public void enterSubOrgNotes(String organisationNotes) {
        setText(this.subOrgNotes, organisationNotes);
    }


    public void clickSubSearchOrganisation(String generatedNumber, String generatedSubOrgName, String OrganisationAddress, String OrganisationCity, String OrganisationZip) {
        clickElement(subOrganisationSearch);
        logger.info("User Click on OrganisationSearch");
        clickElement(cancelAccount);
        subOrganisationId.clear();
        generatedNumber = String.valueOf(resetGeneratedNumber());
        setText(subOrganisationId, generatedNumber);
        logger.info("User Enters new organisationId:" + generatedNumber);
        clickElement(subOrganisationSearch);
        organisationSubName.clear();
        setText(organisationSubName, generatedSubOrgName);
        logger.info("User Enters the organisationName:" + generatedSubOrgName);
        setText(organisationAddress, OrganisationAddress);
        setText(organisationCity, OrganisationCity);
        setText(organisationZipCode, OrganisationZip);

    }

    public void createdOrg() {
        //waitForCondition().until(ExpectedConditions.visibilityOf(createdOrg));
        waitABit(3000);
        createdOrg.waitUntilVisible().isClickable();
        logger.info("created Org is:" + createdOrg.getText());

    }


    public void EditOrganisationInfo(String generatedSubOrgName) {
        EditOrgName.clear();
        setText(EditOrgName, generatedSubOrgName);
        logger.info("User Enters new organisationId:" + generatedSubOrgName);

    }


    public void Saveall() {
        final String comments = testDataManager.getTestInputCommonData("orgInfo.editorg");
        editcomments.click();
        setText(editcomments, comments);
        logger.info("user enteretd the comments:" + comments);
        clickElement(saveAll);


    }


    public void clickOnApproveInfo() {
        clickElement(approvalInfoButton);

    }

    public void editInfo() {
        Assert.assertTrue("Button should not be clickable before filling the form.", editInfo.isEnabled());
    }


    public void verifyApprovalInfoButtonIsDisabled() {
        WebElement approveInfoButton = getDriver().findElement(By.cssSelector("div.searchOrgName.mt-1rem button#approveInfo"));
        boolean isDisabled = approveInfoButton.getAttribute("class").contains("specs-button--disabled");
        //logger.info("Is the Approve Info button disabled? " + isDisabled);
        Assert.assertTrue("The Approve Info button should be disabled, but it is not.", isDisabled);

    }

    public void verifyNextButtonsIsDisabled() {
        WebElement nextButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nextButton")));
        boolean isDisabled = nextButton.getAttribute("class").contains("specs-button--disabled");
        //logger.info("Is the Next button disabled? " + isDisabled);
        Assert.assertTrue("The Next button should be disabled, but it is not.", isDisabled);

    }


    public void verifyApprovalInfoButtonIsEnabled() {
        boolean isEnabled = approvalInfoButton.isEnabled();
        Assert.assertTrue("The Approve Info button should be enabled.", isEnabled);
        WebElement clickableButton = wait.until(ExpectedConditions.elementToBeClickable(approvalInfoButton));
        Assert.assertNotNull("The Approve Info button should be clickable.", clickableButton);


    }

    public void verifyNextButtonsIsEnabled() {
        boolean isEnabled = next.isEnabled();
        Assert.assertTrue("The Approve Info button should be enabled.", isEnabled);
        WebElement clickableButton = wait.until(ExpectedConditions.elementToBeClickable(next));
        Assert.assertNotNull("The Approve Info button should be clickable.", clickableButton);


    }


    public void changeAgreement() {
        clickElement(editNext);
        logger.info("User Click on Next");
        clickElement(replacetheAgreement);
        logger.info("User Click replace agreement ");
        clickElement(addchange);
        logger.info("User Click add or change");

    }


    public void clickNext() {
        clickElement(next);

    }

    public void enterOrganisationEmail() {
        String generateEmail = generateEmail();
        setText(InputEmail, generateEmail);
    }


    public void enterSubOrgEmail() {
        String generateEmail = generateEmail();
        setText(subInputEmail, generateEmail);
    }

    public void clickEmailSearch() {
        clickElement(emailSearch);

    }

    public void clickEmailSubSearch() {
        clickElement(emailsubSearch);

    }


    public void enterAdminSubFirstName(String aFirstName) {
        setText(adminsSubFirstName, aFirstName);

    }

    public void enterAdminFirstName(String aFirstName) {
        setText(adminFirstName, aFirstName);

    }

    public void enterAdminLastName(String aLastName) {
        setText(adminLastName, aLastName);

    }

    public void enterMobileNo(String mobile) {
        setText(mobileNo, mobile);

    }

    public void enterSubMobileNo(String mobile) {
        setText(mobileSubNo, mobile);

    }


    public void enterAdminTitle(String title) {
        setText(adminTitle, title);
    }


    //input[@id='suborgAdminTitle']

    public void enterAdminSubLastName(String aLastName) {
        setText(adminSubLastName, aLastName);

    }


    public void enterAdminSubTitle(String title) {
        setText(adminSubTitle, title);

    }


    public void selectOrgSize0To200() {
        clickElement(orgSize200);

    }

    public void selectOrgSize100() {
        clickElement(orgSize200Plus);
        logger.info("User Selects Org size as 25-100");
    }

    public void selectOrgSize500() {
        clickElement(orgSize700Plus);
        logger.info("User Selects Org size as 100-500");
    }

    public void selectOrgSize500p() {
        clickElement(orgSize500p);
        logger.info("User Selects Org size as 500+");
    }

    public void selectAgreementType() {
        clickElement(agreementType);

    }

    public void selectUseAgreement() {
        clickElement(useAgreement);
    }

    public void selectCustomerPayment() {
        clickElement(customerPayment);

    }

    public void selectCentralInvoice() {
        clickElement(centralInvoice);


    }

    public void selectStoreInvoice() {

        clickElement(storeInvoice);

    }

    public void hoverStoreInvoice() {
        Actions actions = new Actions(getDriver());
        actions.moveToElement(storeInvoice).build().perform();
    }

    public void selectOrgContact() {
        clickElement(contactMenu);

    }


    public void provideFinanceId(int providefinanceId) {
        provideFinanceId.clear();
        provideFinanceId.click();
        setText(provideFinanceId, String.valueOf(providefinanceId));

    }


    public void selectOrgSpecsaversContact() {

        clickElement(orgSpecContact);


    }

    public void selectOrgmanagerSpecsaversContact() {
        clickElement(orgSpecContactmanager);

    }

    public void selectAccSpecsaversContact() {
        clickElement(accSpecContact);

    }

    public void enterInvoiceComments(String Comments) {
        setText(invoiceComments, Comments);
    }

    public void enterPrimaryReference(String primary) {
        setText(primaryReference, primary);
    }

    public void enterSecondaryReference(String secondary) {
        setText(secondaryReference, secondary);
    }

    public void enterComments(String comment) {
        setText(comments, comment);
    }

    public void selectRequisitionPeriod30days() {
        clickElement(requisitionPeriod30days);

    }


    public void selectRequisitionPeriod60days() {
        clickElement(requisitionPeriod60days);

    }

    public void selectRequisitionPeriod90days() {
        clickElement(requisitionPeriod90days);

    }


    public void selectCreate() {
        clickElement(createButton);

    }

    public void clickOrgId() {
        reqpage.checkForNoResults();
        evaluateScriptClick($(By.cssSelector(".specs-list-label.address-align")));
        //clickElement(getOrgid);
    }


    public void waituntilNationalpageLoad() {
        waitForLoaderIfPresent();

    }

    public boolean validateAccountType(String accountType) {
        for (WebElementFacade acc : createdAcc) {
            String accText = acc.getText();
            if (accText.contains(accountType)) {
                logger.info("Account Type is :" + accText);
                return true;
            }
        }
        return false;
    }

    public boolean validateAccountName(int index, String generatedName) {
        //for(WebElementFacade acc: createdAcc){
        if (index >= 0 && index < createdAcc.size()) {
            WebElementFacade acc = createdAcc.get(index);
            String accText = acc.getText();
            if (accText.contains(generatedName)) {
                logger.info("Account Name is :" + accText);
                return true;
            }
        }
        return false;
    }


    public void clickAndSetActive(WebElementFacade button) {
        if (!button.getAttribute("class").contains("specs-card-active")) {
            button.click();
            logger.info("Clicked to make the button active.");
        }
    }

    public void makeInactive(WebElementFacade button) {
        if (button.getAttribute("class").contains("specs-card-active")) {
            button.click();
            logger.info("Making button inactive.");
        }
    }


    public void manageButtonsState() {
        // Ensure digitalSpec is active
        if (!digitalSpec.getAttribute("class").contains("specs-card-active")) {
            clickAndSetActive(digitalSpec);
        }

        // Check safetySpec and make it inactive if active
        if (safetySpec.getAttribute("class").contains("specs-card-active")) {
            makeInactive(safetySpec);
        }

        // Check bespoke and make it inactive if active
        if (bespoke.getAttribute("class").contains("specs-card-active")) {
            makeInactive(bespoke);
        }
    }

    public void selectDigitalSpare() {
        clickElement(sparePairDigital);

    }


}



