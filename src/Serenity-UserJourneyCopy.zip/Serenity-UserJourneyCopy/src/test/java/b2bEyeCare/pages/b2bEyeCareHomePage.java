package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class b2bEyeCareHomePage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareHomePage.class);

    @FindBy(xpath = "(//input[@id='searchValue'])[1]")
    private WebElementFacade homesearch;


    @FindBy(id = "searchButton")
    private WebElementFacade searchMagnifying;

    @FindBy(id = "homeOrganisationTile")
    private WebElementFacade HomeOrganisation;

    @FindBy(id = "homeRequisitionTile")
    private WebElementFacade HomeRequisition;


    @FindBy(id = "homePricelistTile")
    private WebElementFacade PriceList;

    @FindBy(linkText = "Categories")
    private WebElementFacade Categories;

    @FindBy(linkText = "Price Lists")
    private WebElementFacade PriceListDropDown;

    @FindBy(css = "a.nav-link[href='/templates']")
    private WebElementFacade Templates;


    @FindBy(id = "homeReportTile")
    private WebElementFacade HomeReport;


    @FindBy(css = "a.nav-link[href='/organisations']")
    private WebElementFacade HeaderOrganisation;

    @FindBy(css = "a.nav-link[href='/requisitions']")
    private WebElementFacade HeaderRequisition;


    public void clickOnHeaderOrganisation() {

        clickElement(HeaderOrganisation);

    }

    public void clickOnHeaderRequisation() {

        clickElement(HeaderRequisition);
        waitForListElement();
    }


    public void clickOnHomeOrganisation() {
        clickElement(HomeOrganisation);

    }

    public void clickOnRequisition() {
        clickElement(HomeRequisition);
        waitForPaginationToLoad();

    }




    public void clickOnPricelistMenu() {
        clickElement(PriceList);

    }


    public void clickOnCategories() {
        clickElement(PriceListDropDown);
        clickElement(Categories);

    }

    public void clickOnTemplate() {
        clickElement(Templates);

    }


    public void clickOnReport() {
        clickElement(HomeReport);


    }


    public void searchOrganisationId(String generatedNumber) {
        if (generatedNumber == null) {
            throw new IllegalArgumentException("Organisation Number cant be Null");
        }
        homesearch.clear();
        clickElement(homesearch);
        setText(homesearch, generatedNumber);
        //setText(homesearch,"151796084" );

    }


    public void clickOnSearchMagnifying() {
        clickElement(searchMagnifying);
    }


    public void searchExistingOrganisationId(String orgType) {
        final String qa2Key = String.format("OrganiationNo.qa2.%s", orgType);
        final String qaKey = String.format("OrganiationNo.qa.%s", orgType);
        final String stgKey = String.format("OrganiationNo.stg.%s", orgType);

        final String noqa2existingNumber = testDataManager.getTestInputRegionData(qa2Key);
        final String noqaexistingNumber = testDataManager.getTestInputRegionData(qaKey);
        final String nostgexistingNumber = testDataManager.getTestInputRegionData(stgKey);
        final String seqa2existingNumber = testDataManager.getTestInputRegionData(qa2Key);
        final String seqaexistingNumber = testDataManager.getTestInputRegionData(qaKey);
        final String sestgexistingNumber = testDataManager.getTestInputRegionData(stgKey);
        final String ukqa2existingNumber = testDataManager.getTestInputRegionData(qa2Key);
        final String ukqaexistingNumber = testDataManager.getTestInputRegionData(qaKey);
        final String ukstgexistingNumber = testDataManager.getTestInputRegionData(stgKey);

        String targetRegion = Staf.getTargetRegion();
        String environment = Staf.getEnvironment();

        String organisationId = null;
        if (targetRegion.equals("no")) {
            switch (environment) {
                case "b2bqa2":
                    organisationId = noqa2existingNumber;
                    break;
                case "b2bqa":
                    organisationId = noqaexistingNumber;
                    break;
                case "b2bstg":
                    organisationId = nostgexistingNumber;
                    break;
            }
        } else if (targetRegion.equals("se")) {
            switch (environment) {
                case "b2bqa2":
                    organisationId = seqa2existingNumber;
                    break;
                case "b2bqa":
                    organisationId = seqaexistingNumber;
                    break;
                case "b2bstg":
                    organisationId = sestgexistingNumber;
                    break;
            }
        } else if (targetRegion.equals("uk")) {
            switch (environment) {
                case "b2bqa2":
                    organisationId = ukqa2existingNumber;
                    break;
                case "b2bqa":
                    organisationId = ukqaexistingNumber;
                    break;
                case "b2bstg":
                    organisationId = ukstgexistingNumber;
                    break;
            }
        }

        if (organisationId != null) {
            homesearch.clear();
            clickElement(homesearch);
            setText(homesearch, organisationId);
            logger.info("User Enters the existing organisationId: " + organisationId);
        } else {
            throw new RuntimeException("Region and environment not satisfied");
        }
    }

    public void searchExistingSIOrganisationId() {
        searchExistingOrganisationId("SI");
    }

    public void searchExistingCPOrganisationId() {searchExistingOrganisationId("CP");}

    public void searchExistingCIOrganisationId() {
        searchExistingOrganisationId("CI");
    }

    public void searchExistingSILOrganisationId() {
        searchExistingOrganisationId("SIL");
    }

    public void searchExistingCPLOrganisationId() {
        searchExistingOrganisationId("CPL");
    }

    public void searchExistingCILOrganisationId() {
        searchExistingOrganisationId("CIL");
    }

    public void searchExistingCILROrganisationId() {
        searchExistingOrganisationId("CILR");
    }


    public void searchExistingSSIOrganisationId() {
        searchExistingOrganisationId("SSI");
    }

    public void searchExistingSCIOrganisationId() {searchExistingOrganisationId("SCI");}

    public void searchExistingSCPOrganisationId() {
        searchExistingOrganisationId("SCP");
    }

    public void searchExistingACPOrganisationId() {
        searchExistingOrganisationId("ACP");
    }

}
