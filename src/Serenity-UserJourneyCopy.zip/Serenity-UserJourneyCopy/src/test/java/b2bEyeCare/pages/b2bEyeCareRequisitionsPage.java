package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import static Framework.Staf.wait;


public class b2bEyeCareRequisitionsPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareRequisitionsPage.class);

    b2bEyeCareBase base = new b2bEyeCareBase();
    public static String generateEmail = generateEmail();
    private String reqrequisitionNumber;
    String ActiveNumber;
    private String storedRequisition, storedReference1, storedReference2, storedVoucherValue, storedEmployeeName, storedOrganisationName, storedStoreName, storedPriceList, storedCategory, storedComments, storedCreatedDate;
    private String enteredReceiptNumber;

    private String ManagerApproved;
    private String ManagerClaimed;
    private String UserApproved;
    private String UserClaimed;
    @FindBy(id = "reqCreateRequisitionByAdmin")
    private WebElementFacade create_Requisitions_employee;



    @FindBy(css = "input[id='user.firstName']")
    private WebElementFacade selfReqEmployeeFirstName;

    @FindBy(css = "input[id='user.lastName']")
    private WebElementFacade selfReqEmployeeLastName;

    @FindBy(css = "input[id='user.phoneNumber']")
    private WebElementFacade selfReqEmployeePhoneNo;

    @FindBy(css = "input[id='user.businessEmail']")
    private WebElementFacade selfReqEmployeeBusinessEmail;

    @FindBy(css = "input[id='user.personalEmail']")
    private WebElementFacade selfReqEmployeePersonalEmail;



    @FindBy(css = "#reqEmployeeFirstName")
    private WebElementFacade reqEmployeeFirstName;

    @FindBy(css = "#reqEmployeeLastName")
    private WebElementFacade reqEmployeeLastName;

    @FindBy(css = "#reqEmployeeBusinessEmail")
    private WebElementFacade reqEmployeeBusinessEmail;


    @FindBy(xpath = "//input[@id='reqEmployeePhoneNo']")
    private WebElementFacade reqEmployeePhoneNo;


    @FindBy(css = "#reqEmployeePersonalEmail")
    private WebElementFacade reqEmployeePersonalEmail;


    @FindBy(xpath = "//input[@id='approval_mgr_email']")
    private WebElementFacade approvalManagerEmail;


    @FindBy(css = "#primaryRef")
    private WebElementFacade primaryRef;

    @FindBy(css = "#secondaryRef")
    private WebElementFacade secondaryRef;


    @FindBy(css = "input[placeholder='dd/mm/yyyy']")
    private WebElementFacade birthday;


    @FindBy(css = "#specTypeDigitalRequested")
    private WebElementFacade digitalspecs;

    @FindBy(css = "#distanceNotes")
    private WebElementFacade notes;

    @FindBy(css = "#spect-table-check")
    private WebElementFacade selectReForInvoice;

    @FindBy(css = "div.col-sm-12.col-md-12.col-lg-5.offset-lg-1 button#lockandunlock")
    private WebElementFacade lockunlockbutton;
    @FindBy(css = "div.col-sm-12.col-md-12.col-lg-3 button#lockandunlock")
    private WebElementFacade exportbutton;

    @FindBy(id = "Invoice")
    private WebElementFacade invoicebutton;


    @FindBy(css = "#createRequisition")
    private WebElementFacade createRequisition;

    @FindBy(css = "#self-requisition-submit")
    private WebElementFacade selfCreateRequisition;


    @FindBy(css = ".clr-mint.ml-5px")
    private WebElementFacade headerrequisition;

    @FindBy(css = ".err-container_bar-code")
    private WebElementFacade barcode;


    @FindBy(css = "#bookAppointment")
    private WebElementFacade bookappointment;

    @FindBy(css = ".specs-list-label.org-class")
    private WebElementFacade req;

    @FindBy(xpath = "//input[@id='maxDistance']")
    private WebElementFacade maxDistance;
    @FindBy(xpath = "//input[@id='screenDistance']")
    private WebElementFacade screenDistance;
    @FindBy(xpath = "//input[@id='readingDistance']")
    private WebElementFacade readingDistance;
    @FindBy(xpath = "//input[@id='keyboardDistance']")
    private WebElementFacade keyboardDistance;


    @FindBy(css = ".req-url-button")
    private WebElementFacade Newrequistionslink;

    @FindBy(css = ".row.req-url-row")
    private WebElementFacade requisitionLink;

    @FindBy(css = ".col-8.req-url-col-border")
    private WebElementFacade getURL;

    @FindAll({@FindBy(xpath = "(//div[@class='specs-list-label reqList-class'])"), @FindBy(xpath = "(//div[@class='specs-list-label org-class'])")})
    private WebElementFacade ReqNumber;


    @FindBy(css = ".iconBox.icon--align-horizontal.icon--midGreen")
    private WebElementFacade activecard;

    @FindBy(className = "req-data")
    List<WebElementFacade> userreqnumber;


    @FindBy(css = ".ml-1")
    private WebElementFacade usergetreqnumber;


    @FindBy(css = ".iconBox.icon--align-horizontal.icon--primary")
    private WebElementFacade needsAction;


    @FindBy(css = ".specs-card.specs-card--color.specs-card--default.specs-card-active")
    private WebElementFacade getTheCountofWidge;


    @FindBy(css = ".iconBox.icon--align-horizontal.icon--navy")
    private WebElementFacade redeemedrequisitions;

    @FindBy(css = ".specs-Label.specs-label--success.specs-label--align-right")
    private WebElementFacade activeStatusCheck;

    @FindBy(css = ".specs-Label.specs-label--primary.specs-label--align-right")
    private WebElementFacade inReqPaidAppStatusCheck;


    @FindBy(css = ".specs-Label.specs-label--warning.specs-label--align-right")
    private WebElementFacade refundedStatusCheck;

    @FindBy(css = ".specs-Label.specs-label--danger.specs-label--align-right")
    private WebElementFacade returnedStatusCheck;

    @FindBy(css = ".specs-Label.specs-label--muted.specs-label--align-right")
    private WebElementFacade cancelledStatusCheck;

    @FindBy(css = ".specs-Label.specs-label--secondary.specs-label--align-right")
    private WebElementFacade claimedStatusCheck;




    @FindBy(xpath = "(//input[@id='searchValue'])[1]")
    private WebElementFacade search;


    @FindBy(css = "#searchButton")
    private WebElementFacade searchMagnifying;




    @FindBy(css = "#spec-button")
    private WebElementFacade requisationClearSearch;


    @FindBy(css = ".specs-button--size-large")
    private WebElementFacade invoiceClearSearch;

    @FindBy(css = ".specs-link.spec-link--style.specs-link--underline-always.specs-link--color-primary")
    private WebElementFacade clickAdvanceSearch;

    @FindBy(css = "button[class='btn invoice-tab invoice-tab-selected']")
    private WebElementFacade centralisenabled;



    @FindBy(css = ".dp__input_icon")
    private WebElementFacade reportCalender;


    @FindBy(css = ".dp__icon.dp__input_icon.dp__input_icons")
    private WebElementFacade requisitionCalender;

    @FindBy(css = ".dp__today")
    private WebElementFacade selectTodaysDate;


    @FindBy(css = "input[data-test='dp-input']")
    private WebElementFacade getReqSearchDate;

    @FindBy(css = "input[data-test='dp-input']")
    private WebElementFacade defaultCalenderDate;


    @FindBy(xpath = "(//input[@id='requisitionno'])[1]")
    private WebElementFacade advSearchReq;


    @FindBy(xpath = "(//input[@id='ref1'])[1]")
    private WebElementFacade referenceNumber1;


    @FindBy(xpath = "(//input[@id='referenceTwo'])[1]")
    private WebElementFacade referenceNumber2;

    @FindBy(xpath = " (//input[@id='amount'])[1]")
    private WebElementFacade voucherValue;


    @FindBy(xpath = "(//input[@role='combobox'])[1]")
    private WebElementFacade Organisationname;

    @FindBy(xpath = "(//input[@role='combobox'])[2]")
    private WebElementFacade StoreName;

    @FindBy(xpath = "(//input[@role='combobox'])[3]")
    private WebElementFacade EmployeeName;


    @FindBy(xpath = "(//input[@role='combobox'])[4]")
    private WebElementFacade PriceLists;
    @FindBy(xpath = "(//input[@role='combobox'])[5]")
    private WebElementFacade Category;

    @FindBy(css = ".accordion-button.collapsed")
    private WebElementFacade clickMore;


    @FindBy(xpath = "(//button[@id='accept'])[2]")
    private WebElementFacade clikcAdvSearch;


    @FindBy(css = ".dp__month_year_select:nth-child(1)")
    private WebElementFacade getMonth;

    @FindBy(css = ".dp__btn:nth-child(2)")
    private WebElementFacade getYear;
    @FindBy(css = ".dp__btn:nth-child(3) .dp__icon")
    private WebElementFacade nextMonth;

    @FindBy(css = ".dp__today")
    private WebElementFacade selectDate;


    @FindBy(css = ".errorClass.fs-1rem.mt-1em")
    private WebElementFacade errormessage;

    @FindBy(css = ".errorClass")
    private WebElementFacade redeemdedNoRecord;


    @FindBy(id = "searchButton")
    private WebElementFacade reqSearch;

    @FindBy(xpath = "//div[@class='modal-header']//*[name()='svg']//*[name()='path' and contains(@fill,'currentCol')]")
    private WebElementFacade closePopup;


    @FindBy(xpath = "//button[normalize-space()='×']")
    private WebElementFacade alert;


    @FindBy(css = ".loader")
    private WebElementFacade loader;


    @FindBy(css = ".specs-list.specs-list-label-font-size")
    private WebElementFacade getreqdetails;

    @FindBy(css = "div[data-active='true'] div[class='specs-list specs-list-label-font-size']")
    private WebElementFacade getreportreqdetails;

    @FindBy(css = ".errorClass")
    private WebElementFacade noRecordFound;

    @FindBy(css = "button.specs-button--size-extrasmall.specs-button--contained")
    private WebElementFacade claim;


    private WebElementFacade Claimrequisition;

    @FindBy(css = " div[id='collapseOne'] div div[class='dp__main dp__theme_light'] div input")
    private WebElementFacade CreatedDate;


    @FindBy(xpath = "(//input[@id='comment'])[1]")
    private WebElementFacade Comments;

    @FindBy(xpath = "(//input[@id='comment'])[2]")
    private WebElementFacade ApproveComments;
    @FindBy(xpath = "(//button[@id='commentButton'])[2]")
    private WebElementFacade confirm;


    @FindBy(xpath = "//div[@class='comment-model']//button[1]")
    private WebElementFacade yes;


    @FindBy(xpath = "(//button[normalize-space()='Yes'])[1]")
    private WebElementFacade iYes;


    @FindBy(xpath = "(//button[normalize-space()='No'])[1]")
    private WebElementFacade no;

    @FindBy(css = ".Vue-Toastification__toast.Vue-Toastification__toast--success.top-right.my-custom-toast-class")
    private WebElementFacade sucessMessage;


    @FindBy(css = ".component-content")
    private WebElementFacade excel;


    @FindBy(css = ".specs-button.specs-button--size-extrasmall.specs-button--mintOutlined.specs-button--align-right.specs-button--mintOutlined-default.specs-button--underline-hover")
    private WebElementFacade cancel;


    @FindBy(css = "div[class='specs-config-type specs-config-special specs-dash-border'] span[class='tippy-container']")
    private WebElementFacade productDropdown;


    @FindBy(css = ".specs-config-item.specs-config-item--border")
    private WebElementFacade specislProductDropDown;

    @FindBy(css = "div.specs-config-item:nth-child(5) p.specs-typography--p")
    private WebElementFacade selectSpecislProduct;


    @FindBy(css = "div[class='specs-config-type specs-config-special'] span[class='tippy-container']")
    private WebElementFacade getSpecialProductName;
    @FindBy(css = " div[class='specs-config-type']")
    private WebElementFacade getSpecialtype;
    @FindBy(xpath = "(//section[@type='text'])[2]")
    private WebElementFacade getSpecialProductValue;


    @FindBy(xpath = "//span[normalize-space()='Lens upgrade 1.67 approved by organisation']")
    private WebElementFacade selectTheProduct;
    @FindBy(xpath = " (//input[@type='text'])[2]")
    private WebElementFacade inputValue;


    @FindBy(xpath = "(//span[contains(text(),'Created Date')])[1]")
    private WebElementFacade sortascending;

    @FindBy(css = "button[class='specs-button specs-button--size-large specs-button--contained specs-button--align-right specs-button--contained-default specs-button--underline-hover ml-5rem']")
    private WebElementFacade YesInvoiced;


    @FindBy(css = ".specs-list-label.reqList-class")
    private List<WebElementFacade> allRequisitionElements;


    @FindBy(css = ".reqList-class")
    private WebElementFacade clickTheReq;


    @FindBy(xpath = "//section[@class='menuItem']//p[contains(text(),'Digital')]")
    private WebElementFacade Digital;


    @FindBy(xpath = "//section[@class='menuItem']//p[normalize-space()='995']")
    private WebElementFacade noframe;


    @FindBy(xpath = "//section[@class='menuItem']//p[normalize-space()='795']")
    private WebElementFacade seframe;


    @FindBy(xpath = "//section[@class='menuItem']//p[contains(text(),'Access HD')]")
    private WebElementFacade noLens;


    @FindBy(xpath = "//section[@class='menuItem']//p[contains(text(),'Access HD')]")
    private WebElementFacade seLens;

    @FindBy(xpath = "//section[@class='menuItem']//p[normalize-space()='1,5']")
    private WebElementFacade noIndex;

    @FindBy(xpath = "//section[@class='menuItem']//p[normalize-space()='1.5']")
    private WebElementFacade seIndex;

    @FindBy(xpath = "(//section[@class='menuItem']//p[contains(text(),'UCSC')])")
    private WebElementFacade noCoating;

    @FindBy(xpath = "(//section[@class='menuItem']//p[contains(text(),'Ultra Clear')])")
    private WebElementFacade seCoating;

    @FindBy(xpath = "(//section[@class='dropDownMenuWrapper w-100 item_container'])")
    private WebElementFacade dropDown;

    @FindBy(xpath = "(//section[@class='dropDownMenuWrapper w-100 position-relative item_container'])")
    private WebElementFacade dropDown1;

    @FindBy(css = " button[class='specs-card specs-card--color specs-card--default report-tiles']")
    private WebElementFacade redeemedRequisation;

    @FindBy(css = ".iconBox.icon--align-horizontal.icon--mintGreen")
    private WebElementFacade invoicedRequisation;

    @FindBy(css = ".pagination.justify-content-md-center")
    private WebElementFacade reqpagination;

    @FindBy(id = "receipt")
    private WebElementFacade receipt;

    @FindBy(css = "input[class='specs-input error-border specs-input--small specs-input--align-left margin-t']")
    private WebElementFacade inputReceiptNumber;


    @FindBy(css = ".specs-typography.specs-typography--h3.specs-typography--h3-bold.specs-typography--align-left.specs-typography--color-primary.specs-typography--display-block")
    private WebElementFacade getReceiptNumber;
    @FindBy(css = ".fa-pen-to-square")
    private WebElementFacade Edit;


    @FindBy(xpath = "//div[@class='till-input']//button[@id='spec-button']")
    private WebElementFacade saveReceipt;


    @FindBy(css = "button[class='specs-button specs-button--size-extrasmall specs-button--contained specs-button--align-right specs-button--contained-default specs-button--underline-hover']")
    private WebElementFacade done;

    @FindBy(css = "div[class='column-3'] div div[id='cell-1'] a")
    private WebElementFacade ViewSelfServeRequisition;

    @FindBy(css = " button[class='specs-button specs-button--size-extrasmall specs-button--danger specs-button--align-right specs-button--danger-default specs-button--underline-hover']")
    private WebElementFacade refund;

    @FindBy(css = "button[class='specs-button specs-button--size-extrasmall specs-button--contained specs-button--align-right specs-button--contained-default specs-button--underline-hover']")
    private WebElementFacade approve;

    @FindBy(css = "button[class='specs-button specs-button--size-extrasmall specs-button--danger specs-button--align-right specs-button--danger-default specs-button--underline-hover']")
    private WebElementFacade returne;

    @FindBy(css = "button[class='specs-button specs-button--size-extrasmall specs-button--yellowOutlined specs-button--align-right specs-button--yellowOutlined-default specs-button--underline-hover']")
    private WebElementFacade edit;


    @FindBy(css = "button[class='specs-button specs-button--size-extrasmall specs-button--contained specs-button--align-right specs-button--contained-default specs-button--underline-hover']")
    private WebElementFacade save;

    @FindBy(css = "button[class='specs-button specs-input--fontawesome specs-button--size-small specs-button--outlined specs-button--align-left specs-button--outlined-default specs-button--underline-hover']")
    private WebElementFacade addSpecialProduct;

    @FindBy(css = "button[class='specs-button specs-input--fontawesome specs-button--size-small specs-button--outlined specs-button--align-right specs-button--outlined-default specs-button--underline-hover']")
    private WebElementFacade addItems;

    @FindBy(css = "button[aria-label='close']")
    private WebElementFacade sucessMessageClose;

    @FindBy(css = ".multiselect-option")
    private List<WebElementFacade> selectSpecialProduct;
    @FindAll({@FindBy(xpath = "(//textarea[@class='text_areas visittextarea'])[1]"), @FindBy(xpath = "(//textarea[@class='text_areas visittextarea'])[2]")})
    private WebElementFacade reason;

    @FindBy(css = "div[class='vue-recycle-scroller__item-view hover'] div[class='specs-list specs-list-label-font-size']")
    private WebElementFacade ReportReqVisible;


    @FindBy(css = ".Vue-Toastification__toast.Vue-Toastification__toast--error.top-right.my-custom-toast-class")
    private WebElementFacade Toastificationtoast;

    @FindBy(css = ".note-box-home")
    private WebElementFacade notemessage;

    @FindBy(css = "button[aria-label='close']")
    private WebElementFacade closeToastification;

    @FindBy(css = "#lockandunlock")
    private WebElementFacade orgExportbutton;


    @FindBy(css = " .Vue-Toastification__toast.Vue-Toastification__toast--success.top-right.my-custom-toast-class")
    private WebElementFacade SucessToastificationtoast;


    @FindBy(css = "#spect-table-check")
    private WebElementFacade selectRequisition;

    @FindBy(css = ".errorClass.fs-1rem.mt-1em")
    private WebElementFacade noresults;

    public void checkForNoResults() {
        if (noresults.isPresent()) {
            String noResultsText = noresults.getText();
            logger.error("Error: " + noResultsText);
            throw new AssertionError("Test failed due to: " + noResultsText);
        }
    }

    public void waitForPaginationToLoad() {
        wait.until(ExpectedConditions.visibilityOf(reqpagination));
    }

    public void clickOnDynamicReqLink() {
        checkForNoResults();
       if (ActiveNumber == null) {
            throw new IllegalArgumentException("Organiksation Number cant be Null");
        }
        String requisationNumber = "(//p[normalize-space()='" + ActiveNumber + "'])";
        logger.info(("clicking on dynamic xpath" + requisationNumber));
        evaluateScriptClick($(By.xpath(requisationNumber)));

    }


    public void selectOnReport() {
        waitForLoaderIfPresent();
        String rowSelector = "//td[contains(text(),'HT4JS2')]";
        logger.info(("clicking on dynamic xpath" + rowSelector));
        WebElement rowElement = getDriver().findElement(By.xpath(rowSelector));
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].classList.add('selected');", rowElement);
    }


    public void waitForLoaderToDisappear() {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(30));
        try {
            if (isLoaderDisplayed()) {
                wait.until(ExpectedConditions.invisibilityOf(loader));
                logger.info("Loader has disappeared.");
            } else {
                logger.info("Loader is not displayed.");
            }
        } catch (NoSuchElementException e) {
            logger.info("Loader element was not found.");
        } catch (TimeoutException e) {
            logger.info("Loader did not disappear within the timeout period.");
        } catch (Exception e) {
            logger.info("An unexpected error occurred: " + e.getMessage());
        }
    }

    private boolean isLoaderDisplayed() {
        try {
            return loader.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    public void clickActiveRequisition() {

        //waitForCondition().until(ExpectedConditions.visibilityOf(activecard));
        clickElement(activecard);
        waitForLoaderToDisappear();
        waitForListElement();
    }


    public void clickNeedsAction() {

        //waitForCondition().until(ExpectedConditions.visibilityOf(needsAction));
        clickElement(needsAction);
        waitForLoaderToDisappear();
        waitForListElement();
    }


    public void clickSave() {
        clickElement(save);

    }

    public void verifyCentralElementIsEnabled() {
        if (!centralisenabled.isEnabled()) {
            Assert.fail("The centralisenabled element is not enabled.");
        }
    }


    public void validateActiveReqStatus(String status) {
        waitForCondition().until(ExpectedConditions.visibilityOf(activeStatusCheck));
        activeStatusCheck.waitUntilVisible();
        String activestatus = activeStatusCheck.getText();
        logger.info("Requisitions Status:" + activestatus);
        Assertions.assertEquals(status, activestatus);
    }

    public void validateInvoiceRequestedPaidAppReqStatus(String status) {
        waitForCondition().until(ExpectedConditions.visibilityOf(inReqPaidAppStatusCheck));
        inReqPaidAppStatusCheck.waitUntilVisible();
        String approvedstatus = inReqPaidAppStatusCheck.getText();
        logger.info("Requisitions Status:" + approvedstatus);
        Assertions.assertEquals(status, approvedstatus);


    }


    public void validateRefundedReqStatus(String status) {
        waitForCondition().until(ExpectedConditions.visibilityOf(refundedStatusCheck));
        refundedStatusCheck.waitUntilVisible();
        String refundstatus = refundedStatusCheck.getText();
        logger.info("Requisitions Status:" + refundstatus);
        Assertions.assertEquals(status, refundstatus);
    }

    public void validateReturnedReqStatus(String status) {
        waitForCondition().until(ExpectedConditions.visibilityOf(returnedStatusCheck));

        String returnstatus = returnedStatusCheck.getText();
        logger.info("Requisitions Status:" + returnstatus);
        Assertions.assertEquals(status, returnstatus);
    }


    public void validateCancelledReqStatus(String status) {
        waitForCondition().until(ExpectedConditions.visibilityOf(cancelledStatusCheck));
        cancelledStatusCheck.waitUntilVisible();
        String cancelstatus = cancelledStatusCheck.getText();
        logger.info("Requisitions Status:" + cancelstatus);
        Assertions.assertEquals(status, cancelstatus);
    }

    public void validateClaimedReqStatus(String status) {
        waitForCondition().until(ExpectedConditions.visibilityOf(claimedStatusCheck));
        claimedStatusCheck.waitUntilVisible();
        String claimstatus = claimedStatusCheck.getText();
        logger.info("Requisitions Status:" + claimstatus);
        Assertions.assertEquals(status, claimstatus);
    }

    public void enterReqEmployeeFirstName(String FirstName) {
        setText(reqEmployeeFirstName, FirstName);

    }

    public void enterReqEmployeeLastName(String LastName) {
        setText(reqEmployeeLastName, LastName);

    }

    public void enterReqEmployeeBusinessEmail(String reqEmployeeBusinessEmail) {
        setText(this.reqEmployeeBusinessEmail, generateEmail);

    }

    public void enterSelfReqEmployeeFirstName(String FirstName) {
        setText(selfReqEmployeeFirstName, FirstName);

    }

    public void enterSelfReqEmployeeLastName(String LastName) {
        setText(selfReqEmployeeLastName, LastName);

    }

    public void enterSelfReqEmployeePhoneNo(String PhoneNo) {
        setText(selfReqEmployeePhoneNo, PhoneNo);


    }

    public void enterSelfReqEmployeeBusinessEmail(String reqEmployeeBusinessEmail) {
        setText(this.selfReqEmployeeBusinessEmail, generateEmail);

    }

    public void enterSelfReqEmployeePersonalEmail(String reqEmployeePersonalEmail) {
        setText(this.selfReqEmployeePersonalEmail, generateEmail);

    }


    public void enterReqEmployeePhoneNo(String PhoneNo) {
        setText(reqEmployeePhoneNo, PhoneNo);


    }

    public void enterReqEmployeePersonalEmail(String reqEmployeePersonalEmail) {
        setText(this.reqEmployeePersonalEmail, generateEmail);

    }

    public void enterApprovalManagerEmail() {
        setText(approvalManagerEmail, generateEmail);

    }

    public void enterPrimaryRef(String primary) {
        setText(primaryRef, primary);

    }

    public void enterSecondaryRef(String secondary) {
        setText(secondaryRef, secondary);

    }

    public void enterReasonForVisit(String visit) {
        setText(reason, visit);

    }

    public void enterNotes(String reason) {
        setText(notes, reason);
        logger.info("User Enters Reason to Visit");
    }

    public void enterBirthday(String dob) {

        setText(birthday, dob);
        getDriver().findElement(By.xpath("//body")).click();

    }

    public void selectDigitalspecs() {
        clickElement(digitalspecs);

    }


    public void clickCreateEmpreq() {
        clickElement(create_Requisitions_employee);

    }

    public void submitTheRequisition() {
        clickElement(createRequisition);
    }

    public void submitSelfRequisition() {
        clickElement(selfCreateRequisition);
    }



    public void checkBarCode() {
        Assert.assertTrue("Barcode is not displayed", barcode.isDisplayed());
    }


    public void gettheReqNumber() {
        WebElement parentElement = getDriver().findElement(By.xpath("//div[contains(@class, 'err-container')]"));
        String fullText = parentElement.getText();
        String[] lines = fullText.split("\\r?\\n");
        String ActiveNumber = lines[0].trim();
        logger.info("reqno is:"+ ActiveNumber);

    }





    public void enterMaxDistance(String Distance) {
        setText(maxDistance, Distance);

    }

    public void enterScreenDistance(String sDistance) {
        setText(screenDistance, sDistance);

    }

    public void enterReadingDistance(String rDistance) {
        setText(readingDistance, rDistance);

    }

    public void enterKeyboardDistance(String kDistance) {
        setText(keyboardDistance, kDistance);

    }

    public void clicktheOrgExport() {
        orgExportbutton.click();
    }

    public void clickViewSelfServeRequisition() {
        clickElement(ViewSelfServeRequisition);

    }

    public void validateTheLinkErrorMessage(){
        String toastMessage = Toastificationtoast.getText();
        logger.info("Toast message: " + toastMessage);
        String toastpattern = "link expired";
        validateAndLogMessage(toastMessage, toastpattern, "Toast message");


    }

    public void clickNewrequistionslink() {

        if (!requisitionLink.isPresent()) {
            clickElement(Newrequistionslink);

        }
    }

    public void clickrequistion() {
        clickElement(clickTheReq);
        logger.info("User Clicks Requistion");
    }


    public void getActiveReqNumber() {
        ActiveNumber = ReqNumber.getText();
        logger.info("Requisition Number is :" + ActiveNumber);

    }

    private List<String> requisitionTexts = new ArrayList<>();

    public void getAllReqNumber() {
        requisitionTexts.clear();
        for (WebElementFacade requisitionElement : allRequisitionElements) {
            String requisitionText = requisitionElement.getText();
            requisitionTexts.add(requisitionText);
            logger.info("Requisition Text: " + requisitionText);
        }
    }


    public void clearRequisationSearch() {
        requisationClearSearch.click();
        //waitABit(3000);
        waitForLoaderToDisappear();

    }


    public void setCalendarForRedemedDate() {
        final String noqa2redeemedDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.qa2.Redeemeddate");
        final String noqaredeemedDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.qa.Redeemeddate");
        final String nostgredeemedDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.stg.Redeemeddate");
        String targetRegion = Staf.getTargetRegion();
        String environment = Staf.getEnvironment();
        String redeemedDateStr = null;

        if (targetRegion.equals("no")) {
            switch (environment) {
                case "b2bqa2":
                    redeemedDateStr = noqa2redeemedDateStr;
                    break;
                case "b2bqa":
                    redeemedDateStr = noqaredeemedDateStr;
                    break;
                case "b2bstg":
                    redeemedDateStr = nostgredeemedDateStr;
                    break;
            }
            LocalDate redeemedDate = LocalDate.parse(redeemedDateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            setCalendarForDateRange(redeemedDate, redeemedDate);
        }
    }

    private void setCalendarForDateRange(LocalDate startDate, LocalDate endDate) {
        try {
            reportCalender.click();
            setDate(startDate);

            String startDateFormatted = startDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
            String endDateFormatted = endDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));

            List<WebElement> dateElements = getDriver().findElements(By.cssSelector(".dp__calendar_item"));

            WebElement startDateElement = null;
            WebElement endDateElement = null;

            for (WebElement dateElement : dateElements) {
                WebElement innerElement = dateElement.findElement(By.cssSelector(".dp__cell_inner"));
                String dateText = innerElement.getText();

                if (dateText.equals(String.valueOf(startDate.getDayOfMonth()))) {
                    startDateElement = dateElement;
                }

                if (dateText.equals(String.valueOf(endDate.getDayOfMonth()))) {
                    endDateElement = dateElement;
                }

                if (startDateElement != null && endDateElement != null) {
                    break;
                }
            }

            if (startDateElement != null && endDateElement != null) {
                Actions actions = new Actions(getDriver());
                actions.click(startDateElement).perform();
                actions.click(endDateElement).perform();
                logger.info("Selected date range: " + startDateFormatted + " to " + endDateFormatted);
            } else {
                logger.error("Failed to find the required dates in the calendar.");
            }
        } catch (NoSuchElementException e) {
            logger.error("Element not found: ", e);
        } catch (Exception e) {
            logger.error("An error occurred while selecting the date range: ", e);
        }
    }

    private void setDate(LocalDate date) {
        try {
            String currentYear = getYear.getText();
            String currentMonth = getMonth.getText();

            int targetYear = date.getYear();
            String targetMonth = date.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);

            if (currentYear == null || Integer.parseInt(currentYear) != targetYear) {
                clickElement(getYear);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".dp__overlay_container")));

                List<WebElement> yearOptions = getDriver().findElements(By.cssSelector(".dp__overlay_cell_pad"));
                for (WebElement option : yearOptions) {
                    if (option.getText().equals(String.valueOf(targetYear))) {
                        option.click();
                        break;
                    }
                }
            }

            if (currentMonth == null || !currentMonth.equals(targetMonth)) {
                getMonth.click();
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".dp__overlay_container")));

                List<WebElement> monthOptions = getDriver().findElements(By.cssSelector(".dp__overlay_cell_pad"));
                for (WebElement option : monthOptions) {
                    if (option.getText().equals(targetMonth)) {
                        option.click();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred while setting the date: ", e);
        }
    }

    public static LocalDate getCurrentDate() {
        return LocalDate.now();
    }


    public void verifyCalendarDate() {
        String defaultDate = defaultCalenderDate.getAttribute("value");
        logger.info("Calender default date is :" + defaultDate);
        if (defaultDate == null || defaultDate.isEmpty()) {
            logger.error("Error: Date picker text is empty.");
            return;
        }
        String[] dates = defaultDate.split(" - ");
        if (dates.length != 2) {
            logger.error("Error: Date range format is incorrect.");
            return;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);
        LocalDate startDate;
        LocalDate endDate;
        try {
            startDate = LocalDate.parse(dates[0], formatter);
            endDate = LocalDate.parse(dates[1], formatter);
        } catch (DateTimeParseException e) {
            logger.error("Error: Unable to parse dates.", e);
            return;
        }
        LocalDate today = LocalDate.now();
        LocalDate previousMonthStart = today.minusMonths(1).withDayOfMonth(1);
        LocalDate previousMonthEnd = today.minusMonths(1).withDayOfMonth(today.minusMonths(1).lengthOfMonth());

        if (!startDate.equals(previousMonthStart) || !endDate.equals(previousMonthEnd)) {
            logger.error("Error: Selected dates are not from the start to the end of the previous month.");
        } else {
            logger.info("The selected date range is correct: " + defaultDate);
        }
    }

    public void setDateRangeToYesterdayToday() {
        reportCalender.click();
        //WebElement monthButton = getDriver().findElement(By.cssSelector("button[data-test='month-toggle-overlay-0']"));
        WebDriver driver = getDriver();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector('button[data-test=\"month-toggle-overlay-0\"]').click();");
        //monthButton.click();
        waitABit(2000);

        WebElement selectedMonth = getDriver().findElement(By.cssSelector("div[aria-selected='true']"));
        String currentMonth = LocalDate.now().getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
        WebElement currentMonthElement = getDriver().findElement(By.cssSelector("div[data-test='" + currentMonth + "']"));
        currentMonthElement.click();
        logger.info("Selected month is: " + currentMonth);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM");
        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate yesterday = LocalDate.now().minusDays(1);
        LocalDate today = LocalDate.now();
        String yesterdayStr = yesterday.format(formatter);
        logger.info("Selected yesterday date: " + yesterdayStr);
        String todayStr = today.format(formatter);
        logger.info("Selected today date: " + todayStr);
        List<WebElement> calendarItems = getDriver().findElements(By.cssSelector("div.dp__calendar_item"));
        for (WebElement item : calendarItems) {
            String itemId = item.getAttribute("id");
            if (itemId != null && itemId.contains(todayStr)) {
                item.click();
                break;
            }
            if (itemId != null && itemId.contains(yesterdayStr)) {
                item.click();
            }
        }
    }

    public void setDateRangeToSpecificDates() {
        final String qa2fromDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.qa2.Startdate");
        final String qa2toDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.qa2.ToDate");
        final String qafromDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.qa.Startdate");
        final String qatoDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.qa.ToDate");
        final String stgfromDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.stg.Startdate");
        final String stgtoDateStr = testDataManager.getTestInputRegionData("AdvanceSearch.stg.ToDate");
        String targetRegion = Staf.getTargetRegion();
        String environment = Staf.getEnvironment();
        String fromDateStr = null;
        String toDateStr = null;

        if (targetRegion.equals("no")) {
            switch (environment) {
                case "b2bqa2":
                    fromDateStr = qa2fromDateStr;
                    toDateStr = qa2toDateStr;
                    break;
                case "b2bqa":
                    fromDateStr = qafromDateStr;
                    toDateStr = qatoDateStr;
                    break;
                case "b2bstg":
                    fromDateStr = stgfromDateStr;
                    toDateStr = stgtoDateStr;
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported environment: " + environment);
            }

            // Parse the dates
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate fromDate = LocalDate.parse(fromDateStr, dateFormatter);
            LocalDate toDate = LocalDate.parse(toDateStr, dateFormatter);

            reportCalender.click();
            //WebElement monthButton = getDriver().findElement(By.cssSelector("button[data-test='month-toggle-overlay-0']"));
            WebDriver driver = getDriver();
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("document.querySelector('button[data-test=\"month-toggle-overlay-0\"]').click();");
            //monthButton.click();
            waitABit(2000);

            // Select the month if necessary
            String monthName = fromDate.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            WebElement monthElement = getDriver().findElement(By.cssSelector("div[data-test='" + monthName + "']"));
            monthElement.click();
            logger.info("Selected month is: " + monthName);

            String fromDateFormatted = fromDate.format(dateFormatter);
            String toDateFormatted = toDate.format(dateFormatter);

            List<WebElement> calendarItems = getDriver().findElements(By.cssSelector("div.dp__calendar_item"));
            boolean fromDateClicked = false;
            boolean toDateClicked = false;

            for (WebElement item : calendarItems) {
                String itemId = item.getAttribute("id");
                if (itemId != null) {
                    if (itemId.contains(fromDateFormatted)) {
                        item.click();
                        fromDateClicked = true;
                        logger.info("Selected start date: " + fromDateFormatted);
                    }
                    if (itemId.contains(toDateFormatted)) {
                        item.click();
                        toDateClicked = true;
                        logger.info("Selected end date: " + toDateFormatted);
                    }
                }
                // Break the loop if both dates have been clicked
                if (fromDateClicked && toDateClicked) {
                    break;
                }
            }
        }
    }


    public void setRequisitionDateRangeToToday() {
        requisitionCalender.click();
        selectTodaysDate.click();
        selectTodaysDate.click();
        String inputValue = getReqSearchDate.getAttribute("value");
        logger.info("Input field value: " + inputValue);
        waitABit(3000);
    }


    public void clearInvoiceSearch() {
        invoiceClearSearch.click();
    }

    public void clickAdvanceSearch() {
        clickAdvanceSearch.click();
    }

    public void advSearchRequisition() {
        advSearchReq.click();
    }


    public void clikcAdvSearch() {
        clikcAdvSearch.click();
    }

    public void clikcMore() {
        clickMore.click();
    }


    public void setAdvSearchRequisition() {
        storedRequisition = getStoredValue("Requisitionno");
        if (storedRequisition != null) {
            advSearchReq.click();
            setText(advSearchReq, storedRequisition);
            logger.info("Advanced search requisition set to: " + storedRequisition);
        }
    }

    public void setAdvSearchRefNo1() {
        storedReference1 = getStoredValue("Reference1");
        if (storedReference1 != null) {
            referenceNumber1.click();
            setText(referenceNumber1, storedReference1);
            logger.info("Advanced search reference set to: " + storedReference1);
        }
    }

    public void setAdvSearchRefNo2() {
        storedReference2 = getStoredValue("Reference2");
        if (storedReference2 != null) {
            referenceNumber2.click();
            setText(referenceNumber2, storedReference2);
            logger.info("Advanced search reference set to: " + storedReference2);
        }
    }

    public void setAdvSearchAmount() {
        storedVoucherValue = getStoredValue("Vouchervalue");
        if (storedVoucherValue != null) {
            voucherValue.click();
            setText(voucherValue, storedVoucherValue);
            logger.info("Advanced search voucher value set to: " + storedVoucherValue);
        }
    }

    public void setAdvSearchOrg() {
        storedOrganisationName = getStoredValue("CompanyName");
        if (storedOrganisationName != null) {
            Organisationname.click();
            setText(Organisationname, storedOrganisationName);
            logger.info("Advanced search organisation name set to: " + storedOrganisationName);

            String optionSelector = String.format("li[id='multiselect-option-%s'] span", storedOrganisationName);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(optionSelector)));
            WebElement firstOption = getDriver().findElement(By.cssSelector(optionSelector));
            firstOption.click();
            logger.info("Advanced search option selected: " + firstOption.getText());
        }
    }

    public void setAdvSearchStore() {
        storedStoreName = getStoredValue("StoreName");
        if (storedStoreName != null) {
            StoreName.click();
            setText(StoreName, storedStoreName);
            logger.info("Advanced search store name set to: " + storedStoreName);

            String optionSelector = String.format("li[id='multiselect-option-%s'] span", storedStoreName);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(optionSelector)));
            WebElement firstOption = getDriver().findElement(By.cssSelector(optionSelector));
            firstOption.click();
            logger.info("Advanced search option selected: " + firstOption.getText());
        }
    }

    public void setAdvSearchEmpName() {
        storedEmployeeName = getStoredValue("UserName");
        if (storedEmployeeName != null) {
            EmployeeName.click();
            setText(EmployeeName, storedEmployeeName);
            logger.info("Advanced search employee name set to: " + storedEmployeeName);

            String optionSelector = String.format("li[id='multiselect-option-%s'] span", storedEmployeeName);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(optionSelector)));
            WebElement firstOption = getDriver().findElement(By.cssSelector(optionSelector));
            firstOption.click();
            logger.info("Advanced search option selected: " + firstOption.getText());
        }
    }

    public void setAdvSearchPriceList() {
        storedPriceList = getStoredValue("PriceList");
        if (storedPriceList != null) {
            PriceLists.click();
            setText(PriceLists, storedPriceList);
            logger.info("Advanced search employee name set to: " + storedPriceList);

            String optionSelector = String.format("li[id='multiselect-option-%s'] span", storedPriceList);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(optionSelector)));
            WebElement firstOption = getDriver().findElement(By.cssSelector(optionSelector));

            JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("arguments[0].scrollIntoView(true);", firstOption);
            js.executeScript("arguments[0].click();", firstOption);
            logger.info("Advanced search option selected: " + firstOption.getText());
        }
    }

    public void setAdvSearchCategory() {
        storedCategory = getStoredValue("Category");
        if (storedCategory != null) {
            Category.click();
            setText(Category, storedCategory);
            logger.info("Advanced search employee name set to: " + storedCategory);

            String optionSelector = String.format("li[id='multiselect-option-%s'] span", storedCategory);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(optionSelector)));
            WebElement firstOption = getDriver().findElement(By.cssSelector(optionSelector));
            JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("arguments[0].scrollIntoView(true);", firstOption);
            js.executeScript("arguments[0].click();", firstOption);
            logger.info("Advanced search option selected: " + firstOption.getText());
        }
    }

    public void setAdvSearchComments() {
        storedComments = getStoredValue("Comments");
        if (storedComments != null) {
            Comments.click();
            setText(Comments, storedComments);
            logger.info("Advanced search employee name set to: " + storedComments);

        }
    }


    public void setAdvSearchCreatedDate() {
        storedCreatedDate = getStoredValue("CreatedDate");
        if (storedCreatedDate != null) {
            CreatedDate.click();
            setText(CreatedDate, storedCreatedDate);
            logger.info("Advanced search employee name set to: " + storedCreatedDate);
            getDriver().findElement(By.xpath("//body")).click();
        }
    }

    private String getStoredValue(String key) {
        String storedValue = null;
        String targetRegion = Staf.getTargetRegion();
        String environment = Staf.getEnvironment();

        if (targetRegion.equals("no")) {
            switch (environment) {
                case "b2bqa2":
                    storedValue = testDataManager.getTestInputRegionData("AdvanceSearch.qa2." + key);
                    break;
                case "b2bqa":
                    storedValue = testDataManager.getTestInputRegionData("AdvanceSearch.qa." + key);
                    break;
                case "b2bstg":
                    storedValue = testDataManager.getTestInputRegionData("AdvanceSearch.stg." + key);
                    break;
            }
        }
        return storedValue;
    }


    public void SearchRequDetails() {
        validateDetails(0, storedRequisition, "Requisition numbers");
    }

    public void SearchVoucherValueDetails() {
        validateDetails(2, storedVoucherValue, "Voucher value");
    }

    public void SearchStoreName() {
        validateDetails(4, storedStoreName, "Store name");
    }

    public void SearchOrganisationName() {
        validateDetails(6, storedOrganisationName, "Organisation name");
    }

    public void SearchEmpName() {
        validateDetails(7, storedEmployeeName, "Employee name");
    }

    public void SearchRef1Details() {
        validateDetails(8, storedReference1, "Reference number 1");
    }

    public void SearchRef2Details() {
        validateDetails(9, storedReference2, "Reference number 2");
    }


    private void validateDetails(int lineIndex, String expectedValue, String valueDescription) {
        String details = getreportreqdetails.getText();
        logger.info("Raw Requisition Details: " + details);

        String[] lines = details.split("\\r?\\n");
        logger.info("Number of lines: " + lines.length);

        for (int i = 0; i < lines.length; i++) {
            logger.info("Line " + (i + 1) + ": " + lines[i].trim());
        }

        if (lines.length == 12) {
            String resultValue = lines[lineIndex].trim();
            if (resultValue.equals(expectedValue)) {
                logger.info(valueDescription + " match: " + expectedValue);
            } else {
                if (redeemdedNoRecord.isDisplayed()) {
                    throw new IllegalStateException("'redeemdedNoRecord' element is displayed, indicating no records found.");
                } else {
                    throw new IllegalArgumentException("Requisition number does not match. Expected: " + storedRequisition + ", Found: " + resultValue);
                }
            }
        } else {
            throw new IllegalArgumentException("Unexpected format of requisition details. Expected at least 12 lines, found: " + lines.length);
        }
    }



    public void validateRequisitionDetails() {

        String storedRequisition = getStoredValue("Requisitionno");

        List<WebElement> elements = getDriver().findElements(By.cssSelector(".specs-list-label.reqList-class .labels"));

        boolean isFound = false;
        for (WebElement element : elements) {
            if (element.getText().contains(storedRequisition)) {
                isFound = true;
                break;
            }
        }
        Assertions.assertTrue(isFound, "Requisition no " + storedRequisition + " is NOT present in the search results.");
        logger.info("Requisition no " + storedRequisition + " is present in the search results.");
    }


        /*if (storedRequisition == null) {
            throw new IllegalArgumentException("Stored requisition number is null.");
        }

        String details = getreportreqdetails.getText();
        logger.info("Raw Requisition Details: " + details);

        String[] lines = details.split("\\r?\\n");
        logger.info("Number of lines: " + lines.length);

        for (int i = 0; i < lines.length; i++) {
            logger.info("Line " + (i + 1) + ": " + lines[i].trim());
        }

        // Check if lines array has sufficient length to prevent out of bound exception
        if (lines.length >= 12) {
            // Assuming the requisition number is on the first line (lineIndex 0)
            int lineIndex = 0;
            String resultValue = lines[lineIndex].trim();
            if (resultValue.equals(storedRequisition)) {
                logger.info("Requisition number match: " + storedRequisition);
            } else {
                if (redeemdedNoRecord.isDisplayed()) {
                    throw new IllegalStateException("'redeemdedNoRecord' element is displayed, indicating no records found.");
                } else {
                    throw new IllegalArgumentException("Requisition number does not match. Expected: " + storedRequisition + ", Found: " + resultValue);
                }
            }
        } else {
            throw new IllegalArgumentException("Unexpected format of requisition details. Expected at least 12 lines, found: " + lines.length);
        }
    }*/


    public void validateActiveReq() {
        clickElement(search);
        setText(search, ActiveNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requisition number: " + requisitionNumber);

        String status = lines[7].trim();

        if (!requisitionNumber.equals(ActiveNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("ACTIVE")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }
    }

    public void validateApprovedReq() {
        clickElement(search);
        setText(search, ActiveNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requisition number: " + requisitionNumber);

        String status = lines[7].trim();

        if (!requisitionNumber.equals(ActiveNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("APPROVED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }
    }

    public void validateApprovedReqinReports() {
        clickElement(search);
        setText(search, ActiveNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requisition number: " + requisitionNumber);

        String status = lines[10].trim();

        if (!requisitionNumber.equals(ActiveNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("APPROVED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }
    }


    public void validateTheReq() {
        evaluateScriptClick(search);
        setText(search, ActiveNumber);
        logger.info("Enter Requisition No:" + ActiveNumber);
        reqSearch.click();
        logger.info("Click on  Search");

        try {
            if (noRecordFound.isDisplayed()) {
                String actualMessage = noRecordFound.getText();
                logger.info("Message is: " + actualMessage);
            } else {

                String requisitionNumberXpath = "//p[normalize-space()='" + ActiveNumber + "']";
                boolean isPresent = getDriver().findElements(By.xpath(requisitionNumberXpath)).isEmpty();

                if (isPresent) {
                    boolean isVisible = getDriver().findElement(By.xpath(requisitionNumberXpath)).isDisplayed();
                    if (isVisible) {
                        logger.warn("Requisition is visible: " + ActiveNumber);
                        throw new RuntimeException("Test case failed: Requisition is visible: " + ActiveNumber);
                    } else {
                        logger.warn("Requisition number is present but not visible: " + ActiveNumber);
                    }
                } else {
                    logger.warn("Requisition number not found: " + ActiveNumber);
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred: ", e);
            throw new RuntimeException(e);
        }
    }


    public void validateInvoicedReq() {
        evaluateScriptClick(search);
        setText(search, ActiveNumber);
        logger.info("Enter Requisition No:" + ActiveNumber);
        reqSearch.click();
        logger.info("Click on  Search");

        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requisition number: " + requisitionNumber);

        String status = lines[11].trim();

        if (!requisitionNumber.equals(ActiveNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("INVOICED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }
    }

    public void validateInvoicedReqwithoutTillId() {
        evaluateScriptClick(search);
        setText(search, ActiveNumber);
        logger.info("Enter Requisition No:" + ActiveNumber);
        reqSearch.click();
        logger.info("Click on  Search");

        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requisition number: " + requisitionNumber);

        String status = lines[10].trim();

        if (!requisitionNumber.equals(ActiveNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("INVOICED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }
    }

    public void validateLockedReq() {
        evaluateScriptClick(search);
        setText(search, ActiveNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requisition number: " + requisitionNumber);

        String status = lines[11].trim();

        if (!requisitionNumber.equals(ActiveNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("LOCKED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }
    }


    public void checkbuttonsdisabled() {
        if (exportbutton.isPresent()) {
            logger.info("Export button is Disabled");
        } else {
            throw new AssertionError("Export button is unexpectedly present");
        }
        if (invoicebutton.isPresent()) {
            logger.info("Invoice is Disabled");

        } else {
            throw new AssertionError("Invoice button is unexpectedly enabled");
        }
        if (lockunlockbutton.isPresent()) {
            logger.info("Lock is Disabled");

        } else {
            throw new AssertionError("Lock button is unexpectedly enabled");
        }
    }


    public void checkbuttonsenabled() {

        if (invoicebutton.isPresent()) {
            try {
                wait.until(ExpectedConditions.elementToBeClickable(invoicebutton));
                logger.info("Invoice button is Enabled and Clickable");
            } catch (Exception e) {
                throw new AssertionError("Invoice button is unexpectedly disabled or not clickable");
            }
        } else {
            throw new AssertionError("Invoice button is not present");
        }

        if (lockunlockbutton.isPresent()) {
            try {
                wait.until(ExpectedConditions.elementToBeClickable(lockunlockbutton));
                logger.info("Lock button is Enabled and Clickable");
            } catch (Exception e) {
                throw new AssertionError("Lock button is unexpectedly disabled or not clickable");
            }
        } else {
            throw new AssertionError("Lock button is not present");
        }
        if (exportbutton.isPresent()) {
            try {
                wait.until(ExpectedConditions.elementToBeClickable(exportbutton));
                logger.info("Export button is Enabled and Clickable");
            } catch (Exception e) {
                throw new AssertionError("Export button is unexpectedly disabled or not clickable");
            }
        } else {
            throw new AssertionError("Export button is not present");
        }


    }


    public void validateSucessMsg() {
        String actualMessage = sucessMessage.getText().replaceAll("[^a-zA-Z0-9!\\s]", "").trim();
        logger.info("Success Message is: " + actualMessage);
        if (!actualMessage.equals("1 Requisition is invoiced!")) {
            Assert.fail("Unexpected message found: " + actualMessage);
        }

        sucessMessageClose.click();

    }


    public void selecttheReqForInvoice() {

        clickElement(selectReForInvoice);
        logger.info("Req selected for Invoice");
    }

    public void clicktheInvoice() {

        clickElement(invoicebutton);
        logger.info("User Click on Invoice");
        clickElement(iYes);
        logger.info("User Click on Yes");
    }

    public void clicktheInvoiceForLocked() {

        clickElement(invoicebutton);

    }

    public void clicktheLockForInvoice() {

        clickElement(lockunlockbutton);
        logger.info("User Click on Lock for Invoice");
    }


    public void getNeedsActionCount() {
        String naWidgeCount = getTheCountofWidge.getText();
        String extractedNumberStr = naWidgeCount.replaceAll("\\D+", "");
        //logger.info("Widge Count is: " + extractedNumberStr);
        clickElement(needsAction);
        //waitABit(3000);
    }

    public String getReqReqNumber() {
        reqrequisitionNumber = userreqnumber.get(0).getText();
        logger.info("Requested Requisitions Number: " + reqrequisitionNumber);
        return reqrequisitionNumber;
    }


    public String processRequisitionText() {
        int elementIndex = 1;

        try {
            while (true) {
                WebElement element = getDriver().findElement(By.xpath("(//div[@class='specs-list specs-list-label-font-size'])[" + elementIndex + "]"));
                String textContent = element.getText();
                String[] lines = textContent.split("\n");
                String reqstatus = lines[7].trim();
                if (!reqstatus.equals("CLAIMED") && !reqstatus.equals("RETURNED")) {
                    if (reqstatus.equals("REQUESTED")) {
                        reqrequisitionNumber = lines[0].trim();
                        logger.info("NA Requested Requisition number: " + reqrequisitionNumber);
                        break;
                    }
                }
                elementIndex++;
            }
        } catch (NoSuchElementException e) {
            // This exception occurs when the element is not found, indicating the end of the list.
            logger.info("No more requisitions found.");
        } catch (Exception e) {
            // Log any other exceptions for further investigation
            logger.error("Error occurred while processing requisition text: " + e.getMessage());
        }

        return reqrequisitionNumber;
    }


    public void enterRqReqIdInSearchBox() {
        logger.info("enterRqReqIdInSearchBox: " + reqrequisitionNumber);
        if (reqrequisitionNumber == null) {
            throw new IllegalArgumentException("Requisition Number cannot be null");
        }
        search.clear();
        setText(search, reqrequisitionNumber);
        logger.info("User Enters the requisition id: " + reqrequisitionNumber);

    }


    public String processClaimedRequisitionText() {
        int elementIndex = 1;

        try {
            while (true) {
                WebElement element = getDriver().findElement(By.xpath("(//div[@class='specs-list specs-list-label-font-size'])[" + elementIndex + "]"));
                String textContent = element.getText();
                String[] lines = textContent.split("\n");
                String reqstatus = lines[6].trim();
                if (!reqstatus.equals("REQUESTED") && !reqstatus.equals("RETURNED")) {
                    if (reqstatus.equals("CLAIMED")) {
                        reqrequisitionNumber = lines[0].trim();
                        logger.info("NA Claimed Requisition number: " + reqrequisitionNumber);
                        break;
                    }
                }
                elementIndex++;
            }
        } catch (NoSuchElementException e) {
            // This exception occurs when the element is not found, indicating the end of the list.
            logger.info("No more requisitions found.");
        } catch (Exception e) {
            // Log any other exceptions for further investigation
            logger.error("Error occurred while processing requisition text: " + e.getMessage());
        }

        return reqrequisitionNumber;
    }

    public String processReturnedRequisitionText() {
        int elementIndex = 1;

        try {
            while (true) {
                WebElement element = getDriver().findElement(By.xpath("(//div[@class='specs-list specs-list-label-font-size'])[" + elementIndex + "]"));
                String textContent = element.getText();
                String[] lines = textContent.split("\n");
                String reqstatus = lines[6].trim();
                if (!reqstatus.equals("REQUESTED") && !reqstatus.equals("CLAIMED")) {
                    if (reqstatus.equals("RETURNED")) {
                        reqrequisitionNumber = lines[0].trim();
                        logger.info(" NA Returned Requisition number: " + reqrequisitionNumber);
                        break;
                    }
                }
                elementIndex++;
            }
        } catch (NoSuchElementException e) {
            // This exception occurs when the element is not found, indicating the end of the list.
            logger.info("No more requisitions found.");
        } catch (Exception e) {
            // Log any other exceptions for further investigation
            logger.error("Error occurred while processing requisition text: " + e.getMessage());
        }

        return reqrequisitionNumber;
    }


    public void validateRqActiveReq() {
        clickElement(search);
        setText(search, reqrequisitionNumber);
        //logger.info("Enter Requisation: " + reqrequisitionNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Requested Requisition number: " + requisitionNumber);

        String status = lines[7].trim();

        if (!requisitionNumber.equals(reqrequisitionNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("REQUESTED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }

    }

    public void validateClaimedReq() {
        clickElement(search);
        setText(search, reqrequisitionNumber);
        //logger.info("Check: " + reqrequisitionNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Claimed Requisition number: " + requisitionNumber);

        String status = lines[6].trim();

        if (!requisitionNumber.equals(reqrequisitionNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("CLAIMED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }

    }

    public void validateReturnedReq() {
        clickElement(search);
        setText(search, reqrequisitionNumber);
        //logger.info("Check: " + reqrequisitionNumber);
        reqSearch.click();
        String getreqdetail = getreqdetails.getText();
        //logger.info("Requisition Text: " + getreqdetail);

        String[] lines = getreqdetail.split("\n");
        String requisitionNumber = lines[0].trim();
        logger.info("Returned Requisition number: " + requisitionNumber);

        String status = lines[6].trim();

        if (!requisitionNumber.equals(reqrequisitionNumber)) {
            logger.error("Validation Failed: Requisition Number is incorrect.");
            throw new IllegalArgumentException("Requisition Number is incorrect.");
        }
        if (!status.equals("RETURNED")) {
            logger.error("Validation Failed: Status is incorrect.");
            throw new IllegalArgumentException("Status is incorrect.");
        } else {
            logger.info("Validation Passed: Requisition Number and Status are correct.");
        }

    }


    public void clickOnDynamicReReqLink() {
        checkForNoResults();
        logger.info("Dynamic: " + reqrequisitionNumber);
        if (reqrequisitionNumber == null) {
            throw new IllegalArgumentException("Organisation Number cant be Null");
        }
        String requisationNumber = "(//p[normalize-space()='" + reqrequisitionNumber + "'])";
        logger.info(("clicking on dynamic xpath:" + requisationNumber));
        evaluateScriptClick($(By.xpath(requisationNumber)));
    }


    public void getActiveuserReqNumber() {
        ActiveNumber = userreqnumber.get(0).getText();
        logger.info("Requisitions Number:" + ActiveNumber);

    }

    public void getActiveuserReqNumberNew() {
        ActiveNumber = usergetreqnumber.getText();
        logger.info("Requisitions Number:" + ActiveNumber);

    }


    public void copyUrl() {
        String URL = getURL.getText();
        logger.info("URL is=" + URL);

        ArrayList<String> allTabs = new ArrayList<>(getDriver().getWindowHandles());

        if (allTabs.size() == 1) {
            // If there is only one window (the main window), open a new tab
            JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("window.open();");
            allTabs = new ArrayList<>(getDriver().getWindowHandles());
        }

        if (allTabs.size() > 1) {
            final String mainWindowTitle = getDriver().switchTo().window(allTabs.get(0)).getTitle(); // Store the main window title
            getDriver().switchTo().window(allTabs.get(1)); // Switch to the new tab

            // Navigate to the URL in the new tab
            getDriver().navigate().to(URL);
        } else {
            // Handle the case where there are no tabs to switch to
            logger.warn("No tabs to switch to.");
        }

    }


    public void enterReqIdInSearchBox() {
        logger.info("enterReqIdInSearchBox: " + ActiveNumber);
        if (ActiveNumber == null) {
            throw new IllegalArgumentException("requisation Number cant be Null");
        }
        search.clear();
        setText(search, ActiveNumber);
        logger.info("User Enters the requisation id :" + ActiveNumber);

    }


    public void clickOnClaim() {
        clickElement(claim);

    }


    public void clickOnRefund() {
        clickElement(refund);
        logger.info("User Click on refund");
    }

    public void clickOnApprove() {
        clickElement(approve);

    }


    public void clickOnReturn() {
        waitForCondition().until(ExpectedConditions.visibilityOf(returne));
        clickElement(returne);

    }

    public void enterComments(String comments) {
        setText(ApproveComments, comments);

    }

    public void clickOnConfirm() {
        clickElement(confirm);

    }


    public void clickOnYes() {
        clickElement(yes);
        logger.info("User Click on Yes");
    }

    public void clickOninvoiceYes() {
        waitForCondition().until(ExpectedConditions.visibilityOf(iYes));
        clickElement(iYes);
        logger.info("User Click on Yes");
    }


    public void clickOnNo() {
        clickElement(no);
        logger.info("User Click on NO");
    }


    public void clickOnSearchReq() {
        waitForCondition().until(ExpectedConditions.visibilityOf(reqSearch));
        reqSearch.click();

    }


    public void clickOnCancel() {

        clickElement(cancel);
        logger.info("User Click on Cancel");
    }

    public void checkCancelIsNotPresent() {
        cancel.shouldNotBePresent();

    }

    public void checkEditIsNotPresent() {
        edit.shouldNotBePresent();

    }

    public void clickOnEdit() {
        clickElement(edit);

    }


    public void switchingBackToOriginalWindow() {
        switchToOriginalWindow();
        logger.info("Switched to Original Window.");
    }


    public void clickOnAddSpecialProduct() {
        clickElement(addSpecialProduct);
        clickElement(specislProductDropDown);

    }

    public void selecttheProduct() {
        clickElement(productDropdown);
        clickElement(selectSpecislProduct);


        /*final String productName = testDataManager.getTestInputCommonData("orgInfo.SpecialProduct");
        clickElement(productDropdown);
        for (WebElementFacade option : selectSpecialProduct) {
            if (option.getText().trim().equals(productName)) {
                option.click();
                break;
            }
        }*/
    }


    public void inputProductvalue(String value) {
        setText(inputValue, value);

    }


    public void validateTheSelectedProduct() {

        String specialProductNameText = getSpecialProductName.getText();
        logger.info("specialProductName:" +specialProductNameText);
        Assert.assertNotNull("Special product name text is null!", specialProductNameText);
        Assert.assertFalse("Special product name text is empty!", specialProductNameText.trim().isEmpty());

        String specialProductMenu = getSpecialtype.getText();
        logger.info("specialProductName:" +specialProductMenu);
        Assert.assertNotNull("Special product Menu is null!", specialProductMenu);
        Assert.assertFalse("Special product Menu is empty!", specialProductMenu.trim().isEmpty());

    }


    public void clickToClosePopUp() {
        withAction().moveToElement(closePopup).doubleClick(closePopup).perform();
    }

    public void waitUntillPageListisLoaded() {
        waitForLoaderIfPresent();
    }


    public void selecttheAddItems() {
        clickElement(addItems);

    }

    public void addItemstoreq() {
        clickElement(dropDown);
        clickElement(Digital);
        logger.info("User selected Digital :Digital");
        clickElement(dropDown);
        if (Staf.getTargetRegion().equals("no")) {
            clickElement(noframe);
            logger.info("User selected frame :noframe");
        } else if (Staf.getTargetRegion().equals("se")) {
            clickElement(seframe);
            logger.info("User selected frame :seframe");
        }


        clickElement(dropDown);
        if (Staf.getTargetRegion().equals("no")) {
            clickElement(noLens);
            logger.info("User selected Lens :noLens");
        } else if (Staf.getTargetRegion().equals("se")) {
            clickElement(seLens);
            logger.info("User selected Lens :seLens");
        }


        clickElement(dropDown1);
        if (Staf.getTargetRegion().equals("no")) {
            clickElement(noIndex);
            logger.info("User selected Index :noIndex");
        } else if (Staf.getTargetRegion().equals("se")) {
            clickElement(seIndex);
            logger.info("User selected Index :seIndex");
        }


        clickElement(dropDown1);
        if (Staf.getTargetRegion().equals("no")) {
            clickElement(noCoating);
            logger.info("User selected Coating :noCoating");
        } else if (Staf.getTargetRegion().equals("se")) {
            clickElement(seCoating);
            logger.info("User selected Coating :seCoating");
        }
    }

    public void clikcOnReceipt() {
        clickElement(receipt);

    }

    public void clikcOnEdit() {
        clickElement(Edit);

    }

    public void enterTheReceiptNumber() {
        clickElement(inputReceiptNumber);
        String receiptNumber;

        String targetRegion = Staf.getTargetRegion();

        switch (targetRegion) {
            case "se":
            case "uk":
                receiptNumber = base.generateSixDigitNumber();
                logger.info("ReceiptNumber is: " + receiptNumber);
                break;
            case "no":
                receiptNumber = base.generateSevenDigitNumber();
                logger.info("ReceiptNumber is: " + receiptNumber);
                break;
            default:
                logger.error("Unknown region: " + targetRegion);
                return;
        }

        setText(inputReceiptNumber, receiptNumber);
        enteredReceiptNumber = receiptNumber;
    }


    public void saveTheReceipt() {
        clickElement(saveReceipt);

    }


    public void validateTheReceipt() {
        waitABit(3000);
        String storedReceipt = getReceiptNumber.getText().trim();
        logger.info("Stored Receipt number:" + storedReceipt);

        String extractedReceiptNumber = null;
        int lastIndex = storedReceipt.lastIndexOf('.');
        if (lastIndex != -1 && lastIndex + 1 < storedReceipt.length()) {
            extractedReceiptNumber = storedReceipt.substring(lastIndex + 1).trim();
        } else {
            logger.error("Validation failed: could not find a valid receipt number after the period.");
            throw new AssertionError("Validation failed: could not find a valid receipt number after the period.");
        }

        if (extractedReceiptNumber == null || extractedReceiptNumber.isEmpty()) {
            logger.error("Validation failed: extracted receipt number is null or empty.");
            throw new AssertionError("Validation failed: extracted receipt number is null or empty.");
        }

        if (!extractedReceiptNumber.equals(enteredReceiptNumber)) {
            logger.error("Validation failed: entered receipt number ("
                    + enteredReceiptNumber + ") does not match stored receipt number ("
                    + extractedReceiptNumber + ").");
            throw new AssertionError("Validation failed: entered receipt number does not match stored receipt number.");
        }

        logger.info("Receipt number validation successful.");
    }

    public void validateTheRequisition() throws Exception {
        boolean isErrorVisible = errormessage.isVisible();
        boolean isReportVisible = ReportReqVisible.isVisible();

        try {
            if (errormessage.isVisible()) {
                throw new Exception("Test failed because error message is visible.");
            } else if (ReportReqVisible.isVisible()) {
                logger.info("Test passed. Requisition is available.");
            } else {
                throw new Exception("Neither error message nor requisition report is visible. Test is inconclusive.");
            }
        } catch (Exception e) {
            throw new Exception("Elements not found on the page.", e);
        }
    }


    private String getTestData(String key) {
        return testDataManager.getTestInputRegionData(key);
    }

    private String getRequisitionKey(String type) {
        String environment = Staf.getEnvironment();
        switch (environment) {
            case "b2bqa2":
                return "Restrictstore.qa2." + type;
            case "b2bqa":
                return "Restrictstore.qa." + type;
            case "b2bstg":
                return "Restrictstore.stg." + type;
            default:
                throw new IllegalArgumentException("Unsupported environment: " + environment);
        }
    }

    private void performSearch(String requisition) {
        search.click();
        setText(search, requisition);
        reqSearch.click();
        waitABit(2000);
        if (Toastificationtoast.isDisplayed()) {
            logger.info("Toast message is displayed.");
        } else {
            logger.info("Toast message is not displayed.");
            Assert.fail("Toast message was not displayed.");
        }
    }


    public void validateAndLogToastMessageForClaimed() {
        String toastMessage = Toastificationtoast.getText();
        logger.info("Toast message: " + toastMessage);
        String toastpattern = "This requisition has been claimed in \\[.*\\]";
        validateAndLogMessage(toastMessage, toastpattern, "Toast message");
        closeToastification.click();
    }


    public void validateAndLogNoteMessage() {
        String noteMessage = notemessage.getText();
        logger.info("Note message: " + noteMessage);
        String notepattern = "This requisition has been claimed in \\[.*\\]";
        validateAndLogMessage(noteMessage, notepattern, "Note message");
    }


    private void validateAndLogMessage(String message, String pattern, String messageType) {
        if (validateMessagePattern(message, pattern)) {
            logger.info(messageType + " validation passed.");
        } else {
            logger.error(messageType + " validation failed.");
        }
    }

    private boolean validateMessagePattern(String message, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(message);
        return m.find();
    }

    public void enterRequisitionAndSearch(String type) {
        if ("no".equals(Staf.getTargetRegion())) {
            String key = getRequisitionKey(type);
            String requisition = getTestData(key);
            performSearch(requisition);
        }
    }

    public void setSearchRequisition() {
        storedRequisition = getStoredValue("Requisitionno");
        if (storedRequisition != null) {
            search.click();
            setText(search, storedRequisition);
            logger.info("search requisition set to: " + storedRequisition);
        }
    }


    public void clickSearchIcon() {
        searchMagnifying.click();
    }


    public void selecttheReqFromList() {

        clickElement(selectRequisition);
        logger.info("Req selected for Invoice");
    }


    public void clicktheExport() {
        exportbutton.click();
    }


    public void validateAndLogToastMessageForOrgExport() {
        String toastMessage = SucessToastificationtoast.getText();
        logger.info("Toast message: " + toastMessage);
        String toastpattern = "Organisations are yet to export!";
        validateAndLogMessage(toastMessage, toastpattern, "Toast message");
        closeToastification.click();
    }

    public void validateAndLogToastMessageForExport() {
        String toastMessage = SucessToastificationtoast.getText();
        logger.info("Toast message: " + toastMessage);
        String toastpattern = "Requisitions are yet to export!";
        validateAndLogMessage(toastMessage, toastpattern, "Toast message");
        closeToastification.click();
    }

    public void validateAndLogToastMessageForOrgEmail() {
        String toastMessage = SucessToastificationtoast.getText();
        logger.info("Toast message: " + toastMessage);
        String toastpattern = "Email has been sent successfully!";
        validateAndLogMessage(toastMessage, toastpattern, "Toast message");
        closeToastification.click();
    }

    public void enterManagerApprovedRequisitionAndSearch() {
        enterRequisitionAndSearch("NationalManagerApproved");
    }

    public void enterManagerClaimedRequisitionAndSearch() {
        enterRequisitionAndSearch("NationalManagerClaimed");
    }

    public void enterUserApprovedRequisitionAndSearch() {
        enterRequisitionAndSearch("NationalUserApproved");
    }

    public void enterPaidRequisitionAndSearch() {
        enterRequisitionAndSearch("Paid");
    }



    public void enterUserClaimedRequisitionAndSearch() {
        enterRequisitionAndSearch("NationalUserClaimed");
    }

    public void enterManagerApprovedRequisitionAndSearchLocal() {
        enterRequisitionAndSearch("LocalManagerApproved");
    }

    public void enterManagerClaimedRequisitionAndSearchLocal() {
        enterRequisitionAndSearch("LocalManagerClaimed");
    }

    public void enterUserApprovedRequisitionAndSearchLocal() {
        enterRequisitionAndSearch("LocalUserApproved");
    }

    public void enterUserClaimedRequisitionAndSearchLocal() {
        enterRequisitionAndSearch("LocalUserClaimed");
    }
}





