package b2bEyeCare.pages;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.actions.SendKeys;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;

public class b2bEyeCareCategoriesPage extends b2bEyeCareBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareCategoriesPage.class);

    @FindBy(xpath = "//li[normalize-space()='Auto']")
    private WebElementFacade CategoryAuto;

    @FindBy(xpath = "//li[normalize-space()='Auto']//div[@class='hovericon']//div//*[name()='svg']")
    private WebElementFacade DeleteIcon;

    @FindBy(xpath = "//button[normalize-space()='Delete']")
    private WebElementFacade Delete;

    @FindBy(css = "#addArticle-7 #show-modal")
    private WebElementFacade AddFramesCategorie;

    @FindBy(css = "#addArticle-8 #show-modal")
    private WebElementFacade AddLenseCategorie;

    @FindBy(css = "#addArticle-9 #show-modal")
    private WebElementFacade AddCoatingCategorie;

    @FindBy(css = "#addArticle-10 #show-modal")
    private WebElementFacade AddIndexCategorie;


    @FindBy(css = "input[placeholder='Name of item']")
    private WebElementFacade CategorieName;

    @FindBy(css = "input[placeholder='Item VAT price']")
    private WebElementFacade CategorieVatPrice;


    @FindBy(css = "input[placeholder='Item none VAT price']")
    private WebElementFacade CategorieNVatPrice;

    @FindBy(css = ".specs-button--size-full-width")
    private WebElementFacade CreateCategorie;

    public void AddFramesCategorie() {
        clickElement(AddFramesCategorie);
    }
    public void AddLenseCategorie() {
        clickElement(AddLenseCategorie);
    }
    public void AddCoatingCategorie() {
        clickElement(AddCoatingCategorie);
    }
    public void AddIndexCategorie() {clickElement(AddIndexCategorie);}

    public void deleteCategoryAutoElements() {
        try {
            while (true) {
                if (CategoryAuto.isDisplayed()) {
                    clickElement(CategoryAuto);
                    Actions actions = new Actions(getDriver());
                    actions.moveToElement(CategoryAuto).perform();
                    logger.info("User hovered over the CategoryAuto element");
                    clickElement(DeleteIcon);
                    logger.info("User clicked the Delete icon in the category auto");
                    clickElement(Delete);
                    logger.info("User deleted the category auto");
                    int minDelaySeconds = 30;
                    int maxDelaySeconds = 50;
                    int randomDelaySeconds = minDelaySeconds + (int) (Math.random() * (maxDelaySeconds - minDelaySeconds + 1));
                    Thread.sleep(randomDelaySeconds * 1000);
                    /*WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(50));
                    wait.until(ExpectedConditions.invisibilityOf(CategoryAuto));*/
                } else {
                    break;
                }
            }
        } catch (NoSuchElementException e) {
            logger.info("No CategoryAuto elements found to delete.");
        } catch (StaleElementReferenceException e) {
            logger.warn("Stale element reference encountered. Retrying...");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }





    public void setNumericValue(WebElementFacade element, int value) {
        Actions actions = new Actions(getDriver());
        actions.moveToElement(element).click().sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), String.valueOf(value)).perform();
    }


    public void addACategoriesValue() {
        setText(CategorieName, "Auto");
        setNumericValue(CategorieVatPrice, 100);
        setNumericValue(CategorieNVatPrice, 100);
        clickElement(CreateCategorie);
    }


        public void DeleteCategoriesFromList () {
            deleteCategoryAutoElements();
        }
    }



