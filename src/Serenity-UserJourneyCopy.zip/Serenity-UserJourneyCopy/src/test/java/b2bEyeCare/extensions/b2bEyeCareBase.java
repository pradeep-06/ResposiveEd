package b2bEyeCare.extensions;

import Framework.BaseObject.BasePageObject;
import Framework.Staf;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.NoSuchElementException;

import static Framework.Staf.wait;
import static net.serenitybdd.screenplay.waits.Wait.until;

public class b2bEyeCareBase extends BasePageObject {

    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareBase.class);
    private static final String[] streetsNO = {"Karl Johans gate", "Strandgata", "Kirkegata", "Kongens gate", "Storgata",
            "Parkveien", "Tollbodgata", "Nygaardsgata", "Grønland", "Langgata"};

    private static final String[] citiesNO = {"Oslo", "Bergen", "Stavanger", "Trondheim", "Tromsø",
            "Ålesund", "Kristiansand", "Fredrikstad", "Drammen", "Sandnes"};

    private static final String[] zipsNO = {"0154", "5014", "4006", "7013", "9008", "6002", "4612", "1605", "3045", "4306"};

    private static final String[] streetsSE = {"Drottninggatan", "Stortorget", "Kungsgatan", "Storgatan", "Hamngatan",
            "Nygatan", "Sturegatan", "Lilla Nygatan", "Östergatan", "Västra Ågatan"};

    private static final String[] citiesSE = {"Stockholm", "Malmö", "Gothenburg", "Uppsala", "Umeå",
            "Malmö", "Stockholm", "Stockholm", "Malmö", "Uppsala"};

    private static final String[] zipsSE = {"11151", "21134", "41119", "75310", "90326", "21138", "11435", "11128", "21125", "75309"};

    private static final String[] streetsGB = {"Baker Street", "Abbey Road", "Oxford Street", "Downing Street", "Portobello Road",
            "Kensington High Street", "Carnaby Street", "Bond Street", "Regent Street", "Savile Row"};

    private static final String[] citiesGB = {"London", "Manchester", "Birmingham", "Glasgow", "Liverpool",
            "Edinburgh", "Bristol", "Leeds", "Newcastle upon Tyne", "Sheffield"};

    private static final String[] zipsGB = {"SW1A 1AA", "M1 1AA", "B1 1AA", "G1 1AA", "L1 1AA",
            "EH1 1AA", "BS1 1AA", "LS1 1AA", "NE1 1AA", "S1 1AA"};

    private static Random random = new Random();
    private static Set<Integer> generatedNumbers = new HashSet<>();
    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";


    private static List<String> generatedOrgNames = new ArrayList<>();
    private static List<String> generatedEmails = new ArrayList<>();
    private static long generatedNumber = 0;


    public static long generate9DigitNumber() {
        long number;
        do {
            number = 100000000L + random.nextInt(900000000);
        } while (generatedNumbers.contains((int) number));
        generatedNumbers.add((int) number);
        return number;
    }

    public static long generate10DigitNumber() {
        long number;
        do {
            number = 1000000000L + (long) random.nextInt(900000000);
        } while (generatedNumbers.contains((int) number));
        generatedNumbers.add((int) number);
        return number;
    }


    public static long generateOrganisationId() {
        if (generatedNumber == 0) {
            if (Staf.getTargetRegion().equals("no")) {
                generatedNumber = generate9DigitNumber();
            } else if (Staf.getTargetRegion().equals("se")) {
                generatedNumber = generate10DigitNumber();
            } else if (Staf.getTargetRegion().equals("uk")) {
                generatedNumber = generate9DigitNumber();
            }
        }
        return generatedNumber;
    }

    public static Object resetGeneratedNumber() {
        generatedNumbers.clear();
        generatedNumber = 0;
        if (Staf.getTargetRegion().equals("no")) {
            generatedNumber = generate9DigitNumber();

        } else if (Staf.getTargetRegion().equals("se")) {
            generatedNumber = generate10DigitNumber();
        } else if (Staf.getTargetRegion().equals("uk")) {
            generatedNumber = generate9DigitNumber();
        }
        return generatedNumber;
    }

    public static String generateEmail() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());
        String email = "b2b" + timestamp + "@test.com";
        generatedEmails.add(email);
        return email;
    }

    public static String generateOrgName() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());
        String orgName;
        if (Staf.getTargetRegion().equals("no")) {
            orgName = "OrgNo" + timestamp;

        } else if (Staf.getTargetRegion().equals("se")) {
            orgName = "OrgSE" + timestamp;
        } else if (Staf.getTargetRegion().equals("uk")) {
            orgName = "OrgGB" + timestamp;

        } else {
            orgName = "Org" + timestamp;

        }
        generatedOrgNames.add(orgName);
        return orgName;
    }

    public static String generateSubOrgName() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());
        String orgName;

        if (Staf.getTargetRegion().equals("no")) {
            orgName = "OrgSubNo" + timestamp;

        } else if (Staf.getTargetRegion().equals("se")) {
            orgName = "OrgSubSE" + timestamp;
        } else if (Staf.getTargetRegion().equals("uk")) {
            orgName = "OrgSubGB" + timestamp;

        } else {
            orgName = "OrgSub" + timestamp;

        }
        generatedOrgNames.add(orgName);
        return orgName;
    }

    public static String generateSubAccName() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());
        String orgName;

        if (Staf.getTargetRegion().equals("no")) {
            orgName = "SubACcNo" + timestamp;

        } else if (Staf.getTargetRegion().equals("se")) {
            orgName = "SubAccSE" + timestamp;
        } else if (Staf.getTargetRegion().equals("uk")) {
            orgName = "SubAccGB" + timestamp;
        } else {
            orgName = "SubAcc" + timestamp;

        }
        generatedOrgNames.add(orgName);
        return orgName;
    }


    public static b2bEyeCareBase.AddressDetails generateAddress() {
        Random random = new Random();
        String street = "";
        String city = "";
        String zip = "";

        if (Staf.getTargetRegion().equals("no")) {
            int indexNO = random.nextInt(streetsNO.length);
            street = streetsNO[indexNO];
            city = citiesNO[indexNO];
            zip = zipsNO[indexNO];
        } else if (Staf.getTargetRegion().equals("se")) {
            int indexSE = random.nextInt(streetsSE.length);
            street = streetsSE[indexSE];
            city = citiesSE[indexSE];
            zip = zipsSE[indexSE];
        } else if (Staf.getTargetRegion().equals("uk")) {
            int indexSE = random.nextInt(streetsGB.length);
            street = streetsGB[indexSE];
            city = citiesGB[indexSE];
            zip = zipsGB[indexSE];
        } else {
            return null;
        }

        return new b2bEyeCareBase.AddressDetails(street, city, zip);
    }

    public static class AddressDetails {

        private final String street;
        private final String city;
        private final String zip;

        public AddressDetails(String street, String city, String zip) {
            this.street = street;
            this.city = city;
            this.zip = zip;
        }

        public String getStreet() {
            return street;
        }

        public String getCity() {
            return city;
        }

        public String getZip() {
            return zip;
        }

    }

    public static long RandomMobileNumberGenerator() {

        Random random = new Random();
        long mobileNumber = 100000000L + random.nextInt(900000000);

        return mobileNumber;
    }

    private String primary;
    private String secondary;

    private String firstname;

    private String lastname;


    private String generateRandomAlphabeticName() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder stringBuilder = new StringBuilder(8);
        for (int i = 0; i < 8; i++) {
            int randomIndex = secureRandom.nextInt(characters.length());
            stringBuilder.append(characters.charAt(randomIndex));
        }
        return stringBuilder.toString();
    }

    public void setRandomNamesForFields() {
        this.primary = generateRandomAlphabeticName();
        this.secondary = generateRandomAlphabeticName();
        this.firstname = generateRandomAlphabeticName();
        this.lastname = generateRandomAlphabeticName();
        ;
    }

    public String getPrimary() {
        return primary;
    }

    public String getSecondary() {
        return secondary;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }








    public void switchingBackToOriginalWindow() {
        switchToOriginalWindow();
        logger.info("Switched to Original Window.");
    }


    public int financeId() {
        Random random = new Random();
        int min = 100000;
        int max = 9999999;
        return random.nextInt((max - min) + 1) + min;
    }

    public void waitForPaginationToLoad() {
        try {
            WebElement pagination = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".pagination.justify-content-md-center")));

            if (pagination.isDisplayed()) {
                wait.until(ExpectedConditions.visibilityOf(pagination));
            }
        } catch (TimeoutException e) {
            logger.info("Pagination element not found, skipping wait.");
        }
    }


    public void waitForLoaderIfPresent() {
        if (isLoaderPresent()) {
            WebDriverWait wait = new WebDriverWait(getDriver(), (Duration.ofMillis(10)));
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".loader")));
            } catch (StaleElementReferenceException e) {

            }
        } else {
            logger.info("Loader is not present. Proceeding to next step.");
        }
    }

    private boolean isLoaderPresent() {
        try {
            getDriver().findElement(By.cssSelector(".loader"));
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    public void waitForElementVisible(String cssSelector, Duration timeout) {
        try {
            WebDriverWait wait = new WebDriverWait(getDriver(), timeout);
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(cssSelector)));
        } catch (NoSuchElementException e) {
            logger.info("Element with CSS selector: " + cssSelector + " not found.");
            throw new NoSuchElementException("Element with CSS selector: " + cssSelector + " not found.");
        }
    }

    public void waitForListElement() {
        try {
            waitForElementVisible(".specs-list.specs-list-label-font-size", Duration.ofSeconds(10));
        } catch (NoSuchElementException e) {
            logger.info("Specs list element not found.");
            throw new NoSuchElementException("Specs list element not found.");
        }
    }

    public String generateSevenDigitNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(7);
        for (int i = 0; i < 7; i++) {
            int index = random.nextInt(ALPHA_NUMERIC_STRING.length());
            sb.append(ALPHA_NUMERIC_STRING.charAt(index));
        }


        return sb.toString();
    }

    public String generateSixDigitNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(6);
        for (int i = 0; i < 6; i++) {
            int index = random.nextInt(ALPHA_NUMERIC_STRING.length());
            sb.append(ALPHA_NUMERIC_STRING.charAt(index));
        }
        return sb.toString();
    }

    public void waitForListRegion() {
        try {
            new WebDriverWait(getDriver(), Duration.ofSeconds(40)).until(
                    webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
            logger.info("Page loaded completely.");
            WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(40));
            List<WebElement> svgElements = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("svg-inline--fa")));
            logger.info("SVG elements found: " + svgElements.size());
            for (WebElement element : svgElements) {
                logger.info("outerHTML");
            }
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for SVG elements to be visible.", e);
            throw new NoSuchElementException("SVG elements not found.");
        } catch (NoSuchElementException e) {
            logger.error("SVG elements not found.", e);
            throw new NoSuchElementException("SVG elements not found.");
        }
    }
}






