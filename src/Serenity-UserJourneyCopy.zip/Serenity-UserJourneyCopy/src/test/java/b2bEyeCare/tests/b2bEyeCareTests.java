package b2bEyeCare.tests;

import Framework.Annotations.B2BEyeCare.*;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Staf;

import b2bEyeCare.stepDefinitions.b2bEyeCareStepDefinitions;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;


import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("b2bEyeCare")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class b2bEyeCareTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    b2bEyeCareStepDefinitions b2b;



    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(1)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295581", projectId = "111992", testCaseName = "Admin Creates Organization with Store Invoice Payments", testType = SSTestType.E2E, testCaseVersion = "1.0")

    public void As_a_admin_create_org_with_store_invoice_payments() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userClickStoreInvoice();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(2)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295582", projectId = "111992", testCaseName = "Admin Creates Organization with Central Invoice Payments", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_admin_create_org_with_Central_Invoice_payments() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCentralInvoice();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();

    }


    @EyeCareHealthCheck
    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(3)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295583", projectId = "111992", testCaseName = "Admin Creates Organization with Customer Payments", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_admin_create_org_with_customer_payments() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCustomerPayments();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();
    }


    @EyeCare
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44413499", projectId = "111992", testCaseName = "Entitlement Value Calculation", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Entitlement_Value_Calculation() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.clickOnAddItem();
        b2b.addItemsTotheProduct();
        b2b.userClickOnClaim();
        b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userClickonEdit();
        b2b.clickOnAddItem();
        b2b.addItemsTotheProduct();
        b2b.clickOnSave();
        b2b.userValidateclaimedStatus();

    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(5)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295614", projectId = "111992", testCaseName = "Create New Account in the Organisation", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Create_New_Account_in_the_Organisation() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        //b2b.userSearchACPOrganisationIdintheOrganisationPage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCustomerPayments();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();
        //NewAccount
        b2b.userClickCreateAccount();
        b2b.userClickCreateSubAccountName();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCustomerPayments();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(6)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44325850", projectId = "111992", testCaseName = "Edit Account in the Organisation", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Edit_Account_in_the_Organisation() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchOrganisationIdintheOrganisationPage();
        b2b.userClickEditAccount();
        b2b.userEditAgreementType();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(7)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295615", projectId = "111992", testCaseName = "Create Sub Organisation with customer payment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Create_Sub_Organisation_With_customer_Payment() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        //b2b.userSearchSCPOrganisationIdintheOrganisationPage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCustomerPayments();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();
        //SubOrganisation
        b2b.userClickCreateSubOrg();
        b2b.userEntersSubOrganisationNumber();
        b2b.userPerformSubOrgNumberSearch();

        b2b.userValidatingTheSubOrgNumber();

        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheSubOrgMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheSubOrgNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterSubOrgEmailIdAndSearch();
        b2b.userEnterSubOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCustomerPayments();
        b2b.userEnterSubOrgMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();



    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(8)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44325851", projectId = "111992", testCaseName = "Edit Sub Organisation with customer payment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Edit_Sub_Organisation_With_customer_Payment() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchOrganisationIdintheOrganisationPage();
        b2b.userClickOneditOrganisationInTheOrganisationPage();
        b2b.validateAccountCreated();


    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(9)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295616", projectId = "111992", testCaseName = "Create Sub Organisation with central invoice payment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Create_Sub_Organisation_With_central_Invoice_Payment() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        //b2b.userSearchSCIOrganisationIdintheOrganisationPage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCentralInvoice();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();
        //SubOrganisation
        b2b.userClickCreateSubOrg();
        b2b.userEntersSubOrganisationNumber();
        b2b.userPerformSubOrgNumberSearch();
        b2b.userValidatingTheSubOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheSubOrgMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheSubOrgNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterSubOrgEmailIdAndSearch();
        b2b.userEnterSubOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCentralInvoice();
        b2b.userEnterSubOrgMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(10)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295617", projectId = "111992", testCaseName = "Create Sub Organisation with store invoice payment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Create_Sub_Organisation_With_store_Invoice_Payment() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        //b2b.userSearchSSIrganisationIdintheOrganisationPage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userClickStoreInvoice();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();
        //SubOrganisation
        b2b.userClickCreateSubOrg();
        b2b.userEntersSubOrganisationNumber();
        b2b.userPerformSubOrgNumberSearch();
        b2b.userValidatingTheSubOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheSubOrgMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheSubOrgNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterSubOrgEmailIdAndSearch();
        b2b.userEnterSubOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userClickStoreInvoice();
        b2b.userEnterSubOrgMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();





    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(11)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44318568", projectId = "111992", testCaseName = "Manager Creates Local Organization with Store Invoice Payments", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_manager_create_local_org_with_store_invoice_payments() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userClickStoreInvoice();
        b2b.userEnterAccountMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userEnterInvoiceComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(12)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44318569", projectId = "111992", testCaseName = "Manager Creates Local Organization with Customer Payments", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_manager_create_local_org_with_customer_payments() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        b2b.userClicksOnAddOrganisation();
        b2b.userEntersOrganisationNumber();
        b2b.userPerformOrganisationNumberSearch();
        b2b.userValidatingTheOrgNumber();
        b2b.validateTheApproveInfoButtonIsDisabled();
        b2b.validaTheNextButtonIsDisabled();
        b2b.enterTheMandatoryInformation();
        b2b.validateTheApproveInfoButtonIsEnabled();
        b2b.userEnterTheNotes();
        b2b.userClickApproveInformation();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userEnterEmailIdAndSearch();
        b2b.userEnterOrganisationAdminDetailsandClickNext();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsOrganisationSizeas0to200();
        b2b.validaTheNextButtonIsEnabled();
        b2b.userSelectsAgreementType();
        b2b.userAddAgreement();
        b2b.userSelectsCustomerPayments();
        b2b.userMandatoryAccountDetails();
        b2b.userEnterNonMandatoryAccountDetails();
        b2b.userEnterComments();
        b2b.userSelectrequisitionPeriod();
        b2b.userSelectCreateOrganisation();
        b2b.validateAccountCreated();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Order(13)
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295594", projectId = "111992", testCaseName = "Edit the Organization and Set Limit", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Edit_the_Organisation_and_Set_Limit() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchOrganisationIdintheOrganisationPage();
        b2b.userEdittheOrganisaation();
        b2b.validateAccountCreated();

    }

    @EyeCareHealthCheck
    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295584", projectId = "111992", testCaseName = "As a Store Manager, Perform a Journey from Active to Paid to Refund", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_store_manager_perform_Journey_From_Active_to_Paid_to_Refund() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userClickOnClaim();
        b2b.userConfirmYes();
        b2b.userValidatePaidStatus();
        b2b.userClickOnRequisationInTheHeader();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnRefund();
        b2b.userValidateRefundStatus();

    }

    @EyeCareHealthCheck
    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295585", projectId = "111992", testCaseName = "As a Store User, Perform a Journey from Active to Paid to Refund", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_store_user_perform_Journey_From_Active_to_Paid_to_Refund() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userClickOnClaim();
        b2b.userConfirmYes();
        b2b.userValidatePaidStatus();
        b2b.userClickOnRefund();
        b2b.userValidateRefundStatus();

    }


    @EyeCare
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295588", projectId = "111992", testCaseName = "Store Manager Creates Active Requisition, Changes to Approved, Admin Changes to Returned, Store Manager Changes to Approved, and Finally Cancels the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_store_manager_create_Active_requisition_and_change_to_Approved_and_Admin_change_to_Returned_and_SM_to_Approved_to_Cancel() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userClickOnClaim();
        b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Admin Changes Approved to Return
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnReturn();
        b2b.userValidateRerunStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Store manager Changes Return to Approved
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userEdithReturned();
        b2b.userValidateApprovedStatus();
        //cancel
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();


    }

    @EyeCare
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295589", projectId = "111992", testCaseName = "Store User Creates Active Requisition, Changes to Approved, Admin Changes to Returned, Store UserChanges to Approved, and Finally Cancels the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_store_user_create_Active_requisition_and_change_to_Approved_and_Admin_change_to_Returned_and_SU_to_Approved_to_Cancel() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userValidateActiveStatus();
        b2b.userRetrivetheRequisation();
        b2b.userClickOnClaim();
        b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Admin Changes Approved to Return
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnReturn();
        b2b.userValidateRerunStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Store user Changes Return to Approved
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userEdithReturned();
        b2b.userValidateApprovedStatus();
        //cancel
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295590", projectId = "111992", testCaseName = "Admin Creates a New Self Requisition With Expired Link", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_admin_create_new_Self_Requisition_with_Expired_Link() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickCreateSelfRequisition();

    }
    @Order(4)
    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se @EyeCareDaily_Uk
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295590", projectId = "111992", testCaseName = "Admin Creates a New Self Requisition in an Organization", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_admin_create_new_Self_Requisition_in_org_with_Active() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchOrganisationIdintheOrganisationPage();
        b2b.userClickCreateSelfRequisition();
        b2b.userCopytheLinkAndOpen();
        //b2b.userEntersReqEmployeeDetailsandApproves();
        b2b.userEntersEmployeeDetailsaInSelfRequisition();
        b2b.userSubmitTheSelfRequisition();
        b2b.getTheRequisitionNumber();
        b2b.switchBackOrgWindow();
        b2b.userRetrivetheActiveRequisationforSelfRequisition();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se @EyeCareDaily_Uk
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295590", projectId = "111992", testCaseName = "Admin Creates a New Self Requisition in an Organization", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_admin_create_new_Self_Requisition_in_org_with_Approval_Required() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILROrganisationIdintheOrganisationPage();
        b2b.userClickCreateSelfRequisition();
        b2b.userCopytheLinkAndOpen();
        //b2b.userEntersReqEmployeeDetailsandApproves();
        b2b.userEntersEmployeeDetailsaInSelfRequisition();
        b2b.userSubmitTheSelfRequisition();
        b2b.getTheRequisitionNumber();
        b2b.switchBackOrgWindow();
        b2b.userRetrivetheRequestedRequisationFotSelfRequsition();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295591", projectId = "111992", testCaseName = "Admin Creates a New Requisition and Then Admin Cancels the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_admin_create_new_Requisition_in_org_with_customer_payments_and_Admin_cancel() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295592", projectId = "111992", testCaseName = "Store Manager Creates a New Requisition Cancels the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_Store_manager_create_new_Requisition_in_org_with_customer_payments_and_cancel() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295593", projectId = "111992", testCaseName = "Store User Creates a New Requisition  Cancels the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void As_a_Store_User_create_new_Requisition_in_org_with_customer_payments_and_cancel() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44325848", projectId = "111992", testCaseName = "Below Limit - Create Organization with Requested to cancel as a Store Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Below_Limit_Create_Organisation_with_Requested_to_cancel_as_store_manager() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILROrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheNeedsActionRequisation();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Store Manager cancel
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchRqReqIdintheReqPage();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();


    }

    @EyeCareHealthCheck
    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44325849", projectId = "111992", testCaseName = "Below Limit - Create Organization with Requested to cancel as a Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Below_Limit_Create_Organisation_with_Requested_to_cancel_as_store_user() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILROrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheNeedsActionRequisation();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Store User Cancel
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchRqReqIdintheReqPage();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295597", projectId = "111992", testCaseName = "Below Limit Create Requisition and Perform journey From Requested to Active to Store Manager cancel", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Below_Limit_Create_Requisition_and_Perform_journey_From_Requested_to_Active_to_Store_Manager_cancel() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILROrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheNeedsActionRequisation();
        //As Admin changes the Status From Requested to Active
        b2b.clickOntheReRequisition();
        b2b.userClickOnApprove();
        b2b.userValidateActiveStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Store Manager cancel
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchRqReqIdintheReqPage();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }


    @EyeCare  @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44328041", projectId = "111992", testCaseName = "Edit The Agreement", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Edit_The_Agreement() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnPriceList();
        b2b.userSelectTheTemplate();
        b2b.userEditTheTemplate();
        b2b.userDeletesTheTemplate();
        b2b.userUpdateTheTemplate();
        b2b.userValidaqtetheMessage();
        b2b.userAddTheSightItem();
        b2b.userAddTheDigitalItem();
        b2b.userAddTheSafetySItem();
        b2b.userAddTheSafteyFItem();
        b2b.userAddTheBespokeItem();
        b2b.userAddTheItemsAndSave();


    }

    @EyeCare  @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44413500", projectId = "111992", testCaseName = "Add and Delete the Categories", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Edit_The_Categories() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnPriceList();
        b2b.userClickOnCategories();
        b2b.userAddFrameCategories();
        b2b.userAddLenseCategories();
        b2b.userAddCoatingCategories();
        b2b.userAddIndexCategories();
        b2b.userDeleteCategories();

    }

    @EyeCareHealthCheck
    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se @EyeCareReRun
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295598", projectId = "111992", testCaseName = "Above Limit Create Requisition and Perform journey From SM Requested to Active To claimed to Return to claimed to Approved", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Above_Limit_Create_Requisition_and_Perform_journey_From_SM_Requested_to_Active_To_claimed_to_Return_to_claimed_to_Approved() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchSILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        //As Admin Changes Claimed to Return
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnReturn();
        b2b.userValidateRerunStatus();


    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se @EyeCareReRun
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295599", projectId = "111992", testCaseName = "Above Limit Create Requisition and Perform journey From Active To claimed to Return  Srore User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Above_Limit_Create_Requisition_and_Perform_journey_From_SU_to_Active_To_claimed_to_Return() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchSILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userValidateActiveStatus();
        b2b.userRetrivetheRequisation();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnReturn();
        b2b.userValidateRerunStatus();


    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295602", projectId = "111992", testCaseName = "Above Limit Create Requisition and Perform journey From Active To claimed to Return to claimed to cancelled as Store Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Above_Limit_Create_Requisition_and_Perform_journey_From_SM__Active_To_claimed_to_Cancelled() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchSILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateclaimedStatus();
        b2b.userClickOnRequisationInTheHeader();
        b2b.userSearchReqIdintheReqPage();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "44295603", projectId = "111992", testCaseName = "Above Limit Create Requisition and Perform journey From Requested to Active To claimed to Return to claimed to cancelled as Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Above_Limit_Create_Requisition_and_Perform_journey_From_SU_Active_To_claimed_to_Cancelled() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchSILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userValidateActiveStatus();
        b2b.userRetrivetheRequisation();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateclaimedStatus();
        b2b.userClickOnRequisationInTheHeader();
        b2b.userSearchReqIdintheReqPage();
        b2b.userCanceltheReq();
        b2b.userValidateCancelledStatus();

    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730949", projectId = "111992", testCaseName = "CustomerPayment With Out TillId Active To Approved check Requisition Reached Report", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Customer_Payment_With_Out_TillID_Active_Approved() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userClickOnClaim();
        b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userValidateRedeemedReq();


    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730950", projectId = "111992", testCaseName = "StoreInvoice With Out TillId Active To Approved check Requisition Reached Report", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_Invoice_With_Out_Till_ID_Active_Approved() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchSIOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userValidateRedeemedReq();


    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730951", projectId = "111992", testCaseName = "No CentralInvoice With Out TillId Active To Approved Invoice the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Central_Invoice_With_Out_Till_ID_Active_Approved_Invoice_the_Requisition() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCIOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userInvoicetheReq();
        b2b.userValidateTheInvoicedWithOutTillId();


    }

    @EyeCare
    @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730952", projectId = "111992", testCaseName = "SE CentralInvoice Check Requisition With Out TillID Active To Approved check Requisition Reached Report", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Se_Central_Invoice_Check_Requisition_With_Out_Till_ID_Reaching_To_Reports() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCIOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userSetCalenderinReport();
        b2b.userValidateRedeemedReq();

    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730953", projectId = "111992", testCaseName = "CustomerPayment With TillId Active Claimed To Approved check Requisition Reached Report", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Customer_Payment_With_Till_ID_Active_Claimed_Approved() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCPLOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userValidateRedeemedReq();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730954", projectId = "111992", testCaseName = "StoreInvoice With TillId Active Claimed To Approved check Requisition Reached Report", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_Invoice_With_Till_ID_Active_Claimed_Approved() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchSILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userValidateRedeemedReq();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730955", projectId = "111992", testCaseName = "CentralInvoice With TillId Active Claimed To Approved Invoice the Requisition", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Central_Invoice_With_Till_ID_Active_Claimed_To_Approved_Invoice_the_Requisition() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userInvoicetheReq();
        b2b.userValidateTheInvoiced();

    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730956", projectId = "111992", testCaseName = "Verify Central Invoice Payment With Locked and Approved", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Verify_Central_Invoice_Payment_With_Locked_And_Approved() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();

        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();

        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userLockTheInvoice();
        b2b.userValidateTheLocked();
        b2b.userSetCalenderinReport();
        b2b.userInvoicetheLockedReq();
        b2b.userValidateTheInvoiced();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730960", projectId = "111992", testCaseName = "Verify Central invoice Payment With Locked and Editable as manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Verify_Central_Invoice_Payment_With_Locked_And_Editable_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userRetrivetheActiveRequisation();
        b2b.clickOntheRequisition();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();

        b2b.userLockTheInvoice();
        b2b.userValidateTheLocked();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userValidateLockedStatus();
        b2b.CheckCancelEditNotPresent();


    }


    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730964", projectId = "111992", testCaseName = "Verify Central invoice Payment With Locked and Editable as Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Verify_Central_Invoice_Payment_With_Locked_And_Editable_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userValidateActiveStatus();
        b2b.userRetrivetheRequisation();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userLockTheInvoice();
        b2b.userValidateTheLocked();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userValidateLockedStatus();
        b2b.CheckCancelEditNotPresent();


    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730965", projectId = "111992", testCaseName = "Verify Central invoice Payment With Manager Locked and Editable as Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Verify_Central_Invoice_Payment_With_Manager_Locked_And_Editable_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userValidateActiveStatus();
        b2b.userRetrivetheRequisation();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();

        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();

        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userLockTheInvoice();
        b2b.userValidateTheLocked();
        b2b.userSignOutOfTheApplicationAndCloseDriver();


        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userValidateLockedStatus();
        b2b.CheckCancelEditNotPresent();

    }

    @EyeCare @EyeCareDaily_No @EyeCareDaily_Se
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730966", projectId = "111992", testCaseName = "Verify Central invoice Payment With User Locked and Editable as Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Verify_Central_Invoice_Payment_With_User_Locked_And_Editable_As_Store_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchCILOrganisationIdintheOrganisationPage();
        b2b.userClickAssignRequisition();
        b2b.userClickCreateEmpRequisition();
        b2b.userEntersEmployeeDetailsinRequisition();
        b2b.userSubmitTheRequisition();
        b2b.userValidateActiveStatus();
        b2b.userRetrivetheRequisation();
        b2b.userAddSpecialProduct();
        b2b.userClickOnClaim();
        //b2b.userConfirmNo();
        b2b.userEnterTheReceiptNumber();
        b2b.userValidateclaimedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userClickOnApprove();
        b2b.userValidateApprovedStatus();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.userSetCalenderinReport();
        b2b.userLockTheInvoice();
        b2b.userValidateTheLocked();
        b2b.userSignOutOfTheApplicationAndCloseDriver();
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchReqIdintheReqPage();
        b2b.userValidateLockedStatus();
        b2b.CheckCancelEditNotPresent();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050973", projectId = "111992", testCaseName = "Advance Search using Requisition No in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_RequisitionNo_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.setRequisitionnoInAdvSearch();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheSearchRequisition();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050974", projectId = "111992", testCaseName = "Advance Search using Reference No 1 in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_ReferenceNo1_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.setReference1();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheReference1();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050975", projectId = "111992", testCaseName = "Advance Search using Reference No 2 in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_ReferenceNo2_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setReference2();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheReference2();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050976", projectId = "111992", testCaseName = "Advance Search using Voucher Value in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Voucher_Value_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setVoucherValue();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheVoucher();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050977", projectId = "111992", testCaseName = "Advance Search using Org Name in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Org_Name_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setOrganisationName();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheOrgName();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050978", projectId = "111992", testCaseName = "Advance Search using Store Name in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Store_Name_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setStore();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheStoreName();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050979", projectId = "111992", testCaseName = "Advance Search using Employee Name in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Employee_Name_In_Reports() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setEmployeeName();
        b2b.clikcAdvanceSearch();
        b2b.userValidateTheEmployeeName();
    }

    @EyeCare @EyeCareDaily_No @EyeCareNew_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050980", projectId = "111992", testCaseName = "Advance Search using Price List in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Price_List_In_Reports() throws Exception {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setPriceList();
        b2b.clikcAdvanceSearch();
        b2b.validteTheRequisitionResult();


    }


    @EyeCare @EyeCareDaily_No @EyeCareNew_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050981", projectId = "111992", testCaseName = "Advance Search using Category in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Category_In_Reports() throws Exception {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setCategory();
        b2b.clikcAdvanceSearch();
        b2b.validteTheRequisitionResult();
    }


    @EyeCare @EyeCareDaily_No @EyeCareNew_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050982", projectId = "111992", testCaseName = "Advance Search using Comments in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Comments_In_Reports() throws Exception {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setComments();
        b2b.clikcAdvanceSearch();
        b2b.validteTheRequisitionResult();
    }


    @EyeCare @EyeCareDaily_No @EyeCareNew_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46050983", projectId = "111992", testCaseName = "Advance Search using Created Date in Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Advance_Search_Using_Created_Date_In_Reports() throws Exception {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.clickOnAdvancedSearchTab();
        b2b.checkCentralisenabled();
        b2b.inAdvanceSearchClickMore();
        b2b.setCreatedDate();
        b2b.clikcAdvanceSearch();
        b2b.validteTheRequisitionResult();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138086", projectId = "111992", testCaseName = "Manager Approved Requistions In National Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Approved_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138087", projectId = "111992", testCaseName = "Manager Claimed Requistions In National Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Claimed_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerClaimedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();
    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138088", projectId = "111992", testCaseName = "Store User Approved Requistions In National Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Approved_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138089", projectId = "111992", testCaseName = "Store User Claimed Requistions In National Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Claimed_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserClaimedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138090", projectId = "111992", testCaseName = "Manager Approved Requistions In National Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Approved_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138091", projectId = "111992", testCaseName = "Manager Claimed Requistions In National Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Claimed_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerClaimedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138092", projectId = "111992", testCaseName = "Store User Approved Requistions In National Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Approved_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138093", projectId = "111992", testCaseName = "Store User Claimed Requistions In National Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Claimed_Requistions_In_National_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserClaimedReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138094", projectId = "111992", testCaseName = "Manager Approved Requistions In Local Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Approved_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerApprovedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138095", projectId = "111992", testCaseName = "Manager Claimed Requistions In Local Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Claimed_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerClaimedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138096", projectId = "111992", testCaseName = "Store User Approved Requistions In Local Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Approved_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserApprovedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138097", projectId = "111992", testCaseName = "Store User Claimed Requistions In Local Agreement Validate Restrict Store As Manager", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Claimed_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeManagerSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserClaimedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138098", projectId = "111992", testCaseName = "Manager Approved Requistions In Local Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Approved_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerApprovedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138099", projectId = "111992", testCaseName = "Manager Claimed Requistions In Local Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Manager_Claimed_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchManagerClaimedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138100", projectId = "111992", testCaseName = "Store User Approved In Local Agreement Validate  Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Approved_In_Local_Agreement_Validate__Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserApprovedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138101", projectId = "111992", testCaseName = "Store User Claimed Requistions In Local Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Claimed_Requistions_In_Local_Agreement_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchUserClaimedLocalReqForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138101", projectId = "111992", testCaseName = "Store User Claimed Requistions In Local Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Paid_Requistions_Validate_Restrict_Store_As_Store_User() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchPaidForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "46138101", projectId = "111992", testCaseName = "Store User Claimed Requistions In Local Agreement Validate Restrict Store As Store User", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Store_User_Paid_Requistions_Validate_Restrict_Store_As_Store_Manager() {
        b2b.launchEyeCareUrl();
        b2b.storeUserSignIn();
        b2b.userSelectsTheRegion();
        b2b.userSearchPaidForRestricStore();
        b2b.ValidateTheToastMessage();
        b2b.ValidateTheNoteMessage();
        b2b.userClickOnRequisitionInTheHomePage();
        b2b.userSearchManagerApprovedReqForRestricStore();
        b2b.ValidateTheToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730949", projectId = "111992", testCaseName = "Customer Exports Requisition in the Reports", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Customer_Export_Requisition() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClickOnReportInTheHomePage();
        b2b.setTheCalenderAsPerDefinedDate();
        b2b.setRequisitionnoinSearchbox();
        b2b.userExporttheReq();
        b2b.ValidateTheExportToastMessage();

    }

    @EyeCare @EyeCareDaily_No
    @Tags(value = {@Tag("no"), @Tag("se"), @Tag("uk")})
    @Test @SSTest(testCaseId = "45730949", projectId = "111992", testCaseName = "Customer Exports Organisation ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Customer_Export_Organisation() {
        b2b.launchEyeCareUrl();
        b2b.specAdminSignIn();
        b2b.userSelectsTheRegion();
        b2b.userClicksOnOrganisationInHomePage();
        b2b.userExporttheOrg();
        b2b.ValidateTheOrgExportToastMessage();

    }


    @AfterEach
    public void tearDown() {
        b2b.closeSession();
    }
}

