package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.pages.b2bEyeCareCategoriesPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Categories extends ScenarioSteps {

    b2bEyeCareCategoriesPage categoriesPage;

    private final Logger logger = LoggerFactory.getLogger(Categories.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    public void userAddFramesCategorie() {
        categoriesPage.AddFramesCategorie();
        logger.info("User added a Frame category");
        categoriesPage.addACategoriesValue();
        logger.info("User added a value to the Frame category");
    }

    public void userAddLenseCategorie() {
        categoriesPage.AddLenseCategorie();
        logger.info("User added a Lens category");
        categoriesPage.addACategoriesValue();
        logger.info("User added a value to the Lens category");
    }

    public void userAddCoatingCategorie() {
        categoriesPage.AddCoatingCategorie();
        logger.info("User added a Coating category");
        categoriesPage.addACategoriesValue();
        logger.info("User added a value to the Coating category");
    }

    public void userAddIndexCategorie() {
        categoriesPage.AddIndexCategorie();
        logger.info("User added an Index category");
        categoriesPage.addACategoriesValue();
        logger.info("User added a value to the Index category");
    }

    public void deleteCategorie() {
        categoriesPage.DeleteCategoriesFromList();
        logger.info("User deleted the selected categories");
    }
}
