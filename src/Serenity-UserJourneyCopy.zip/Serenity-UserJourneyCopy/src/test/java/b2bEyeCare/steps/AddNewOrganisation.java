package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import b2bEyeCare.pages.b2bEyeCareOrganisationsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddNewOrganisation extends ScenarioSteps {

    b2bEyeCareOrganisationsPage organisationsPage;
    b2bEyeCareBase base;
    private final Logger logger = LoggerFactory.getLogger(AddNewOrganisation.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    long generatedNumber = b2bEyeCareBase.generateOrganisationId();
    String orgnumber = String.valueOf(generatedNumber);
    String generatedNumberStr = String.valueOf(generatedNumber);
    long mobileNumber = b2bEyeCareBase.RandomMobileNumberGenerator();
    String generatedName = b2bEyeCareBase.generateOrgName();
    String mobileNo = String.valueOf(mobileNumber);
    String generatedSubOrgName = b2bEyeCareBase.generateSubOrgName();
    b2bEyeCareBase.AddressDetails addressDetails = b2bEyeCareBase.generateAddress();
    String organisationAddress = addressDetails.getStreet();
    String organisationCity = addressDetails.getCity();
    String organisationZip = addressDetails.getZip();
    int index;

    public void clickToAddOrganisation() {
        organisationsPage.clickOnAddOrganisation();
        logger.info("User clicked on 'Add Organisation'");
    }

    public void editOrganisation() {
        organisationsPage.clickeditOrganisation();
        logger.info("User clicked on 'Edit Organisation'");
    }

    public void getOrgName() {
        organisationsPage.EditOrganisationInfo(generatedSubOrgName);
        organisationsPage.Saveall();
        logger.info("User clicked on 'Save All'");
    }

    public void userEnterOrgNumber() {
        organisationsPage.enterOrganisationId(orgnumber);
        logger.info("Entered Organisation ID: " + orgnumber);
    }

    public void userEnterSubOrgNumber() {
        organisationsPage.enterSubOrganisationId(orgnumber);
        logger.info("Entered Sub Organisation ID: " + orgnumber);
    }

    public void performOrgNumberSearch() {
        organisationsPage.performOrganisationNumberSearch();
        logger.info("User clicked on 'Search' for Organisation Number");
    }

    public void performSubOrgNumberSearch() {
        organisationsPage.performSubOrganisationNumberSearch();
        logger.info("User clicked on 'Search' for Sub Organisation Number");
    }

    public void validatingTheOrganisationNumber() {
        organisationsPage.validateOrganisationNumber(String.valueOf(generatedNumber));
        logger.info("Validated Organisation Number: " + generatedNumber);
    }

    public void validatingTheSubOrganisationNumber() {
        organisationsPage.validateSubOrganisationNumber(String.valueOf(generatedNumber));
        logger.info("Validated Sub Organisation Number: " + generatedNumber);
    }

    public void validateApproveInfoButtonIsDisabled() {
        organisationsPage.verifyApprovalInfoButtonIsDisabled();
        logger.info("Validated 'Approve Information' button is disabled");
    }

    public void validateApproveInfoButtonIsEnabled() {
        organisationsPage.verifyApprovalInfoButtonIsEnabled();
        logger.info("Validated 'Approve Information' button is enabled");
    }

    public void validateNextButtonIsDisabled() {
        organisationsPage.verifyNextButtonsIsDisabled();
        logger.info("Validated 'Next' button is disabled");
    }

    public void validateNextButtonIsEnabled() {
        organisationsPage.verifyNextButtonsIsEnabled();
        organisationsPage.clickNext();
        logger.info("Validated 'Next' button is enabled and clicked on 'Next'");
    }

    public void enterTheMandatorydcetails() {
        organisationsPage.enterCompanyName(generatedName);
        organisationsPage.enterAddress(organisationAddress);
        organisationsPage.enterCity(organisationCity);
        organisationsPage.enterZip(organisationZip);
        logger.info("Entered mandatory Organisation details");
    }

    public void enterTheSubOrgMandatorydcetails() {
        organisationsPage.enterSubOrgName(generatedSubOrgName);
        organisationsPage.enterAddress(organisationAddress);
        organisationsPage.enterCity(organisationCity);
        organisationsPage.enterZip(organisationZip);
        logger.info("Entered mandatory Sub Organisation details");
    }

    public void clickApproveInformation() {
        organisationsPage.clickOnApproveInfo();
        logger.info("User clicked on 'Approve Information'");
        organisationsPage.editInfo();
    }

    public void enterTheNotes() {
        String organisationNotes = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.OrgNotes");
        organisationsPage.enterNotes(organisationNotes);
        logger.info("User entered notes: " + organisationNotes);
    }

    public void enterTheSubOrgNotes() {
        String organisationNotes = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.SubOrgNotes");
        organisationsPage.enterSubOrgNotes(organisationNotes);
        logger.info("User entered Sub Organisation notes: " + organisationNotes);
    }

    public void userEnterSubOrganisationId() {
        b2bEyeCareBase.generateAddress();
        organisationsPage.enterSubOrganisationId(generatedNumberStr);
        logger.info("Entered Sub Organisation ID: " + generatedNumber);
        String OrganisationAddress = addressDetails.getStreet();
        String OrganisationCity = addressDetails.getCity();
        String OrganisationZip = addressDetails.getZip();
        organisationsPage.clickSubSearchOrganisation(generatedNumberStr, generatedSubOrgName, OrganisationAddress, OrganisationCity, OrganisationZip);
        logger.info("User searched for Sub Organisation with generated details");
    }

    public void enterEmailIdAndClickSearch() {
        organisationsPage.enterOrganisationEmail();
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.clickEmailSearch();
        logger.info("User clicked on 'Email Search'");
    }

    public void enterSubEmailId() {
        organisationsPage.enterSubOrgEmail();
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.clickEmailSubSearch();
        logger.info("User clicked on 'Sub Email Search'");
    }

    public void enterMandatoryOrganisationAdminDetails() {
        base.setRandomNamesForFields();
        String aFirstName = base.getFirstname();
        String aLastName = base.getLastname();
        organisationsPage.enterAdminFirstName(aFirstName);
        logger.info("Admin First Name: " + aFirstName);
        organisationsPage.enterAdminLastName(aLastName);
        logger.info("Admin Last Name: " + aLastName);
        String title = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.Title");
        organisationsPage.enterAdminTitle(title);
        organisationsPage.enterMobileNo(mobileNo);
        logger.info("User entered Organisation Admin details");
    }

    public void enterMandatorySubOrganisationAdminDetails() {
        base.setRandomNamesForFields();
        String aFirstName = base.getFirstname();
        String aLastName = base.getLastname();
        organisationsPage.enterAdminSubFirstName(aFirstName);
        logger.info("Sub Admin First Name: " + aFirstName);
        organisationsPage.enterAdminSubLastName(aLastName);
        logger.info("Sub Admin Last Name: " + aLastName);
        String title = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.Title");
        organisationsPage.enterAdminSubTitle(title);
        organisationsPage.enterMobileNo(mobileNo);
        logger.info("User entered Sub Organisation Admin details");
    }

    public void enterMandatoryOrganisationSubAdminDetails() {
        logger.info("User entering Organisation Admin details");
        organisationsPage.enterAdminSubFirstName(generatedNumberStr);
        logger.info("User entered Organisation Admin First Name");
        organisationsPage.enterAdminSubLastName(generatedNumberStr);
        logger.info("User entered Organisation Admin Last Name");
        organisationsPage.enterMobileNo(mobileNo);
        logger.info("User entered Organisation Admin Mobile Number");
    }

    public void SelectsTheOrganisationsize0To200() {
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.selectOrgSize0To200();
        logger.info("User selected Organisation size as 0-200");
    }

    public void selectTheAgreement() {
        organisationsPage.selectAgreementType();
        logger.info("User selected the Agreement");
    }

    public void selectAddTheAgreement() {
        organisationsPage.selectUseAgreement();
        logger.info("User added the Agreement");
        organisationsPage.clickNext();
    }

    public void selectEditAgreement() {
        organisationsPage.changeAgreement();
        logger.info("User edited the Agreement");
    }

    public void userSelectsCustomerPayment() {
        organisationsPage.selectCustomerPayment();
        logger.info("User selected 'Customer Payment'");
    }

    public void userSelectCentralInvoice() {
        organisationsPage.selectCentralInvoice();
        logger.info("User selected 'Central Invoice'");
    }

    public void UserClickStoreInvoice() {
        organisationsPage.selectStoreInvoice();
        logger.info("User clicked on 'Store Invoice'");
    }

    public void UserSelectStoreInvoice() {
        organisationsPage.hoverStoreInvoice();
        logger.info("User hovered on 'Store Invoice'");
    }

    public void userEnterAccountDetails() {
        base.setRandomNamesForFields();
        String comments = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.comments");
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.enterComments(comments);
        logger.info("User entered Account details and Comments: " + comments);
    }

    public void userEnterMandatoryAccountDetails() {
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.selectOrgContact();
        organisationsPage.selectOrgSpecsaversContact();
        logger.info("User selected 'Specsavers Contact'");
        organisationsPage.verifyNextButtonsIsEnabled();
    }

    public void userEnterSubMandatoryAccountDetails() {
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.selectOrgContact();
        organisationsPage.selectAccSpecsaversContact();
        logger.info("User selected Sub Organisation 'Specsavers Contact'");
        organisationsPage.verifyNextButtonsIsEnabled();
    }

    public void userEnterAccountMandatoryAccountDetails() {
        organisationsPage.verifyNextButtonsIsDisabled();
        organisationsPage.selectOrgContact();
        organisationsPage.selectOrgmanagerSpecsaversContact();
        logger.info("User selected Account 'Specsavers Contact'");
        organisationsPage.verifyNextButtonsIsEnabled();
    }

    public void userEntersFinanceID() {
        int providefinanceId = base.financeId();
        organisationsPage.provideFinanceId(providefinanceId);
        logger.info("User entered Finance ID: " + providefinanceId);
    }

    public void userEnterReferences() {
        base.setRandomNamesForFields();
        String primary = base.getPrimary();
        String secondary = base.getSecondary();
        organisationsPage.enterPrimaryReference(primary);
        logger.info("User entered Primary Reference: " + primary);
        organisationsPage.enterSecondaryReference(secondary);
        logger.info("User entered Secondary Reference: " + secondary);
    }

    public void userEnterComments() {
        final String comments = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.comments");
        organisationsPage.enterComments(comments);
        logger.info("User entered Comments: " + comments);
    }

    public void selectOrgContact() {
        organisationsPage.selectOrgContact();
        logger.info("User selected 'Organisation Contact'");
    }

    public void userSelectOrgSpecContact() {
        organisationsPage.selectOrgSpecsaversContact();
        logger.info("User selected Organisation 'Specsavers Contact'");
    }

    public void userSelectOrgManagerSpecContact() {
        organisationsPage.selectOrgmanagerSpecsaversContact();
        logger.info("User selected Organisation Manager 'Specsavers Contact'");
    }

    public void userSelectAccountSpecContact() {
        organisationsPage.selectAccSpecsaversContact();
        logger.info("User selected Account 'Specsavers Contact'");
    }

    public void userClickNext() {
        organisationsPage.clickNext();
        logger.info("User clicked on 'Next'");
    }

    public void userSelectsRequisitionPeriodAs30Days() {
        organisationsPage.selectRequisitionPeriod30days();
        logger.info("User selected Requisition Period as 30 days");
    }

    public void editandSetLimit() {
        final String limit = testDataManager.getTestInputCommonData("orgInfo.Limit");
        organisationsPage.clickCollapse();
        logger.info("User clicked on 'Collapse'");
        organisationsPage.clickEditAccount();
        logger.info("User clicked on 'Edit Account'");
        organisationsPage.clickRequisitionApprovalRequired();
        logger.info("User clicked on 'Requisition Approval Required'");
        organisationsPage.clickApprovalRequired();
        logger.info("User clicked on 'Approval Required'");
        organisationsPage.seteditApprovalLimit(limit);
        logger.info("User set the Approval Limit to: " + limit);
        organisationsPage.saveTheEditedtAcount();
        logger.info("User saved the edited Account");
    }

    public void userEnterInvoiceComments() {
        final String invoiceComments = testDataManager.getTestInputRegionData("organisationData.orgAccountInfo.comments");
        organisationsPage.enterInvoiceComments(invoiceComments);
        logger.info("User entered Invoice Comments: " + invoiceComments);
    }

    public void unselectApprovalRequired() {
        organisationsPage.clickApprovalRequired();
        logger.info("User unselected 'Approval Required'");
    }

    public void userSelectCreateOrganisation() {
        organisationsPage.selectCreate();
        logger.info("User clicked on 'Create Organisation'");
    }

    public void createdOrganisation() {
        organisationsPage.createdOrg();
        logger.info("Organisation was created successfully");
    }

    public void userSelectOrganisation() {
        organisationsPage.clickOrgId();
        logger.info("User clicked on Organisation ID");
    }

    public void userSelectTypeofSpec() {
        organisationsPage.manageButtonsState();
        logger.info("User selected 'Type of Specification'");
    }

    public void userSelectDigitalSpare() {
        organisationsPage.selectDigitalSpare();
        logger.info("User selected 'Digital Spare'");
    }
}
