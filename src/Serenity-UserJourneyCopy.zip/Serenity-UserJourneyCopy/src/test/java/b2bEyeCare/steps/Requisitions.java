package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import b2bEyeCare.pages.b2bEyeCareHomePage;
import b2bEyeCare.pages.b2bEyeCareRequisitionsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Requisitions extends ScenarioSteps {

    b2bEyeCareRequisitionsPage requisitionPage;
    b2bEyeCareHomePage homePage;

    private final Logger logger = LoggerFactory.getLogger(Requisitions.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    private b2bEyeCareBase base = new b2bEyeCareBase();

    public void clickCreateEmpReq() {
        requisitionPage.clickCreateEmpreq();
        logger.info("Clicked 'Create Requisition for Employee'.");
    }

    public void clickCreateSelfServeRequisition() {
        requisitionPage.clickViewSelfServeRequisition();
        logger.info("Navigated to 'View Self Serve Requisition'.");
        requisitionPage.clickNewrequistionslink();
        logger.info("Selected 'New Requisition' link.");
    }


    public void validateTheLinkErrorMessage(){
        requisitionPage.validateTheLinkErrorMessage();
        logger.info("Validate the Link Expired Toast Message");

    }
    public void copyTheLinkAndOpen() {
        requisitionPage.copyUrl();
        logger.info("Copied the URL.");
    }

    public void enterEmployeeBasicDetailsForSelfReq() {
        base.setRandomNamesForFields();
        String reqEmployeeFirstName = base.getFirstname();
        String reqEmployeeLastName = base.getLastname();

        requisitionPage.enterSelfReqEmployeeFirstName(reqEmployeeFirstName);
        logger.info("Entered Self Requisition Employee First Name: {}", reqEmployeeFirstName);
        requisitionPage.enterSelfReqEmployeeLastName(reqEmployeeLastName);
        logger.info("Entered Self Requisition Employee Last Name: {}", reqEmployeeLastName);
    }

    public void enterEmployeeEmailsForSelfReq() {
        final String reqEmployeeBusinessEmail = b2bEyeCareBase.generateOrgName();
        requisitionPage.enterSelfReqEmployeeBusinessEmail(reqEmployeeBusinessEmail);
        logger.info("Entered Self Requisition Employee Business Email: {}", reqEmployeeBusinessEmail);
    }

    public void enterEmployeePhoneNoForSelfReq() {
        String mobileNo = generateMobileNumber();
        requisitionPage.enterSelfReqEmployeePhoneNo(mobileNo);
        logger.info("Entered Self Requisition Employee Phone Number: {}", mobileNo);
    }

    public void enterPersonalEmailsForSelfReq() {
        final String reqEmployeePersonalEmail = b2bEyeCareBase.generateOrgName();
        requisitionPage.enterSelfReqEmployeePersonalEmail(reqEmployeePersonalEmail);
        logger.info("Entered Self Requisition Employee Personal Email: {}", reqEmployeePersonalEmail);
    }

    public void enterEmployeeBasicDetails() {
        base.setRandomNamesForFields();
        String reqEmployeeFirstName = base.getFirstname();
        String reqEmployeeLastName = base.getLastname();

        requisitionPage.enterReqEmployeeFirstName(reqEmployeeFirstName);
        logger.info("Entered Requisition Employee First Name: {}", reqEmployeeFirstName);
        requisitionPage.enterReqEmployeeLastName(reqEmployeeLastName);
        logger.info("Entered Requisition Employee Last Name: {}", reqEmployeeLastName);
    }

    public void enterEmployeeEmails() {
        final String reqEmployeeBusinessEmail = b2bEyeCareBase.generateOrgName();
        requisitionPage.enterReqEmployeeBusinessEmail(reqEmployeeBusinessEmail);
        logger.info("Entered Requisition Employee Business Email: {}", reqEmployeeBusinessEmail);
    }

    public void enterEmployeeBirthday() {
        final String enterBirthday = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.enterBirthday");
        requisitionPage.enterBirthday(enterBirthday);
        logger.info("Entered Employee's Date of Birth: {}", enterBirthday);
    }

    private String generateMobileNumber() {
        long mobileNumber = b2bEyeCareBase.RandomMobileNumberGenerator();
        return String.valueOf(mobileNumber);
    }

    public void enterEmployeePhoneNo() {
        String mobileNo = generateMobileNumber();
        requisitionPage.enterReqEmployeePhoneNo(mobileNo);
        logger.info("Entered Requisition Employee Phone Number: {}", mobileNo);
    }

    public void enterPersonalEmails() {
        final String reqEmployeePersonalEmail = b2bEyeCareBase.generateOrgName();
        requisitionPage.enterReqEmployeePersonalEmail(reqEmployeePersonalEmail);
        logger.info("Entered Requisition Employee Personal Email: {}", reqEmployeePersonalEmail);
    }

    public void enterRequisitionReferences() {
        String primaryReference = base.getPrimary();
        String secondaryReference = base.getSecondary();

        requisitionPage.enterPrimaryRef(primaryReference);
        logger.info("Entered Primary Reference: {}", primaryReference);
        requisitionPage.enterSecondaryRef(secondaryReference);
        logger.info("Entered Secondary Reference: {}", secondaryReference);
    }

    public void enterMeasurementDetails() {
        final String maxDistance = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.maxDistance");
        final String screenDistance = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.screenDistance");
        final String readingDistance = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.readingDistance");
        final String keyboardDistance = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.keyboardDistance");

        requisitionPage.enterMaxDistance(maxDistance);
        logger.info("Entered Max Distance: {}", maxDistance);
        requisitionPage.enterReadingDistance(readingDistance);
        logger.info("Entered Reading Distance: {}", readingDistance);
        requisitionPage.enterKeyboardDistance(keyboardDistance);
        logger.info("Entered Keyboard Distance: {}", keyboardDistance);
        requisitionPage.enterScreenDistance(screenDistance);
        logger.info("Entered Screen Distance: {}", screenDistance);
    }

    public void selectDigitalSpecs() {
        requisitionPage.selectDigitalspecs();
        logger.info("Selected Digital Specs.");
    }

    public void submitTheRequisition() {
        requisitionPage.submitTheRequisition();
        logger.info("Submitted the Requisition.");
    }

    public void submitSelfRequisition() {
        requisitionPage.submitSelfRequisition();
        logger.info("Submitted Self Requisition.");
    }

    public void gettheReqNo() {
        requisitionPage.checkBarCode();
        logger.info("Checked the barcode.");
        requisitionPage.gettheReqNumber();
        logger.info("Retrieved Requisition Number.");
    }

    public void clickDasboardActive() {
        requisitionPage.setRequisitionDateRangeToToday();
        logger.info("Set Requisition Date Range to Today.");
        requisitionPage.clickActiveRequisition();
        logger.info("Clicked on 'Active Requisition' on Dashboard.");
    }

    public void clickDasboardNeedsAction() {
        requisitionPage.setRequisitionDateRangeToToday();
        logger.info("Set Requisition Date Range to Today.");
        requisitionPage.clickNeedsAction();
        logger.info("Clicked on 'Needs Action'.");
    }

    public void getRequNumber() {
        requisitionPage.getActiveReqNumber();
        logger.info("Retrieved Active Requisition Number.");
    }

    public void getNAReqNumber() {
        requisitionPage.processRequisitionText();
        logger.info("Processed Requisition Text.");
    }

    public void validateTheReq() {
        requisitionPage.validateActiveReq();
        logger.info("Validated the Active Requisition.");
    }

    public void validateTheNeedReq() {
        requisitionPage.validateRqActiveReq();
        logger.info("Validated the Needs Action Requisition.");
    }

    public void clickClearSearchInvoice() {
        requisitionPage.clearInvoiceSearch();
        logger.info("Cleared Invoice Search.");
    }

    public void AdvanceSearch() {
        requisitionPage.clickAdvanceSearch();
        logger.info("Clicked on 'Advanced Search'.");
    }

    public void checkElementenabled() {
        requisitionPage.verifyCentralElementIsEnabled();
        logger.info("Verified that the central element is enabled.");
    }

    public void validateTheReqResult() {
        requisitionPage.SearchRequDetails();
        logger.info("Validated the Requisition Number.");
    }

    public void validateTheReference1() {
        requisitionPage.SearchRef1Details();
        logger.info("Validated the Reference 1.");
    }

    public void validateTheReference2() {
        requisitionPage.SearchRef2Details();
        logger.info("Validated the Reference 2.");
    }

    public void validateTheVoucherValue() {
        requisitionPage.SearchVoucherValueDetails();
        logger.info("Validated the Voucher Value.");
    }

    public void validateTheOrganisationName() {
        requisitionPage.SearchOrganisationName();
        logger.info("Validated the Organisation Name.");
    }

    public void validateTheStoreName() {
        requisitionPage.SearchStoreName();
        logger.info("Validated the Store Name.");
    }

    public void validateTheEmployeeName() {
        requisitionPage.SearchEmpName();
        logger.info("Validated the Employee Name.");
    }

    public void validateTheReportReq() throws Exception {
        requisitionPage.validateTheRequisition();
        logger.info("Validated the Requisition Report.");
    }

    public void searchRequisition() {
        requisitionPage.advSearchRequisition();
        logger.info("Searched Requisition using Advanced Search.");
    }

    public void setSearchRequisitionInAdvSearch() {
        requisitionPage.setAdvSearchRequisition();
        logger.info("Set Requisition in Advanced Search.");
    }

    public void validateRequisitionNo() {
        requisitionPage.validateRequisitionDetails();
        logger.info("Validated the Requisition Number.");
    }

    public void setSearchReference1() {
        requisitionPage.setAdvSearchRefNo1();
        logger.info("Searched Reference 1 using Advanced Search.");
    }

    public void clickMoreInAdvanceSearch() {
        requisitionPage.clikcMore();
        logger.info("Expanded the Advanced Search section.");
    }

    public void setSearchReference2() {
        requisitionPage.setAdvSearchRefNo2();
        logger.info("Searched Reference 2 using Advanced Search.");
    }

    public void setSearchAmount() {
        requisitionPage.setAdvSearchAmount();
        logger.info("Searched Amount using Advanced Search.");
    }

    public void setSearchOrg() {
        requisitionPage.setAdvSearchOrg();
        logger.info("Searched Organisation using Advanced Search.");
    }

    public void setSearchStore() {
        requisitionPage.setAdvSearchStore();
        logger.info("Searched Store using Advanced Search.");
    }

    public void setSearchEmpName() {
        requisitionPage.setAdvSearchEmpName();
        logger.info("Searched Employee Name using Advanced Search.");
    }

    public void setSearchPriceList() {
        requisitionPage.setAdvSearchPriceList();
        logger.info("Searched Price List using Advanced Search.");
    }

    public void setSearchCategory() {
        requisitionPage.setAdvSearchCategory();
        logger.info("Searched Category using Advanced Search.");
    }

    public void setSearchComments() {
        requisitionPage.setAdvSearchComments();
        logger.info("Searched Comments using Advanced Search.");
    }

    public void setSearchCreatedDate() {
        requisitionPage.setAdvSearchCreatedDate();
        logger.info("Searched Created Date using Advanced Search.");
    }

    public void clikcAdvSearch() {
        waitABit(1500);
        requisitionPage.clikcAdvSearch();
        logger.info("Clicked on 'Advanced Search' button.");
    }

    public void setTheCalender() {
        requisitionPage.verifyCalendarDate();
        logger.info("Verified the Calendar Date.");
        requisitionPage.setDateRangeToYesterdayToday();
        logger.info("Set Calendar Date Range from Yesterday to Today.");
        waitABit(8000);
    }

    public void setTheCalenderForRedeemedDate() {
        requisitionPage.setCalendarForRedemedDate();
        logger.info("Set the Calendar for Redeemed Date.");
    }

    public void setTheCalenderForSpecificDate() {
        requisitionPage.setDateRangeToSpecificDates();
        logger.info("Set the Calendar for Specific Date.");
    }

    public void validateTheInvoicedReq() {
        requisitionPage.validateInvoicedReq();
        logger.info("Validated the Invoiced Requisition.");
    }

    public void validateTheInvoicedReqWithOutTillId() {
        requisitionPage.validateInvoicedReqwithoutTillId();
        logger.info("Validated the Invoiced Requisition without Till ID.");
    }

    public void validateTheLockedReq() {
        requisitionPage.validateLockedReq();
        logger.info("Validated the Locked Requisition.");
    }

    public void validateThedisabledMenu() {
        requisitionPage.checkbuttonsdisabled();
        logger.info("Validated that the buttons are disabled.");
    }

    public void validateTheRededemedReq() {
        requisitionPage.checkbuttonsdisabled();
        logger.info("Validated that the buttons are disabled.");
        requisitionPage.validateTheReq();
        logger.info("Validated the Redeemed Requisition.");
    }

    public void validateTheReqStatus() {
        requisitionPage.validateTheReq();
        logger.info("Validated the Requisition Status.");
    }

    public void selectReqAndInvoice() {
        requisitionPage.checkbuttonsdisabled();
        logger.info("Validated that the buttons are disabled.");
        requisitionPage.selecttheReqForInvoice();
        logger.info("Selected the Requisition for Invoicing.");
        requisitionPage.checkbuttonsenabled();
        logger.info("Validated that the buttons are enabled.");
        requisitionPage.clicktheInvoice();
        logger.info("Clicked on 'Invoice'.");
    }

    public void selectReqAndInvoiceTheLocked() {
        requisitionPage.checkbuttonsdisabled();
        logger.info("Validated that the buttons are disabled.");
        requisitionPage.selecttheReqForInvoice();
        logger.info("Selected the Locked Requisition for Invoicing.");
        requisitionPage.checkbuttonsenabled();
        logger.info("Validated that the buttons are enabled.");
        requisitionPage.clicktheInvoiceForLocked();
        logger.info("Clicked on 'Invoice' for Locked Requisition.");
    }

    public void selectReqAndLock() {
        requisitionPage.checkbuttonsdisabled();
        logger.info("Validated that the buttons are disabled.");
        requisitionPage.selecttheReqForInvoice();
        logger.info("Selected the Requisition for Locking.");
        requisitionPage.checkbuttonsenabled();
        logger.info("Validated that the buttons are enabled.");
        requisitionPage.clicktheLockForInvoice();
        logger.info("Locked the Invoice.");
    }

    public void getuserRequNumber() {
        requisitionPage.getActiveuserReqNumber();
        logger.info("Retrieved Active User Requisition Number.");
    }

    public void getReqNumber() {
        requisitionPage.getActiveuserReqNumberNew();
        logger.info("Retrieved the New Active User Requisition Number.");
    }

    public void switchBackToOriginalwindows() {
        requisitionPage.switchingBackToOriginalWindow();
        logger.info("Switched back to the original window.");
        requisitionPage.clickToClosePopUp();
        logger.info("Closed the popup.");
    }

    public void selectOrgAndExport() {
        requisitionPage.clicktheOrgExport();
        logger.info("Clicked on 'Export' for Organisation.");
    }

    public void userSearchRequisation() {
        requisitionPage.enterReqIdInSearchBox();
        logger.info("Entered Requisition ID in search box.");
        requisitionPage.clickOnSearchReq();
        logger.info("Clicked on 'Search' for Requisition.");
    }

    public void userSearchRequisationAfterSetDate() {
        requisitionPage.enterReqIdInSearchBox();
        logger.info("Entered Requisition ID in search box.");
        requisitionPage.clickOnSearchReq();
        logger.info("Clicked on 'Search' for Requisition.");
    }


    public void userClearRequisition() {
        requisitionPage.clearRequisationSearch();
    }



    public void userSearchRqRequisation() {
        requisitionPage.enterRqReqIdInSearchBox();
        logger.info("Entered RQ Requisition ID in search box.");
        requisitionPage.clickOnSearchReq();
        logger.info("Clicked on 'Search' for RQ Requisition.");
    }

    public void clickOnDynamicReReqLink() {
        requisitionPage.clickOnDynamicReReqLink();
        logger.info("Clicked on Dynamic Re-Requisition link.");
    }

    public void clickOnDynamicReqLink() {
        requisitionPage.clickOnDynamicReqLink();
        logger.info("Clicked on Dynamic Requisition link.");
    }

    public void clickOnAddItems() {
        requisitionPage.selecttheAddItems();
        logger.info("Selected 'Add Items' option.");
    }

    public void addItems() {
        requisitionPage.addItemstoreq();
        logger.info("Added items to requisition.");
    }

    public void userclickonClaim() {
        final String comments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason1");
        requisitionPage.clickOnClaim();
        logger.info("Clicked on 'Claim'.");
        waitABit(3000);
        requisitionPage.enterComments(comments);
        logger.info("Entered claim comments: {}", comments);
        requisitionPage.clickOnConfirm();
        logger.info("Clicked on 'Confirm'.");
    }

    public void userclickYes() {
        requisitionPage.clickOnYes();
        logger.info("Clicked on 'Yes'.");
    }

    public void userclickNo() {
        requisitionPage.clickOnNo();
        logger.info("Clicked on 'No'.");
    }

    public void userValidatethePaidStatus() {
        final String paid = testDataManager.getTestInputCommonData("orgInfo.Status5");
        requisitionPage.validateInvoiceRequestedPaidAppReqStatus(paid);
        logger.info("Validated Paid Status: {}", paid);
    }

    public void userValidatetheInvoicedStatus() {
        final String invoiced = testDataManager.getTestInputCommonData("orgInfo.Status2");
        requisitionPage.validateInvoiceRequestedPaidAppReqStatus(invoiced);
        logger.info("Validated Invoiced Status: {}", invoiced);
    }

    public void userValidatetheClaimedStatus() {
        final String claimed = testDataManager.getTestInputCommonData("orgInfo.Status1");
        requisitionPage.validateClaimedReqStatus(claimed);
        logger.info("Validated Claimed Status: {}", claimed);
    }

    public void userValidatetheApprovedStatus() {
        final String approved = testDataManager.getTestInputCommonData("orgInfo.Status8");
        requisitionPage.validateInvoiceRequestedPaidAppReqStatus(approved);
        logger.info("Validated Approved Status: {}", approved);
    }

    public void userValidatetheLockedStatus() {
        final String locked = testDataManager.getTestInputCommonData("orgInfo.Status9");
        requisitionPage.validateRefundedReqStatus(locked);
        logger.info("Validated Locked Status: {}", locked);
    }

    public void userValidatetheCancelledStatus() {
        final String cancel = testDataManager.getTestInputCommonData("orgInfo.Status3");
        requisitionPage.validateCancelledReqStatus(cancel);
        logger.info("Validated Cancelled Status: {}", cancel);
    }

    public void userValidatetheActiveStatus() {
        final String active = testDataManager.getTestInputCommonData("orgInfo.Status");
        requisitionPage.validateActiveReqStatus(active);
        logger.info("Validated Active Status: {}", active);
    }

    public void userValidatetheRefundStatus() {
        final String refund = testDataManager.getTestInputCommonData("orgInfo.Status7");
        requisitionPage.validateRefundedReqStatus(refund);
        logger.info("Validated Refund Status: {}", refund);
    }

    public void userValidatetheReturnedStatus() {
        final String returned = testDataManager.getTestInputCommonData("orgInfo.Status4");
        requisitionPage.validateReturnedReqStatus(returned);
        logger.info("Validated Returned Status: {}", returned);
    }

    public void userValidatetheRequestedStatus() {
        final String requested = testDataManager.getTestInputCommonData("orgInfo.Status6");
        requisitionPage.validateInvoiceRequestedPaidAppReqStatus(requested);
        logger.info("Validated Requested Status: {}", requested);
    }

    public void userClickonOrgHeader() {
        homePage.clickOnHeaderOrganisation();
        logger.info("Clicked on 'Organisation' header.");
    }

    public void userClickonReqHeader() {
        homePage.clickOnHeaderRequisation();
        logger.info("Clicked on 'Requisition' header.");
    }

    public void userClickOnRefund() {
        final String refundComments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason");
        requisitionPage.clickOnRefund();
        logger.info("Clicked on 'Refund'.");
        requisitionPage.enterComments(refundComments);
        logger.info("Entered refund comments: {}", refundComments);
        requisitionPage.clickOnConfirm();
        logger.info("Clicked on 'Confirm'.");
    }

    public void userClickOnReturn() {
        final String comments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason");
        requisitionPage.clickOnReturn();
        logger.info("Clicked on 'Return'.");
        requisitionPage.enterComments(comments);
        logger.info("Entered return comments: {}", comments);
        requisitionPage.clickOnConfirm();
        logger.info("Clicked on 'Confirm'.");
    }

    public void userClickOnApprove() {
        final String comments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason1");
        requisitionPage.clickOnApprove();
        logger.info("Clicked on 'Approve'.");
        requisitionPage.enterComments(comments);
        logger.info("Entered approval comments: {}", comments);
        requisitionPage.clickOnConfirm();
        logger.info("Confirmed the Approval.");
    }

    public void userClickOnEdit() {
        final String comments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason");
        requisitionPage.clickOnEdit();
        logger.info("Clicked on 'Edit'.");
        requisitionPage.clickSave();
        logger.info("Clicked 'Save'.");
        requisitionPage.enterComments(comments);
        logger.info("Entered edit comments: {}", comments);
        requisitionPage.clickOnConfirm();
        logger.info("Confirmed the Edit.");
    }

    public void userClickEdit() {
        requisitionPage.clickOnEdit();
        logger.info("Clicked on 'Edit'.");
    }

    public void userClickOnCancel() {
        final String comments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason");
        requisitionPage.clickOnCancel();
        logger.info("Clicked on 'Cancel'.");
        requisitionPage.enterComments(comments);
        logger.info("Entered cancellation comments: {}", comments);
        requisitionPage.clickOnConfirm();
        logger.info("Confirmed the Cancellation.");
    }

    public void userClickCancel() {
        requisitionPage.clickOnCancel();
        logger.info("Clicked on 'Cancel'.");
    }

    public void userCheckCancelEditNotPresent() {
        requisitionPage.checkCancelIsNotPresent();
        logger.info("Verified that 'Cancel' button is not present.");
        requisitionPage.checkEditIsNotPresent();
        logger.info("Verified that 'Edit' button is not present.");
    }

    public void userClickAddSpecialProduct() {
        requisitionPage.clickOnAddSpecialProduct();
        logger.info("Clicked on 'Add Special Product'.");
    }

    public void userSelectSpecialProduct() {
        requisitionPage.selecttheProduct();
        logger.info("Selected a Special Product.");
    }

    public void userClickOnSave() {
        final String comments = testDataManager.getTestInputRegionData("RequisitionData.reqInfo.reason");
        requisitionPage.clickSave();
        logger.info("Clicked 'Save'.");
        requisitionPage.enterComments(comments);
        logger.info("Entered save comments: {}", comments);
        requisitionPage.clickOnConfirm();
        logger.info("Confirmed the Save.");
    }

    public void setProductValue() {
        final String value = testDataManager.getTestInputCommonData("orgInfo.Limit1");
        requisitionPage.inputProductvalue(value);
        logger.info("Entered product value: {}", value);
    }

    public void validatetheselectedProduct() {
        requisitionPage.validateTheSelectedProduct();
        logger.info("Validated the selected product.");
    }

    public void entersTheReceiptNumber() {
        if (testDataManager.getFeatureData("requisitions.Receipt", Boolean.class)) {
            requisitionPage.clikcOnEdit();
            logger.info("Clicked on Edit icon.");
            requisitionPage.enterTheReceiptNumber();
            requisitionPage.saveTheReceipt();
            logger.info("Saved the Receipt.");
        }
    }

    public void validatetheReceipt() {
        if (testDataManager.getFeatureData("requisitions.Receipt", Boolean.class)) {
            requisitionPage.validateTheReceipt();
            logger.info("Validated the receipt number.");
        }
    }

    public void searchManagerApproved() {
        requisitionPage.enterManagerApprovedRequisitionAndSearch();
        logger.info("Searched for Manager Approved Requisition.");
    }

    public void validateTheToastificationForClaimed() {
        requisitionPage.validateAndLogToastMessageForClaimed();
        logger.info("Validated Toast notification for Claimed status.");
    }

    public void validateTheNoteMessage() {
        requisitionPage.validateAndLogNoteMessage();
        logger.info("Validated Note message.");
    }

    public void setSearchRequisition() {
        requisitionPage.setSearchRequisition();
        logger.info("Set Requisition Search.");
        requisitionPage.clickSearchIcon();
        logger.info("Clicked on 'Search' icon.");
    }

    public void selectReqAndExport() {
        requisitionPage.selecttheReqFromList();
        logger.info("Selected Requisition from the list for Export.");
        requisitionPage.clicktheExport();
        logger.info("Clicked on 'Export'.");
    }

    public void validateTheToastificationForExport() {
        requisitionPage.validateAndLogToastMessageForExport();
        logger.info("Validated Toast notification for Export.");
    }

    public void validateTheToastificationForOrgExport() {
        requisitionPage.validateAndLogToastMessageForOrgExport();
        logger.info("Validated Toast notification for Organisation Export.");
    }

    public void searchManagerClaimed() {
        requisitionPage.enterManagerClaimedRequisitionAndSearch();
        logger.info("Searched for Manager Claimed Requisition.");
    }

    public void searchUserApproved() {
        requisitionPage.enterUserApprovedRequisitionAndSearch();
        logger.info("Searched for User Approved Requisition.");
    }

    public void searchUserclaimed() {
        requisitionPage.enterUserClaimedRequisitionAndSearch();
        logger.info("Searched for User Claimed Requisition.");
    }

    public void searchPaid() {
        requisitionPage.enterPaidRequisitionAndSearch();
        logger.info("Searched for Paid Requisition.");
    }

    public void searchManagerApprovedForLocal() {
        requisitionPage.enterManagerApprovedRequisitionAndSearchLocal();
        logger.info("Searched for Local Manager Approved Requisition.");
    }

    public void searchManagerClaimedForLocal() {
        requisitionPage.enterManagerClaimedRequisitionAndSearchLocal();
        logger.info("Searched for Local Manager Claimed Requisition.");
    }

    public void searchUserApprovedForLocal() {
        requisitionPage.enterUserApprovedRequisitionAndSearchLocal();
        logger.info("Searched for Local User Approved Requisition.");
    }

    public void searchUserclaimedForLocal() {
        requisitionPage.enterUserClaimedRequisitionAndSearchLocal();
        logger.info("Searched for Local User Claimed Requisition.");
    }
}
