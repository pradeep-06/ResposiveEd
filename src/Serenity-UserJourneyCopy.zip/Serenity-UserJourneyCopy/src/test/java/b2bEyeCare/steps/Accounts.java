package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import b2bEyeCare.pages.b2bEyeCareAccountPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Accounts extends ScenarioSteps {

    b2bEyeCareAccountPage accountPagee;
    private final Logger logger = LoggerFactory.getLogger(Accounts.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    public void userClickAssignRequisition() {
        accountPagee.clickAssignRequisition();
        logger.info("User clicked on 'Assign Requisition'");
    }

    public void validateAssignRequisitionvisible() {
        accountPagee.assignRequisitionVisible();
        logger.info("Validated that 'Assign Requisition' is visible");
    }

    public void userClickAddAccount() {
        accountPagee.clickAddAccount();
        logger.info("User clicked on 'Add Account'");
    }

    public void userSubOrg() {
        accountPagee.clickSunOrganisationt();
        logger.info("User clicked on 'Sub Organisation'");
    }

    public void userEnterSubAccountName() {
        accountPagee.enterNewSubAccountName();
        logger.info("User entered the sub-organisation name");
    }

    public void ValidateAccountCreated() {
        accountPagee.createdAccountValidation();
        logger.info("Validated the newly created account");
    }

    public void userClickCreateAccount() {
        accountPagee.clickCreateAccount();
        logger.info("User clicked on 'Create Account'");
    }

    public void userselectTheSubAccountandEdit() {
        accountPagee.clickEditPriceList();
        logger.info("User clicked on 'Edit Price List'");
        accountPagee.clickReplaceAgreement();
        logger.info("User clicked on 'Replace Agreement'");
    }
}
