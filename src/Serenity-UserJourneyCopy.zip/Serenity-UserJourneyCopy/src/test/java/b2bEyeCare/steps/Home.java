package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.extensions.b2bEyeCareBase;
import b2bEyeCare.pages.b2bEyeCareHomePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Home extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(Home.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    b2bEyeCareHomePage homepage;
    long generatedNumber = b2bEyeCareBase.generateOrganisationId();
    String generatedNumberStr = String.valueOf(generatedNumber);

    public void userClicksOnHomeOrganisation() {
        homepage.clickOnHomeOrganisation();
        logger.info("User clicked on 'Organisation' from Home page");
    }

    public void userClicksOnRequisition() {
        homepage.clickOnRequisition();
        logger.info("User clicked on 'Requisition' from Home page");
    }

    public void userClicksOnPricelistMenu() {
        homepage.clickOnPricelistMenu();
        logger.info("User clicked on 'Pricelist' menu from Home page");
    }

    public void userClickOnCategories() {
        homepage.clickOnCategories();
        logger.info("User clicked on 'Categories' from Home page");
    }

    public void userClickOnTemplate() {
        homepage.clickOnTemplate();
        logger.info("User clicked on 'Template' from Home page");
    }

    public void userClicksOnReport() {
        homepage.clickOnReport();
        logger.info("User clicked on 'Report' from Home page");
    }

    public void userSearchOrganisationId() {
        homepage.searchOrganisationId(generatedNumberStr);
        logger.info("User searched for Organisation ID: " + generatedNumberStr);
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' after entering Organisation ID");
    }

    public void userSearchSIOrganisationId() {
        homepage.searchExistingSIOrganisationId();
        logger.info("User entered the SI Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for SI Organisation ID");
    }

    public void userSearchCPOrganisationId() {
        homepage.searchExistingCPOrganisationId();
        logger.info("User entered the CP Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for CP Organisation ID");
    }

    public void userSearchCIOrganisationId() {
        homepage.searchExistingCIOrganisationId();
        logger.info("User entered the CI Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for CI Organisation ID");
    }

    public void userSearchSILOrganisationId() {
        homepage.searchExistingSILOrganisationId();
        logger.info("User entered the SIL Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for SIL Organisation ID");
    }

    public void userSearchCPLOrganisationId() {
        homepage.searchExistingCPLOrganisationId();
        logger.info("User entered the CPL Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for CPL Organisation ID");
    }

    public void userSearchCILOrganisationId() {
        homepage.searchExistingCILOrganisationId();
        logger.info("User entered the CIL Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for CIL Organisation ID");
    }

    public void userSearchCILROrganisationId() {
        homepage.searchExistingCILROrganisationId();
        logger.info("User entered the CILR Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for CILR Organisation ID");
    }

    public void userSearchSSIOrganisationId() {
        homepage.searchExistingSSIOrganisationId();
        logger.info("User entered the SSI Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for SSI Organisation ID");
    }

    public void userSearchSCIOrganisationId() {
        homepage.searchExistingSCIOrganisationId();
        logger.info("User entered the SCI Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for SCI Organisation ID");
    }

    public void userSearchSCPOrganisationId() {
        homepage.searchExistingSCPOrganisationId();
        logger.info("User entered the SCP Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for SCP Organisation ID");
    }

    public void userSearchACPOrganisationId() {
        homepage.searchExistingACPOrganisationId();
        logger.info("User entered the ACP Organisation ID");
        homepage.clickOnSearchMagnifying();
        logger.info("User clicked on 'Search' for ACP Organisation ID");
    }
}
