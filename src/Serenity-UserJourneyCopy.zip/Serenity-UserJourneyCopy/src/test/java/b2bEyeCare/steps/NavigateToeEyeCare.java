package b2bEyeCare.steps;

import Framework.BaseObject.SsoLoginBase;
import Framework.DataManager.TestDataManager;
import b2bEyeCare.pages.b2bEyeCareLoginPage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NavigateToeEyeCare extends SsoLoginBase {

    private final Logger logger = LoggerFactory.getLogger(NavigateToeEyeCare.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    b2bEyeCareLoginPage b2bEyeCareLoginPage;

    public void openEyeCareUrl() {
        b2bEyeCareLoginPage.open();
        logger.info("B2B EyeCare application launched successfully");
    }

    public void signOut() {
        b2bEyeCareLoginPage.clickSignOutDropDown();
        logger.info("User clicked on the 'Sign-out' dropdown");
        b2bEyeCareLoginPage.clickSignOut();
        logger.info("User clicked on 'Sign-out'");
        b2bEyeCareLoginPage.loginFormVisible();
        logger.info("Login form is visible after sign-out");
    }

    public void otherAccount() {
        b2bEyeCareLoginPage.clickUseOtherAccount();
        logger.info("User clicked on 'Use Other Account'");
    }

    public void clickLoginIcon() {
        b2bEyeCareLoginPage.clickSsoLogin();
        logger.info("User clicked on the SSO login icon");
    }
}
