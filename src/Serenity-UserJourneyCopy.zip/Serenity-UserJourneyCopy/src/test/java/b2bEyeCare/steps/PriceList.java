package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.pages.b2bEyeCarePriceListPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PriceList extends ScenarioSteps {

    b2bEyeCarePriceListPage pricelistPage;

    private final Logger logger = LoggerFactory.getLogger(PriceList.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    public void userSelecttheTemplate() {
        pricelistPage.selectTheTemplate();
        logger.info("User selected the template");
    }

    public void userEdittheTemplate() {
        pricelistPage.clickOnEdit();
        logger.info("User edited the template");
    }

    public void userDeletetheTemplate() {
        pricelistPage.deleteTemplate();
        logger.info("User deleted the template");
    }

    public void usersClickAddItem() {
        pricelistPage.clickAddItem();
        logger.info("User clicked on 'Add Item'");
    }

    public void usersAddSightItem() {
        pricelistPage.addsighttestItemtoTemplate();
        logger.info("User added a sight item to the template");
    }

    public void usersAddDigitalItem() {
        pricelistPage.adddigitalItemtoTemplate();
        logger.info("User added a digital item to the template");
    }

    public void usersAddSafetySItem() {
        pricelistPage.addsafetysItemtoTemplate();
        logger.info("User added a safety S item to the template");
    }

    public void usersAddSafteyFItem() {
        pricelistPage.addsafetyfItemtoTemplate();
        logger.info("User added a safety F item to the template");
    }

    public void usersValidateTheUpdate() {
        pricelistPage.userWaituntillupdated();
        logger.info("User validated the update");
    }

    public void usersAddBespokeItem() {
        pricelistPage.addbespokeItemtoTemplate();
        logger.info("User added a bespoke item to the template");
    }

    public void usersUpdate() {
        pricelistPage.selectUpdate();
        logger.info("User updated the template");
    }

    public void addItemRowMessageDisplayed() {
        pricelistPage.isAddItemRowMessageDisplayed();
        logger.info("Add Item row message is displayed");
    }
}
