package b2bEyeCare.steps;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.pages.b2bEyeCareMultiUserPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MultiRegionUser extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(MultiRegionUser.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    b2bEyeCareMultiUserPage multiUser;

    public void userSelectsRegion() {
        multiUser.selectTheRegion();
        logger.info("User selected the region");
    }

    public void userSelectsRegionAsStoreManager() {
        multiUser.waituntillSelectRegionisDisplayed();
        logger.info("Region selection is displayed for Store Manager");
        multiUser.selectTheRegionAsStoreManager();
        logger.info("User selected the region as Store Manager");
    }

    public void userSelectsRegionAsStoreUser() {
        multiUser.waituntillSelectRegionisDisplayed();
        logger.info("Region selection is displayed for Store User");
        multiUser.selectTheRegionAsStoreUser();
        logger.info("User selected the region as Store User");
    }
}
