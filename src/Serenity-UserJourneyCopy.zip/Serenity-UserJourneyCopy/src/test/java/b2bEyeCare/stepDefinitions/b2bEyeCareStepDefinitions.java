package b2bEyeCare.stepDefinitions;

import Framework.DataManager.TestDataManager;
import b2bEyeCare.steps.*;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class b2bEyeCareStepDefinitions extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(b2bEyeCareStepDefinitions.class);

    protected final TestDataManager testDataManager = new TestDataManager();
    @Steps
    NavigateToeEyeCare navigateTo;


    @Steps
    Home home;
    @Steps
    AddNewOrganisation org;

    @Steps
    MultiRegionUser multiUser;

    @Steps
    Accounts account;

    @Steps
    Requisitions req;

    @Steps
    PriceList price;

    @Steps
    Categories categories;


    @Step("User launches the Eye Care application URL")
    public void launchEyeCareUrl() {
        navigateTo.openEyeCareUrl();
    }

    @Step("User logs in as Spec Admin")
    public void specAdminSignIn() {
        navigateTo.enterLoginCredentials("SPECADMIN_USERNAME", "SPECADMIN_PASSWORD");
        logger.info("Spec Admin Credentials Entered");
    }

    @Step("User logs in as Store User")
    public void storeUserSignIn() {
        navigateTo.enterLoginCredentials("STOREUSER_USERNAME", "STOREUSER_PASSWORD");
        logger.info("Store User Credentials Entered");
    }

    @Step("User logs in as Store Manager")
    public void storeManagerSignIn() {
        navigateTo.enterLoginCredentials("STOREMANAGER_USERNAME", "STOREMANAGER_PASSWORD");
        logger.info("Store Manager Credentials Entered");
    }

    @Step("User selects the region")
    public void userSelectsTheRegion() {
        multiUser.userSelectsRegion();
    }

    @Step("User signs out and closes the browser")
    public void userSignOutOfTheApplicationAndCloseDriver() {
        getDriver().quit();
    }

    @Step("User clicks on Organisation in the Home page")
    public void userClicksOnOrganisationInHomePage() {
        home.userClicksOnHomeOrganisation();
    }

    @Step("User clicks on Requisition in the Header")
    public void userClickOnRequisationInTheHeader() {
        req.userClickonReqHeader();
    }

    @Step("User clicks on Requisition in the Home page")
    public void userClickOnRequisitionInTheHomePage() {
        home.userClicksOnRequisition();
    }

    @Step("User clicks on Report in the Home page")
    public void userClickOnReportInTheHomePage() {
        home.userClicksOnReport();
    }

    @Step("User clicks on Price List")
    public void userClickOnPriceList() {
        home.userClicksOnPricelistMenu();
    }

    @Step("User clicks on Categories")
    public void userClickOnCategories() {
        home.userClickOnCategories();
    }

    @Step("User clicks on Template in the Price List")
    public void userClickOnTemplateI() {
        home.userClickOnTemplate();
    }

    @Step("User adds a Frame Category")
    public void userAddFrameCategories() {
        categories.userAddFramesCategorie();
    }

    @Step("User adds a Lenses Category")
    public void userAddLenseCategories() {
        categories.userAddLenseCategorie();
    }

    @Step("User adds a Coating Category")
    public void userAddCoatingCategories() {
        categories.userAddCoatingCategorie();
    }

    @Step("User adds an Index Category")
    public void userAddIndexCategories() {
        categories.userAddIndexCategorie();
    }

    @Step("User deletes a Category")
    public void userDeleteCategories() {
        categories.deleteCategorie();
    }

    @Step("User clicks on Add Organisation in the Organisation Page")
    public void userClicksOnAddOrganisation() {
        org.clickToAddOrganisation();
    }

    @Step("User clicks on Edit Organisation in the Organisation Page")
    public void userClickOneditOrganisationInTheOrganisationPage() {
        org.editOrganisation();
        org.getOrgName();
    }

    @Step("User enters Organisation ID in the Organisation Page")
    public void userEntersOrganisationNumber() {
        org.userEnterOrgNumber();
    }

    @Step("User enters Sub Organisation ID in the Organisation Page")
    public void userEntersSubOrganisationNumber() {
        org.userEnterSubOrgNumber();
    }

    @Step("User performs Organisation number search")
    public void userPerformOrganisationNumberSearch() {
        org.performOrgNumberSearch();
    }

    @Step("User performs Sub Organisation number search")
    public void userPerformSubOrgNumberSearch() {
        org.performSubOrgNumberSearch();
    }

    @Step("User validates the Organisation number")
    public void userValidatingTheOrgNumber() {
        org.validatingTheOrganisationNumber();
    }

    @Step("User validates the Sub Organisation number")
    public void userValidatingTheSubOrgNumber() {
        org.validatingTheSubOrganisationNumber();
    }

    @Step("User selects a Template")
    public void userSelectTheTemplate() {
        price.userSelecttheTemplate();
    }

    @Step("User edits the Template")
    public void userEditTheTemplate() {
        price.userEdittheTemplate();
    }

    @Step("User deletes the Template")
    public void userDeletesTheTemplate() {
        price.userDeletetheTemplate();
    }

    @Step("User updates the Template after deleting")
    public void userUpdateTheTemplate() {
        price.usersUpdate();
    }

    @Step("User validates the message")
    public void userValidaqtetheMessage() {
        price.addItemRowMessageDisplayed();
    }

    @Step("User adds a Sight Item")
    public void userAddTheSightItem() {
        price.usersClickAddItem();
        price.usersAddSightItem();
    }

    @Step("User adds a Digital Item")
    public void userAddTheDigitalItem() {
        price.usersClickAddItem();
        price.usersAddDigitalItem();
    }

    @Step("User adds a Safety S Item")
    public void userAddTheSafetySItem() {
        price.usersClickAddItem();
        price.usersAddSafetySItem();
    }

    @Step("User adds a Safety F Item")
    public void userAddTheSafteyFItem() {
        price.usersClickAddItem();
        price.usersAddSafteyFItem();
    }

    @Step("User adds a Bespoke Item")
    public void userAddTheBespokeItem() {
        price.usersClickAddItem();
        price.usersAddBespokeItem();
    }

    @Step("User updates the items and saves the Template")
    public void userAddTheItemsAndSave() {
        price.usersUpdate();
        price.usersValidateTheUpdate();
    }

    @Step("User searches Organisation ID in the Organisation Page")
    public void userSearchOrganisationIdintheOrganisationPage() {
        home.userSearchOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches SI Organisation ID in the Organisation Page")
    public void userSearchSIOrganisationIdintheOrganisationPage() {
        home.userSearchSIOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches CP Organisation ID in the Organisation Page")
    public void userSearchCPOrganisationIdintheOrganisationPage() {
        home.userSearchCPOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches CI Organisation ID in the Organisation Page")
    public void userSearchCIOrganisationIdintheOrganisationPage() {
        home.userSearchCIOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches SIL Organisation ID in the Organisation Page")
    public void userSearchSILOrganisationIdintheOrganisationPage() {
        home.userSearchSILOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches CILR Organisation ID in the Organisation Page")
    public void userSearchCILROrganisationIdintheOrganisationPage() {
        home.userSearchCILROrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches CPL Organisation ID in the Organisation Page")
    public void userSearchCPLOrganisationIdintheOrganisationPage() {
        home.userSearchCPLOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches CIL Organisation ID in the Organisation Page")
    public void userSearchCILOrganisationIdintheOrganisationPage() {
        home.userSearchCILOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches SSI Organisation ID in the Organisation Page")
    public void userSearchSSIrganisationIdintheOrganisationPage() {
        home.userSearchSSIOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches SCI Organisation ID in the Organisation Page")
    public void userSearchSCIOrganisationIdintheOrganisationPage() {
        home.userSearchSCIOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches SCP Organisation ID in the Organisation Page")
    public void userSearchSCPOrganisationIdintheOrganisationPage() {
        home.userSearchSCPOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches ACP Organisation ID in the Organisation Page")
    public void userSearchACPOrganisationIdintheOrganisationPage() {
        home.userSearchACPOrganisationId();
        org.userSelectOrganisation();
    }

    @Step("User searches Requisition ID in the Requisition Page")
    public void userSearchReqIdintheReqPage() {
        req.userClearRequisition();
        req.userSearchRequisation();
        req.clickOnDynamicReqLink();
    }

    @Step("User searches Requisition ID in the Requisition Page for RQ")
    public void userSearchRqReqIdintheReqPage() {
        req.userClearRequisition();
        req.userSearchRqRequisation();
        req.clickOnDynamicReReqLink();
    }

    @Step("User sets the calendar and searches Requisition ID in the Report Page")
    public void userSetCalenderinReport() {
        req.setTheCalender();
        req.userSearchRequisationAfterSetDate();
    }

    @Step("User sets the date in the Report Page")
    public void setTheCalenderAsPerDefinedDate() {
        req.setTheCalenderForSpecificDate();
    }

    @Step("User clicks on Advanced Search tab in the Requisition Page")
    public void clickOnAdvancedSearchTab() {
        req.AdvanceSearch();
    }

    @Step("User exports the Organisation")
    public void userExporttheOrg() {
        req.selectOrgAndExport();
    }

    @Step("User validates the Advanced Search functionality for Centralise")
    public void checkCentralisenabled() {
        req.checkElementenabled();
    }

    @Step("User validates the Requisition number")
    public void userValidateTheSearchRequisition() {
        req.validateTheReqResult();
    }

    @Step("User validates the Reference No:1")
    public void userValidateTheReference1() {
        req.validateTheReference1();
    }

    @Step("User validates the Reference No:2")
    public void userValidateTheReference2() {
        req.validateTheReference2();
    }

    @Step("User validates the Voucher value")
    public void userValidateTheVoucher() {
        req.validateTheVoucherValue();
    }

    @Step("User validates the Organisation name")
    public void userValidateTheOrgName() {
        req.validateTheOrganisationName();
    }

    @Step("User validates the Store name")
    public void userValidateTheStoreName() {
        req.validateTheStoreName();
    }

    @Step("User validates the Employee name")
    public void userValidateTheEmployeeName() {
        req.validateTheEmployeeName();
    }

    @Step("User performs Advanced Search for Requisition")
    public void setRequisitionnoInAdvSearch() {
        req.setSearchRequisitionInAdvSearch();
    }

    @Step("User validates the Requisition result in Advanced Search")
    public void validteTheRequisitionResult() {
        req.validateRequisitionNo();
    }

    @Step("User performs Advanced Search for Reference1")
    public void setReference1() {
        req.setSearchReference1();
    }

    @Step("User clicks on More in Advanced Search")
    public void inAdvanceSearchClickMore() {
        req.clickMoreInAdvanceSearch();
    }

    @Step("User performs Advanced Search for Reference2")
    public void setReference2() {
        req.setSearchReference2();
    }

    @Step("User performs Advanced Search for Voucher value")
    public void setVoucherValue() {
        req.setSearchAmount();
    }

    @Step("User performs Advanced Search for Organisation name")
    public void setOrganisationName() {
        req.setSearchOrg();
    }

    @Step("User performs Advanced Search for Store")
    public void setStore() {
        req.setSearchStore();
    }

    @Step("User performs Advanced Search for Employee name")
    public void setEmployeeName() {
        req.setSearchEmpName();
    }

    @Step("User performs Advanced Search for Price List")
    public void setPriceList() {
        req.setSearchPriceList();
    }

    @Step("User performs Advanced Search for Category")
    public void setCategory() {
        req.setSearchCategory();
    }

    @Step("User performs Advanced Search for Comments")
    public void setComments() {
        req.setSearchComments();
    }

    @Step("User performs Advanced Search for Created Date")
    public void setCreatedDate() {
        req.setSearchCreatedDate();
    }

    @Step("User clicks on Advanced Search")
    public void clikcAdvanceSearch() {
        req.clikcAdvSearch();
    }

    @Step("User invoices the Requisition")
    public void userInvoicetheReq() {
        req.selectReqAndInvoice();
    }

    @Step("User invoices the Locked Requisition")
    public void userInvoicetheLockedReq() {
        req.selectReqAndInvoiceTheLocked();
    }

    @Step("User locks the Invoice")
    public void userLockTheInvoice() {
        req.selectReqAndLock();
    }

    @Step("User validates the Invoiced Requisition in the Redemption Page")
    public void userValidateTheInvoiced() {
        req.validateThedisabledMenu();
        req.validateTheInvoicedReq();
    }

    @Step("User validates the Invoiced Requisition without Till ID in the Redemption Page")
    public void userValidateTheInvoicedWithOutTillId() {
        req.validateThedisabledMenu();
        req.validateTheInvoicedReqWithOutTillId();
    }

    @Step("User validates the Locked Requisition in the Redemption Page")
    public void userValidateTheLocked() {
        req.validateThedisabledMenu();
        req.validateTheLockedReq();
    }

    @Step("User validates the Redeemed Requisition in the Redemption Page")
    public void userValidateRedeemedReq() {
        req.validateTheRededemedReq();
    }

    @Step("User validates the Requisition status in the Requisition Page")
    public void userValidateTheReq() {
        req.validateTheReqStatus();
    }

    @Step("User clicks on Save in the Requisition Page")
    public void clickOnSave() {
        req.userClickOnSave();
    }

    @Step("User clicks on the Requisition")
    public void clickOntheRequisition() {
        req.clickOnDynamicReqLink();
    }

    @Step("User clicks on the Re-Requisition")
    public void clickOntheReRequisition() {
        req.clickOnDynamicReReqLink();
    }

    @Step("User clicks on Add Item")
    public void clickOnAddItem() {
        req.clickOnAddItems();
    }

    @Step("User adds items to the product")
    public void addItemsTotheProduct() {
        req.addItems();
    }

    @Step("User edits the returned Requisition")
    public void userEdithReturned() {
        req.userClickOnEdit();
    }

    @Step("User cancels the Requisition")
    public void userCanceltheReq() {
        req.userClickOnCancel();
    }

    @Step("User validates the Cancel Edit is not present")
    public void CheckCancelEditNotPresent() {
        req.userCheckCancelEditNotPresent();
    }

    @Step("User clicks on Claim")
    public void userClickOnClaim() {
        req.userclickonClaim();
    }

    @Step("User confirms Claim with Yes")
    public void userConfirmYes() {
        req.userclickYes();
    }

    @Step("User confirms Claim with No")
    public void userConfirmNo() {
        req.userclickNo();
    }

    @Step("User validates the Paid status")
    public void userValidatePaidStatus() {
        req.userValidatethePaidStatus();
    }

    @Step("User validates the Claimed status")
    public void userValidateclaimedStatus() {
        req.userValidatetheClaimedStatus();
    }

    @Step("User enters the Receipt number")
    public void userEnterTheReceiptNumber() {
        req.entersTheReceiptNumber();
        req.validatetheReceipt();
    }

    @Step("User validates the Approved status")
    public void userValidateApprovedStatus() {
        req.userValidatetheApprovedStatus();
    }

    @Step("User validates the Locked status")
    public void userValidateLockedStatus() {
        req.userValidatetheLockedStatus();
    }

    @Step("User validates the Cancelled status")
    public void userValidateCancelledStatus() {
        req.userValidatetheCancelledStatus();
    }

    @Step("User validates the Active status")
    public void userValidateActiveStatus() {
        req.userValidatetheActiveStatus();
    }

    @Step("User validates the Refund status")
    public void userValidateRefundStatus() {
        req.userValidatetheRefundStatus();
    }

    @Step("User validates the Returned status")
    public void userValidateRerunStatus() {
        req.userValidatetheReturnedStatus();
    }

    @Step("User clicks on Refund")
    public void userClickOnRefund() {
        req.userClickOnRefund();
    }

    @Step("User clicks on Approve")
    public void userClickOnApprove() {
        req.userClickOnApprove();
    }

    @Step("User clicks on Return")
    public void userClickOnReturn() {
        req.userClickOnReturn();
    }

    @Step("User enters mandatory Organisation details and approves")
    public void userEntersMandatoryOrganisationDetailsAndApprove() {
        org.clickApproveInformation();
    }

    @Step("User enters mandatory Organisation details and clicks on Approve")
    public void userClickApproveInformation() {
        org.clickApproveInformation();
    }

    @Step("User validates the Approve Info button is disabled")
    public void validateTheApproveInfoButtonIsDisabled() {
        org.validateApproveInfoButtonIsDisabled();
    }

    @Step("User validates the Next button is disabled")
    public void validaTheNextButtonIsDisabled() {
        org.validateNextButtonIsDisabled();
    }

    @Step("User validates the Approve Info button is enabled")
    public void validateTheApproveInfoButtonIsEnabled() {
        org.validateApproveInfoButtonIsEnabled();
    }

    @Step("User validates the Next button is enabled")
    public void validaTheNextButtonIsEnabled() {
        org.validateNextButtonIsEnabled();
    }

    @Step("User enters mandatory Organisation details")
    public void enterTheMandatoryInformation() {
        org.enterTheMandatorydcetails();
    }

    @Step("User enters mandatory Sub Organisation details")
    public void enterTheSubOrgMandatoryInformation() {
        org.enterTheSubOrgMandatorydcetails();
    }

    @Step("User enters notes for Organisation")
    public void userEnterTheNotes() {
        org.enterTheNotes();
    }

    @Step("User enters notes for Sub Organisation")
    public void userEnterTheSubOrgNotes() {
        org.enterTheSubOrgNotes();
    }

    @Step("User enters email and searches for Organisation")
    public void userEnterEmailIdAndSearch() {
        org.enterEmailIdAndClickSearch();
    }

    @Step("User enters email and searches for Sub Organisation")
    public void userEnterSubOrgEmailIdAndSearch() {
        org.enterSubEmailId();
    }

    @Step("User enters Organisation Admin details and clicks Next")
    public void userEnterOrganisationAdminDetailsandClickNext() {
        org.enterMandatoryOrganisationAdminDetails();
    }

    @Step("User enters Sub Organisation Admin details and clicks Next")
    public void userEnterSubOrganisationAdminDetailsandClickNext() {
        org.enterMandatorySubOrganisationAdminDetails();
    }

    @Step("User enters Organisation Admin sub-details and clicks Next")
    public void userEnterOrganisationAdminSubDetailsandClickNext() {
        org.enterMandatoryOrganisationSubAdminDetails();
        org.userClickNext();
    }

    @Step("User selects Organisation Size as 1-25")
    public void userSelectsOrganisationSizeas0to200() {
        org.SelectsTheOrganisationsize0To200();
    }

    @Step("User selects Agreement Type")
    public void userSelectsAgreementType() {
        org.selectTheAgreement();
    }

    @Step("User adds Agreement")
    public void userAddAgreement() {
        org.selectAddTheAgreement();
    }

    @Step("User clicks Next")
    public void userClickNext() {
        org.userClickNext();
    }

    @Step("User edits Agreement Type")
    public void userEditAgreementType() {
        org.selectEditAgreement();
    }

    @Step("User selects Customer Payments")
    public void userSelectsCustomerPayments() {
        org.userSelectsCustomerPayment();
    }

    @Step("User selects Central Invoice")
    public void userSelectsCentralInvoice() {
        org.userSelectCentralInvoice();
    }

    @Step("User selects Store Invoice")
    public void userSelectsStoreInvoice() {
        org.UserSelectStoreInvoice();
    }

    @Step("User clicks on Store Invoice")
    public void userClickStoreInvoice() {
        org.UserClickStoreInvoice();
    }

    @Step("User enters Organisation Spec References")
    public void userEnterOrgSpecReferences() {
        org.selectOrgContact();
        org.userSelectOrgSpecContact();
        org.userClickNext();
    }

    @Step("User enters Organisation Manager Spec References")
    public void userEnterOrgManagerSpecReferences() {
        org.userSelectOrgManagerSpecContact();
        org.userClickNext();
    }

    @Step("User enters Account Spec References")
    public void userEnterAccSpecReferences() {
        org.userSelectAccountSpecContact();
        org.userClickNext();
    }

    @Step("User enters Invoice Comments")
    public void userEnterInvoiceComments() {
        org.userEnterInvoiceComments();
        org.userClickNext();
    }

    @Step("User selects Requisition Period as 30 days")
    public void userSelectrequisitionPeriod() {
        org.userSelectsRequisitionPeriodAs30Days();
        org.userSelectTypeofSpec();
        org.userSelectDigitalSpare();
        org.unselectApprovalRequired();
        org.userClickNext();
    }

    @Step("User edits Organisation and sets Limit")
    public void userEdittheOrganisaation() {
        org.editandSetLimit();
    }

    @Step("User enters Account details")
    public void userEnterAccountDetails() {
        org.userEnterAccountDetails();
    }

    @Step("User enters mandatory Account details")
    public void userMandatoryAccountDetails() {
        org.userEnterMandatoryAccountDetails();
    }

    @Step("User enters mandatory Account details for Sub Organisation")
    public void userEnterSubOrgMandatoryAccountDetails() {
        org.userEnterSubMandatoryAccountDetails();
    }

    @Step("User enters mandatory Account details for Organisation")
    public void userEnterAccountMandatoryAccountDetails() {
        org.userEnterAccountMandatoryAccountDetails();
    }

    @Step("User enters non-mandatory Account details")
    public void userEnterNonMandatoryAccountDetails() {
        org.userEntersFinanceID();
        org.userEnterReferences();
    }

    @Step("User enters Comments for Account")
    public void userEnterComments() {
        org.userEnterComments();
        org.userClickNext();
    }

    @Step("User clicks on Create button")
    public void userSelectCreateOrganisation() {
        org.userSelectCreateOrganisation();
    }

    @Step("User validates the created Account")
    public void validateAccountCreated() {
        org.createdOrganisation();
        account.validateAssignRequisitionvisible();
    }

    @Step("User adds Special Product for the created Account")
    public void userAddSpecialProduct() {
        req.userClickAddSpecialProduct();
        req.userSelectSpecialProduct();
        req.setProductValue();
        req.validatetheselectedProduct();
    }

    @Step("User validates Self Requisition for the Account")
    public void switchBackOrgWindow() {
        req.switchBackToOriginalwindows();
    }

    @Step("User selects the created Account and edits it")
    public void userClickEditAccount() {
        account.userselectTheSubAccountandEdit();
    }

    @Step("User clicks on Assign Requisition")
    public void userClickAssignRequisition() {
        account.userClickAssignRequisition();
    }

    @Step("User clicks on Create Employee Requisition")
    public void userClickCreateEmpRequisition() {
        req.clickCreateEmpReq();
    }

    @Step("User clicks on Create Self Requisition")
    public void userClickCreateSelfRequisition() {
        req.clickCreateSelfServeRequisition();
        req.validateTheLinkErrorMessage();
    }

    @Step("User copies the link and opens it")
    public void userCopytheLinkAndOpen() {
        req.copyTheLinkAndOpen();
    }

    @Step("User enters Employee details and approves Requisition")
    public void userEntersEmployeeDetailsinRequisition() {
        req.enterEmployeeBasicDetails();
        req.enterEmployeeEmails();
        req.enterEmployeeBirthday();
        req.enterEmployeePhoneNo();
        req.enterPersonalEmails();
        req.enterRequisitionReferences();
        if (testDataManager.getFeatureData("requisitions.measurements", Boolean.class)) {
            req.enterMeasurementDetails();
        }
        req.selectDigitalSpecs();
    }

    @Step("User submits the Requisition")
    public void userSubmitTheRequisition() {
        req.submitTheRequisition();
    }

    @Step("User enters Employee details and approves Self Requisition")
    public void userEntersEmployeeDetailsaInSelfRequisition() {
        req.enterEmployeeBasicDetailsForSelfReq();
        req.enterEmployeeEmailsForSelfReq();
        req.enterEmployeeBirthday();
        req.enterEmployeePhoneNoForSelfReq();
        req.enterPersonalEmailsForSelfReq();
        req.enterRequisitionReferences();
        if (testDataManager.getFeatureData("requisitions.measurements", Boolean.class)) {
            req.enterMeasurementDetails();
        }
        req.selectDigitalSpecs();
    }

    @Step("User submits the Self Requisition")
    public void userSubmitTheSelfRequisition() {
        req.submitSelfRequisition();
    }

    @Step("User retrieves the Requisition number and validates BarCode")
    public void getTheRequisitionNumber() {
        req.gettheReqNo();
    }

    @Step("User clicks on Create Account")
    public void userClickCreateAccount() {
        account.userClickAddAccount();
    }

    @Step("User clicks on Create Sub Organisation")
    public void userClickCreateSubOrg() {
        account.userSubOrg();
    }

    @Step("User validates second account")
    public void validateSecondAccount() {
        account.ValidateAccountCreated();
        logger.info("Validate the Created Account");
    }

    @Step("User enters and creates Sub Account name")
    public void userClickCreateSubAccountName() {
        account.userEnterSubAccountName();
        account.userClickCreateAccount();
    }

    @Step("User retrieves the created Active Requisition")
    public void userRetrivetheActiveRequisation() {
        req.userClearRequisition();
        req.clickDasboardActive();
        req.getRequNumber();
        req.validateTheReq();
    }

    @Step("User retrieves the Needs Action Requisition")
    public void userRetrivetheNeedsActionRequisation() {
        req.userClearRequisition();
        req.clickDasboardNeedsAction();
        req.getNAReqNumber();
        req.validateTheNeedReq();
    }

    @Step("User retrieves the created Active Requisition for Self Requisition")
    public void userRetrivetheActiveRequisationforSelfRequisition() {
        req.userClearRequisition();
        //req.clickDasboardActive();
        req.validateTheReq();
    }

    @Step("User retrieves the Needs Action Requisition for Self Requisition")
    public void userRetrivetheRequestedRequisationFotSelfRequsition() {
        req.userClearRequisition();
        //req.clickDasboardNeedsAction();
        req.validateTheNeedReq();
    }

    @Step("User clicks on Edit for the created Active Requisition")
    public void userClickonEdit() {
        req.userClickEdit();
    }

    @Step("User retrieves the Requisition number")
    public void userRetrivetheRequisation() {
        req.getReqNumber();
    }

    @Step("User searches for Manager Approved Requisition in Restricted Store")
    public void userSearchManagerApprovedReqForRestricStore() {
        req.searchManagerApproved();
    }

    @Step("User searches for Manager Claimed Requisition in Restricted Store")
    public void userSearchManagerClaimedReqForRestricStore() {
        req.searchManagerClaimed();
    }

    @Step("User searches for User Approved Requisition in Restricted Store")
    public void userSearchUserApprovedReqForRestricStore() {
        req.searchUserApproved();
    }

    @Step("User searches for Paid Requisition in Restricted Store")
    public void userSearchPaidForRestricStore() {
        req.searchPaid();
    }

    @Step("User searches for User Claimed Requisition in Restricted Store")
    public void userSearchUserClaimedReqForRestricStore() {
        req.searchUserclaimed();
    }

    @Step("User searches for Manager Approved Local Requisition in Restricted Store")
    public void userSearchManagerApprovedLocalReqForRestricStore() {
        req.searchManagerApprovedForLocal();
    }

    @Step("User searches for Manager Claimed Local Requisition in Restricted Store")
    public void userSearchManagerClaimedLocalReqForRestricStore() {
        req.searchManagerClaimedForLocal();
    }

    @Step("User searches for User Approved Local Requisition in Restricted Store")
    public void userSearchUserApprovedLocalReqForRestricStore() {
        req.searchUserApprovedForLocal();
    }

    @Step("User searches for User Claimed Local Requisition in Restricted Store")
    public void userSearchUserClaimedLocalReqForRestricStore() {
        req.searchUserclaimedForLocal();
    }

    @Step("User validates the Toast Notification for Claimed Requisition")
    public void ValidateTheToastMessage() {
        req.validateTheToastificationForClaimed();
    }

    @Step("User validates the Note Notification")
    public void ValidateTheNoteMessage() {
        req.validateTheNoteMessage();
    }

    @Step("User searches Requisition")
    public void setRequisitionnoinSearchbox() {
        req.setSearchRequisition();
    }

    @Step("User exports the Requisition")
    public void userExporttheReq() {
        req.selectReqAndExport();
    }

    @Step("User validates the Toast Notification for Export")
    public void ValidateTheExportToastMessage() {
        req.validateTheToastificationForExport();
    }

    @Step("User validates the Toast Notification for Organisation Export")
    public void ValidateTheOrgExportToastMessage() {
        req.validateTheToastificationForOrgExport();
    }

    public void closeSession() {
        if (getDriver() != null) {
            logger.info(("Destroy the web driver instance"));
            getDriver().quit();
        }
    }
}
