package digital.eComm.ui.pages.checkout;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommCustomerDetailsPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    eCommCustomerAddressPage eCommCustomerAddressPage;

    @FindBy(id = "edit-commerce-checkout-form-your-details-toggle-register-login-1")
    private WebElementFacade newCustomerRadio;

    @FindBy(id = "edit-field-prefix-und-button")
    private WebElementFacade userTitle;

    @FindBy(id = "edit-field-firstname-und-0-value")
    private WebElementFacade userFirstName;

    @FindBy(id = "edit-field-lastname-und-0-value")
    private WebElementFacade userLastName;

    @FindBy(id = "edit-mail")
    private WebElementFacade userEmailInputBox;

    @FindBy(id = "edit-conf-mail")
    private WebElementFacade userConfirmEmailInputBox;

    @FindBy(css = "input#edit-field-person-number-und-0-value")
    private WebElementFacade socialSecurityNumber;

    @FindBy(xpath = "//*[@id=\"edit-field-dob-und-0-value-day-button\"]")
    private WebElementFacade dayElement;

    @FindBy(xpath = "//*[@id=\"edit-field-dob-und-0-value-month-button\"]")
    private WebElementFacade monthElement;

    @FindBy(xpath = "//*[@id=\"edit-field-dob-und-0-value-year-button\"]")
    private WebElementFacade yearElement;

    @FindBy(id = "edit-field-gender-und-button")
    private WebElementFacade gender;

    @FindBy(xpath = "//*[@id=\"edit-field-customer-contact-phone-und-0-value\"]")
    private WebElementFacade contactNumber;

    @FindBy(id = "edit-continue")
    private WebElementFacade continueButton;

    @FindBy(id = "edit-commerce-checkout-form-your-details-toggle-register-login-0")
    private WebElementFacade existingUser;

    @FindBy(id = "edit-commerce-checkout-form-your-details-toggle-register-login-0")
    private WebElementFacade existingUserRadio;

    @FindBy(id = "edit-name")
    private WebElementFacade existingUserEmailId;

    @FindBy(id = "edit-pass")
    private WebElementFacade existingUserPassword;

    @FindBy(id = "edit-submit")
    private WebElementFacade loginButton;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[3]/div[1]/div[7]/div[1]/label")
    private WebElementFacade emailES;

    @FindBy(xpath = "//*[@id=\"customer-email\"]")
    private WebElementFacade enterEmailES;

    public void clickNewCustomerRadio() {
        clickElement(newCustomerRadio);
        logger.info("VALIDATE: username is visible on the page after clicking 'I am a new customer' on the Your Details page of checkout");
        assertPageObjectIsDisplayed(userFirstName);
    }

    public void selectUserTitle(String title) {
        selectOptionFromDropdown(this.userTitle, title);
    }

    public void enterUserFirstName(String firstName) {
        setText(this.userFirstName, firstName);
    }

    public void enterUserLastName(String lastName) {
        setText(this.userLastName, lastName);
    }

    public void enterUserEmailInputBox(String emailId) {
        setText(this.userEmailInputBox, emailId);
    }

    public void enterUserConfirmEmailInputBox(String emailId) {
        setText(this.userConfirmEmailInputBox, emailId);
    }

    public void enterSocialSecurityNumber(String regionalData) {
        setText(this.socialSecurityNumber, regionalData);
    }

     public void selectDayElement(String day) {
        selectOptionFromDropdown(this.dayElement, day);
    }

    public void selectMonthElement(String month) {
        selectOptionFromDropdown(this.monthElement, month);
    }

    public void selectYearElement(String year) {
        selectOptionFromDropdown(this.yearElement, year);
    }

    public void selectGender(String gender) {
        selectOptionFromDropdown(this.gender, gender);
    }

    public void enterContactNumber(String contactNumber) {
        setText(this.contactNumber, contactNumber);
    }

    public void clickContinueButton() {
        clickElement(this.continueButton);
        logger.info("VALIDATE: The addressed details are displayed after completing and continuing from the Your Details page");
        if(eCommCustomerAddressPage.featureShowsEnterAddressManuallyLink()){
            assertPageObjectExists(eCommCustomerAddressPage.getEnterAddressManuallyLink()); //most regions by default hide address1 - for these regions check for link to enter address manually
        }
        else {assertPageObjectExists(eCommCustomerAddressPage.getAddressLine1());} //Some regions dont have the manual link and show address1 as default
    }

    public void clickExistingCustomerRadio() { clickElement(this.existingUserRadio); }

    public void theUserLoginWithTheCredentials(String emailId,String password) {
        logger.info("entering email: " + emailId);
        setText(this.existingUserEmailId,emailId);
        logger.info("entering email: " + password);
        setText(this.existingUserPassword,password);
        clickElement(this.loginButton);
    }

    public WebElementFacade getUserFirstName(){return userFirstName;}

    public void enterUserEmailInputBoxEs(String emailId) {
            logger.info("enter email");
            setText(this.enterEmailES, emailId);
//            emailES.click();
        }
    }
