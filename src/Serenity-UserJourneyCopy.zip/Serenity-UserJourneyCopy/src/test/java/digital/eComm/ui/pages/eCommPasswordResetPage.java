package digital.eComm.ui.pages;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@DefaultUrl("page:eComm.drupal.home.url")
public class eCommPasswordResetPage extends eCommBase {
    eCommHomePage homePage;
    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);

    final String newPassword = testDataManager.getTestInputRegionData("resetPassword.password");
    final String newConfirmPassword = testDataManager.getTestInputRegionData("resetPassword.confirmPassword");

    final String passwordRuleEnsurePwd = testDataManager.getTestInputRegionData("resetPassword.passwordRuleEnsurePwd");

    final String passwordRuleMin8Char = testDataManager.getTestInputRegionData("resetPassword.passwordRuleMin8Char");

    final String passwordRuleUpperAndLowerLetter = testDataManager.getTestInputRegionData("resetPassword.passwordRuleUpperAndLowerLetter");

    final String passwordRule1Number = testDataManager.getTestInputRegionData("resetPassword.passwordRule1Number");

    @FindBy(css = ".specs-pl-3")
    private WebElementFacade forgetPasswordLink;

    @FindBy(id = "edit-name")
    private WebElementFacade emailAddress;

    @FindBy(id = "edit-submit")
    private WebElementFacade sendButton;

    static String emailId = null;

    @FindBy(id = "edit-pass-pass1")
    public WebElementFacade password;

    @FindBy(id = "edit-pass-pass2")
    public WebElementFacade confirmPassword;

    @FindBy(id = "edit-submit")
    public WebElementFacade loginButton;

    @FindBy(css=".password-suggestions")
    public WebElementFacade passwordRule;

    @FindBy(css="#messages-help-wrapper > div")
    public WebElementFacade passwordSuccessMsg;

    public void clickforgetPasswordLink() {
        logger.info("STEP: user Click on forget password Link");
        clickElement(forgetPasswordLink);
    }

    public void fillEmailIAndClickSendButton(String emailId) {
        logger.info("entering email: " + emailId);
        setText(this.emailAddress,emailId);
        clickElement(sendButton);
    }

    public void enterCredentials() {
        setText(this.password, newPassword);
        setText(this.confirmPassword, newConfirmPassword);
        clickElement(this.loginButton);
        logger.info("STEP: verify user password has been reset successful for the user");
        assertPageObjectIsDisplayed(passwordSuccessMsg);
    }

    public void verifyPasswordRuleMessage(){
        waitABit(10000);
        clickElement(this.password);
        logger.info("STEP: verify user password rule" + " - " + passwordRuleEnsurePwd);
        assertElementContainsText(passwordRule, passwordRuleEnsurePwd);
        logger.info("STEP: verify user password rule" +  " - " + passwordRuleMin8Char);
        assertElementContainsText(passwordRule, passwordRuleMin8Char);
        logger.info("STEP: verify user password rule" + " - " + passwordRuleUpperAndLowerLetter);
        assertElementContainsText(passwordRule, passwordRuleUpperAndLowerLetter);
        logger.info("STEP: verify user password rule" + " - " + passwordRule1Number);
        assertElementContainsText(passwordRule, passwordRule1Number);
    }
}
