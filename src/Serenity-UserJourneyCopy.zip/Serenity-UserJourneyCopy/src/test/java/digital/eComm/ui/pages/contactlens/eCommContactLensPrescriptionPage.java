package digital.eComm.ui.pages.contactlens;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.extensions.util.eCommCurrencyHandler;
import digital.eComm.ui.pages.eCommBasketPage;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommContactLensPrescriptionPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    eCommBasketPage eCommBasketPage;
    eCommCurrencyHandler eCommCurrencyHandler;

    String productAmount;

    String totalPayableAmount;

    private String amount = null;

    @FindBy(css = "#edit-eyes-right-eye-base-curve-button")
    private WebElementFacade rightEyeBaseCurve;

    @FindBy(css = "#edit-eyes-left-eye-base-curve-button")
    private WebElementFacade leftEyeBaseCurve;

    @FindBy(css = "#edit-eyes-right-eye-power--2-button")
    private WebElementFacade rightEyeSphere;

    @FindBy(css = "#edit-eyes-left-eye-power--2-button")
    private WebElementFacade leftEyeSphere;

    @FindBy(id = "edit-payment-payment-switcher")
    private WebElementFacade oneOffRadioButton;

    @FindBy(id = "edit-subscribe-subscribe-switcher")
    private WebElementFacade subscriptionRadioButton;

    @FindBy(css = "button#edit-payment-add-to-basket")
    private WebElementFacade addToBasketButton;

    @FindBy(css = "button#edit-payment-add-to-basket")
    private WebElementFacade addOneOffToBasket;

    @FindBy(css = "button#edit-subscribe-add-to-basket")
    private WebElementFacade addSubscriptionToBasket;

    @FindBy(xpath = "//span[@class='price-from-discount']")
    private WebElementFacade priceFromDiscount;

    @FindBy(xpath = "//span[@class='price-now-discount']")
    private WebElementFacade priceNowAfterDiscount;

    @FindBy(css = "div#cl-product-info span.price-value.text-black")
    private WebElementFacade itemPrice;

    @FindBy(css = "div#rxentry-modal div.one-off-selected > div.quantity.payment-section.clearfix > div.quantity-selects > div:nth-child(2) > div > div > span > a > span.ui-selectmenu-status")
    private WebElementFacade rightEyeQty;

    @FindBy(css = "div#rxentry-modal div.one-off-selected > div.quantity.payment-section.clearfix > div.quantity-selects > div:nth-child(1) > div > div > span > a > span.ui-selectmenu-status")
    private WebElementFacade leftEyeQty;

    @FindBy(css = "div#new-total-payment > span")
    private WebElementFacade subTotalAmount;

    @FindBy(css = "div#payment-shipping-cost > span.line-value.shipping-cost.green-bold")
    private WebElementFacade deliveryCharges;

    @FindBy(css = "div#payment-you-pay > span")
    private WebElementFacade PaymentYouPay;

    @FindBy(css = "#edit-eyes-right-eye-power--2-button")
    private WebElementFacade rightEyeStrenght;

    @FindBy(css = "#edit-eyes-left-eye-power--2-button")
    private WebElementFacade leftEyeStrenght;

    @FindBy(css = "#edit-eyes-right-eye-add-type--2-button")
    private WebElementFacade rightEyeType;

    @FindBy(css = "#edit-eyes-left-eye-add-type--2-button")
    private WebElementFacade leftEyeType;

    public void selectRightEyeBaseCurve(String rightBaseCurve) {
        selectOptionFromDropdown(this.rightEyeBaseCurve, rightBaseCurve);
    }

    public void selectLeftEyeBaseCurve(String leftBaseCurve) {
        selectOptionFromDropdown(this.leftEyeBaseCurve, leftBaseCurve);
    }

    public void selectRightEyeSphere(String rightSphere) {

        selectOptionFromDropdown(this.rightEyeSphere, rightSphere);
    }

    public void selectLeftEyeSphere(String leftSphere) {

        selectOptionFromDropdown(this.leftEyeSphere, leftSphere);
    }

    public void selectRightEyeStrenght(String rightStrenght) {
        selectOptionFromDropdown(this.rightEyeStrenght, rightStrenght);
    }

    public void selectLeftEyeStrenght(String leftStrenght) {
        selectOptionFromDropdown(this.leftEyeStrenght, leftStrenght);
    }

    public void selectRightEyeType(String rightType) {

        selectOptionFromDropdown(this.rightEyeType, rightType);
    }

    public void selectLeftEyeType(String leftType) {

        selectOptionFromDropdown(this.leftEyeType, leftType);
    }

    public void clickOneOffRadioButton() {
        clickElement(this.oneOffRadioButton);
    }

    public void clickAddOneOffToBasket() {
        clickElement(this.addOneOffToBasket);
    }

    public void clickAddToBasketButton() {

        clickElement(this.addToBasketButton);
        logger.info("VALIDATE: Check basket page is displayed and is not empty");
        assertElementContainsText(eCommBasketPage.getNonEmptyBasketTitle(), testDataManager.getTestAssertionData("contentTitles.nonEmptyBasketPage"));
    }

    public void clickAddSubscriptionToBasket() {
        clickElement(this.addSubscriptionToBasket);
    }

    public WebElementFacade getSubscriptionRadioButton() {
        return subscriptionRadioButton;
    }

    public WebElementFacade getRightEyeBaseCurve() {
        return rightEyeBaseCurve;
    }

    //Feature Flags & Region Specific Feature Rules
    public Boolean featureSeparatePrescriptionPageOn() {
        return testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class);
    }

    public void theUserConfirmsPayableAmountBasedOnTheQty() {

       logger.info("User confirm product price for one off order after adding left and right eye quantity on a pdp page");

        if (priceNowAfterDiscount.isPresent()){

            logger.info("Product price on a pdp page ::{} ", getProductBasePrice(priceFromDiscount));
            final int rightEyeQty = Integer.parseInt(getElementText(this.rightEyeQty));
            final int leftEyeQty = Integer.parseInt(getElementText(this.leftEyeQty));

            int totalQty = rightEyeQty + leftEyeQty;

            Double productPrice = getProductBasePrice(priceFromDiscount) * totalQty;
            this.productAmount = eCommCurrencyHandler.getRegionalCurrency(productPrice);

            logger.info("Total qty on a pdp page {}, so calculating total price based on left and right eye qty::{} ", totalQty, this.productAmount);
            assertNormalizeStringText(getAndTrimText(subTotalAmount), this.productAmount);

        } else {
            logger.info("Product price on a pdp page ::{} ", getProductBasePrice(itemPrice));

            final int rightEyeQty = Integer.parseInt(getElementText(this.rightEyeQty));
            final int leftEyeQty = Integer.parseInt(getElementText(this.leftEyeQty));

            int totalQty = rightEyeQty + leftEyeQty;

            Double productPrice = getProductBasePrice(itemPrice) * totalQty;

            this.productAmount = eCommCurrencyHandler.getRegionalCurrency(productPrice);

            logger.info("Total qty on a pdp page {}, so calculating total price based on left and right eye qty::{} ", totalQty, this.productAmount);

            assertNormalizeStringText(getAndTrimText(subTotalAmount), this.productAmount);

            Double deliveryAmount = getProductBasePrice(deliveryCharges);
            logger.info("Delivery Amount ::{} ", deliveryAmount);

            totalPayableAmount = String.valueOf(deliveryAmount + productPrice);
            this.productAmount = eCommCurrencyHandler.getRegionalCurrency(Double.valueOf(totalPayableAmount));
            logger.info("You pay  ::{} ", this.productAmount);
            assertNormalizeStringText(getAndTrimText(PaymentYouPay), this.productAmount);

            setTotalPayableAmount(getAndTrimText(PaymentYouPay));
        }
    }

    public String getTotalPayableAmount() {
        logger.info("getTotalPayableAmount  ::{} ", amount);
        return this.amount;
    }

    public void setTotalPayableAmount(String amount) {
        logger.info("setTotalPayableAmount  ::{} ", amount);
        this.amount = amount;
    }

    public String theUserRetrievePayableAmount() {

        return eCommBasketPage.theUserRetrieveAmount();
    }
}
