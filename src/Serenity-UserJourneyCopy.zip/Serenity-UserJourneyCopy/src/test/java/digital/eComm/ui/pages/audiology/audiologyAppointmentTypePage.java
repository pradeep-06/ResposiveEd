package digital.eComm.ui.pages.audiology;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class audiologyAppointmentTypePage extends BasePageObject {

    @FindBy(css="div#appointment-type-10011")
    private WebElementFacade hearingTestButton;

    @FindBy(css="div#appointment-type-10010")
    private WebElementFacade hearingAidConsultationTestButton;

    @FindBy(css="div#appointment-type-10021")
    private WebElementFacade hearingAidWearersTestButton;

    @FindBy(css="div#appointment-type-10022")
    private WebElementFacade hearingAidMaintenanceTestButton;

    @FindBy(css="div#appointment-type-10030")
    private WebElementFacade hearingAidProtectionTestButton;

    @FindBy(css="div#appointment-type-10040")
    private WebElementFacade earWaxRemovalTestButton;

    @FindBy(css="#appointments-book-button")
    private WebElementFacade bookSlotButton;

    public void UserClicksOnHearingTestType() { clickElement(this.hearingTestButton); }

    public void UserClicksOnBookSlotButton() { clickElement(this.bookSlotButton);waitABit(5000);
    }
}
