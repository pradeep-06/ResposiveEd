package digital.eComm.ui.extensions.util;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommGSTCalculator extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommGSTCalculator.class);
    Double gstTaxAmount;

    Double productPrice;

    Double deliveryAmount;

    public Double getGSTAmount(Double totalPayableAmount, Double gstValue, Integer productQty) {

        switch (Staf.getTargetRegion()) {

            case "nl":
                productPrice = totalPayableAmount / productQty;
                logger.info("product price calculated based on the total amount and qty :: {}", productPrice);
                gstTaxAmount = productPrice - (productPrice / (1 + gstValue));
                gstTaxAmount = gstTaxAmount * productQty;
                gstTaxAmount = gstTaxAmount + 0.01;
                break;
            case "uk":
                productPrice = totalPayableAmount / productQty;
                logger.info("product price calculated based on the total amount and qty :: {}", productPrice);
                gstTaxAmount = productPrice - (productPrice / (1 + gstValue));
                gstTaxAmount = gstTaxAmount * productQty;
                gstTaxAmount = gstTaxAmount + 0.03;
                break;
            case "au":
            case "no":
            case "nz":
                productPrice = totalPayableAmount / productQty;
                logger.info("product price calculated based on the total amount and qty :: {}", productPrice);
                gstTaxAmount = productPrice - (productPrice / (1 + gstValue));
                gstTaxAmount = gstTaxAmount * productQty;
                gstTaxAmount = gstTaxAmount + 0.03;
                break;
            case "se":
            case "fi":
                productPrice = totalPayableAmount / productQty;
                logger.info("product price calculated based on the total amount and qty :: {}", productPrice);
                gstTaxAmount = productPrice - (productPrice / (1 + gstValue));
                gstTaxAmount = gstTaxAmount * productQty;
                gstTaxAmount = gstTaxAmount + 0.03;
                break;
            case "dk":
            case "ie":
                productPrice = totalPayableAmount / productQty;
                logger.info("product price calculated based on the total amount and qty :: {}", productPrice);
                gstTaxAmount = productPrice - (productPrice / (1 + gstValue));
                gstTaxAmount = gstTaxAmount * productQty;
                break;
            default:
                logger.info("Invalid region!!!");
                break;
        }

        return gstTaxAmount;
    }

    public Double getGSTOnADeliveryAmount(Double deliveryAmount) {

        logger.info("Retrieve GST on a delivery amount :: {}", deliveryAmount);

        final TestDataManager testDataManager = new TestDataManager();
        final Double gstShippingValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstShippingValue"));

        logger.info("DeliveryAmount :: " + deliveryAmount);
        deliveryAmount = deliveryAmount - (deliveryAmount / (1 + gstShippingValue));


        logger.info("Retrieve GST on a delivery amount :: {}", deliveryAmount);
        return deliveryAmount;
    }

}
