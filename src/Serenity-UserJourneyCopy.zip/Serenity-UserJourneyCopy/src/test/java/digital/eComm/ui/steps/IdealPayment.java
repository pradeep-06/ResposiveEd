package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.checkout.ideal.eCommIdealAuthorizePage;
import digital.eComm.ui.pages.checkout.ideal.eCommIdealDetailsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IdealPayment extends ScenarioSteps {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(IdealPayment.class);

    eCommIdealAuthorizePage eCommIdealAuthorizePage;
    eCommIdealDetailsPage eCommIdealDetailsPage;

    public void theUserSelectsBankDetails() {
        eCommIdealDetailsPage.selectBank();
    }

    public void theUserPerformAuthorization() {
        eCommIdealAuthorizePage.selectAuthorizationButton();
    }
}
