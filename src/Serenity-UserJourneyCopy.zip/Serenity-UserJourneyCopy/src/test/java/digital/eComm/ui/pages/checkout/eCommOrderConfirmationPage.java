package digital.eComm.ui.pages.checkout;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommOrderConfirmationPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(id = "edit-password-pass-pass1")
    private WebElementFacade editPassword;

    @FindBy(id = "edit-password-pass-pass2")

    private WebElementFacade editConfirmPassword;

    @FindBy(xpath = "//div[@class='checkout-completion-message']//h2")
    private WebElementFacade orderId;

    @FindBy(xpath = "(//div[@class='views-field views-field-order-number']/span[@class='field-content']//a)[1]")
    private WebElementFacade lensReplacementOrderId;

    @FindBy(css = ".component-type-commerce-price-formatted-amount .component-total")
    private WebElementFacade costEle;

    @FindBy(xpath = "//*[@id=\"edit-payment-schedule\"]/div[2]/div/table[2]/tbody/tr[1]/td[2]")
    private WebElementFacade installmentEle;

    @FindBy(id = "edit-password-save")
    private WebElementFacade saveDetailsButton;

    @FindBy(xpath = "//*[@id='edit-checkout-completion-message-body']/button")
    private WebElementFacade invoiceOfOrder;

    @FindBy(xpath = "//*[@id=\"edit-commerce-checkout-confirmation-body\"]/div/fieldset[2]/div/div/div[2]/div/div/div/table/tbody/tr[1]/td[2]")
    private WebElementFacade discountPrice;

    @FindBy(xpath = "//*[@id=\"block-system-main\"]/div/div[2]/div/div/div[2]/div[2]/div/div/div[1]/div[1]/span[2]/font/font")
    private WebElementFacade subTotal;

    @FindBy(xpath = "//*[@id=\"block-system-main\"]/div/div[2]/div/div/div[2]/div[2]/div/div/div[1]/div[3]/ul/li/span[1]/font/font")
    private WebElementFacade discountAmount;

    @FindBy(css = "h1#page-title")
    private WebElementFacade orderConfirmation;

    @FindBy(css = "h1#page-title")
    private WebElementFacade pageTitle;

    @FindBy(xpath = "//*[contains(@class, 'btn-upsell')]")
    private WebElementFacade printInvoiceButton;

    @FindBy(css = "div.de-qualifier-block.view-mode-view > ul > li > a")
    private WebElementFacade discountTitle;

    @FindBy(css = "a[trackaid='header-my-account']")
    private WebElementFacade myAccount;

    @FindBy(css = "a[trackaid='header-orders']")
    private WebElementFacade myOrder;

    @FindBy(css = ".collapsed a")
    private WebElementFacade myWallet;

    @FindBy(css = ".fa-trash--lg")
    private WebElementFacade deleteButtonAtSavedCard;

    @FindBy(css = ".block-system p")
    private WebElementFacade deleteConfirmationMessage;

    public void enterEditPassword(String password) {
        setText(this.editPassword, password);
    }

    public void enterEditConfirmPassword(String password) {
        setText(this.editConfirmPassword, password);
    }

    public void clickSaveDetailsButton() {
        evaluateScriptClick(this.saveDetailsButton);
    }

    public String getOrderIdText() {
        return getElementText(orderId);
    }

    public String getLensReplacementOrderIdText(){return getElementText(lensReplacementOrderId);}

    public String getCostIdText() {
        return getAndTrimText(costEle);
    }
    public String getInstallmentCostText() {
        return getAndTrimText(installmentEle);
    }
/*
    public void clickInvoiceOfOrder() {
        evaluateScriptClick(this.invoiceOfOrder);
    }
*/

    public String getDiscountPrice() {
        return discountPrice.getText();
    }

    public String getSubTotal() {
        return subTotal.getText();

    }

    public String getDiscountAmount() {
        return discountAmount.getText();
    }

    public void assertOrderConfirmationMessage(String orderConfirmationMsg) {
        logger.info("VALIDATE order confirmation message");
        assertElementText(orderConfirmation, orderConfirmationMsg);
    }

    public WebElementFacade getPageTitle() {
        return pageTitle;
    }

    public void selectPrintInvoiceButton() {

        evaluateScriptClick(printInvoiceButton);
    }

    public void check2for1Discount(String discountText) {
        assertElementContainsText(discountTitle, discountText);
    }

    public void clickMyAccountLink() {
        logger.info("Mouse hovering at my account link");
        withAction().moveToElement(myAccount).perform();
    }

    public void clickMyOrderLink() {
        logger.info("Select my order link");
        clickElement(this.myOrder);
    }

    public void clickMyWallet() {
        logger.info("Click on myWallet link");
        clickElement(this.myWallet);
    }

    public void clickDeleteButton() {
        logger.info("Click on delete button");
        clickElement(this.deleteButtonAtSavedCard);
    }

    public void verifyDeleteCardMessage(String deleteCardText){
        logger.info("VALIDATE attempt to delete saved card confirmation message");
        assertElementText(deleteConfirmationMessage, deleteCardText);
    }
}