package digital.eComm.ui.stepDefinitions;

import Framework.Annotations.Common.WIP;
import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.pages.audiology.audiologyAppointmentTypePage;
import digital.eComm.ui.pages.audiology.audiologyConfirmationPage;
import digital.eComm.ui.pages.audiology.audiologyDateAndTimePage;
import digital.eComm.ui.pages.audiology.audiologyRecapPage;
import digital.eComm.ui.pages.checkout.customeraccount.eCommMyDetailsPage;
import digital.eComm.ui.pages.checkout.eCommCustomerDetailsPage;
import digital.eComm.ui.pages.checkout.eCommPaymentModePage;
import digital.eComm.ui.pages.checkout.eCommPrescriptionPage;
import digital.eComm.ui.pages.contactlens.eCommContactLensLandingPage;
import digital.eComm.ui.pages.contactlens.eCommContactLensPrescriptionPage;
import digital.eComm.ui.pages.customeraccount.eCommMyOrdersPage;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.pages.eCommPasswordResetPage;
import digital.eComm.ui.pages.eCommProductSearchPage;
import digital.eComm.ui.pages.glasses.eCommProductDetailedPage;
import digital.eComm.ui.pages.sharedModules.eCommWebsiteHeader;
import digital.eComm.ui.pages.sharedModules.expressreorder.eCommExpressReorderLandingPage;
import digital.eComm.ui.steps.*;
import net.serenitybdd.annotations.Pending;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class eCommStepDefinitions extends ScenarioSteps {
    private final Logger logger = LoggerFactory.getLogger(eCommStepDefinitions.class);
    String payableAmount;
    @Steps
    NavigateToeComm navigateTo;
    @Steps
    eCommContactLensPrescriptionPage eCommContactLensPrescriptionPage;
    @Steps
    eCommContactLensLandingPage contactLensLandingPage;
    @Steps
    AddLensToBasket addLensToBasket;
    @Steps
    AddGlassesToBasket addGlassesToBasket;
    @Steps
    OrderCheckOut orderCheckOut;
    @Steps
    eCommWebsiteHeader websitePrimaryNavigation;
    @Steps
    eCommMyOrdersPage myOrdersPage;
    @Steps
    eCommMyDetailsPage myDetailsPage;
    @Steps
    eCommPrescriptionPage eCommPrescriptionPage;
    @Steps
    eCommHomePage eCommHomePage;
    @Steps
    eCommPaymentModePage eCommPaymentModePage;
    @Steps
    eCommProductSearchPage eCommProductSearchpage;
    @Steps
    AudiologyFindStorePage AudiologyfindStorePage;
    @Steps
    audiologyAppointmentTypePage AudiologyAppointmentTypePage;
    @Steps
    audiologyDateAndTimePage AudiologyDateAndTimePage;
    @Steps
    AudiologyPersonalDetails AudiologyPersonalDetails;
    @Steps
    audiologyRecapPage AudiologyRecapPage;
    @Steps
    audiologyConfirmationPage AudiologyConfirmationPage;
    @Steps
    DrupalHome drupalHome;
    @Steps
    XMLConfirmation xmlConfirmation;
    @Steps
    DrupalDiscount addDiscount;
    @Steps
    LensExpressReorder lensExpressReorder;
    @Steps
    PaypalPayment paypalPayment;
    @Steps
    IdealPayment idealPayment;
    @Steps
    AddNewCard addNewCardDetails;
    @Steps
    eCommExpressReorderLandingPage eCommExpressReorderLandingPage;
    @Steps
    eCommProductDetailedPage productDetailedPage;

    @Steps
    eCommCustomerDetailsPage eCommCustomerDetailsPage;

    @Steps
    eCommPasswordResetPage eCommPasswordResetPage;

    @Steps
    DrupalCustomerDetails drupalCustomerDetails;

    protected final TestDataManager testDataManager = new TestDataManager();
    List<Integer> pids = new ArrayList<Integer>();

    public void openeCommHome() {
        navigateTo.theHomePage();
    }

    public void openeCommHomeAndAcceptCookies() {

        String environment = Staf.getEnvironment();
        logger.info("current testing environment :: {} ", environment);

        openeCommHome();
        navigateTo.theUserAcceptCookies();
    }

    @Step("GIVEN I am on the basket page WHEN I apply the GIVE25OFF promo code in the basket THEN the basket should display the promo code GIVE25OFF applied with the total that was affected by the promo code.")
    public void useCode() {
        addLensToBasket.enterPromocodeDetails();
    }

    @Step("GIVEN I am on the drupal home page WHEN A line level discount has been added THEN line level discount is available in the active discount.")
    public void lineLevelDiscountHasBeenSetupInDrupal() {

        final String menu = testDataManager.getTestInputRegionData("drupal.discount.menu.main");
        final String subMenu = testDataManager.getTestInputRegionData("drupal.discount.menu.submenu");

        navigateTo.theLoginHomePage().theUserAcceptCookies();
        navigateTo.theAdminUserLoginWithCredentials();
        drupalHome.theUserNavigateThroughMenu(menu, subMenu);
        addDiscount.theUserConfirmAvailabilityOfLineLevelDiscount();
        drupalHome.theAdminUserSelectsLogoutLink();
    }

    @Step("GIVEN I am on the drupal home page WHEN GIVE25OFF promo code is added with 1 maximum redemption count THEN GIVE25OFF promo code is available in the active promo admin title.")
    public void codeHasBeenSetupInDrupal() {

        final String menu = testDataManager.getTestInputRegionData("drupal.discount.menu.main");
        final String subMenu = testDataManager.getTestInputRegionData("drupal.discount.menu.submenu");

        navigateTo.theLoginHomePage().theUserAcceptCookies();
        navigateTo.theAdminUserLoginWithCredentials();
        drupalHome.theUserNavigateThroughMenu(menu, subMenu);
        addDiscount.theUserConfirmAvailabilityOfCoupon();
    }

    @Step("GIVEN I am on the drupal home page WHEN A order level discount has been added THEN line level discount is available in the active discount.")
    public void discountHasBeenSetupInDrupal() {
        addDiscount.theUserConfirmAvailabilityOfDiscount();
        drupalHome.theAdminUserSelectsLogoutLink();
    }

    @Step("Given I am on the checkout page with a discount applied")
    public void discountHasBeenAppliedInCheckout() {

        final String contactLensProduct = testDataManager.getTestInputRegionData("purchasing.contactLens.availableProduct.sku");
        final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");
        final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");

        logger.info("Contact lens product :: {} ", contactLensProduct);
        navigateTo.theUserAcceptCookies();
        addLensToBasket.selectContactLensProduct(contactLensProduct);

        if (testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class)) {
            addLensToBasket.selectProductQuantity(leftEyeQty, rightEyeQty);
        }

        addLensToBasket.selectPrescriptionButton().theUserSelectPrescriptionValues();
        addLensToBasket.enterPromocodeDetails();
        addLensToBasket.selectCheckOutSecurely();
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer().theUserAddAddressDetails();
        orderCheckOut.theUserConfirmPrescriptionDetails();
        orderCheckOut.selectVisaCardForThePayment();
        orderCheckOut.theUserAddCardDetails();
        orderCheckOut.checkInvoiceAndVerifyDiscount();
    }

    @Pending
    @Step("Given the subscription option is available when a customer selects a pair of contact lenses (see picture)")
    public void buyContactLenses() {
    }

    @Pending
    @Step("Click on any pair of glasses in the PLP")
    public void ClickOnAnyPairOfGlassesInThePLP() {
    }

    @Pending
    @Step("Make sure that the selected pair can be ordered online")
    public void MakeSureThatTheSelectedPairCanBeOrderedOnline() {
    }

    @Pending
    @Step("Click input prescription (localised)")
    public void ClickInputPrescription() {
    }

    @Pending
    @Step("Input required inputs into the form")
    public void InputRequiredInputsIntoTheForm() {
    }

    @Pending
    @Step("WHEN I complete a purchase for using a WorldPay payment method")
    public void WhenICompleteAPurchaseForUsingAWorldPayPaymentMethod() {
    }

    @Step("Given there are products available in the PLP")
    public void GivenThereAreProductsAvailableInThePLP() {

        final String ophthalmicFrames = testDataManager.getTestInputRegionData("purchasing.glasses.availableProduct.sku");
        logger.info("ophthalmic frames product :: {} ", ophthalmicFrames);

        navigateTo.theUserAcceptCookies();
        addGlassesToBasket.theGuestUserSelectOneOphthalmicFrames(ophthalmicFrames);
        Assertions.assertThat(eCommProductSearchpage.productCode()).isEqualTo(ophthalmicFrames);
    }

    @Step("Ensure values are correct after applying discount code on contact lenses")
    public void EnsureValuesAreCorrectAfterApplyingDiscountCodeOnContactLenses() {

        final String contactLensProduct = testDataManager.getTestInputRegionData("purchasing.contactLens.availableProduct.sku");
        final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");
        final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");

        logger.info("Contact lens product :: {} ", contactLensProduct);

        navigateTo.theUserAcceptCookies();
        addLensToBasket.selectContactLensProduct(contactLensProduct);

        if (testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class)) {
            addLensToBasket.selectProductQuantity(leftEyeQty, rightEyeQty);
        }

        addLensToBasket.selectPrescriptionButton();
        addLensToBasket.theUserSelectPrescriptionValues();
        addLensToBasket.enterPromocodeDetails();
        addLensToBasket.selectCheckOutSecurely();
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer().theUserAddAddressDetails();
        orderCheckOut.theUserConfirmPrescriptionDetails();
        orderCheckOut.selectVisaCardForThePayment().theUserAddCardDetails();
        orderCheckOut.checkInvoiceAndVerifyDiscount();
    }

    @Pending
    @Step("GIVEN user is on the recall booking journey")
    public void GIVENUserIsOnTheRecallBookingJourney() {
    }

    @Pending
    @Step("WHEN the user navigates to 'Additional information' page")
    public void WHENTheUserNavigatesToAdditionalInformationPage() {
    }

    @Pending
    @Step("WHEN the user confirms the booking")
    public void WHENTheUserConfirmsTheBooking() {
    }

    @Pending
    @Step("WHEN the user amends the date/time of the booking (after")
    public void WHENTheUserAmendsTheDateTimeOfTheBooking() {
    }

    @Pending
    @Step("WHEN the user selects 'Confirm your booking'")
    public void WHENTheUserSelectsConfirmYourBooking() {
    }

    @Pending
    @Step("WHEN the user clicks 'cancel booking'")
    public void WHENTheUserClicksCancelBooking() {
    }

    @WIP
    @Step("Navigate to /book/{location}-hearing/appointment-type")
    public void NavigateToBookLocationHearingAppointmentType() {
        AudiologyfindStorePage.enterAudiologyFindLocationDetails();
    }

    @WIP
    @Step("Choose any appointment type")
    public void ChooseAnyAppointmentType() {
        AudiologyAppointmentTypePage.UserClicksOnHearingTestType();
        AudiologyAppointmentTypePage.UserClicksOnBookSlotButton();
    }

    @WIP
    @Step("Select an appropriate appointment slot")
    public void SelectAnAppropriateAppointmentSlot() {
        AudiologyDateAndTimePage.UserSelectsDateSlot();
        AudiologyDateAndTimePage.UserSelectsTimeSlot();
        AudiologyDateAndTimePage.UserSelectsContinueButton();
    }

    @WIP
    @Step("Enter required data")
    public void EnterRequiredData() {
        AudiologyPersonalDetails.UserEntersPersonalDetails();
    }

    @WIP
    @Step("user validates details on recap page")
    public void ValidateRecapAndContinue() {
        AudiologyRecapPage.UserValidatesDetailsOnRecapPage();
    }

    @WIP
    @Step("user validates details on Confirmation page")
    public void ValidateConfirmationPage() {
        AudiologyConfirmationPage.UserValidatesDataOnConfirmationPage();
    }

    @Pending
    @Step("Tokenised - A customer can complete the tokenised journey")
    public void TokenisedACustomerCanCompleteTheTokenisedJourney() {
    }

    @Step("Add a pair of glasses to the basket")
    public void AddAPairOfGlassesToTheBasket() {
        addGlassesToBasket.theUserFillPrescriptionDetails();
        addGlassesToBasket.theGuestUserSelectLensType();
        addGlassesToBasket.selectHealthFund();
        addGlassesToBasket.enterPromoCodeDetails();
        addGlassesToBasket.selectCheckOutSecurely();
    }

    @Step("User is on the glasses landing page BASEURL/briller")
    public void userIsOnTheGlassesLandingPage() {
        navigateTo.theUserAcceptCookies();
        final String ophthalmicFrames = testDataManager.getTestInputRegionData("purchasing.glasses.availableProduct.sku");

        logger.info("ophthalmic frames product :: {} ", ophthalmicFrames);
        addGlassesToBasket.theGuestUserSearchesOphthalmicFrames(ophthalmicFrames);
    }

    @Step("Click on any pair of glasses in the PLP")
    public void clickOnAnyPairOfGlassesinThePlp() {
        //Force pass because we haven't covered this yet or the test case needs to changed
    }

    @Step("Make sure that the selected pair can be ordered online")
    public void makeSureThatTheSelectedPairCanBeOrderedOnline() {
        //Force pass because we haven't covered this yet or the test case needs to changed
    }

    @Step("Click Buy online")
    public void clickOnBuyOnlineButton() {
        logger.info("the user selects a buy online button");
        addGlassesToBasket.theUserSelectBuyOnlineButton();
    }

    @Step("Input required inputs into the form")
    public void inputRequiredInputsIntoTheForm() {
        addGlassesToBasket.theUserFillPrescriptionDetails();
        addGlassesToBasket.theGuestUserSelectLensType();
        addGlassesToBasket.selectHealthFund();
        addGlassesToBasket.selectCheckOutSecurely();
    }

    @Step("WHEN I complete a purchase for using a WorldPay payment method")
    public String whenICompleteAPurchaseForUsingWorldPayItShouldSucceed() {
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer();
        orderCheckOut.theUserAddAddressDetails();
        orderCheckOut.theUserConfirmPrescriptionInformation();
        orderCheckOut.selectVisaCardForThePayment();
        orderCheckOut.theUserAddCardDetails();
        String orderNo = orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessageOnly();
        return orderNo;
    }

    @Step("WHEN I complete a purchase for using a PAYPAL payment method")
    public void whenICompleteAPurchaseForUsingPaypalItShouldSucceed() {

        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer();
        orderCheckOut.theUserAddAddressDetails();
        orderCheckOut.theUserConfirmPrescriptionInformation();
        orderCheckOut.selectPaypalForThePayment();
        paypalPayment.theUserEnterPaypalDetails();
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessage();
    }

    @Step("WHEN I complete a purchase for using a WorldPay payment method and discount")
    public void whenICompleteAPurchaseForUsingWorldPayItShouldSucceedWithDiscount() {

        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer().theUserAddAddressDetails();
        orderCheckOut.selectVisaCardForThePayment();
        orderCheckOut.theUserAddCardDetails();
        orderCheckOut.checkInvoiceAndVerifyDiscount();
    }

    @Step("WHEN I complete a purchase for Contact Lenses using a Medipass V3")
    public void buyContactLensWithMedipass() {

        final String contactLensProduct = testDataManager.getTestInputRegionData("purchasing.contactLens.availableProduct.sku");
        final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");
        final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");

        logger.info("Contact lens product :: {} ", contactLensProduct);

        navigateTo.theUserAcceptCookies();
        addLensToBasket.selectContactLensProduct(contactLensProduct);

        if (testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class)) {
            addLensToBasket.selectProductQuantity(leftEyeQty, rightEyeQty);
        }

        addLensToBasket.selectPrescriptionButton().theUserSelectPrescriptionValues();
        addLensToBasket.selectCheckOutSecurely();
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer().theUserAddAddressDetails();
        orderCheckOut.selectMedipassForThePayment();
        orderCheckOut.theUserHealthFundDetailsSkipAndPayFull();
        //orderCheckOut.skipAndPayAmount();
        orderCheckOut.medipassCardDetails();
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessage();
    }

    @Step("WHEN I complete a purchase for Contact Lenses using a Medipass V3")
    public void buyContactLensWithMedipassISF() {

        final String contactLensProduct = testDataManager.getTestInputRegionData("purchasing.contactLens.availableProduct.sku");
        final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");
        final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");

        logger.info("Contact lens product :: {} ", contactLensProduct);

        navigateTo.theUserAcceptCookies();
        addLensToBasket.selectContactLensProduct(contactLensProduct);

        if (testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class)) {
            addLensToBasket.selectProductQuantity(leftEyeQty, rightEyeQty);
        }

        addLensToBasket.selectPrescriptionButton().theUserSelectPrescriptionValues();
        addLensToBasket.selectCheckOutSecurely();
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomer().theUserAddAddressDetails();
        orderCheckOut.selectMedipassForThePaymentISF();
        orderCheckOut.theUserHealthFundDetails();
        // orderCheckOut.skipAndPayAmount();
        orderCheckOut.medipassCardDetailsISF();
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessage();
    }

    @Step("WHEN a returning user complete a purchase for glasses using a WorldPay payment method")
    public void whenExistingUserCompleteAPurchaseUsingWorldPayItShouldSucceed() {

        orderCheckOut.theUserClicksIAmExistingCustomer();
        orderCheckOut.theExistingUserLoginWithTheCredentials().theUserContinueWithTheExistingAddressDetails();
        orderCheckOut.selectVisaCardForThePayment();
        orderCheckOut.theUserAddCardDetails();
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserConfirmsOrderConfirmationMessage();
    }

    @Step("WHEN existing customer complete a purchase for glasses using a saved card payment method")
    public void whenExistingUserCompleteAPurchaseForUsingSavedCard() {

        orderCheckOut.theUserClicksIAmExistingCustomer();
        orderCheckOut.theExistingUserLoginWithTheCredentials().theUserContinueWithTheExistingAddressDetails();
        orderCheckOut.selectSavedCardForThePayment().theUserRetrieveOrderNumber();
        orderCheckOut.theUserConfirmsOrderConfirmationMessage();
    }

    @Step("As any user, GIVEN I am on the eCommerce Homepage, WHEN I click on the primary navigation link 'Contact Lens', THEN the COntact Lens landing page is displayed")
    public void userNavigatesToContactLensPageViaPrimaryNavLinkFromNewBrowser() {
        closeSession(); //close existing session if it exists
        openeCommHomeAndAcceptCookies();

        if (!Staf.getTargetRegion().equals("dk")) {
            logger.info("STEP: userNavigatesToContactLensPageViaPrimaryNavLink");
            navigateTo.theContactLensLandingPage();
        }
    }

    @Step("As any user, GIVEN I am on the eCommerce Homepage, WHEN I click on the primary navigation link 'Contact Lens', THEN the COntact Lens landing page is displayed")
    public void userNavigatesToContactLensPageViaPrimaryNavLink() {

 /*       if (!Staf.getTargetRegion().equalsIgnoreCase("dk") && !Staf.getTargetRegion().equalsIgnoreCase("fi") && !Staf.getTargetRegion().equalsIgnoreCase("no")) {
            logger.info("STEP: userNavigatesToContactLensPageViaPrimaryNavLink");
            navigateTo.theContactLensLandingPage();
        }*/
    }

    @Step("As any user, GIVEN I am on the eCommerce Homepage, WHEN I click on the Sign in button , THEN the Log-in page is displayed")
    public void userNavigatesToLoginPage() {
        navigateTo.theSignInPage();
    }

    @Step("As any user, GIVEN I am on the Sign in page, WHEN I click on the forget password link, THEN the forget password page is displayed")
    public void userNavigatesToForgetPasswordPage() {
        eCommPasswordResetPage.clickforgetPasswordLink();
    }

    @Step("As any user, GIVEN I am on the forget password page, WHEN I enter the user mail id and click on the send button, THEN the mal should go to the user mail id")
    public void userEnterTheEmailIdAndClickOnSend(String customerMailId) {
        eCommPasswordResetPage.fillEmailIAndClickSendButton(customerMailId);
    }


    @Step("As any user, GIVEN I am on the eComm Contact Lenses landing page, WHEN I click on a common brand from the Contact Lens primary navigation link, THEN the results will be refined to show only that brand of lenses")
    public void theUserNavigatesToBrandViaCommonBrandsLink() {
        theUserNavigatesToBrandViaCommonBrandsLink("");
    }

    @Step("As any user, GIVEN I am on the eComm Contact Lenses landing page, WHEN I click on a common brand from the Contact Lens primary navigation link, THEN the results will be refined to show only that brand of lenses")
    public void theUserNavigatesToBrandViaCommonBrandsLink(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        //DK have different execution flow & IE is failing while navigating through brand so to avoid failure added below code - Dipak
 /*       if (!Staf.getTargetRegion().equalsIgnoreCase("dk") && !Staf.getTargetRegion().equalsIgnoreCase("fi") && !Staf.getTargetRegion().equalsIgnoreCase("no")) {
            logger.info("STEP: guestUserNavigatesToBrandViaCommonBrandsLink");
            addLensToBasket.selectCommonBrand(userRole);
        }*/
    }

    //Product Selection & Details (Contact Lenses)
    @Step("As any user, GIVEN I am on the product page, WHEN I click on the first product THEN I am taken to that product's individual page")
    public void selectFirstContactLensProduct() {
        logger.info("STEP: selectFirstContactLensProduct");
        addLensToBasket.selectFirstProductListed();
    }

    @Step("AS any user, GIVEN I can see the 'search' area to look up a product, WHEN I enter in a valid SKU AND click on the item, THEN the product details page for that item is displayed.'")
    public void searchAndSelectContactLensProductBySku() {
        addLensToBasket.searchAndSelectContactLensProductBySku();
    }

    @Step("AS a user, GIVEN I am on the product's details page, WHEN I select a quantity from the Left Eye drop down, THEN the button 'Select Prescription' will remain available")
    public void specifyLeftEyeQuantity() {
        specifyLeftEyeQuantity("");
    }

    @Step("AS a user, GIVEN I am on the product's details page, WHEN I select a quantity from the Left Eye drop down, THEN the button 'Select Prescription' will remain available")
    public void specifyLeftEyeQuantity(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: specifyLeftEyeQuantity"));
        addLensToBasket.selectLeftEyeQuantity(userRole);
    }

    @Step("AS a user, GIVEN I am on the product page, WHEN I select a quantity from the Right Eye drop down, THEN the button 'Select Prescription' will remain available")
    public void specifyRightEyeQuantity() {
        specifyRightEyeQuantity("");
    }

    @Step("AS a user, GIVEN I am on the product page, WHEN I select a quantity from the Right Eye drop down, THEN the button 'Select Prescription' will remain available")
    public void specifyRightEyeQuantity(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: specifyRightEyeQuantity"));
        addLensToBasket.selectRightEyeQuantity(userRole);
    }

    @Step("AS a user, GIVEN I am on the product page, WHEN I select a quantity from the Right Eye drop down AND I click the button 'Select Prescription, THEN the 'Enter Your Prescription' module will be displayed.")
    public void specifyRightEyeQuantityAndClickSelectPrescription() {
        specifyRightEyeQuantityAndClickSelectPrescription("");
    }

    @Step("AS a user, GIVEN I am on the product page, WHEN I select a quantity from the Right Eye drop down AND I click the button 'Select Prescription, THEN the 'Enter Your Prescription' module will be displayed.")
    public void specifyRightEyeQuantityAndClickSelectPrescription(String userRole) {
        //Note where userRole = "" then common data will be selected
        logger.info("STEP: specifyRightEyeQuantityAndClickSelectSelectPrescription");
        addLensToBasket.selectRightEyeQuantityAndClickSelectPrescription(userRole);
        addLensToBasket.checkProductPriceAfterSelectingQty();
    }

    @Step("AS a user, GIVEN I am on the product page, WHEN I select a quantity from the Right and Left Eye drop downs AND I click the button 'Select Prescription, THEN the 'Enter Your Prescription' module will be displayed.")
    public void specifyLeftAndRightEyeQuantityAndClickSelectPrescription(String userRole) {
        //Note where userRole = "" then common data will be selected
        logger.info("STEP: specifyLeftAndRightEyeQuantityAndClickSelectPrescription");
        addLensToBasket.selectLeftEyeQuantity(userRole);
        addLensToBasket.selectRightEyeQuantityAndClickSelectPrescription(userRole);
        addLensToBasket.checkProductPriceAfterSelectingQty();
    }

    @Step("GIVEN I have entered a value for both Eyes WHEN I select 'Select prescription' THEN the Enter your Prescription popup is displayed")
    public void clickToSpecifyPrescription() {
        addLensToBasket.clickToSpecifyPrescriptionDetails();
    }

    //Prescription Details (Contact Lenses)
    @Step("AS any user, GIVEN I am on the 'Select Prescription' page, WHEN I enter valid values in the fields displayed AND I click on the 'Confirm' button, THEN the basket page is displayed")
    public void specifyPrescriptionDetailsAndContinue(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSpecifyPrescriptionDetailsAndContinue"));
        addLensToBasket.theUserSelectsPrescriptionValuesAndAddsToBasket("");
    }

    @Step("AS any user, GIVEN I am on the 'Select Prescription' page, WHEN I enter valid values in the fields displayed AND I click on the 'Confirm' button, THEN the basket page is displayed")
    public void specifyPrescriptionDetailsAndContinueMerken(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSpecifyPrescriptionDetailsAndContinue"));
        addLensToBasket.theUserSelectsPrescriptionValuesAndAddsToBasketMerken("");
    }

    //Prescription Details (Contact Lenses)
    @Step("AS any user, GIVEN I am on the 'Select Prescription' page, WHEN I enter valid values in the fields displayed AND I click on the 'Confirm' button, THEN the basket page is displayed")
    public void specifyPrescriptionDetailsAndContinue2(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSpecifyPrescriptionDetailsAndContinue"));
        //addLensToBasket.theUserSelectsPrescriptionValuesAndAddsToBasket("");
    }

    @Step("AS any user, GIVEN I am on the 'Select Prescription' page, WHEN I enter valid values in the fields displayed AND I click on the 'Confirm' button, THEN the basket page is displayed")
    public void specifyPrescriptionDetailsAndContinue() {
        specifyPrescriptionDetailsAndContinue("");
    }

    @Step("AS any user, GIVEN I am on the 'Select Prescription' page, WHEN I enter valid values in the fields displayed AND I click on the 'Confirm' button, THEN the basket page is displayed")
    public void specifyPrescriptionDetailsAndContinue2() {
        specifyPrescriptionDetailsAndContinue2("");
    }

    //Confirm product details
    @Step("AS any user, GIVEN I am on the basket page, WHEN I check basket , THEN I start confirming product details and payable amount before checkout")
    public void theUserConfirmProductDetailsBeforeCheckout() {
        logger.info(("STEP: VALIDATION user start validating product amount before checkout"));
        addLensToBasket.checkProductDetails();
        payableAmount = addLensToBasket.theUserRetrievePayableAmount();
    }

    //2022.07.21 CL Adding in a dummy step for test cases which take up a step to call to another step.
    @Step("AS a Tester, GIVEN I am running a test which uses 'call-to' then reports can stepp update by using this dummy test step to represent the calling of another test case")
    public void callToAnotherTestCase() {
        logger.info("This test step doesn't need to be validate - it is to represent a call to another test case only - to keep number of test steps in sync");
    }

    //Checkout Steps
    @Step("AS any user, GIVEN I am on the basket page, WHEN I click on the button 'Checkout Securely', THEN I am taken to the 'Your Details' page")
    public void clickOnCheckoutSecurelyFromBasketPage() {
        logger.info(("STEP: clickOnCheckoutSecurelyFromBasketPageAsGuestUser"));
        addLensToBasket.selectCheckOutSecurely();
    }

    @Step("AS any user, GIVEN I am on the basket page, WHEN I click on the button 'add Solution CTA', THEN the solution liquid will be added to bag")
    public void clickOnAddSolutionLiquidCTA() {
        logger.info(("STEP: clickOnAddSolutionCTA"));
        addLensToBasket.selectAddSolutionCTA();
    }

    @Step("AS a guest user, GIVEN I am on the 'Your Details' page, WHEN I select that I am a new customer, THEN the customer detail fields will be displayed")
    public void selectNewCustomerDuringCheckoutGuestUser() {
        logger.info(("STEP: selectNewCustomerDuringCheckoutGuestUser"));
        orderCheckOut.theUserClicksImANewCustomer();
    }

    @Step("AS a guest user, GIVEN I am on the 'Your Details' page of the checkout process, AND I have selected that I am a new customer, WHEN I enter valid details into the mandatory fields AND I click 'continue', THEN the page 'Address Details' is displayed")
    public void guestUserEnterPersonalDetails() {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserEnterPersonalDetails"));
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomerAfterNewCustomerClick();
    }

    @Step("AS a guest user, GIVEN I am on the 'Your Details' page of the checkout process, AND I have selected that I am a new customer, WHEN I enter valid details into the mandatory fields AND I click 'continue', THEN the page 'Address Details' is displayed")
    public void guestUserEnterPersonalDetails(String customerEmailAddress) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserEnterPersonalDetails"));
        orderCheckOut.theUserFillsMandatoryInfoForNewCustomerAfterNewCustomerClick(customerEmailAddress);
    }

    @Step("AS a guest user, GIVEN I am on the 'Address Page' of the checkout process, WHEN I select 'Enter Address Manually', THEN the address fields are displayed")
    public void guestUserSpecifyToEnterAddressDetailsManually() {
        logger.info(("STEP: guestUserSpecifyToEnterAddressDetailsManually"));
        orderCheckOut.theUserClicksLinkToEnterAddressManually();
    }

    @Step("AS a guest user, GIVEN I am on the 'Address Page' of the checkout process, AND I have selected to enter address manually, WHEN I enter valid data into the mandatory fields AND I select a store from the aftercare dropdown, THEN the store will persist in the field once selected")
    public void guestUserEnterAddressDetailsAndSelectAftercareStoreFromList() {
        guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
    }

    @Step("AS a guest user, GIVEN I am on the 'Address Page' of the checkout process, AND I have selected to enter address manually, WHEN I enter valid data into the mandatory fields AND I select a store from the aftercare dropdown, THEN the store will persist in the field once selected")
    public void guestUserEnterAddressDetailsAndSelectAftercareStoreFromList(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserEnterAddressDetails"));
        orderCheckOut.theUserAddsAddressDetailsManually(userRole);
        orderCheckOut.theUserSelectsFromTheAftercareStoreDropDown(userRole);
        orderCheckOut.manageTermsAndConditions();
    }

    @Step("AS a guest user, GIVEN I am on the 'Address Page' of the checkout process, AND I have entered the location postcode, WHEN I select search icon, THEN the store will enter in the aftercare field")
    public void guestUserSearchWithPostcode(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserEnterAddressDetails"));
        orderCheckOut.theUserAddsAddressDetailsManually(userRole);
        orderCheckOut.theUserSearchStoreWithPostcode(userRole);
        orderCheckOut.manageTermsAndConditions();
    }

    @Step("AS a guest user, GIVEN I have manually entered valid address details during the checkout process, WHEN I click the 'continue' button, THEN the 'verify prescription' page is displayed")
    public void guestUserConfirmAddressDetailsAndContinue() {
        guestUserConfirmAddressDetailsAndContinue("");
    }

    @Step("AS a guest user, GIVEN I have manually entered valid address details during the checkout process, WHEN I click the 'continue' button, THEN the 'verify prescription' page is displayed")
    public void guestUserConfirmAddressDetailsAndContinue(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserConfirmAddressDetailsAndContinue"));
        orderCheckOut.clickAddressDetailsContinueButton();
    }

    @Step("AS a guest user, GIVEN that I am on the verify prescription page, WHEN I choose the option 'I have a Specsavers prescription', THEN the option to choose a store is made available")
    public void specifyGuestUserHasSpecsaversPrescription() {
        logger.info(("STEP: specifyGuestUserHasSpecsaversPrescription"));
        orderCheckOut.theUserConfirmsTheyHaveSpecsPrescription();
    }

    @Step("AS a guest user, GIVEN that I am on the verify prescription page AND I have selected that I have a Specsavers prescription, WHEN I choose a store from the store dropdown AND I click continue, THEN the review and page page is displayed.")
    public void guestUserSelectStoreFromVerifyPrescriptionPage() {
        guestUserSelectStoreFromVerifyPrescriptionPage("");
    }

    @Step("AS a guest user, GIVEN that I am on the verify prescription page AND I have selected that I have a Specsavers prescription, WHEN I choose a store from the store dropdown AND I click continue, THEN the review and page page is displayed.")
    public void guestUserSelectStoreFromVerifyPrescriptionPage(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSelectStoreFromVerifyPrescriptionPage"));
        orderCheckOut.theUserSelectsAftercareStoreFromTheDropDown(userRole);
        orderCheckOut.theUserClicksToContinueOnVerifyPrescriptionPage();
    }

    @Step("As a guest user, GIVEN that I am on the review and pay page WHEN I select VISA from the payment method AND I select 'place order securely', THEN the Worldpay payments screen is displayed")
    public void guestUserSelectPaymentMethodAndContinue(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSelectPaymentMethodAndContinue"));
        orderCheckOut.selectVisaCardForThePayment();
    }

    @Step("As a guest user, GIVEN that I am on the payment details screen, WHEN I enter valid payment details AND I click to make the payment, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void guestUserEntersPaymentDetailsAndContinues() {
        logger.info(("STEP: guestUserEntersPaymentDetailsAndContinues"));
        orderCheckOut.theUserAddsCardDetailsAndClicksCheckout();
    }

    @Step("As a Xro user, GIVEN that I am on the payment details screen, WHEN I enter valid payment details AND I click to make the payment, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void theExistingCustomerAddsCardDetailsAndClicksCheckout() {
        logger.info(("STEP: ExistingCustomerEntersPaymentDetailsAndContinues"));
        orderCheckOut.theXROUserAddsCardDetailsAndClicksCheckout();
    }

    @Step("AS a existing user, GIVEN I am on the 'Your Details' page, WHEN I select that I am a existing customer, THEN the customer login fields will be displayed")
    public void selectExistingCustomerDuringCheckout() {
        logger.info(("STEP: selectExistingCustomerDuringCheckout"));
        orderCheckOut.theUserClicksIAmExistingCustomer();
    }

    @Step("AS a existing user, GIVEN I am on the 'Your Details' page of the checkout process, AND I have selected that I am a existing customer, WHEN I enter valid credential into the mandatory fields AND I click 'login', THEN the page 'Address data' is displayed with already filled address as a guest user")
    public void alreadyMemberLoginWithTheCredentials() {
        logger.info(("STEP: ExistingCustomerEntersEmailIdAndPassword"));
        orderCheckOut.theExistingUserLoginWithTheCredentials();
    }

    @Step("AS a existing user, GIVEN I am on the 'Address details' page of the checkout process, WHEN I confirmed that I have a valid prescription that corresponds to my order along with all other mandatory address data fields AND I click 'continue', THEN the review and page page is displayed.")
    public void theExistingUserContinueWithTheAddressDetails() {
        orderCheckOut.theUserContinueWithTheExistingAddressDetails();
    }

    @Step("AS a existing user, GIVEN that I am on the review and pay page WHEN I select VISA from the payment method AND I select 'place order securely', THEN the Worldpay payments screen is displayed")
    public void theExistingUserSelectPaymentMethodAndContinue(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: theExistingUserSelectPaymentMethodAndContinue"));
        orderCheckOut.selectVisaCardForThePayment();
    }

    @Step("As a existing user, GIVEN that I am on the payment details screen, WHEN I enter valid payment details AND I click to make the payment, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void theExistingUserEntersPaymentDetailsAndContinues() {
        logger.info(("STEP: theExistingUserEntersPaymentDetailsAndContinues"));
        orderCheckOut.theUserAddsCardDetailsAndClicksCheckout();
        String orderNumber = orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserConfirmsOrderConfirmationMessage();
    }

    @Step("As a existing user, GIVEN that I am on the payment details screen, WHEN I select saved card payment method AND I click to make the payment, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void selectSavedCardPaymentMethod(String s) {
        orderCheckOut.selectSavedCardForThePayment();
    }

    @Step("As a guest user, GIVEN the Save my details is available, WHEN I select the button, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void theUserRetrieveOrderDetailsAndPerformStoreCredentialCheck() {
        String orderNumber = orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessage();

        if (testDataManager.getFeatureData("storeCredentials.xmlVerification", Boolean.class)) {
            final String menu = testDataManager.getTestInputRegionData("drupal.worldPay.menu");
            final String subMenu = testDataManager.getTestInputRegionData("drupal.worldPay.newCardSubmenu");

            navigateTo.theLoginHomePage();
            navigateTo.theAdminUserLoginWithCredentials();
            drupalHome.theUserNavigateThroughMenu(menu, subMenu);
            xmlConfirmation.theUserConfirmWorldpayMessageForANewCard(orderNumber);
        }
    }

    @Step("As a guest user, GIVEN the Save my details is available, WHEN I select the button, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void theUserRetrieveOrderDetailsAndPerformStoreCredentialCheckOnly() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        String orderNumber = orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessageOnly();

        if (testDataManager.getFeatureData("storeCredentials.xmlVerification", Boolean.class)) {
            final String menu = testDataManager.getTestInputRegionData("drupal.worldPay.menu");
            final String subMenu = testDataManager.getTestInputRegionData("drupal.worldPay.newCardSubmenu");

            eCommHomePage.bannerStaticHeader();
            eCommHomePage.bannerStaticFooter();

            navigateTo.theLoginHomePage();
            navigateTo.theAdminUserLoginWithCredentials();
            drupalHome.theUserNavigateThroughMenu(menu, subMenu);
            xmlConfirmation.theUserConfirmWorldpayMessageForANewCard(orderNumber);
        }
    }

    @Step("AS a existing user, GIVEN the Save my details is available, WHEN I select the button, THEN the complete checkout page is displayed and the correct regional message is displayed and after that user should be able to confirm store credentials.")
    public void theExistingUserRetrieveOrderDetailsAndPerformStoreCredentialCheck() {

        String orderNumber = orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserConfirmsOrderConfirmationMessageOnly(true);

        if (testDataManager.getFeatureData("storeCredentials.xmlVerification", Boolean.class)) {

            final String menu = testDataManager.getTestInputRegionData("drupal.worldPay.menu");
            final String subMenu = testDataManager.getTestInputRegionData("drupal.worldPay.newCardSubmenu");

            navigateTo.theLoginHomePage();
            navigateTo.theAdminUserLoginWithCredentials();
            drupalHome.theUserNavigateThroughMenu(menu, subMenu);
            xmlConfirmation.theUserConfirmWorldpayMessageForANewCard(orderNumber);
        }
    }

    @Step("AS a existing user, GIVEN The user retrieves and order and logs in and confirms payment card, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void theExistingUserRetrieveOrderNumberAndPerformStoreCredentialCheck() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        String orderNumber = orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserConfirmsOrderConfirmationMessageOnly(true);

        if (testDataManager.getFeatureData("storeCredentials.xmlVerification", Boolean.class)) {

            final String menu = testDataManager.getTestInputRegionData("drupal.worldPay.menu");
            final String subMenu = testDataManager.getTestInputRegionData("drupal.worldPay.savedCardSubmenu");

            navigateTo.theLoginHomePage();
            navigateTo.theAdminUserLoginWithCredentials();
            drupalHome.theUserNavigateThroughMenu(menu, subMenu);
            xmlConfirmation.theUserConfirmWorldpayMessageForASavedCard(orderNumber);
        }
    }

    @Step("AS a existing user, GIVEN that I am on the payment details screen, WHEN I enter valid payment details AND I click to make the payment, THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void theExistingEntersPaymentDetailsAndContinues() {
        logger.info(("STEP: existingUserEntersPaymentDetailsAndContinues"));
        orderCheckOut.theUserAddsCardDetailsAndClicksCheckout();
    }

    @Step("AS any user, GIVEN I am on the 'Select Prescription' page, WHEN I enter valid values in the fields displayed AND I click on the 'Confirm' button, THEN the basket page is displayed")
    public void specifyPrescriptionDetailsForASubscriptionAndContinue(String userRole) {

        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSpecifyPrescriptionDetailsForASubscriptionAndContinue"));
        addLensToBasket.theUserSelectsPrescriptionValuesAndAddSubscriptionToBasket("");
    }

    @Step("AS a user, GIVEN I am on the product page, WHEN I click 'Select Prescription' button, THEN the 'Enter Your Prescription' module will be displayed.")
    public void theUserSelectPrescriptionButton(String userRole) {
        logger.info(("STEP: theUserSelectsPrescriptionButtonFromThePDP"));
        addLensToBasket.selectPrescriptionButton();
    }

    @Step("As a guest user, GIVEN that I am on the review and pay page WHEN I select VISA from the payment method along with merchant initialised transaction checkbox AND I select 'place order securely', THEN the Worldpay payments screen is displayed")
    public void guestUserSelectSubscriptionPaymentMethodAndContinue(String userRole) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserSelectSubscriptionPaymentMethodAndContinue"));
        orderCheckOut.selectVisaCardForTheSubscriptionPayment();
    }

    @Step("As a existing user, GIVEN that I am on the review and pay page WHEN I select saved card from the payment method AND I select 'place order securely', THEN the order confirmation page is displayed and the correct regional message is displayed.")
    public void theExistingUserSelectPaymentOptionAndContinue(String userRole) {
        logger.info(("STEP:theExistingUserSelectSavedCardPaymentMethodAndContinue"));
        orderCheckOut.selectSavedCardPaymentOption();
    }

    @Step("AS any user, GIVEN I have selected the required frequency, THEN the checkout securely button is visible and enabled")
    public void theUserSelectFrequencyAndSecurelyFromBasketPage() {
        addLensToBasket.checkoutSecurelyWithSubscription();
    }

    @Step("GIVEN I am on the basket page WHEN I confirm the discount is applied in the basket, THEN the basket should clearly display the total was affected by the promotion.")
    public void lineLevelDiscountHasBeenAppliedInCheckout() {
        addLensToBasket.checkDiscountHasBeenApplied();
    }

    @Step("GIVEN A line level discount is activated under discounts section after login to drupal , WHEN line level discount is removed from the active discounts THEN a line level discount is removed from the active discount.")
    public void discountHasBeenRemoved() {
        final String menu = testDataManager.getTestInputRegionData("drupal.discount.menu.main");
        final String subMenu = testDataManager.getTestInputRegionData("drupal.discount.menu.submenu");

        navigateTo.theLoginHomePage().theAdminUserLoginWithCredentials();
        drupalHome.theUserNavigateThroughMenu(menu, subMenu);
        addDiscount.theUserConfirmUnavailabilityOfDiscount();
        drupalHome.theAdminUserSelectsLogoutLink();
    }

    @Step("As a guest user, GIVEN I have completed checkout AND I provide the same complant password into each password field - THEN the 'save my details' button is enabled")
    public void theGuestUserProvidesPasswordsAfterCheckout() {
        orderCheckOut.theUserEnterPassword();
    }

    @Step("As a guest user, GIVEN I have provided the same compliant passwords after checkount WHEN I click on the save my details button, THEN the 'checkout complete' page is displayed along with the correct regional message ")
    public void theGuestUserClicksSaveMyDetailsAfterCheckout() {
        theGuestUserClicksSaveMyDetailsAfterCheckout(true);
    }

    @Step("As a guest user, GIVEN I have provided the same compliant passwords after checkount WHEN I click on the save my details button, THEN the 'checkout complete' page is displayed along with the correct regional message ")
    public void theGuestUserClicksSaveMyDetailsAfterCheckout(Boolean closeDriver) {
        orderCheckOut.theUserConfirmsOrderConfirmationMessage(closeDriver);
    }

    @Step("AS an existing customer, GIVEN I have signed in, WHEN I navigate to 'My Details' via the primary navigation 'Account' link' THEN I am presented with my details AND the email address matches my account ID")
    public void ExistingUserClicksMyDetails(String expectedEmail) {
        websitePrimaryNavigation.selectMyDetailsFromAccountDropDown(expectedEmail);
    }

    @Step("AS an existing customer, GIVEN I have signed in, WHEN I navigate to 'My orders' via the primary navigation 'Account' link' THEN I am able to see my last order")
    public void ExistingUserChecksOrderSummary() {
        myOrdersPage.clickOnLastOrder();
    }

    @Step("AS an existing customer, GIVEN I have signed in, WHEN I navigate to 'My orders' via the primary navigation 'Account' link' THEN I am able to see my last order")
    public void ExistingUserChecksOrderSummary(String orderNumber) {
        websitePrimaryNavigation.selectMyOrdersFromAccountDropDown(orderNumber);
    }

    @Step("As an existing customer, GIVEN I am on the account homepage screen and I click on 'my orders' fro mthe primary navigation link, THEN I am taken to the 'my orders' page")
    public void ExistingUserNavigatesToMyOrdersFromAccountDropdown() {
        websitePrimaryNavigation.selectMyOrdersFromAccountDropDown();
    }

    @Step("AS an existing customer, GIVEN I have signed in, WHEN I click on an order from m'my orders' page, THEN I will see details of the correct order")
    public void ExistingUserClicksOnLastOrder() {
        myOrdersPage.clickOnLastOrder();
    }

    @Step("AS an existing customer, GIVEN I am  signed into my account, WHEN I select 'Log out' from the account menu, THEN I am returned to the home page and the login link is now visible nd enabled")
    public void ExistingUserLogsOutFromAccountDropDown() {
        websitePrimaryNavigation.selectMyDetailsFromAccountDropDown();
    }

    @Step("As a guest user, GIVEN I have completed checkout AND the site provides me the opportunity to store a password to create an account, WHEN I enter the same compliant password into both of the password fields AND click SAVE MY DETAILS, THEN the 'checkout complete' page is displayed and the correct regional message is displayed.")
    public void theGuestUserSavesAPasswordToCreateAnAccountAfterCheckout() {
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessage();
    }

    @Step("As a guest user, GIVEN I have provided the same compliant passwords after checkout WHEN I click on the save my details button, THEN the 'checkout complete' page is displayed along with the correct regional message ")
    public String theGuestUserClicksSaveMyDetailsAfterCheckout(Boolean closeDriver, Boolean returnOrderNumber) {
        orderCheckOut.theUserConfirmsOrderConfirmationMessageOnly(closeDriver);
        return orderCheckOut.theUserRetrieveOrderNumber();
    }

    @Step("As a guest user, GIVEN I have provided the same compliant passwords after checkout WHEN I click on the save my details button, THEN the 'checkout complete' page retrieve the lensReplacementOrderID ")
    public String theUserRetrieveLensReplacementOrderIDFromCheckoutPage() {
        return orderCheckOut.theUserRetrieveLensReplacementOrderNumber();
    }

    @Step("AS any user, GIVEN I am on the basket page WHEN I add easypay into the basket AND select checkout after confirming subscription is added into the basket THEN I am taken to the 'Your Details' page")
    public void theUserConfirmSubscriptionAndPerformCheckout() {
        addLensToBasket.checkoutSecurelyWithSubscription();
        logger.info(("STEP: clickOnCheckoutSecurelyFromBasketPageAsGuestUser"));
        addLensToBasket.selectCheckOutSecurely();
    }

    @Step("User Clicks on the Express Reorder Link")
    public void userNavigateToExpressReorderLink() {
        logger.info(("STEP: the user selects express reorder link"));
        lensExpressReorder.navigateToExpressReorderLink();
    }

    @Step("Existing User Amends Qty for Express Reorder")
    public void theExistingUserAmendsEyeQty() {
        theExistingUserAmendsEyeQty("");
    }

    @Step("Existing User Amends Qty for Express Reorder")
    public void theExistingUserAmendsEyeQty(String userRole) {
        logger.info(("STEP: Existing User Amends the Eye Qty"));
        lensExpressReorder.amendRightEyeQuantity(userRole);
        lensExpressReorder.amendLeftEyeQuantity(userRole);
    }

    @Step("Existing User Adds a New Address for Express Reorder")
    public void theExistingUserAddsNewAddress() {
        theExistingUserAddsNewAddress("");
    }

    @Step("Existing User Adds a New Address for Express Reorder")
    public void theExistingUserAddsNewAddress(String userRole) {
        logger.info(("STEP: Existing User Adds a New Address"));
        lensExpressReorder.ClicknewAddressButton();
        lensExpressReorder.AddnewAddressDetails(userRole);
        lensExpressReorder.SavenewAddress();
    }

    @Step("Existing User Adds a New Card for Express Reorder")
    public void theExistingUserAddsNewCard() {
        theExistingUserAddsNewCard("");
    }

    @Step("Existing User Adds a New Card for Express Reorder")
    public void theExistingUserAddsNewCard(String userRole) {
        logger.info(("STEP: Existing User Adds a New Card"));
        lensExpressReorder.AddnewCard();
        lensExpressReorder.AddnewAddressDetails(userRole);
        lensExpressReorder.SavenewCard();
    }

    @Step("Existing User Place Order Securely for Express Reorder")
    public void placeOrderSecurelyForExpressReorder() {
        logger.info(("STEP: User Clicks on Place Order Securely"));
        lensExpressReorder.XroPlaceOrderSecurley();
    }

    @Step("As a guest user, GIVEN that I am on the review and pay page WHEN I select Paypal from the payment method AND I select 'place order securely', THEN  I am taken to the PayPal payments screen")
    public void guestUserSelectPaypalPaymentMethodAndContinue() {
        orderCheckOut.selectPaypalForThePayment();
    }

    @Step("As a guest user, GIVEN that I am on the paypal details page WHEN I complete payment using paypal payment, THEN I am taken to the 'Checkout complete' page and the correct message is shown for the region (e.g. UK = Checkout complete - Thank you for your order)")
    public void guestUserEntersPaypalDetailsAndContinues() {
        paypalPayment.theUserEnterPaypalDetails();
    }

    @Step("AS a guest user GIVEN the Save my details is available WHEN I select the button THEN the complete checkout page is displayed and the correct regional message is displayed.")
    public void guestUserEnterPasswordAndConfirmOrderNumber() {
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword().theUserConfirmsOrderConfirmationMessageOnly();
    }

    @Step("As a guest user, GIVEN that I am on the review and pay page WHEN I select Ideal from the payment method AND I select 'place order securely', THEN  I am taken to the Ideal payments screen")
    public void guestUserSelectIdealPaymentMethodAndContinue() {
        orderCheckOut.selectIdealForThePayment();
    }

    @Step("As a guest user, GIVEN that I am on the Ideal pay page WHEN I select bank for the payment THEN  I am taken to the Ideal payments screen for further authorization")
    public void guestUserSelectsBankDetailsAndPerformAuthorization() {
      //  idealPayment.theUserSelectsBankDetails();
        idealPayment.theUserPerformAuthorization();
    }

    @Step("AS a user, GIVEN I am on the product's details page, WHEN I select a quantity from the Left & Right Eye drop down, THEN price is updated based on the number of quantity selected")
    public void theUserCheckProductPriceAfterSelectingLeftAdRightEyeQuantity() {
        addLensToBasket.checkProductPriceAfterSelectingQty();
    }

    @Step("As a guest user, GIVEN that I am on the order confirmation screen AND saved my details WHEN I select the button to confirm order details through an invoice, THEN I am taken to the invoice details page AND I am able to confirm order details along with the amount payable")
    public void guestUserPerformsInvoiceCheck() {
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword();
        orderCheckOut.theUserCheckOrderInvoice(payableAmount);
    }

    public void closeSession() {

        getDriver().close();

        if (getDriver() != null) {
            logger.info(("Destroy the web driver instance"));
            getDriver().quit();
        }

        if ( SystemUtils.IS_OS_WINDOWS) {
            for (Integer pid : pids) {
                try {
                    Runtime.getRuntime().exec("taskkill /F /PID " + pid);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            pids.clear();
            try {
                Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe*");
                Runtime.getRuntime().exec("taskkill /F /IM msedgedriver.exe*");
                Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe*");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Step("As a any user, GIVEN that I am on the order confirmation screen, AND saved my details , WHEN I select the button to confirm order details through an invoice,THEN I am taken to the invoice details page AND I am able to confirm order details along with the amount payable")
    public void guestUserPerformsInvoiceCheckToConfirmDiscountIsApplied() {
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword();
        orderCheckOut.theUserCheckDiscountedOrderInvoice(payableAmount);
    }

    // Product Select for Glasses
    @Step("GIVEN I am on the home page WHEN I select 'Glasses' from the page header THEN I am taken to the 'All Glasses Page'")
    public void userNavigatesToGlassesPage() {
//        logger.info("The user navigates to the glasses page from the home page");
//        addGlassesToBasket.navigateToGlassesPageFromHome();
    }

    @Step("GIVEN I select the 'Age & Gender' Filter WHEN I Select 'Male' THEN the glasses displayed will reduce to show only Male (or unisex) frames")
    public void userSelectsMaleFromAgeAndGenderFilter() {
//        logger.info("The user selects 'male' from Age and Gender filter");
//        addGlassesToBasket.selectMaleAgeAndGenderFilter();
    }

    @Step("GIVEN I select the 'Type' Filter WHEN I Select 'Optical' THEN the glasses displayed will reduce to show only optical frames (Sunglasses will be removed)")
    public void userSelectsOpticalFromTypeFilter() {
//        if (!Staf.getTargetRegion().equals("se")) {
//            logger.info("The user selects 'optical' from Type filter");
//            addGlassesToBasket.selectOpticalTypeFilter();
 //       }
    }

    @Step("GIVEN I select the 'Available Online' Filter WHEN I Select 'Buy Online' THEN the glasses displayed will reduce to show only frames that can be purchased online")
    public void userSelectsBuyOnlineFromAvailableOnlineFilter() {
//        if (!(Staf.getTargetRegion().equals("dk") || Staf.getTargetRegion().equals("no") || Staf.getTargetRegion().equals("nl") || Staf.getTargetRegion().equals("se"))) {
//            logger.info("The user selects 'buy online' from Available Online filter");
//            addGlassesToBasket.selectAvailableOnlineFilter();
//        }
    }

    @Step("GIVEN I glasses are displayed WHEN I select a frame that has the camera icon and 'try on' is displayed THEN the Product Description Page (PDP) is displayed")
    public void userSelectsFrameWithTryOn() {
//        logger.info("The user selects glasses with Virtual Try On feature");
 //       addGlassesToBasket.selectGlassesWithTryOn();
    }

    @Step("GIVEN I am on the PDP WHEN I select Virtual Try On THEN the Virtual Try On pop up is displayed")
    public void userSelectsVirtualTryOn() {
        logger.info("The user selects virtual try on");
        addGlassesToBasket.selectVirtualTryOn();
    }

    @Step("GIVEN I Follow the on-screen instructions WHEN the scan is completed THEN the results of scan are displayed")
    public void userFollowsVTOOnScreenInstructions() {
        logger.info("The user selects understand button");
        productDetailedPage.clickUnderstandButton();
    }

    @Step("GIVEN i am on the scan result pop up WHEN I Select the close icon THEN I am returned to the PDP")
    public void userClosesVTO() {
        logger.info("The user closes virtual try on");
        productDetailedPage.closeVTO();
    }

    @Step("GIVEN I am on the PDP WHEN I select the Magnifying glass from the top right THEN the Search Option is displayed on the page")
    public void userSelectsSearchFromPDP() {
        logger.info("The user selects search tool");
        addGlassesToBasket.selectSearchFromPDP();
    }

    @Step("GIVEN The search bar is displayed WHEN I enter the SKU number 25667202 into the box AND click the enter key THEN I am taken to a Product Listing Page with a single frame displayed")
    public void userSearchesForGlassesFirstProduct() {
        final String ophthalmicFrames = testDataManager.getTestInputRegionData("purchasing.glasses.secondAvailableProduct.sku");
        logger.info("the user searches for: ophthalmic frames product :: {} ", ophthalmicFrames);
        addGlassesToBasket.searchForProduct(ophthalmicFrames);
    }

    @Step("GIVEN I am on the PLP WHEN I select the image of the frame THEN I am taken to the PDP for the page")
    public void userSelectsFrameFromSearch() {
        logger.info("the user selects frame from search");
        addGlassesToBasket.selectGlassesFromSearch();
    }

    @Step("GIVEN I am on the PDP page WHEN I Select \"Choose Lenses & Buy THEN I am taken to the Prescriptions page")
    public void userSelectsBuyGlasses() {
        logger.info("the user selects buy online");
        addGlassesToBasket.theUserSelectBuyOnlineButton();
    }

    @Step("GIVEN I enter the following details in the prescription Page: WHEN I confirm the details are correct and select Next THEN I am taken to the Lens Options page")
    public void userEntersPrescriptionDetails() {
        logger.info("the user fills prescription details");
        addGlassesToBasket.theUserFillPrescriptionDetails();
    }

    @Step("GIVEN I am on the Lens Options Page WHEN I select 'Clear Lenses' THEN I am taken to the Thickness options")
    public void userSelectsClearLensOption() {
        logger.info("the user selects clear lens");
        addGlassesToBasket.selectClearLensOption();
    }

    @Step("GIVEN I am on the Thickness Options Page WHEN I Select 'Standard' THEN I am taken to the lens Extras page")
    public void userSelectsStandardThicknessOption() {
        logger.info("the user selects standard thickness");
        addGlassesToBasket.selectStandardThicknessOption();
    }

    @Step("GIVEN I am on the Lens Extras page WHEN I Select Scratch-Resistant THEN a the Add to basket option is displayed")
    public void userSelectsScratchResistanceOption() {
        logger.info("the user selects scratch resistance");
        addGlassesToBasket.selectScratchResistanceOption();
    }

    @Step("GIVEN I the add to basket option is displayed WHEN I select Add to basket THEN I am taken to the 'Your Basket' page")
    public void userSelectsAddToBasket() {
        logger.info("the user selects add to basket");
        addGlassesToBasket.selectAddToBasket();
    }

    @Step("GIVEN I am on the Your Basket page WHEN I select 'Glasses' from the top menu THEN I am taken to the 'All Glasses' Page")
    public void userSelectsGlassesPageFromBasket() {
        logger.info("the user selects glasses page from basket");
        addGlassesToBasket.selectGlassesPageFromBasket();
    }

    @Step("GIVEN I select the 'Type' Filter WHEN I Select 'Designer' THEN the glasses displayed will reduce to show only Designer frames (Sunglasses will be removed)")
    public void userSelectsDesignerFromTypeFilter() {
 //       if (!Staf.getTargetRegion().equals("se")) {
 //           logger.info("The user selects 'designer' from Type filter");
 //           addGlassesToBasket.selectDesignerTypeFilter();
  //      }
    }

    @Step("GIVEN The search bar is displayed WHEN I enter the SKU number 30520509 into the box AND click the enter key")
    public void userSearchesForGlassesSecondProduct() {
        final String ophthalmicFrames = testDataManager.getTestInputRegionData("purchasing.glasses.thirdAvailableProduct.sku");
        logger.info("the user searches for: ophthalmic frames product :: {} ", ophthalmicFrames);
        addGlassesToBasket.searchForProduct(ophthalmicFrames);
    }

    @Step("GIVEN I the add to basket option is displayed WHEN I select Add to basket THEN I am taken to the 'Your Basket' page with a '2 for 1' discount applied, (Where prices differ the Cheapest frame should be removed)")
    public void userSelectsAddToBasketAndAsserts2for1() {
        logger.info("the user selects add to basket");
        addGlassesToBasket.selectAddToBasket();
        addGlassesToBasket.check2for1DiscountHasBeenApplied();
    }

    @Step("GIVEN I enter the following address in the manual address fields: WHEN I deselect the fields THEN no errors will be displayed on the address fields")
    public void guestUserEnterAddressDetails(String userRole) {
        logger.info("the user enters address details");
        orderCheckOut.theUserAddsAddressDetailsManually(userRole);
    }

    @Step("GIVEN all mandatory details have been complete of the address details page have been completed WHEN I select a preferred store from the drop-down at the bottom of the page AND select Continue THEN I am taken to the \"Verify Prescription\" Page")
    public void guestUserSelectsPreferredAftercareStore(String userRole) {
        logger.info("the user selects aftercare store and continues");
        orderCheckOut.theUserSelectsFromTheAftercareStoreDropDown(userRole);
        orderCheckOut.manageTermsAndConditions();
        orderCheckOut.clickAddressDetailsContinueButton();
    }

    @Step("GIVEN I am on the Prescription Verification page WHEN I select 'I have a Specsavers Prescription' and choose any store from the dropdown and then select continue THEN I am taken to the 'Review and Pay' Page")
    public void guestUserSelectsSpecsaversPrescription() {
        logger.info("the user selects specsavers prescription and chooses store");
        if (orderCheckOut.theRegionHasAPrescriptionPageAvailable()) {
            orderCheckOut.theUserConfirmsTheyHaveSpecsPrescription();
            guestUserSelectStoreFromVerifyPrescriptionPage("");
        }
    }

    @Step("")
    public void userSelectsCheckoutWithNoHealthFund() {
        addGlassesToBasket.selectHealthFundNotAvailable();
        addGlassesToBasket.selectCheckoutButton();
    }

    @Step("As a guest user, GIVEN I have selected health fund, THEN I can add provider and policy")
    public void userSelectsCheckoutWithHealthFund() {
        logger.info("the user selects heath plan provider and policy");
        addGlassesToBasket.selectHealthFund();
    }

    //[2022.05.18 CL] Below are full E2E Tests - might want to consider moving these to a separate tests class to reduce noise on this page.
    //These have been created in order to be able to report in qTest where the qTest tests has only one test step
    //ToDo Implement capability to handled scenario where one STAF2 test covers multiple qTest test cases (regardless of number of steps) then remove the below which are covered by this

    //[2022.05.18 CL] Added specifically for qTest item 37495184 in project 96896
    @Step("As a guest user, GIVEN I have selected some contact lenses, THEN I can checkout successfully")
    public void E2E_Checkout_Guest_User_Contacts() {
        userNavigatesToContactLensPageViaPrimaryNavLink();
        searchAndSelectContactLensProductBySku();
        specifyLeftEyeQuantity();
        specifyRightEyeQuantityAndClickSelectPrescription();
        specifyPrescriptionDetailsAndContinue();
        clickOnCheckoutSecurelyFromBasketPage();
        selectNewCustomerDuringCheckoutGuestUser();
        guestUserEnterPersonalDetails();
        guestUserSpecifyToEnterAddressDetailsManually();
        guestUserEnterAddressDetailsAndSelectAftercareStoreFromList();
        guestUserConfirmAddressDetailsAndContinue();
        specifyGuestUserHasSpecsaversPrescription();
        guestUserSelectStoreFromVerifyPrescriptionPage();
        guestUserEntersPaymentDetailsAndContinues();
        theExistingUserRetrieveOrderDetailsAndPerformStoreCredentialCheck();
    }

    //[2022.05.18 CL] Added specifically for returning customers so that they are not relying on the first test to run
    @Step("As a guest user, GIVEN I have selected some contact lenses, THEN I can checkout successfully")
    public void purchaseContactsAsGuestAndSaveAccount() {
        openeCommHomeAndAcceptCookies();
        E2E_Checkout_Guest_User_Contacts();
    }

    //[2022.05.18 CL] Added specifically for qTest item 37495184 in project 96896
    @Step("GIVEN a customer is on the Specsavers website WHEN a customer wants to express re-order a previously dispatched set of contact lenses AND change the quantity amount, THEN a customer is able to complete the amended quantity purchase as an express re-order ")
    public void amend_quantity_on_expressReOrder() {
        userNavigateToExpressReorderLink();
        alreadyMemberLoginWithTheCredentials();
        theExistingUserAmendsEyeQty();
        theExistingUserAddsNewAddress();
        theExistingUserAddsNewCard();
        theExistingCustomerAddsCardDetailsAndClicksCheckout();
        placeOrderSecurelyForExpressReorder();
        theExistingUserRetrieveOrderNumberAndPerformStoreCredentialCheck();
    }

    //[2022.05.18 CL] Added specifically for qTest item 37495182 in project 96896 which only has two test steps
    @Step("GIVEN a customer is on the Specsavers website WHEN a customer wants to express re-order a previously dispatched set of contact lenses AND the customer wants to pay using a saved Worldpay card, THEN a customer is able to complete the purchase as an express re-order")
    public void express_reOrder_with_saved_worldpay_card() {
        userNavigatesToContactLensPageViaPrimaryNavLink();
        theUserNavigatesToBrandViaCommonBrandsLink("");
        searchAndSelectContactLensProductBySku();
        specifyLeftEyeQuantity();
        specifyRightEyeQuantityAndClickSelectPrescription();
        specifyPrescriptionDetailsAndContinue();
        clickOnCheckoutSecurelyFromBasketPage();
        selectExistingCustomerDuringCheckout();
        alreadyMemberLoginWithTheCredentials();
        theExistingUserContinueWithTheAddressDetails();
        selectSavedCardPaymentMethod("");
        theExistingUserRetrieveOrderNumberAndPerformStoreCredentialCheck();
    }

    //[2022.05.18 CL] Added specifically for qTest item 37495182 in project 96896 which only has two test steps
    @Step("GIVEN an express reorder has been completed WHEN the customer checks their email THEN the appropriate confirmation email has been sent once")
    public void checkEmailExpressReOrder() {
        //ToDo need to merge in Sayed code for checking emails.
    }

    @Step("AS an existing customer, GIVEN I am on the Order Details page, WHEN i select Payment cards from the right-hand side (under: Manage user account),THEN i am taken to the Payment Methods page")
    public eCommStepDefinitions theExistingUserSelectsPaymentCards() {
        myOrdersPage.theUserSelectsPaymentCards();
        return this;
    }

    @Step("AS an existing customer, GIVEN I am one of the Payment Methods page, WHEN I select Add Card, THEN I am taken to the Add card to debit cards page")
    public eCommStepDefinitions theExistingUserSelectAddsNewCard() {
        addNewCardDetails.theUserSelectAddsNewCard();
        return this;
    }

    @Step("AS an existing customer, GIVEN i am on the Add a card to debit cards, WHEN i select Mastercard ,THEN the personal details fields will be displayed")
    public void theExistingUserSelectMasterCard() {
        addNewCardDetails.theUserSelectMasterCard();
    }

    @Step("AS an existing customer, GIVEN I check the I agree to the storage of my card details checkbox, WHEN I Select the previously added address from the Address Book drop down , THEN the previously entered personal details will be pre populated")
    public void theExistingUserSelectConsentAndContinueWithThePreviousAddress() {
        addNewCardDetails.selectConsents();
        addNewCardDetails.theUserSelectAddressFromTheDropdown();
    }

    @Step("AS an existing customer, GIVEN the details have been pre-populated , WHEN I select Next , THEN I am redirected to the world pay Page")
    public eCommStepDefinitions theExistingUserSelectNextButton() {
        addNewCardDetails.theUserSelectNextButton();
        return this;
    }

    @Step("AS an existing customer, GIVEN I am on the World Pay screen and enter the following payment details , WHEN I select Make a Payment , THEN i will be returned to the Payment page Where both cards are now shown")
    public void theExistingUserAddMasterCardDetails() {
        addNewCardDetails.theUserAddMasterCardPaymentDetails();
    }

    @Step("AS an existing customer, GIVEN I am on the Payment Methods page, WHEN I select Contact Lens Replacement Order from the page header ,THEN I will be taken to the Order Details with the order pre-populated with the same details as the previous order")
    public void theExistingUserSelectsContactLensReplacementOrder() {
        myOrdersPage.selectExpressReorderLink();
    }

    @Step("AS an existing customer, GIVEN i am on the Order Details page, WHEN i select the master card from the dropdown in the Billing Information section, THEN the card will now be displayed in the box")
    public eCommStepDefinitions theExistingUserSelectsFromTheBillingInformationSection() {
        eCommExpressReorderLandingPage.selectMasterCard();
        return this;
    }

    @Step("AS an existing customer, GIVEN Mastercard is now selected, WHEN I select the privacy and terms on the right-hand side along with CTA and ok the on-screen prompt , THEN I am taken to the Payment accepted - Thank you for your order! page")
    public void theExistingUserConfirmCorrespondsOfTheOrder() {

        if (testDataManager.getFeatureData("xro.hasPrivacyAndTermsCheckbox", Boolean.class)) {
            eCommExpressReorderLandingPage.agreeCheckBox();
        }
        eCommExpressReorderLandingPage.placeOrder();
        eCommExpressReorderLandingPage.alertMessage();
    }

    @Step("AS any customer, GIVEN I am on the Payment accepted - Thank you for your order! Page, WHEN I select the Subscriptions option in the User Account menu from the top-right menu, THEN be taken to the Orders page where I will now see new order is displayed")
    public void ExistingUserChecksOrderDetails() {
        orderCheckOut.theUserConfirmsOrderConfirmationMessageOnly(false);
        String orderNumber = orderCheckOut.theUserRetrieveOrderNumber();
        this.ExistingUserChecksOrderSummary(orderNumber);
    }

    @Step("AS an existing customer, GIVEN I am on the order Details page ,WHEN I select Express Reorder from the My Account drop down, THEN I am taken to an Order Details screen displaying the same order contents previously made")
    public void theExistingCustomerSelectsXROFromTheAccountOption() {
        websitePrimaryNavigation.selectExpressReorderFromAccountDropDown();
    }

    @Step("Given user searches for the glasses product based on the sku, When user selects pair of glasses in the PLP after product search performed through sku, THEN User will be taken to the PDP for the selected pair of glasses")
    public void OpenTryOnGlassesOnPdp() {
        productDetailedPage.clickVirtualTryOn();
    }

    @Step("GIVEN user clicks a Virtual Try On button for a particular frame on PDP page, And adding glasses to favourites after performing  face scan, THEN  a face scan is process is completed, AND the same glasses added to the favourites")
    public void addGlassesToFavourites() {
        productDetailedPage.clickAddToFavorite();
        productDetailedPage.closeVirtualTryOnModal();
    }

    @Step("Click on any pair of glasses and scan with Virtual Try On from PLP page")
    public void clickOnAnyPairOfGlassesInThePlpAndTryOn() {
        navigateTo.theUserAcceptCookies();
        logger.info("Clicking the first occurring product ");
        navigateTo.navigateToAllGlassesPage();
    //    eCommHomePage.bannerStaticHeader();
    //    eCommHomePage.bannerStaticFooter();
        eCommProductSearchpage.clickTryOnIcon();
    }

    @Step("As a user, while trying on glasses on PLP, I would like to navigate to next and previous frames")
    public void navigateToNextAndPreviousFrames() {
        eCommProductSearchpage.clickToNextFrame();
        eCommProductSearchpage.clickToPreviousFrame();
    }

    @Step("Check eComm Emails in Mailosaur")
    public void checkeCommEmailInMailosaur(String customerEmailAddress, String orderNo, boolean lensReplacement, boolean subscriptionOrEazyPay) {
        logger.info("********** CheckEmailIn MAILOSAUR ********** ");
        orderCheckOut.checkeCommEmailInMailosaur(customerEmailAddress, orderNo, lensReplacement, subscriptionOrEazyPay);
        logger.info("******************************************** ");
    }

    @Step("Check eComm Emails in Mailosaur")
    public void checkeCommEmailInMailosaur2(String customerEmailAddress, String orderNo, boolean lensReplacement, boolean subscriptionOrEazyPay) {
        logger.info("********** CheckEmailIn MAILOSAUR ********** ");
        orderCheckOut.checkeCommEmailInMailosaur2(customerEmailAddress, orderNo, lensReplacement, subscriptionOrEazyPay);
        logger.info("******************************************** ");
    }

    @Step("Reset password at reset password screen")
    public void theUserVerifyPasswordAndLoginWithNewPassword() {
        logger.info("********** Verify the user password rules ********** ");
        eCommPasswordResetPage.verifyPasswordRuleMessage();
        logger.info("STEP: user enter new password and confirm password");
        eCommPasswordResetPage.enterCredentials();
    }

    @Step("Enter new password and confirm password and click on Lodin button")
    public void checkUserPasswordEmailInMailosaur(String customerEmailAddress) {
        logger.info("********** Check reset password url link in MAILOSAUR Mail box ********** ");
        orderCheckOut.checkeCommEmailInMailosaur(customerEmailAddress);
    }

    @Step("GIVEN I am on on 'My Wallet' page WHEN I click delete button from the page  THEN I verify the delete card messgae")
    public void navigateToMyWalletDetailsPageVerifyTheUnableToDeleteCardMessage() {
        logger.info("User navigate to My wallet Page and verify the delete card validation message");
        orderCheckOut.navigateToMyWalletPage();
        orderCheckOut.theUserVerifyTheUnableToDeleteCardMessage();
    }

    @Step("GIVEN I am on the drupal home page WHEN i select my wallet option THEN The Remove box should be greyed out .")
    public void theAdminUserAttemptToDeleteCardInCSR(String orderID) {
        logger.info("Login to drupal and search the order WHEN i select my wallet option THEN The Remove box should be greyed out");
        navigateTo.theLoginHomePage();
        navigateTo.theAdminUserLoginWithCredentials();
        drupalHome.theUserSearchTheOderID(orderID);
        drupalHome.theUserSelectsTheWalletandEnsureDeleteButtonIsDisable();
        drupalHome.theAdminUserSelectsLogoutLink();
    }

    @Step("As a guest user, Retrieve the Email id from the personal details ")
    public String theUserRetrieveEmailIDFromCheckoutPage() {
        return orderCheckOut.theUserRetrieveEmailID();
    }

    @Step("As a guest user, Retrieve the Cost from the Order Confirmation Page ")
    public String theUserRetrieveCostFromOrderConfirmationPage() {
        return orderCheckOut.theUserRetrieveOrderCost();
    }

    @Step("As a any user, GIVEN that I am on the order confirmation screen, AND saved my details , WHEN I select the button to confirm order details through an invoice,THEN I am taken to the invoice details page AND I am able to confirm order details along with the amount payable")
    public void guestUserPerformsOrderlevelInvoiceCheckToConfirmDiscountIsApplied() {
        orderCheckOut.theUserRetrieveOrderNumber();
        orderCheckOut.theUserEnterPassword();
        orderCheckOut.guestUserPerformsOrderlevelInvoiceCheckToConfirmDiscountIsApplied(payableAmount);
    }

    @Step("As a any user, GIVEN I am on the PDP page, WHEN I Select the Grey heart icon found to the left of the price,THEN the heart icon will change to a filled Green circle with a white heart")
    public void userClicksOnFavouritesIconDisplayAtLeftSideOfPriceValue() {
        addGlassesToBasket.clickOnFavouritesIconDisplayAtLeftSideOfPriceValue();
    }

    @Step("As a any user, GIVEN I am on the PDP page WHEN I Select the 'View Favorites', THEN I will be taken to the 'Your favorite frame' where a single set of frames will be displayed")
    public void userClicksOnViewFavouritesButton() {
        addGlassesToBasket.clickOnViewFavouritesButton();
    }

    @Step("As a any user, GIVEN I am on the 'Your favorite frame' page, WHEN I select 'Find a store' from the only displayed set of frames, THEN I am taken to the 'Book an eye Appointment' page")
    public void userClicksOnFindAStoreButton() {
        addGlassesToBasket.clickOnFindAStoreButton();
    }

    @Step("As a any user, GIVEN i am on the 'Book an appointment page' page, WHEN I enter store into the empty field and select 'Find', THEN stores with 'Book an appointment' buttons should be displayed")
    public void verifyStoreNamesAreDisplayedBasedOnSearchLocationEntered() {
        addGlassesToBasket.enterStoreLocationandSearch(testDataManager.getTestInputRegionData("appointmentData.storeLocation.locationSearchString"));
        addGlassesToBasket.VerifyBookAnAppointmentButtonsAreDisplayed();
    }

    @Step("As a any user, GIVEN The password has been Set, WHEN I select the 'My Orders' option in the 'My Account' menu from the top-right menu, THEN 'Orders' Summary will be displayed")
    public void userNavigatestoMyOrderDetailsPageViaMyAccountsMenuLink() {
        orderCheckOut.navigateToMyOrderDetailsPage();
    }

    @Step("As a user  GIVEN I can see orders in the 'Orders' Page, WHEN I select an underlined Bestelnummer from the list, THEN I am taken to the 'Bestelgegevens' page")
    public void verifyOrderDetailsPageisDisplayedWhenUserClicksOnOrderNumber() {
        myOrdersPage.clickOnLastOrder();
        orderCheckOut.verifyOrderDetailsPageIsDisplayed();
    }

    @Step("AS an existing customer, GIVEN i am on the Add a card to debit cards, WHEN i select IdealCard ,THEN the personal details fields will be displayed")
    public void theExistingUserSelectIdealCard() {
        addNewCardDetails.theUserSelectIdealCard();
    }

    @Step("AS an existing customer, GIVEN I check the I agree to the storage of my card details checkbox, select previous address, WHEN I select Next , THEN I am redirected to the world pay Page")
    public void existingUserEnterIdealCardDetailsAndClickOnNextButton() {
        addNewCardDetails.selectConsentsForIdealCard();
        addNewCardDetails.theUserSelectAddressFromTheDropdown();
        addNewCardDetails.theUserSelectNextButton();
    }

    @Step("As a existing user, GIVEN that I am on the Ideal pay page WHEN I select bank for the payment THEN  I am taken to the Ideal payments screen for further authorization")
    public void existingUserSelectsBankDetailsAndPerformAuthorization() {
 //       idealPayment.theUserSelectsBankDetails();
        idealPayment.theUserPerformAuthorization();
    }

    @Step("As a user, GIVEN I see new card is added in CardDetails page, WHEN I reorder the previous order, THEN both the orders should be visible in Order Details")
    public String verifyReOrderingOfConcatLensesUsingNewlyAddedIDealCard() {
        String rightEyeQuanity = testDataManager.getTestInputRegionData("expressReOrder.rightEyeQuantity");
        String leftEyeQuantity = testDataManager.getTestInputRegionData("expressReOrder.leftEyeQuantity");
        String paymentMethod = testDataManager.getTestInputRegionData("expressReOrder.idealPaymentMethod");

        return lensExpressReorder.verifyXROUsingNewlyAddedIdealCard(rightEyeQuanity, leftEyeQuantity, paymentMethod);
    }

    @Step("As a user, GIVEN I see new card is added in CardDetails page, WHEN I reorder the previous order with Amended quantity, THEN both the orders should be visible in Order Details")
    public String verifyReOrderingWithAmendedQuantityOfContactLensesUsingVisaCard() {
        String rightEyeQuanity = testDataManager.getTestInputRegionData("expressReOrder.rightEyeQuantity");
        String leftEyeQuantity = testDataManager.getTestInputRegionData("expressReOrder.leftEyeQuantity");
        String paymentMethod = testDataManager.getTestInputRegionData("expressReOrder.visaPaymentMethod");

        return lensExpressReorder.verifyReOrderingWithAmendedQuantityUsingSavedVisaCard(rightEyeQuanity, leftEyeQuantity, paymentMethod);
    }

    @Step("As a user, GIVEN I see new card is added in CardDetails page, WHEN I reorder the previous order with Amended quantity, THEN both the orders should be visible in Order Details")
    public String verifyReOrderingWithAmendedQuantityOfContactLensesUsingVisaCardConsentConfirm() {
        String rightEyeQuanity = testDataManager.getTestInputRegionData("expressReOrder.rightEyeQuantity");
        String leftEyeQuantity = testDataManager.getTestInputRegionData("expressReOrder.leftEyeQuantity");
        String paymentMethod = testDataManager.getTestInputRegionData("expressReOrder.visaPaymentMethod");

        return lensExpressReorder.verifyReOrderingWithAmendedQuantityUsingSavedVisaCardConsentConfirm(rightEyeQuanity, leftEyeQuantity, paymentMethod);
    }

    @Step("Verify Order numbers are displayed in order summary page")
    public void verifyOrderNumbersAreDisplayedInOrderSummaryPage(String OrderNumber) {
        lensExpressReorder.verifyOrderNumberIsDisplayedInOrderSummaryPage(OrderNumber);
    }

    @Step("Login as an Admin User")
    public void loginAsAdminUser() {
        navigateTo.theLoginHomePage().theUserAcceptCookies();
        navigateTo.theAdminUserLoginWithCredentials();
    }

    @Step("Click on customer name to view customer details.")
    public void clickOnCustomerNameToViewCustomerDetails(String orderNo) {
        drupalHome.theUserSearchTheOderID(orderNo);
    }

    @Step("Get customer details before update")
    public void getCustomerDetailsBeforeUpdate() {
        drupalCustomerDetails.getCustomerDetailsBeforeUpdate();
    }

    @Step("Update customer details page")
    public void updateCustomerDetailsPage() {
        drupalCustomerDetails.updateCustomerDetailsPage();
    }

    @Step("Get customer details after update")
    public void getCustomerDetailsAfterUpdate() {
        drupalCustomerDetails.GetCustomerDetailsAfterUpdate();
    }

    @Step("verify customer details are Updated")
    public void verifyCustomerDetailsAreUpdated() {
        drupalCustomerDetails.verifyCustomerDetailsAreUpdated();
    }

    @Step("Navigate to first item on PLP")
    public void navigateToPLP() {
        navigateTo.navigateToAllGlassesPage();
    }

    @Step("GIVEN user clicks FittingBox Live VTO button on PLP, THEN I can see 'how we use your data' page AND I close the modal")
    public void checkFittingBoxLiveVTO() {
//        eCommHomePage.bannerStaticHeader();
//        eCommHomePage.bannerStaticFooter();
        eCommProductSearchpage.clickLunaVtoIcon();
        eCommProductSearchpage.onModalLanding();
        eCommProductSearchpage.goToHowWeUseDataInModal();
        eCommProductSearchpage.openPrivacyPolicyPage();
        eCommProductSearchpage.closeLiveVTOModal();
    }

    @Step("User sort frames by quick filter on PLP")
    public void filterListByQuickFilter() {
        eCommProductSearchpage.filterByQuickFilter();
        logger.info("Applied quick filter");
        eCommProductSearchpage.openAndCloseVTOModal();
        logger.info("VTO modal opened and closed");
    }

    @Step("User loads more frames on PLP")
    public void loadMoreFrames() {
        eCommProductSearchpage.loadMoreFrames();
        logger.info("More frames loaded on PLP");
        eCommProductSearchpage.openAndCloseVTOModalNoBanner();
        logger.info("VTO modal opened and closed");
    }

    @Step("User selects page size on PLP")
    public void selectPageSize() {
        eCommProductSearchpage.selectPageSize();
        logger.info("Page size increased to 60 on PLP");
        eCommProductSearchpage.openAndCloseVTOModalNoBanner();
        logger.info("VTO modal opened and closed");
    }

    @Step("When user selects the language version on top right")
    public void clickOnLanguageButton() {
        eCommProductSearchpage.clickChangeLanguageButton();
        logger.info("Change language button");
    }

    @Step("Then the website language updates to the selected language")
    public void titleChangesToSelectedLanguage() {
        eCommProductSearchpage.languageChanges();
        logger.info("Language changes");
    }

    @Step("When I click on the find store CTA on the top left")
    public void clicksOnFindAStoreButton() {
        eCommProductSearchpage.clickFindStore();
        logger.info("Click find Store Button");

    }

    @Step("When I click on view store button")
    public void clickOnViewStoreBtn() {
        eCommProductSearchpage.clickViewStoreButton();
        logger.info("Click view store button");
    }

    @Step("Search for Store via Find store link")
    public void v3_searchStoreViaFindStoreLink() {
        navigateTo.v3_UserClicksOnFinaAStoreLink();
        eCommProductSearchpage.v3_inputSASStore();
        eCommProductSearchpage.v3_clickFind();
    }

    @Step("Verify 'Find a store' link is displayed")
    public void v4_verifyFindAStoreLinkIsDisplayed() {
        logger.info("Verify find A store link is displayed");
        eCommProductSearchpage.v4_VerifyFindAStoreLinkIsdisplayed();
    }

    @Step("Perform a RAF store search")
    public void findRAFStore() {
        logger.info("Search a RAF Store");
        navigateTo.clickOnBookAppointmentButton();
        eCommProductSearchpage.enterRAFStoreNameAndClickOnSearchButton();
    }

    @Step("Select a store")
    public void selectAStore() {
        logger.info("click on book Appointment against searched store");
        eCommProductSearchpage.v3_bookOnlineInSelectedLocation();
    }

    @Step("Select RAF appointment type as Contact Lens Assessment")
    public void selectRAFAppointmentAs_ContactLensAssessment() {
        eCommProductSearchpage.clickOnOptometryServices(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.contactLensAssessment"));

        //eCommProductSearchpage.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.contactLensAssessment"));
    }

    @Step("verify 'Request an appointment' button is displayed")
    public void verifyRequestAnAppointmentButtonIsDisplayed() {
        eCommProductSearchpage.verifyRequestAnAppointmentButtonIsDisplayed();
    }

    @Step("Perform a SAS store search ")
    public void findSASStore() {
        logger.info("Search a SAS Store");
        String targetEnvironment = Staf.getTargetEnvironmentWithRegion()[0];

        if (Staf.getTargetRegion().equals("no") || Staf.getTargetRegion().equals("se")) {
            navigateTo.clickOnFindAStoreButton();
        } else {
            navigateTo.clickOnBookAppointmentButton();
        }

        eCommProductSearchpage.v3_inputSASStore();
        eCommProductSearchpage.v3_clickFind();
    }

    @Step("Select SAS appointment type as Adult sight Test")
    public void selectSASAppointmentAs_AdultSightTest() {
        logger.info("Select appointment type as Adult Sight Test");
        eCommProductSearchpage.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.adultEyeTest"));
        eCommProductSearchpage.clickBookASlotButton();
    }

    @Step("Select SAS appointment type as Child eye Test")
    public void selectSASAppointmentAs_ChildEyeTest() {
        logger.info("Select appointment type as Child eye test");
        if (Staf.getTargetRegion().equals("ie")) {
            eCommProductSearchpage.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.childEyeTest"));
            eCommProductSearchpage.clickBookASlotButton();
        } else {
            eCommProductSearchpage.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.childEyeTest"));
            eCommProductSearchpage.clickBookASlotButton();
        }
    }

    @Step("Select SAS appointment type as Contact lens consultation and trial")
    public void selectSASAppointmentAs_ContactLensConsultationAndTrial() {
        logger.info("select an appointment ContactLensConsultationAndTrial ");
        eCommProductSearchpage.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.contactLensConsultationAndTrial"));
        eCommProductSearchpage.clickBookASlotButton();
    }

    @Step("Select SAS appointment type as Contact lens consultation")
    public void selectAppointmentAs_ContactLensInitialappointment() {
        logger.info("select an appointment ContactLensConsultation");
        eCommProductSearchpage.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.contactLensAssessment"));
        eCommProductSearchpage.clickBookASlotButton();
    }

    @Step("Click on Hearing services in appointment type page")
    public void clickOnHearingServices() {
        eCommProductSearchpage.clickHearingServices();
    }

    @Step("Click hearing appointment")
    public void clickHearingAppointment() {
        eCommProductSearchpage.clickHearingAppointment();
        eCommProductSearchpage.clickBookASlotButton();
    }

    @Step("AS any user, GIVEN I can see the 'search' area to look up a product, WHEN I enter in a valid SKU AND click on the item, THEN the product details page for that item is displayed.'")
    public void searchAndSelectContactLensProductBySkuMerken() {
        addLensToBasket.searchAndSelectContactLensProductBySkuMerken();

    }

    @Step("Select Raf Request an appointment tab")
    public void rafSelectRequestAnAppointmentTab() {
        eCommProductSearchpage.clickRafRequestAnAppointmentBtn();
    }

    @Step("Select RAF appointment type as Adult eye test")
    public void selectRAFAppointmentAs_AdultEyeTest() {
        eCommProductSearchpage.clickOnAppointmentEs(testDataManager.getTestInputRegionData("appointmentType.adultEyeTest"));
    }

    @Step("Input personal details for RAF booking")
    public void inputRAFPersonalDetailsForBooking(String email) {

        final String dateAndTime = testDataManager.getTestInputCommonData("rafUserInformation.dateAndTime");
        final String title = testDataManager.getTestInputCommonData("rafUserInformation.title");
        final String firstName = testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userInformation.lastName");
        final String mobileNumber = testDataManager.getTestInputCommonData("rafUserInformation.mobileNumber");
        final String esesTitle = testDataManager.getTestInputCommonData("rafUserInformation.esesTitle");
        eCommProductSearchpage.inputRAFPersonalDetails(dateAndTime, esesTitle, firstName, lastName, mobileNumber, email);
    }

    @Step("Click submit")
    public void submitButton() {
        eCommProductSearchpage.submitBtn();
    }

    @Step("Check eComm Emails in Mailosaur")
    public void checkeCommEmailInMailosaur3(String customerEmailAddress) {
        logger.info("********** CheckEmailIn MAILOSAUR ********** ");
        orderCheckOut.checkeCommEmailInMailosaur3(customerEmailAddress);
        logger.info("******************************************** ");
    }

    @Step("AS a guest user, GIVEN I am on the 'Your Details' page of the checkout process, AND I have selected that I am a new customer, WHEN I enter valid details into the mandatory fields AND I click 'continue', THEN the page 'Address Details' is displayed")
    public void guestUserEnterEmailES(String customerEmailAddress) {
        //Note where userRole = "" then common data for current region will be selected
        logger.info(("STEP: guestUserEnterPersonalDetails"));
        orderCheckOut.theUserFillsEsBookingEmail(customerEmailAddress);
        eCommHomePage.focusOnAnythingElseWeShouldKnow();
    }

    @Step("Given there are products available in the PLP")
    public void GivenThereAreProductsAvailableInTheNewPLP() {

        final String ophthalmicFrames = testDataManager.getTestInputRegionData("purchasing.glasses.availableProduct.sku");
        logger.info("ophthalmic frames product :: {} ", ophthalmicFrames);

        navigateTo.theUserAcceptCookies();
        addGlassesToBasket.theGuestUserSelectOneOphthalmicFramesNew(ophthalmicFrames);
        Assertions.assertThat(eCommProductSearchpage.productCode()).isEqualTo(ophthalmicFrames);
    }

    @Step("Check eComm Emails in Mailosaur")
    public void checkeCommEmailInMailosaur4(String customerEmailAddress, String orderNo, boolean lensReplacement, boolean subscriptionOrEazyPay) {
        logger.info("********** CheckEmailIn MAILOSAUR ********** ");
        orderCheckOut.checkeCommEmailInMailosaur4(customerEmailAddress, orderNo, lensReplacement, subscriptionOrEazyPay);
        logger.info("******************************************** ");
    }



}