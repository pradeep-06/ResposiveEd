package digital.eComm.ui.pages;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;

@DefaultUrl("page:eComm.drupal.home.url")
public class eCommLoginPage extends eCommBase {

    @FindBy(id = "edit-name")
    public WebElementFacade userName;

    @FindBy(id = "edit-pass")
    public WebElementFacade password;

    @FindBy(id = "edit-submit")
    public WebElementFacade loginButton;

    public void enterCredentials(String username, String password) {

        setText(this.userName, username);
        setText(this.password, password);
        clickElement(this.loginButton);
    }
}
