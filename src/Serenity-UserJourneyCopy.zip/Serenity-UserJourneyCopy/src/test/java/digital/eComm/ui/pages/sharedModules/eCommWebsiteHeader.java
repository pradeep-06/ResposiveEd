package digital.eComm.ui.pages.sharedModules;

import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.checkout.customeraccount.eCommMyDetailsPage;
import digital.eComm.ui.pages.checkout.eCommCustomerDetailsPage;
import digital.eComm.ui.pages.customeraccount.eCommMyOrdersPage;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import digital.eComm.ui.pages.eCommHomePage;


public class eCommWebsiteHeader extends eCommBase {
    eCommCustomerDetailsPage eCommCustomerDetailsPage;
    eCommMyDetailsPage myDetailsPage;
    eCommMyOrdersPage myOrdersPage;
    eCommHomePage eCommHomePage;

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);

    @FindBy(xpath = "//a[@trackaid='header-my-account']")
    private WebElementFacade myAccountLink;
    @FindBy(xpath = "//a[@trackaid='header-my-details']")
    private WebElementFacade myDetailsLink;

    @FindBy(xpath = "//a[@trackaid='header-orders']")
    private WebElementFacade myOrdersLink;

    @FindBy(xpath = "//a[@trackaid='header-express-reorder']")
    private WebElementFacade expressReorderLink;

    @FindBy(xpath = "//a[@trackaid='header-sign-out']")
    private WebElementFacade logoutLink;

    @FindBy(css = "a.ss-top-bar__login-btn")
    private WebElementFacade loginLink;

    public void selectLogoutFromAccountDropDown() {
        //Navigate to the customers myDetails page via header links
        logger.info("clicking logout");
        hoverMenuAndClickOption(myAccountLink,logoutLink);
        logger.info("logout completed");
        logger.info("check link is disabled");
        assertPageObjectExists(loginLink);
        logger.info("LOGIN link is Visible");
    }

    public void selectMyDetailsFromAccountDropDown() {
        selectLogoutFromAccountDropDown();
    }
    public void selectMyDetailsFromAccountDropDown(String expectedEmail) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        //Navigate to the customers myDetails page via header links
        hoverMenuAndClickOption(myAccountLink,myDetailsLink);

        //If the test has specified an email address to validate then validate:
        if(!expectedEmail.equals("")) {
            logger.info("VALIDATING correct customer details..");
            assertElementContainsText(myDetailsPage.getCustomerEmailAddress(),expectedEmail);
        }
    }

    public void selectMyOrdersFromAccountDropDown() {
        hoverMenuAndClickOption(myAccountLink,myOrdersLink);
    }
    public void selectMyOrdersFromAccountDropDown(String orderNumber) {
        //Navigate to the customers orders page via header links
        hoverMenuAndClickOption(myAccountLink,myOrdersLink);

        //If the test has specified an order number to validate then validate:
        if(!orderNumber.equals("")) {
            logger.info("VALIDATING correct customer details..");
            assertElementContainsText(myOrdersPage.getLastOrderNumber(),orderNumber);
        }
    }

    public void selectExpressReorderFromAccountDropDown() {

        logger.info("Navigate to the express reorder page via header links..");
        waitForPageLoader();
        hoverMenuAndClickOption(myAccountLink,expressReorderLink);
    }

}
