package digital.eComm.ui.pages.drupal.discounts;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import digital.eComm.ui.pages.eCommHomePage;

import java.util.List;

public class eCommDiscountPromotionPage extends eCommBase {

    @FindBy(css = "div#commerce-discount-fields-wrapper li.horizontal-tab-button.horizontal-tab-button")
    private List<WebElement> horizontalTabs;

    @FindBy(id = "edit-de-discount-fields-field-c-promote-und")
    private WebElementFacade promoteCheckBox;

    @FindBy(id = "edit-submit")
    private WebElementFacade saveDiscount;

    eCommHomePage eCommHomePage;

    public eCommDiscountPromotionPage theUserStartsPromotingOnProductPages() {

        TestDataManager testDataManager = new TestDataManager();

        selectTab(horizontalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.promotion.tabHeader"));
        clickElement(this.promoteCheckBox);

        return this;
    }

    public void userSavedDiscount() {
        clickElement(this.saveDiscount);
    }
}
