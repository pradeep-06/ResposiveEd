package digital.eComm.ui.pages.drupal.discounts;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import org.openqa.selenium.WebElement;

import java.util.List;

public class eCommDiscountExclusivityPage extends eCommBase {

    @FindBy(css = "div#commerce-discount-fields-wrapper li.horizontal-tab-button.horizontal-tab-button")
    private List<WebElement> horizontalTabs;

}
