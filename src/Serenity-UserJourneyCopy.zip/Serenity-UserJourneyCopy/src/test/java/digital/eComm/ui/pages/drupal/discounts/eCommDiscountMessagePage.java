package digital.eComm.ui.pages.drupal.discounts;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import digital.eComm.ui.pages.eCommHomePage;

import java.util.List;

public class eCommDiscountMessagePage extends eCommBase {

    @FindBy(id = "edit-label")
    private WebElementFacade inputPromoAdminTitle;

    @FindBy(id = "edit-de-discount-fields-field-m-description-und-0-value")
    private WebElementFacade inputDescription;

    @FindBy(id = "edit-de-discount-fields-field-m-title-short-und-0-value")
    private WebElementFacade inputTitle;

    @FindBy(xpath = "//body")
    private WebElementFacade inputBriefDescription;

    @FindBy(css = "div#commerce-discount-fields-wrapper li.horizontal-tab-button.horizontal-tab-button")
    private List<WebElement> horizontalTabs;

    @FindBy(id = "edit-delete")
    private WebElementFacade deleteButton;

    eCommHomePage eCommHomePage;

    public void addOrderLevelPromoCodeMessage() {

        TestDataManager testDataManager = new TestDataManager();
        setText(this.inputPromoAdminTitle,testDataManager.getTestInputRegionData("drupal.discount.orderLevel.promoAdminTitle"));
        setText(this.inputDescription,testDataManager.getTestInputRegionData("drupal.discount.orderLevel.customerMessage.customerDescription"));
        setText(this.inputTitle,testDataManager.getTestInputRegionData("drupal.discount.orderLevel.customerMessage.title"));
        getDriver().switchTo().frame(0);
        setText(this.inputBriefDescription,testDataManager.getTestInputRegionData("drupal.discount.orderLevel.customerMessage.briefDescription"));
        getDriver().switchTo().parentFrame();
    }

    public void deleteDiscountCode() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        evaluateScriptClick(this.deleteButton);
    }

    public void addLineLevelPromoCodeMessage() {
        TestDataManager testDataManager = new TestDataManager();
        setText(this.inputPromoAdminTitle,testDataManager.getTestInputRegionData("drupal.discount.lineLevel.promoAdminTitle"));
        setText(this.inputDescription,testDataManager.getTestInputRegionData("drupal.discount.lineLevel.customerMessage.customerDescription"));
        setText(this.inputTitle,testDataManager.getTestInputRegionData("drupal.discount.lineLevel.customerMessage.title"));
        getDriver().switchTo().frame(0);
        setText(this.inputBriefDescription,testDataManager.getTestInputRegionData("drupal.discount.lineLevel.customerMessage.briefDescription"));
        getDriver().switchTo().parentFrame();
    }
}
