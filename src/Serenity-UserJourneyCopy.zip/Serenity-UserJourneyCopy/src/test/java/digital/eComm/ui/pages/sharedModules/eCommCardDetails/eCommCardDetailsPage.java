package digital.eComm.ui.pages.sharedModules.eCommCardDetails;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.checkout.eCommOrderConfirmationPage;
import digital.eComm.ui.pages.sharedModules.expressreorder.eCommExpressReorderLandingPage;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommCardDetailsPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    eCommOrderConfirmationPage eCommOrderConfirmationPage;
    eCommExpressReorderLandingPage eCommExpressReorderLandingPage;

    @FindBy(id = "cardNumber")
    private WebElementFacade cardNumber;

    @FindBy(id = "cardholderName")
    private WebElementFacade cardholdersName;

    @FindBy(id = "expiryMonth")
    private WebElementFacade expiryMonth;

    @FindBy(id = "expiryYear")
    private WebElementFacade expiryYear;

    @FindBy(id = "securityCode")
    private WebElementFacade securityCode;

    @FindBy(id = "submitButton")
    private WebElementFacade makePayment;

    @FindBy(css = "div#orderSummaryDetailsTop td#orderRef")
    private WebElementFacade orderReference;


    public void enterCardNumber(String cardNumber) {
        setText(this.cardNumber, cardNumber);
    }

    public void enterCardholdersName(String cardholdersName) {
        setText(this.cardholdersName, cardholdersName);
    }

    public void enterExpiryMonth(String expiryMonth) {
        setText(this.expiryMonth, expiryMonth);
    }

    public void enterExpiryYear(String expiryYear) {
        setText(this.expiryYear, expiryYear);
    }

    public void enterSecurityCode(String securityCode) {
        setText(this.securityCode, securityCode);
    }

    public void clickMakePayment() {
        clickElement(this.makePayment);
        logger.info("VALIDATE; Check completion message is correct for the region");
        assertElementContainsText(eCommOrderConfirmationPage.getPageTitle(), testDataManager.getTestAssertionData("orderConfirmationMessage"));
    }

    public void XroclickMakePayment() {
        clickElement(this.makePayment);
        logger.info("VALIDATE: Card Saved success Message");
        final String addedCardConfirmation = testDataManager.getTestAssertionData("CardConfirmation");
        Assertions.assertThat(eCommExpressReorderLandingPage.SucessMsg()).contains(addedCardConfirmation);

    }

    public void enterOrderReference(String orderReference) {
        setText(this.orderReference, orderReference);
    }

    public void waitForCredCardNumberField() {
        waitFor(WebElementExpectations.elementIsDisplayed(cardNumber));
    }

    public void enterMasterCardNumber(String cardNumber) {
        setText(this.cardNumber, cardNumber);
    }

    public void clickMakePaymentButton() {
        clickElement(this.makePayment);
//        logger.info("VALIDATE; Check completion message is correct for the region");
//        assertElementContainsText(eCommOrderConfirmationPage.getPageTitle(), testDataManager.getTestAssertionData("orderConfirmationMessage"));

    }
}
