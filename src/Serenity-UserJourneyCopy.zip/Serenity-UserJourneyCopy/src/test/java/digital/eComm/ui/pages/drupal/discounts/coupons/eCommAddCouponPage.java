package digital.eComm.ui.pages.drupal.discounts.coupons;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class eCommAddCouponPage extends eCommBase {

    @FindBy(id = "edit-title")
    private WebElementFacade inputPromoTitle;

    @FindBy(id = "edit-submit")
    private WebElementFacade createCouponButton;

    public void theUserAddCouponTitle(String promocode) {
        setText(this.inputPromoTitle,promocode);
        clickElement(this.createCouponButton);
    }
}
