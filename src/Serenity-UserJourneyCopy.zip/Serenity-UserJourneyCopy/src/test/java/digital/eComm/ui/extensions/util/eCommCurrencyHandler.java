package digital.eComm.ui.extensions.util;

import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.NumberFormat;
import java.util.Locale;

public class eCommCurrencyHandler extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommCurrencyHandler.class);
    String regionalPayment;

    public String getRegionalCurrency(Double payment) {

        switch (Staf.getTargetRegion()) {

            case "uk":
                regionalPayment = NumberFormat.getCurrencyInstance(Locale.UK).format(payment);
                break;
            case "fi":
                regionalPayment = NumberFormat.getCurrencyInstance(new Locale("fi", "FI")).format(payment).replace(",", ".").replace(" €", "  €");
                break;
            case "nl":
            case "ie":
                regionalPayment = NumberFormat.getCurrencyInstance(new Locale("nl", "NL")).format(payment).replace(",", ".");
                regionalPayment = regionalPayment.replaceAll("\\p{Z}","");
                break;
            case "no":
                regionalPayment = NumberFormat.getCurrencyInstance(new Locale("no", "NO")).format(payment).replace(",", ".");
                break;
            case "dk":
                regionalPayment = NumberFormat.getInstance(new Locale("da", "DK")).format(payment).concat(",00  kr");
                break;
            case "se":
                regionalPayment = NumberFormat.getCurrencyInstance(new Locale("sv", "SE")).format(payment).replace(" kr", "  kr");
                break;
            case "au":
            case "nz":
                regionalPayment = NumberFormat.getCurrencyInstance(Locale.US).format(payment);
                break;
            default:
                logger.info("Invalid region!!!");
                break;
        }

        return regionalPayment;
    }
}
