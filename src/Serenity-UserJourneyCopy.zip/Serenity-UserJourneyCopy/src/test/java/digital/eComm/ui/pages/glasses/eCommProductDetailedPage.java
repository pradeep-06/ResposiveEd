package digital.eComm.ui.pages.glasses;

import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.eCommProductSearchPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import digital.eComm.ui.pages.eCommHomePage;

public class eCommProductDetailedPage extends eCommBase {

    eCommProductSearchPage ecommProductSearchPage;
    eCommHomePage eCommHomePage;
    @FindBy(css = "div#content-column a.btn.btn-block.btn-xl.btn-primary.buy-btn.frames-buy-online-button")
    public WebElementFacade buyOnline;

    @FindBy(xpath = "//*[@id=\"specs-vto-button_specs-vto-icon\"]|//*[@class=\"specs-button-icon pdp-inline\"]|//div[contains(@class,'button-text')]")
    public WebElementFacade virtualTryOnButton;

    @FindBy(xpath = "//*[@id=\"specs-modal_footer\"]/button[2]")
    public WebElementFacade understandVTOButton;

    @FindBy(css = "#specs-modal_header_close-button > svg")
    public WebElementFacade closeVTOButton;

    @FindBy(xpath = "//*[@id=\"header\"]/div[2]/nav/div[1]/ul[2]/li[2]/a/span")
    public WebElementFacade searchButton;

    @FindBy(xpath = "//*[@id=\"specs-vto-button_specs-vto-icon\"]|//*[@class=\"specs-button-icon pdp-inline\"]|//div[contains(@class,'button-text')]|//span[contains(@class,'icon-wrapper checked')]")
    public WebElementFacade virtualTryOn;

    @FindBy(xpath = "//*[contains(@class,'specs-icon--color-default specs-icon specs-icon--size-small specs-close-icon')]")
    public WebElementFacade closeModal;

    @FindBy(xpath = "//*[@id=\"specs-modal_footer\"]/button[2]|//*[@id=\"specs-modal_body\"]/div[1]/div[2]/div/button")
    public WebElementFacade understoodButton;

    @FindBy(css = "#specs-modal_body > div > div.specs-vto-product-details > button")
    public WebElementFacade addToFavorite;

    @FindBy(css="[class='favourites-item-section favourites-item-buynow-section']>a")
    public WebElementFacade findAStoreButton;

    @FindBy(css=".frame__image, .product-cards > li:first-of-type")
    private WebElementFacade clickGlass;

    public void clickBuyOnline() {
        evaluateScriptClick(buyOnline);
    }

    public void clickVirtualTryOnButton() {
        clickElement(virtualTryOnButton);
        waitABit(2000);
    }

    public void clickSearchButton() {
        clickElement(searchButton);
    }

    public void clickVirtualTryOn() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        clickElement(virtualTryOn);
        clickElement(understoodButton);
//        clickElement(closeModal);
       ecommProductSearchPage.isScanDisplayed();
    }

    public void clickUnderstandButton() {
        clickElement(understoodButton);
    }

    public void closeVTO() {
//        ecommProductSearchPage.isScanDisplayed();
        clickElement(closeModal);
    }

    public void closeVirtualTryOnModal() {
        clickElement(closeModal);
    }

    public void clickAddToFavorite() {
        clickElement(addToFavorite);
    }
    public void clickOnFindAStoreButton(){
        clickElement(this.findAStoreButton);
    }

    public void chooseFrame() {
        clickElement(this.clickGlass);
    }
}
