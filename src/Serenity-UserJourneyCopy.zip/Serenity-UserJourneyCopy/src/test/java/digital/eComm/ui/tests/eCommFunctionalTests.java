package digital.eComm.ui.tests;

import Framework.Annotations.Common.*;
import Framework.Annotations.Non_Delivery.BVT_DAILY_REGRESSION;
import Framework.Annotations.Non_Delivery.STAF2_QA;
import Framework.Staf;
import Framework.extensions.StafUtils;
import digital.eComm.ui.stepDefinitions.eCommStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;
import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("eComm")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class eCommFunctionalTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    eCommStepDefinitions ecomm;
    private final static String MAILOSAUR = "mailosaur";


    @BeforeEach
    public void getProcessId() throws Exception {
        Staf.getDriversProcessId();
    }

    @SMOKE
    @Regression
    @RE_RUN
    @Tags(value = {@Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("no"), @Tag("se"), @Tag("fi"), @Tag("nl"), @Tag("ie"), @Tag("uk")})
    @SSTest(testCaseId = "42260616", projectId = "96896", testCaseName = "_001_Check_line_level_discounts", testType = SSTestType.LEGACY, testCaseVersion = "4.0")
    public void _001_Check_line_level_discounts() {

        ecomm.lineLevelDiscountHasBeenSetupInDrupal();
        ecomm.openeCommHome();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.lineLevelDiscountHasBeenAppliedInCheckout();
        ecomm.theUserConfirmProductDetailsBeforeCheckout();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 17
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.guestUserPerformsInvoiceCheckToConfirmDiscountIsApplied();
        ecomm.discountHasBeenRemoved();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("no"), @Tag("se"), @Tag("fi"), @Tag("nl"), @Tag("ie"), @Tag("uk")})
    @SSTest(testCaseId = "42244125", projectId = "96896", testCaseName = "003 - Check promo code order level discount", testType = SSTestType.LEGACY, testCaseVersion = "5.0")
    public void _003_Check_promo_code_order_level_discount() {

        ecomm.codeHasBeenSetupInDrupal();
        ecomm.discountHasBeenSetupInDrupal();
        ecomm.openeCommHome();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.useCode();
        ecomm.theUserConfirmProductDetailsBeforeCheckout();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.guestUserPerformsOrderlevelInvoiceCheckToConfirmDiscountIsApplied();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Order(1)
    @Tags(value = {@Tag("no"), @Tag("uk"), @Tag("dk"), @Tag("se"), @Tag("nz"), @Tag("au"), @Tag("fi"), @Tag("nl"), @Tag("ie")})
    @SSTest(testCaseId = "41419500", projectId = "106044", testCaseName = "Validate a user without an account can purchase some contact lenses then retrieve the order and perform store credential check", testType = SSTestType.LEGACY, testCaseVersion = "5.0")
    public void Add_contact_lens_products_to_basket_and_complete_order_save_and_retrieve_details() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data  DB : //Disabled due to IE failure
        ecomm.searchAndSelectContactLensProductBySku();
        //ecomm.selectFirstContactLensProduct(); //Select product and validate the correct detailed product page is displayed
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 10
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription(); // What is the use of this method ?
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();

        //Below step required for creating account and validating store credentials
        ecomm.theUserRetrieveOrderDetailsAndPerformStoreCredentialCheckOnly();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Order(2)
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("dk"), @Tag("se"), @Tag("nz"), @Tag("au"), @Tag("fi"), @Tag("nl"), @Tag("ie")})
    @SSTest(testCaseId = "41601571", projectId = "106044", testCaseName = "A returning customer can place a contact lens order with Worldpay", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void A_returning_customer_can_place_a_contact_lens_order_with_Worldpay() {

        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription("");
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectExistingCustomerDuringCheckout();
        ecomm.alreadyMemberLoginWithTheCredentials();
        ecomm.theExistingUserContinueWithTheAddressDetails();
        ecomm.theExistingUserSelectPaymentMethodAndContinue("");
        ecomm.theExistingEntersPaymentDetailsAndContinues();
        ecomm.theExistingUserRetrieveOrderDetailsAndPerformStoreCredentialCheck();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Order(3) //CL 2022.02.17 Update the test case ID
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("dk"), @Tag("se"), @Tag("nz"), @Tag("au"), @Tag("fi"), @Tag("nl"), @Tag("ie")})
    @SSTest(testCaseId = "41415864", projectId = "106044", testCaseName = "A returning customer can place a contact lens order with saved card", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void A_returning_customer_can_place_a_contact_lens_order_with_saved_card() {

        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity();
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription();
        ecomm.specifyPrescriptionDetailsAndContinue();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectExistingCustomerDuringCheckout();
        ecomm.alreadyMemberLoginWithTheCredentials();
        ecomm.theExistingUserContinueWithTheAddressDetails();
        ecomm.selectSavedCardPaymentMethod("");
        ecomm.theExistingUserRetrieveOrderNumberAndPerformStoreCredentialCheck();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Order(4)
    @Tags(value = {@Tag("fi"), @Tag("se"), @Tag("no"), @Tag("nz"), @Tag("au"), @Tag("nl")})
    @SSTest(testCaseId = "41415882", projectId = "106044", testCaseName = "A returning customer can place a contact lens subscription order with saved card", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void A_returning_customer_can_place_a_contact_lens_subscription_order_with_saved_card() {

        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        //ecomm.selectFirstContactLensProduct(); //Select product and validate the correct detailed product page is displayed
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 10
        ecomm.specifyPrescriptionDetailsForASubscriptionAndContinue(""); //select quantity of right eye and continue to prescription page
        ecomm.theUserSelectFrequencyAndSecurelyFromBasketPage();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectExistingCustomerDuringCheckout();
        ecomm.alreadyMemberLoginWithTheCredentials();
        ecomm.theExistingUserContinueWithTheAddressDetails();
        ecomm.theExistingUserSelectPaymentOptionAndContinue("");
        ecomm.theExistingUserRetrieveOrderNumberAndPerformStoreCredentialCheck();
    }

    @SMOKE
    @Regression
    @Order(7)
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("fi"), @Tag("se"), @Tag("no"), @Tag("nz"), @Tag("au"), @Tag("nl")})
    @SSTest(testCaseId = "41612639", projectId = "106044", testCaseName = "Add contact lens products to basket with subscription and complete checkout", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void Add_contact_lens_products_to_basket_with_subscription_and_complete_checkout() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 17
        ecomm.specifyPrescriptionDetailsForASubscriptionAndContinue(""); //select quantity of right eye and continue to prescription page
        ecomm.theUserConfirmSubscriptionAndPerformCheckout();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectSubscriptionPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        ecomm.theUserRetrieveOrderDetailsAndPerformStoreCredentialCheck();
        ecomm.checkeCommEmailInMailosaur(newEmailID, orderID, false,true);
    }

    //[2022.05.15 CL] Created specifically for qTest test item id 37495182 (project 96896) which is the same
    // as the test below 41415864 except it only has 2 steps (reporting to qTest issue) and it also checks the
    //customers email

    @BVT_DAILY_REGRESSION
    @Order(8) //CL 2022.02.17 Update the test case ID
    @Tags(value = {@Tag("no"), @Tag("nz")})
    @SSTest(testCaseId = "37495182", projectId = "96896", testCaseName = "A returning customer can place a contact lens order with saved card", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void TC_17_Check_that_you_can_XRO_with_saved_Card_Worldpay() {

        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.express_reOrder_with_saved_worldpay_card();
        ecomm.checkEmailExpressReOrder();
    }

    @Order(9)
    @Regression
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("fi"), @Tag("se"), @Tag("no"), @Tag("nz"), @Tag("au"), @Tag("nl")})
    @SSTest(testCaseId = "41423538", projectId = "106044", testCaseName = "A subscription returning customer can place a contact lens order with new card", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void A_subscription_returning_customer_can_place_a_contact_lens_order_with_new_card() {

        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectExistingCustomerDuringCheckout();
        ecomm.alreadyMemberLoginWithTheCredentials();
        ecomm.theExistingUserContinueWithTheAddressDetails();
        ecomm.theExistingUserSelectPaymentMethodAndContinue("");
        ecomm.theExistingEntersPaymentDetailsAndContinues();
        ecomm.theExistingUserRetrieveOrderDetailsAndPerformStoreCredentialCheck();
    }
    @SMOKE
    @Regression
    @Tags(value = {@Tag("no"), @Tag("dk"), @Tag("se"), @Tag("uk"), @Tag("nz"), @Tag("au"), @Tag("fi"), @Tag("nl"), @Tag("ie")})
    //ToDo update test case id,Project id and testcase name
    @SSTest(testCaseId = "38802424", projectId = "96896", testCaseName = "One off CL with Express Delivery", testType = SSTestType.LEGACY, testCaseVersion = "5.0")
    @Order(5)
    public void One_off_CL_with_Express_Delivery() {

        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigateToExpressReorderLink();
        ecomm.alreadyMemberLoginWithTheCredentials();
        ecomm.theExistingUserAmendsEyeQty("");
        ecomm.theExistingUserAddsNewAddress("");
        ecomm.theExistingUserAddsNewCard("");
        ecomm.theExistingCustomerAddsCardDetailsAndClicksCheckout();
        ecomm.placeOrderSecurelyForExpressReorder();
        ecomm.theExistingUserRetrieveOrderNumberAndPerformStoreCredentialCheck();
    }

    @SMOKE
    @Regression
    @Order(10)
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("nl"), @Tag("ie"), @Tag("se")})
    @SSTest(testCaseId = "38076115", projectId = "96896", testCaseName = "Add glasses to the basket and complete checkout", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void Add_glasses_to_the_basket_and_complete_checkout() {

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
//        ecomm.clickOnAnyPairOfGlassesinThePlp();
//        ecomm.makeSureThatTheSelectedPairCanBeOrderedOnline();
        ecomm.clickOnBuyOnlineButton();
        ecomm.inputRequiredInputsIntoTheForm();
        ecomm.whenICompleteAPurchaseForUsingWorldPayItShouldSucceed();
    }

    @SMOKE
    @Regression
    @Order(11)
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("nl"), @Tag("ie"), @Tag("se")})
    @SSTest(testCaseId = "41060865", projectId = "96896", testCaseName = "A returning customer can place a glasses order with Worldpay", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void A_returning_customer_can_place_a_glasses_order_with_Worldpay() {

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.clickOnAnyPairOfGlassesinThePlp();
        ecomm.makeSureThatTheSelectedPairCanBeOrderedOnline();
        ecomm.clickOnBuyOnlineButton();
        ecomm.inputRequiredInputsIntoTheForm();
        ecomm.whenExistingUserCompleteAPurchaseUsingWorldPayItShouldSucceed();
    }

    @SMOKE
    @Regression
    @Order(12)
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("se"), @Tag("no"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("nl"), @Tag("ie")})
    @SSTest(testCaseId = "41060869", projectId = "96896", testCaseName = "A returning customer can place a glasses order with saved card", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void A_returning_customer_can_place_a_glasses_order_with_saved_card() {

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.clickOnAnyPairOfGlassesinThePlp();
        ecomm.makeSureThatTheSelectedPairCanBeOrderedOnline();
        ecomm.clickOnBuyOnlineButton();
        ecomm.inputRequiredInputsIntoTheForm();
        ecomm.whenExistingUserCompleteAPurchaseForUsingSavedCard();
    }

    @SMOKE
    @Regression
    @Order(13)
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("nl")})
    @SSTest(testCaseId = "42018626", projectId = "106044", testCaseName = "The user confirms tax invoice information and payable amount after contact lens one off purchase", testType = SSTestType.LEGACY, testCaseVersion = "5.0")
    public void Confirm_that_the_tax_invoice_is_correct_after_placing_contact_lens_oneoff_order() {

        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity(""); //Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page
        ecomm.specifyPrescriptionDetailsAndContinue("");

        //Steps 6 to 10
        ecomm.theUserConfirmProductDetailsBeforeCheckout();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 17
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.guestUserPerformsInvoiceCheck();
    }

    @Regression
    @Order(6)
    @Tags(value = {@Tag("au"), @Tag("fi"), @Tag("uk"), @Tag("dk"), @Tag("ie"), @Tag("nl"), @Tag("no"), @Tag("nz"), @Tag("se")})
    @SSTest(testCaseId = "42633787", projectId = "96896", testCaseName = "Confirm password policy has been updated on a password reset and reset password", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void Confirm_Policy_And_Reset_Password() {

        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 6
        ecomm.userNavigatesToLoginPage();
        ecomm.userNavigatesToForgetPasswordPage();
        String eMail = ecomm.theUserRetrieveEmailIDFromCheckoutPage();
        ecomm.userEnterTheEmailIdAndClickOnSend(eMail);
        ecomm.checkUserPasswordEmailInMailosaur(eMail);
        ecomm.theUserVerifyPasswordAndLoginWithNewPassword();
    }

    @Regression
    @SMOKE
    @BVT_DAILY_REGRESSION
    @STAF2_QA
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("ie"), @Tag("fi")})
    @SSTest(testCaseId = "40717740", projectId = "102929", testCaseName = "A user should be able to scan from 'Product Details Page'", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void newScanFromPDP() {

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.OpenTryOnGlassesOnPdp();
//        ecomm.addGlassesToFavourites();
    }

    //[2022.05.18 CL] Created for qTest monthly regression to cover 40109072.
    @Regression
    @SMOKE
    @Tags(value = {@Tag("au")})
    @SSTest(testCaseId = "42248111", projectId = "106044", testCaseName = "Purchase contacts, create account, XRO without logout and no subscription", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void Purchase_contact_lenses_create_account_XRO_no_logout_no_subscription() {

        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink();
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity();
        ecomm.specifyRightEyeQuantity();
        ecomm.clickToSpecifyPrescription();
        ecomm.specifyPrescriptionDetailsAndContinue();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout(); //18
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        ecomm.ExistingUserClicksMyDetails(newEmailID);
        ecomm.ExistingUserChecksOrderSummary(orderID);
        ecomm.ExistingUserClicksOnLastOrder();
        ecomm.theExistingCustomerSelectsXROFromTheAccountOption();
        ecomm.theExistingUserConfirmCorrespondsOfTheOrder();
        ecomm.ExistingUserChecksOrderDetails();
        ecomm.ExistingUserLogsOutFromAccountDropDown();
    }

    @SMOKE
    @Regression
    //@BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("se"), @Tag("no"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("nl"), @Tag("ie"),@Tag("fi")})
    @SSTest(testCaseId = "38076116", projectId = "96896", testCaseName = "Add contact lens to the basket and complete checkout", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void TC_184_Add_contact_lens_products_to_basket_and_complete_checkout() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");

        //DB : Disabled due to IE failure
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity();
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription();
        ecomm.specifyPrescriptionDetailsAndContinue();
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("GuestUser1");
        ecomm.guestUserConfirmAddressDetailsAndContinue("GuestUser1");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        String eMail = ecomm.theUserRetrieveEmailIDFromCheckoutPage();
        ecomm.ExistingUserClicksMyDetails(eMail);
        ecomm.ExistingUserChecksOrderSummary(orderID);
        ecomm.ExistingUserClicksOnLastOrder();
        ecomm.ExistingUserLogsOutFromAccountDropDown();
        ecomm.checkeCommEmailInMailosaur4(eMail, orderID, false,false);
    }

    //[2022.05.18 CL] Created for qTest monthly regression to cover 40109072.
    @SMOKE
    @Regression
    //@BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("no"), @Tag("uk"), @Tag("dk"), @Tag("se"), @Tag("nz"), @Tag("au"), @Tag("fi"), @Tag("nl"), @Tag("ie")})
    @SSTest(testCaseId = "42244794", projectId = "106044", testCaseName = "Purchase contacts, create account, XRO with new card", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void Purchase_contact_lenses_create_account_XRO_new_card() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();

        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity();
        ecomm.specifyRightEyeQuantity();
        ecomm.clickToSpecifyPrescription();
        ecomm.specifyPrescriptionDetailsAndContinue(); //6

        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        ecomm.ExistingUserChecksOrderDetails(); //18

        //12
        ecomm.theExistingUserSelectsPaymentCards().theExistingUserSelectAddsNewCard().theExistingUserSelectMasterCard();
        ecomm.theExistingUserSelectConsentAndContinueWithThePreviousAddress();
        ecomm.theExistingUserSelectNextButton().theExistingUserAddMasterCardDetails();
        ecomm.theExistingUserSelectsContactLensReplacementOrder();
        ecomm.theExistingUserSelectsFromTheBillingInformationSection().theExistingUserConfirmCorrespondsOfTheOrder();
        ecomm.ExistingUserChecksOrderDetails();
        String lensReplacementOrderID = ecomm.theUserRetrieveLensReplacementOrderIDFromCheckoutPage();
        String eMail = ecomm.theUserRetrieveEmailIDFromCheckoutPage();

        ecomm.checkeCommEmailInMailosaur(eMail, orderID, false,false);
        ecomm.checkeCommEmailInMailosaur(eMail, lensReplacementOrderID, true,false);
        ecomm.ExistingUserLogsOutFromAccountDropDown();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("au"), @Tag("nz"), @Tag("ie"), @Tag("no"), @Tag("dk"), @Tag("nl"), @Tag("eses"), @Tag("esen")})
    @SSTest(testCaseId = "38075713", projectId = "96896", testCaseName = "Favourite an item in catalog", testType = SSTestType.LEGACY, testCaseVersion = "4.0")
    public void Favourite_an_item_in_catalog() {

        ecomm.openeCommHome();
        ecomm.GivenThereAreProductsAvailableInThePLP();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("au")})
    @SSTest(testCaseId = "39454783", projectId = "97986", testCaseName = "Customer can place order ISF with Medipass v3", testType = SSTestType.LEGACY, testCaseVersion = "5.0")
    public void customer_can_place_medipass_ISF_order() {
        ecomm.openeCommHome();
        ecomm.buyContactLensWithMedipassISF();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("au"), @Tag("uk")})
    @SSTest(testCaseId = "41968521", projectId = "106044", testCaseName = "Add contact lens products to basket with paypal and complete checkout", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void Add_contact_lens_products_to_basket_with_paypal_and_complete_checkout() {

        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 10
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 17
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription(); // What is the use of this method ?
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");

        ecomm.guestUserSelectPaypalPaymentMethodAndContinue();
        ecomm.guestUserEntersPaypalDetailsAndContinues();
        ecomm.guestUserEnterPasswordAndConfirmOrderNumber();
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("nl")})
    @SSTest(testCaseId = "41981068", projectId = "106044", testCaseName = "Add contact lens products to basket with iDeal and complete checkout", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void Add_contact_lens_products_to_basket_with_iDeal_and_complete_checkout() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 10
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 17
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription(); // What is the use of this method ?
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");

        ecomm.guestUserSelectIdealPaymentMethodAndContinue();
        ecomm.guestUserSelectsBankDetailsAndPerformAuthorization();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        String eMail = ecomm.theUserRetrieveEmailIDFromCheckoutPage();
        ecomm.checkeCommEmailInMailosaur(eMail, orderID, false,false);
    }

    //Note, removed NL from the list as there is some unexpected behavior on the auto-population of the after-care store search field.  To be discussed with Jack Duncan.
    @BVT_DAILY_REGRESSION
    @Regression
    @Tags(value = {@Tag("au"), @Tag("nz"), @Tag("fi"), @Tag("nl"), @Tag("no"), @Tag("se")})
    //ToDo [2022.06.07 CL]Regularly failing for UK and DK so I have taken out for now.  Needs resolving.
    @SSTest(testCaseId = "41257575", projectId = "106044", testCaseName = "Validate a user without an account can purchase some contact lenses (variant 1)", testType = SSTestType.LEGACY, testCaseVersion = "5.0")
    public void uat_purchase_contact_lens_no_account_variant1() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        //Variances in this version of contact lens purchase:
        // the user filters contact lenses by brand
        // the user searches for an aftercare store
        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 10
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("GuestUser1");
        ecomm.guestUserConfirmAddressDetailsAndContinue("GuestUser1");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        String eMail = ecomm.theUserRetrieveEmailIDFromCheckoutPage();
        ecomm.checkeCommEmailInMailosaur(eMail, orderID, true,false);
    }

    @SMOKE
    @Regression
    @BVT_DAILY_REGRESSION
    @Tags(value = {@Tag("uk"), @Tag("au")})
    @SSTest(testCaseId = "39331779", projectId = "96896", testCaseName = "Using PayPal to purchase glasses", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void Add_glasses_to_basket_with_paypal_and_complete_checkout() {

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.clickOnAnyPairOfGlassesinThePlp();
        ecomm.makeSureThatTheSelectedPairCanBeOrderedOnline();
        ecomm.clickOnBuyOnlineButton();
        ecomm.inputRequiredInputsIntoTheForm();
        ecomm.whenICompleteAPurchaseForUsingPaypalItShouldSucceed();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("uk"), @Tag("dk"), @Tag("ie"), @Tag("no"), @Tag("nz"), @Tag("se"), @Tag("nl")})
    @SSTest(testCaseId = "43639239", projectId = "106044", testCaseName = "User adds two pairs of glasses to basket and 2for1 discount is applied", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    void Purchase_Multiple_Frame_Purchase_Create_Account() {

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();

 //       ecomm.openeCommHomeAndAcceptCookies();

        // Steps 1-5
 //       ecomm.userNavigatesToGlassesPage();
        ecomm.userSelectsMaleFromAgeAndGenderFilter();
        ecomm.userSelectsOpticalFromTypeFilter();
        ecomm.userSelectsBuyOnlineFromAvailableOnlineFilter();

        ecomm.userSelectsSearchFromPDP();
        ecomm.userSearchesForGlassesFirstProduct();

        // Steps 11-15
        ecomm.userSelectsFrameFromSearch();
        ecomm.userSelectsBuyGlasses();
        ecomm.userEntersPrescriptionDetails();

        // Steps 16-20
        ecomm.userSelectsClearLensOption();
        ecomm.userSelectsStandardThicknessOption();
        ecomm.userSelectsScratchResistanceOption();
        ecomm.userSelectsAddToBasket();
        ecomm.userSelectsGlassesPageFromBasket();
        // Steps 21-25
        ecomm.userSelectsMaleFromAgeAndGenderFilter();
        ecomm.userSelectsDesignerFromTypeFilter();
        ecomm.userSelectsBuyOnlineFromAvailableOnlineFilter();

        ecomm.userSelectsSearchFromPDP();
        ecomm.userSearchesForGlassesSecondProduct();
        ecomm.userSelectsFrameFromSearch();

        // Steps 31-35
        ecomm.userSelectsBuyGlasses();
        ecomm.userSelectsClearLensOption();
        ecomm.userSelectsStandardThicknessOption();
        ecomm.userSelectsScratchResistanceOption();

        // Steps 36-40
        ecomm.userSelectsAddToBasketAndAsserts2for1();
        ecomm.userSelectsCheckoutWithNoHealthFund();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        // Steps 41-45
        ecomm.guestUserEnterAddressDetails("");
        ecomm.guestUserSelectsPreferredAftercareStore("");
        ecomm.guestUserSelectsSpecsaversPrescription();
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("uk"), @Tag("dk"), @Tag("ie"), @Tag("no"), @Tag("nz"), @Tag("se"), @Tag("nl")})
    @SSTest(testCaseId = "43639244", projectId = "96896", testCaseName = "Purchase_Single_Frame_Purchase_Create_Account_2201", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    void Purchase_Single_Frame_Purchase_Create_Account() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();

     //   ecomm.openeCommHomeAndAcceptCookies();

        // Steps 1-5
     //   ecomm.userNavigatesToGlassesPage();
        ecomm.userSelectsMaleFromAgeAndGenderFilter();
        ecomm.userSelectsOpticalFromTypeFilter();
        ecomm.userSelectsBuyOnlineFromAvailableOnlineFilter();

        ecomm.userSelectsSearchFromPDP();
        ecomm.userSearchesForGlassesFirstProduct();

        // Steps 11-15
        ecomm.userSelectsFrameFromSearch();
        ecomm.userSelectsBuyGlasses();
        ecomm.userEntersPrescriptionDetails();

        // Steps 16-20
        ecomm.userSelectsClearLensOption();
        ecomm.userSelectsStandardThicknessOption();
        ecomm.userSelectsScratchResistanceOption();
        ecomm.userSelectsAddToBasket();
        ecomm.userSelectsCheckoutWithNoHealthFund();

        // Steps 21-25
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");

        // Steps 26-29
        ecomm.guestUserSelectsSpecsaversPrescription();
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        ecomm.checkeCommEmailInMailosaur4(newEmailID, orderID,false,false);
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("au")})
    @SSTest(testCaseId = "42435319", projectId = "96896", testCaseName = "AU_Test_17_Purchase_Single_Frame_Purchase_Healthfund_Create_Account_2204", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    void Purchase_Single_Frame_Purchase_Health_Fund_Create_Account() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);

        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();

     //   ecomm.openeCommHomeAndAcceptCookies();

        // Steps 1-5
     //   ecomm.userNavigatesToGlassesPage();
        ecomm.userSelectsMaleFromAgeAndGenderFilter();
        ecomm.userSelectsOpticalFromTypeFilter();
        ecomm.userSelectsBuyOnlineFromAvailableOnlineFilter();
        ecomm.userSelectsFrameWithTryOn();

        // Steps 6-10
        ecomm.userSelectsVirtualTryOn();
        ecomm.userFollowsVTOOnScreenInstructions();
        ecomm.userClosesVTO();
        ecomm.userSelectsSearchFromPDP();
        ecomm.userSearchesForGlassesFirstProduct();

        // Steps 11-15
        ecomm.userSelectsFrameFromSearch();
        ecomm.userSelectsVirtualTryOn();
        ecomm.userClosesVTO();
        ecomm.userSelectsBuyGlasses();
        ecomm.userEntersPrescriptionDetails();

        // Steps 16-20
        ecomm.userSelectsClearLensOption();
        ecomm.userSelectsStandardThicknessOption();
        ecomm.userSelectsScratchResistanceOption();
        ecomm.userSelectsAddToBasket();
        ecomm.userSelectsCheckoutWithHealthFund();

        // Steps 21-25
        ecomm.clickOnCheckoutSecurelyFromBasketPage(); // not needed for no health plan
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");

        // Steps 26-30
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.guestUserSelectsSpecsaversPrescription();
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        ecomm.checkeCommEmailInMailosaur(newEmailID, orderID, false,false);
    }

    @Regression
    @Tags(value = {@Tag("fi")})
    @SSTest(testCaseId = "42419654", projectId = "96896", testCaseName = "Make EasyPay payment with card, save card, attempt to delete card in My Account and CSR", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void Attempt_To_Delete_Saved_Card_In_My_Account() {

        ecomm.openeCommHomeAndAcceptCookies();

        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 20
        ecomm.specifyPrescriptionDetailsForASubscriptionAndContinue(""); //select quantity of right eye and continue to prescription page
        ecomm.theUserConfirmSubscriptionAndPerformCheckout();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectSubscriptionPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        String orderID = ecomm.theGuestUserClicksSaveMyDetailsAfterCheckout(false, true);
        ecomm.navigateToMyWalletDetailsPageVerifyTheUnableToDeleteCardMessage();
        ecomm.theAdminUserAttemptToDeleteCardInCSR(orderID); // Card remove box should be greyed out in drupal
    }



    @Regression
    @Tags(value = {@Tag("fi")})
    @SSTest(testCaseId = "42664437", projectId = "96896", testCaseName = "Glasses_Search_Favourites_No_Purchase_2108", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void Glasses_Search_Favourites_No_Purchase() {
        ecomm.openeCommHome();


        ecomm.userIsOnTheGlassesLandingPage();
       // ecomm.openeCommHomeAndAcceptCookies();
       // ecomm.userNavigatesToGlassesPage();
        ecomm.userSelectsMaleFromAgeAndGenderFilter();
        ecomm.userSelectsOpticalFromTypeFilter();
        ecomm.userSelectsFrameWithTryOn();
        ecomm.userSelectsVirtualTryOn();
        ecomm.userFollowsVTOOnScreenInstructions();
        ecomm.userClosesVTO();
        ecomm.userClicksOnFavouritesIconDisplayAtLeftSideOfPriceValue();
        ecomm.userClicksOnViewFavouritesButton();
        ecomm.userClicksOnFindAStoreButton();
        ecomm.verifyStoreNamesAreDisplayedBasedOnSearchLocationEntered();
    }

    @Regression
    @Tags(value = {@Tag("nl")})
    @SSTest(testCaseId = "42664471", projectId = "96896", testCaseName = "Purchase_Contact_Lense_Purchase_Create_Account_Ideal_XRO_New_card_2205", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void Purchase_Contact_Lense_Purchase_Create_Account_Ideal_XRO_New_card_2205() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription("");
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails();
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();
        ecomm.userNavigatestoMyOrderDetailsPageViaMyAccountsMenuLink();
        ecomm.verifyOrderDetailsPageisDisplayedWhenUserClicksOnOrderNumber();

        ecomm.theExistingUserSelectsPaymentCards().theExistingUserSelectAddsNewCard();
        ecomm.theExistingUserSelectIdealCard();
        ecomm.existingUserEnterIdealCardDetailsAndClickOnNextButton();
        ecomm.existingUserSelectsBankDetailsAndPerformAuthorization();
        ecomm.userNavigateToExpressReorderLink();
        String orderNumber=ecomm.verifyReOrderingOfConcatLensesUsingNewlyAddedIDealCard();
        ecomm.verifyOrderNumbersAreDisplayedInOrderSummaryPage(orderNumber);
    }

    @Regression
    @Tags(value = {@Tag("ie")})
    @SSTest(testCaseId = "42664525", projectId = "96896", testCaseName = "Check that you can amend qty on XRO", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void CheckThatYouCanAmendQtyOnXRO(){
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription("");
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();

        ecomm.theExistingCustomerSelectsXROFromTheAccountOption();
        String orderNumber=ecomm.verifyReOrderingWithAmendedQuantityOfContactLensesUsingVisaCard();
        ecomm.verifyOrderNumbersAreDisplayedInOrderSummaryPage(orderNumber);
    }

    @Regression
    @Tags(value = {@Tag("no"),@Tag("se")})
    @SSTest(testCaseId = "42664525", projectId = "96896", testCaseName = "Check that you can amend qty on XRO", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void CheckThatYouCanAmendQtyOnXROConsentConfirm(){
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink();
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink("");
        ecomm.searchAndSelectContactLensProductBySku();
        ecomm.specifyLeftEyeQuantity("");
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription("");
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription();
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();
        ecomm.theGuestUserProvidesPasswordsAfterCheckout();

        ecomm.theExistingCustomerSelectsXROFromTheAccountOption();
        String orderNumber=ecomm.verifyReOrderingWithAmendedQuantityOfContactLensesUsingVisaCardConsentConfirm();
        ecomm.verifyOrderNumbersAreDisplayedInOrderSummaryPage(orderNumber);
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("ie"),@Tag("no"),@Tag("nz"),@Tag("dk")})
    @SSTest(testCaseId = "42695116", projectId = "96896", testCaseName = "CSR User is able to update customer details in Drupal backend/Cassie - FR On", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void CSRUserIsAbleToUpdateCustomerDetailsInDrupalBackend(){
        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.clickOnAnyPairOfGlassesinThePlp();
        ecomm.clickOnBuyOnlineButton();
        ecomm.inputRequiredInputsIntoTheForm();
        String orderID= ecomm.whenICompleteAPurchaseForUsingWorldPayItShouldSucceed();
        ecomm.closeSession();

        ecomm.loginAsAdminUser();
        ecomm.clickOnCustomerNameToViewCustomerDetails(orderID);
        ecomm.getCustomerDetailsBeforeUpdate();
        ecomm.updateCustomerDetailsPage();
        ecomm.getCustomerDetailsAfterUpdate();
        ecomm.verifyCustomerDetailsAreUpdated();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("nl")})
    @SSTest(testCaseId = "40020341", projectId = "102929", testCaseName = "A user can interact with FittingBox Live VTO modal", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void Check_Live_VTO_Modal() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.navigateToPLP();
        ecomm.checkFittingBoxLiveVTO();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("uk"), @Tag("se"), @Tag("no"), @Tag("au"), @Tag("nz"), @Tag("dk"), @Tag("ie"), @Tag("nl"), @Tag("fi"), @Tag("eses")})
    @SSTest(testCaseId = "43556404", projectId = "102929", testCaseName = "A user can start up Luna or FittingBox VTO modal on PDP", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void VTO_Modal_Is_Responsive() {
        ecomm.openeCommHome();
        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.userSelectsVirtualTryOn();
    }

    @SMOKE
   // @Regression
//    @Tags(value = {@Tag("uk"), @Tag("se"), @Tag("no"), @Tag("dk"), @Tag("ie"), @Tag("nl")})
    @SSTest(testCaseId = "43559516", projectId = "102929", testCaseName = "A user can start up Luna or FittingBox VTO after refining results", testType = SSTestType.LEGACY, testCaseVersion = "13.0")
    public void Check_VTO_Persistence() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.navigateToPLP();
        ecomm.filterListByQuickFilter();
        ecomm.selectPageSize();
        ecomm.loadMoreFrames();
    }

    @SMOKE
    @Regression
    @Tags(value = {@Tag("uk"), @Tag("au"), @Tag("dk"), @Tag("ie"), @Tag("no"), @Tag("nz"), @Tag("se"), @Tag("fi"), @Tag("eses"), @Tag("nl")})
    @SSTest(testCaseId = "44127188", projectId = "106044", testCaseName = "VTO_E2E", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void VTO_E2E() {

        ecomm.openeCommHome();

        ecomm.userIsOnTheGlassesLandingPage();
        ecomm.userNavigatesToGlassesPage();
        ecomm.userSelectsMaleFromAgeAndGenderFilter();
        ecomm.userSelectsOpticalFromTypeFilter();
        ecomm.userSelectsBuyOnlineFromAvailableOnlineFilter();
        ecomm.userSelectsFrameWithTryOn();

        // Steps 6-10
        ecomm.userSelectsVirtualTryOn();
        ecomm.userFollowsVTOOnScreenInstructions();
        ecomm.userClosesVTO();
        ecomm.userSelectsSearchFromPDP();
        ecomm.userSearchesForGlassesFirstProduct();

        // Steps 11-15
        ecomm.userSelectsFrameFromSearch();
        ecomm.userSelectsVirtualTryOn();
        ecomm.userClosesVTO();
    }

    @Regression
    @Tags(value = {@Tag("esen"), @Tag("eses")})
    @SSTest(testCaseId = "44690595", projectId = "96896", testCaseName = "change Language", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void CheckChangeLanguage() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.clickOnLanguageButton();
        ecomm.titleChangesToSelectedLanguage();
    }

    @Regression
    @Tags(value = {@Tag("esen"), @Tag("eses")})
    @SSTest(testCaseId = "42630867", projectId = "96896", testCaseName = "find Store", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void VerifyFindAStoreAndView() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.clicksOnFindAStoreButton();
        ecomm.clickOnViewStoreBtn();
    }

    @Regression
    @Tags(value = {@Tag("au"),@Tag("uk"),@Tag("no"),@Tag("nl"),@Tag("ie"),@Tag("dk"),@Tag("se"),@Tag("fi"),@Tag("nz")})
    @SSTest(testCaseId = "42630867", projectId = "96896", testCaseName = "Find_a_store_via_the_header_store_finder", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void VerifyFindAStoreLinkInStoreSearchResultPage() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.v3_searchStoreViaFindStoreLink();
        ecomm.v4_verifyFindAStoreLinkIsDisplayed();
    }

    @Regression
    @Tags(value = {@Tag("nz")})
    @SSTest(testCaseId = "42630871", projectId = "96896", testCaseName = "RequestForm", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void VerifyRequestForm() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.findRAFStore();
        ecomm.selectAStore();
        ecomm.selectRAFAppointmentAs_ContactLensAssessment();
        ecomm.verifyRequestAnAppointmentButtonIsDisplayed();
    }

    @Regression
    @Tags(value = {@Tag("uk"),@Tag("ie"),@Tag("nl"),@Tag("no")})
    @SSTest(testCaseId = "44270957", projectId = "96896", testCaseName = "Book_Adult_Sight-Test_Appointment_Journey_2204", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void BookAdultSightTestAppointmentJourney() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.findSASStore();
        ecomm.selectAStore();
        ecomm.selectSASAppointmentAs_AdultSightTest();
    }

    @Regression
    @Tags(value = {@Tag("uk"),@Tag("ie")})
    @SSTest(testCaseId = "44270959", projectId = "96896", testCaseName = "Test_02_Book_Child_Sight-Test_Appointment_Journey_2204", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void BookChildEyeTestAppointmentJourney() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.findSASStore();
        ecomm.selectAStore();
        ecomm.selectSASAppointmentAs_ChildEyeTest();
    }

    @Regression
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "44270932", projectId = "96896", testCaseName = "Book_Contact_Lens_Consultation_&_Trial_Journey_2204", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void BookContactLensConsultationAndTrialJourney() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.findSASStore();
        ecomm.selectAStore();
        ecomm.selectSASAppointmentAs_ContactLensConsultationAndTrial();
    }

    @Regression
    @Tags(value = {@Tag("ie")})
    @SSTest(testCaseId = "44270952", projectId = "96896", testCaseName = "Contact Lens Initial Appointment Journey 2203", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void ContactLensInitialAppointmentJourney() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.findSASStore();
        ecomm.selectAStore();
        ecomm.selectAppointmentAs_ContactLensInitialappointment();
    }

    @Regression
    @Tags(value = {@Tag("ie"),@Tag("uk")})
    @SSTest(testCaseId = "42709632", projectId = "96896", testCaseName = "Drupal Audiology Booking", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void verifyDrupalAudiologyBooking() {
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.findSASStore();
        ecomm.selectAStore();
        ecomm.clickOnHearingServices();
        ecomm.clickHearingAppointment();
    }

    @Regression
    @Tags(value = {@Tag("nl")})
    @SSTest(testCaseId = "44943547", projectId = "96896", testCaseName = "Add the Solution product to basket via the CTA", testType = SSTestType.LEGACY, testCaseVersion = "1.0")
    public void addSolutionProductViaCTA() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();

        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data  DB : //Disabled due to IE failure
        ecomm.searchAndSelectContactLensProductBySkuMerken();
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        ecomm.specifyPrescriptionDetailsAndContinueMerken("");
        ecomm.clickOnAddSolutionLiquidCTA();

        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserEnterAddressDetailsAndSelectAftercareStoreFromList("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription(); // What is the use of this method ?
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();

        //Below step required for creating account and validating store credentials
        ecomm.theUserRetrieveOrderDetailsAndPerformStoreCredentialCheckOnly();
    }

    @Regression
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("dk"), @Tag("se"), @Tag("nz"), @Tag("au"), @Tag("fi"), @Tag("nl"), @Tag("ie")})
    @SSTest(testCaseId = "41601571", projectId = "106044", testCaseName = "Using search location to checkout", testType = SSTestType.LEGACY, testCaseVersion = "8.0")
    public void checkoutUsingSearchLocation() {
        String newEmailID = StafUtils.generateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        //Steps 1 to 5
        ecomm.userNavigatesToContactLensPageViaPrimaryNavLink(); //navigate to contact lenses landing page and validate correct page is returned
        ecomm.theUserNavigatesToBrandViaCommonBrandsLink(""); //Select a common brand from one of the sub-links of the primary navigation link 'Contact Lenses'.  Uses region-specific data  DB : //Disabled due to IE failure
        ecomm.searchAndSelectContactLensProductBySku();
        //ecomm.selectFirstContactLensProduct(); //Select product and validate the correct detailed product page is displayed
        ecomm.specifyLeftEyeQuantity("");//Select quantity of left lens required
        ecomm.specifyRightEyeQuantityAndClickSelectPrescription(""); //select quantity of right eye and continue to prescription page

        //Steps 6 to 10
        ecomm.specifyPrescriptionDetailsAndContinue("");
        ecomm.clickOnCheckoutSecurelyFromBasketPage();
        ecomm.selectNewCustomerDuringCheckoutGuestUser();
        ecomm.guestUserEnterPersonalDetails(newEmailID);
        ecomm.guestUserSpecifyToEnterAddressDetailsManually();

        //Steps 11 to 16
        ecomm.guestUserSearchWithPostcode("");
        ecomm.guestUserConfirmAddressDetailsAndContinue("");
        ecomm.specifyGuestUserHasSpecsaversPrescription(); // What is the use of this method ?
        ecomm.guestUserSelectStoreFromVerifyPrescriptionPage("");
        ecomm.guestUserSelectPaymentMethodAndContinue("");
        ecomm.guestUserEntersPaymentDetailsAndContinues();

        //Below step required for creating account and validating store credentials
        ecomm.theUserRetrieveOrderDetailsAndPerformStoreCredentialCheckOnly();
    }

    @Regression
    @Tags(value = {@Tag("esen"), @Tag("eses")})
    @SSTest(testCaseId = "42521390", projectId = "96896", testCaseName = "Check Booking Email", testType = SSTestType.REPLATFORM, testCaseVersion = "1.0")
    public void CheckBookingEmail() {
        String newEmailID = StafUtils.esGenerateNewCustomerEmail(MAILOSAUR);
        ecomm.openeCommHomeAndAcceptCookies();
        ecomm.clicksOnFindAStoreButton();
        ecomm.clickOnViewStoreBtn();
        ecomm.rafSelectRequestAnAppointmentTab();
        ecomm.selectRAFAppointmentAs_AdultEyeTest();
        ecomm.inputRAFPersonalDetailsForBooking(newEmailID);
        ecomm.submitButton();
        ecomm.checkeCommEmailInMailosaur3(newEmailID);
    }


    @AfterEach
    public void tearDown() {
        ecomm.closeSession();
    }
}