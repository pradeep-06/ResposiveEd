package digital.eComm.ui.pages.drupal.worldpay;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommXMLMessagePage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommXMLMessagePage.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = "tr:nth-child(6)>td")
    public WebElementFacade worldPayXmlMessage;


    public void assertStoreCredentialLogsDetails()  {

        assertElementContainsText(this.worldPayXmlMessage,
                testDataManager.getTestAssertionData("worldPayStoredCredentials.worldPayRecentLogMessage"));
        assertElementContainsText(this.worldPayXmlMessage,
                testDataManager.getTestAssertionData("worldPayStoredCredentials.worldPayNewCardMerchantCode"));
        logger.info("the user confirmed store credentials XML details");

    }

}
