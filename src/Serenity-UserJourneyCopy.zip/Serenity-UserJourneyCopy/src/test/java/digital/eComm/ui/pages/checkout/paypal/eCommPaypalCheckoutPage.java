package digital.eComm.ui.pages.checkout.paypal;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class eCommPaypalCheckoutPage extends eCommBase {

    @FindBy(css = "div#hermione-container p.SingleShippingAddress_name_3siDP")
    private WebElementFacade inputEmail;

    @FindBy(id = "payment-submit-btn")
    private WebElementFacade payNowButton;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    private WebElementFacade continueButton;

    @FindBy(xpath = "//input[@type='submit']")
    private WebElementFacade payNow;


    public void theUserConfirmThePayment() {

        if (continueButton.isPresent()) {
            clickElement(continueButton);
            clickElement(payNow);
        } else {
            clickElement(payNowButton);
        }

    }
}
