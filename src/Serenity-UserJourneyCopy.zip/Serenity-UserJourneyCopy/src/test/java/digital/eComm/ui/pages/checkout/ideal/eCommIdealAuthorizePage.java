package digital.eComm.ui.pages.checkout.ideal;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class eCommIdealAuthorizePage extends eCommBase {

    @FindBy(id = "op-Auth")
    private WebElementFacade authoriseButton;

    public void selectAuthorizationButton() {
        moveTo("#op-Auth");
        clickElement(authoriseButton);
    }
}
