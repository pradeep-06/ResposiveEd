package digital.eComm.ui.pages.checkout;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommCustomerAddressPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(className = "enter_manual_billing_entry")
    private WebElementFacade enterAddressManuallyLink;

    @FindBy(css = "#edit-customer-profile-billing-commerce-customer-address-und-0-thoroughfare")
    private WebElementFacade addressLine1;

    @FindBy(css = "#edit-customer-profile-billing-commerce-customer-address-und-0-locality")
    private WebElementFacade city;

    @FindBy(css = "#edit-customer-profile-billing-commerce-customer-address-und-0-administrative-area")
    private WebElementFacade state;

    @FindBy(css = "#edit-customer-profile-billing-commerce-customer-address-und-0-postal-code")
    private WebElementFacade postCode;

    @FindBy(xpath = "//span[contains(@id,'store')]")
    private WebElementFacade store;

    //Select Store Dropdown
    @FindBy(xpath = "//a[contains(@id,'aftercare')]//span[@class='ui-selectmenu-status']")
    private WebElementFacade storeDropDown;

    @FindBy(xpath = "//button[contains(@id,'edit-commerce-order-aftercare') and contains(@class,'store-search-selector-helper')]")
    private WebElementFacade searchStoreButton;
    //[2022.03.29 CL] Getting a stale ref object no linger attached error on this for some scenarios.

    //Aftercare Location Textbox
    @FindBy(xpath = "//input[contains(@id,'edit-commerce-order-aftercare-field-aftercare-store-id-und-0-location')]")
    private WebElementFacade aftercareSearchBox;


    //Aftercare Select Store Dropdown
    @FindBy(xpath = "//a[contains(@id,'edit-commerce-order-aftercare-field-aftercare-store')]//span[@class='ui-selectmenu-status']")
    private WebElementFacade searchStoreField;

    @FindBy(id = "edit-agree")
    private WebElementFacade agreeCheckbox;

    @FindBy(id = "edit-continue")
    private WebElementFacade addressDetailsContinueButton;

    @FindBy(xpath = "//*[@id=\"edit-commerce-order-aftercare-field-aftercare-store-id-und-0-location\"]")
    private WebElementFacade postcodeAfterCare;

    @FindBy(xpath = "//*[@id=\"edit-commerce-order-aftercare-field-aftercare-store-id-und-0-search-helper\"]")
    private WebElementFacade searchBTN;


    public void clickEnterAddressManuallyLink() {
        clickElement(this.enterAddressManuallyLink);
        logger.info("VALIDATE: Address line 1 field is visible after clicking click to enter address manually");
        assertPageObjectIsDisplayed(addressLine1);
    }

    public void clickEnterAddressManuallyLinkAndWait() {
        clickElement(this.enterAddressManuallyLink);
        waitABit(1000L);
        logger.info("VALIDATE: Address line 1 field is visible after clicking click to enter address manually");
        assertPageObjectIsDisplayed(addressLine1);
    }

    public void enterAddressLine1(String addressLineText) {
        clickElement(this.addressLine1);
        setText(this.addressLine1, addressLineText);
    }

    public void enterCity(String city) {
        setText(this.city, city);
    }

    public void enterPostCode(String postCode) {
        setText(this.postCode, postCode);
    }

    public void selectStore(String store) {
        selectOptionFromDropdown(this.store, store);
    }

    public void clickPostcodeField(String afterCareStorePostcode) {
        clickElement(this.postcodeAfterCare);
        setText(this.postcodeAfterCare, afterCareStorePostcode);
        clickElement(this.searchBTN);
    }

    public void selectState(String regionalData) {
        selectFromDropdown(this.state, regionalData);
    }

    public void clickAgreeCheckbox() {
        clickElement(agreeCheckbox);
    }

    public void clickAddressDetailsContinueButton() {
        clickElement(this.addressDetailsContinueButton);
    }

    //Objects accessible to external classes
    public WebElementFacade getEnterAddressManuallyLink() {
        return enterAddressManuallyLink;
    }

    public WebElementFacade getAddressLine1() {
        return addressLine1;
    }

    public WebElementFacade getAftercareSearchBox() {
        return this.aftercareSearchBox;
    }

    public WebElementFacade getAftercareSearchButton() {
        return this.searchStoreButton;
    }

    public WebElementFacade getAftercareStoreDropDown() {
        return this.storeDropDown;
    }

    //Feature Flags & Region Specific Feature Rules
    public boolean featureShowsEnterAddressManuallyLink() {
        return testDataManager.getFeatureData("shippingAddress.hasAddressManuallyLink", Boolean.class);
    }

    public boolean featureShowPrivacyPolicyAndTandCs() {
        return testDataManager.getFeatureData("privacyPolicies.termsAndConditions", Boolean.class);
    }

    public boolean featureAutoPopulateAfterCareSearchBox() {
        return testDataManager.getFeatureData("aftercareStore.autoPopulates", Boolean.class);
    }

}
