package digital.eComm.ui.pages.sharedModules.eCommCardDetails;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.LensExpressReorder;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommAddCard extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(LensExpressReorder.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(id = "edit-commerce-payment-payment-details-payment-code-nav-visa-ssl")
    public WebElementFacade visaCardRadioButton;

    @FindBy(id = "edit-commerce-payment-payment-details-payment-code-nav-ecmc-ssl")
    public WebElementFacade masterCardRadioButton;

    @FindBy(id = "edit-consent-cit")
    public WebElementFacade customerInitiatedConsent;

    @FindBy(id = "edit-commerce-customer-address-und-0-unipro-addressbook-entries")
    public WebElementFacade customerAddress;

    @FindBy(name = "commerce_customer_address[und][0][first_name]")
    public WebElementFacade firstName;

    @FindBy(name = "commerce_customer_address[und][0][last_name]")
    public WebElementFacade lastName;

    @FindBy(id = "edit-submit")
    public WebElementFacade nextButton;

    @FindBy(css = "[id='edit-commerce-payment-payment-details-payment-code-nav-ideal-ssl']")
    public WebElementFacade idealCardRadioButton;

    @FindBy(id = "edit-idealconsent")
    public WebElementFacade consentForIdealCard;

    public void selectVisaCard() {
        clickElement(this.visaCardRadioButton);
    }

    public void selectMasterCard() {
        clickElement(this.masterCardRadioButton);
    }

    public void theUserConfirmConsent() {
        clickElement(this.customerInitiatedConsent);
    }

    public void selectPreviousAddress() {
        customerAddress.selectByIndex(1);
        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        waitForElementTextToAppear(this.firstName, firstName);
    }

    public void selectNextButton() {
        clickElement(this.nextButton);
    }

    public void selectIdealCard() {
        clickElement(this.idealCardRadioButton);
    }

    public void theUserConfirmConsentForIdealCard() {
        clickElement(this.consentForIdealCard);
    }
}
