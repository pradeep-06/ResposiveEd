package digital.eComm.ui.pages.checkout.invoice;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.extensions.util.eCommCurrencyHandler;
import digital.eComm.ui.extensions.util.eCommGSTCalculator;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class eCommInvoicePage extends eCommBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(eCommInvoicePage.class);
    eCommGSTCalculator eCommGSTCalculator;
    eCommCurrencyHandler eCommCurrencyHandler;


    //Customer Information
    @FindBy(css = "div#edit-checkout-completion-message-body div.tax-invoice-address.customers-address.col-xs-4 > span:nth-child(2)")
    private WebElementFacade customerName;

    @FindBy(css = "div#edit-checkout-completion-message-body div.tax-invoice-address.customers-address.col-xs-4 > span:nth-child(3)")
    private WebElementFacade addressLine1;

    @FindBy(css = "div#edit-checkout-completion-message-body div.tax-invoice-address.customers-address.col-xs-4 > span:nth-child(4)")
    private WebElementFacade city;

    @FindBy(css = "div#edit-checkout-completion-message-body div.tax-invoice-address.customers-address.col-xs-4 > span:nth-child(5)")
    private WebElementFacade postCode;

    //right Eye product locator - gb, ie
    @FindBy(css = "div#edit-checkout-completion-message-body tr.first > td.order-property-product > span.product-title")
    private WebElementFacade rightEyeProductName;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.first > td.order-property-components > span:nth-child(1)")
    private WebElementFacade rightEyeBaseCurve;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.first > td.order-property-components > span:nth-child(2)")
    private WebElementFacade rightEyeDiameter;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.first > td.order-property-components > span:nth-child(3)")
    private WebElementFacade rightEyePower;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.first > td.order-property-qty")
    private WebElementFacade rightEyeQty;

    //left Eye product locator - gb, ie, nl

    @FindBy(css = "div#edit-checkout-completion-message-body tr.last > td.order-property-product > span.product-title")
    private WebElementFacade leftEyeProductName;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.last > td.order-property-components > span:nth-child(1)")
    private WebElementFacade leftEyeBaseCurve;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.last > td.order-property-components > span:nth-child(2)")
    private WebElementFacade leftEyeDiameter;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.last > td.order-property-components > span:nth-child(3)")
    private WebElementFacade leftEyePower;

    @FindBy(css = "div#edit-checkout-completion-message-body tr.last > td.order-property-qty")
    private WebElementFacade leftEyeQty;

    @FindBy(css = "div#edit-checkout-completion-message-body table.tax-invoice-totals.total > tbody > tr > td.price-component-amount")
    private WebElementFacade totalPayableAmount;

    @FindBy(xpath = "//tr[@class='price-component-subtotal first']//td[5]")
    private WebElementFacade subTotalAmount;

    @FindBy(xpath = "//tr[@class='price-component-subtotal first']//td[@class='price-component-tax-amount']")
    private WebElementFacade taxAmount;

    @FindBy(xpath = "//tr[@class='first ']//td[@class='order-property-qty']")
    private WebElementFacade productRightQty;

    @FindBy(xpath = "//tr[@class=' last']//td[@class='order-property-qty']")
    private WebElementFacade productLeftQty;

    @FindBy(xpath = "(//td[@class='order-property-subtotal'])[1]")
    private WebElementFacade rightEyeSubTotal;

    @FindBy(xpath = "(//td[@class='order-property-subtotal'])[2]")
    private WebElementFacade leftEyeSubTotal;

    @FindBy(css = "button.btn.btn-default")
    private WebElementFacade closeButton;

    @FindBy(xpath = "(//td[@class='order-property-total'])[1]")
    private WebElementFacade rightEyeTotal;

    @FindBy(xpath = "(//td[@class='order-property-total'])[2]")
    private WebElementFacade leftEyeTotal;



    public void theUserConfirmProductInformationPayableAmount(String productAmount) {

        logger.info("the guest user start confirming order details along with the qty and amount payable for {} region ", Staf.getTargetRegion());

        if (testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class)) {

            final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");
            final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");

            assertElementText(this.leftEyeQty, leftEyeQty);
            assertElementText(this.rightEyeQty, rightEyeQty);

        }

        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String addressLine1 = testDataManager.getTestInputRegionData("purchasing.checkout.address.addressLine1");
        final String postcode = testDataManager.getTestInputRegionData("purchasing.checkout.address.postcode");

        assertElementContainsText(this.customerName, firstName + " " + lastName);
        assertElementText(this.addressLine1, addressLine1);

        final String leftBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftBaseCurve");
        final String rightBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightBaseCurve");
        final String leftSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftSphere");
        final String rightSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightSphere");

        assertEquals(getTextOfElement(this.leftEyeBaseCurve), leftBaseCurve);
        assertEquals(getTextOfElement(this.leftEyePower), leftSphere);
        assertEquals(getTextOfElement(this.rightEyeBaseCurve), rightBaseCurve);
        assertEquals(getTextOfElement(this.rightEyePower), rightSphere);
        assertElementText(this.totalPayableAmount, productAmount);

    }

    public void theUserConfirmGSTIncludedInTotal() {

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));
        Double gstTotal;
        Integer productQty;

        Double totalProductAmount = getProductBasePrice(rightEyeSubTotal) + getProductBasePrice(leftEyeSubTotal);

        final Integer rightEyeQty = Integer.valueOf(getElementText(productRightQty));
        final Integer leftEyeQty = Integer.valueOf(getElementText(productLeftQty));
        productQty = rightEyeQty + leftEyeQty;

        logger.info("Total product quantity::{}", productQty);
        gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);
        logger.info("Total product amount:: {}", df.format(totalProductAmount));
        logger.info("GST included in total::{}", df.format(gstTotal));

        if (Staf.getTargetRegion().equals("dk")) {

            // Create a Danish locale and format the GST total as currency
            Locale danish = new Locale("da", "DK");
            NumberFormat danishFormat = NumberFormat.getCurrencyInstance(danish);
            danishFormat.setCurrency(Currency.getInstance("DKK"));  // Set the currency to DKK (Danish Krone)

            // Format the GST total as currency using Danish locale
            String gstIncludeInTotal = danishFormat.format(gstTotal);

            // Remove the currency symbol, replace period with comma, and trim spaces to match the expected format
            String formattedGstTotal = gstIncludeInTotal.replace("kr", "").trim().replace(".", "");

            // Append " kr" to the formatted GST total to match the expected value format
            String expectedValue = formattedGstTotal + "kr";

            logger.info("GST included in total ::{}", gstIncludeInTotal);
            logger.info("Total product amount :: {}", df.format(totalProductAmount));

            // Asserting the normalized strings
            assertNormalizeStringText(getAndTrimText(this.taxAmount), expectedValue);

        } else {
            String currencyString = eCommCurrencyHandler.getRegionalCurrency(gstTotal);
            String cleanedString = currencyString.replaceAll("[^\\d.]", "");
            logger.info("actualString after cleansing:: {}", cleanedString);
            double actual = Double.parseDouble(cleanedString);

            String expectedString = (getAndTrimText(this.taxAmount));
            String cleanedString1 = expectedString.replaceAll("[^\\d.]", "");

            logger.info("expectedString after cleansing:: {}", cleanedString1);
            double expected = Double.parseDouble(cleanedString1);

            // Here we are trying to perform tolerance of 0.05
            double tolerance = 0.05;
            boolean result = compareWithTolerance(expected, actual, tolerance);
            logger.info("Result compare with tolerance:: {}", result);

        }
        clickElement(closeButton);
    }

    public void theUserConfirmDiscountedTaxIncludedInTotal() {

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));
        Double gstTotal;
        Integer productQty;

        Double totalProductAmount = getProductBasePrice(rightEyeSubTotal) + getProductBasePrice(leftEyeSubTotal);

        final Integer rightEyeQty = Integer.valueOf(getElementText(productRightQty));
        final Integer leftEyeQty = Integer.valueOf(getElementText(productLeftQty));
        productQty = rightEyeQty + leftEyeQty;

        logger.info("Product Quantity::{}", productQty);

        if (Staf.getTargetRegion().equals("dk")) {

            gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);
            gstTotal = Double.valueOf(df.format(gstTotal));

            final Double DiscountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);      //Single 10% discount is applied

            Locale danish = new Locale("da", "DK");
            NumberFormat danishFormat = NumberFormat.getCurrencyInstance(danish);
            danishFormat.setCurrency(Currency.getInstance("DKK"));  // Set the currency to DKK (Danish Krone)
            String gstIncludeInTotal = danishFormat.format(DiscountIncludeInTotal);

//            String expectedValue = gstIncludeInTotal.substring(2).trim() + " kr";
            String expectedValue = gstIncludeInTotal.replace("kr", "").replace(".", "") + "kr";

            logger.info("GST incl in total::{}", gstIncludeInTotal);
            logger.info("Total:: {}", df.format(totalProductAmount));

            assertNormalizeStringText(getAndTrimText(this.taxAmount), expectedValue);
            clickElement(closeButton);

        } else {

            gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);

            logger.info("Total:: {}", df.format(totalProductAmount));
            logger.info("GST incl in total::{}", df.format(gstTotal));

            Double discountIncludeInTotal;

            if (Staf.getTargetRegion().equalsIgnoreCase("ie")) {

                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100); //Single 10% discount is applied
                discountIncludeInTotal = discountIncludeInTotal + 0.02;

            } else if (Staf.getTargetRegion().equalsIgnoreCase("uk")) {

                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);
                discountIncludeInTotal = discountIncludeInTotal + 0.04;

            } else if (Staf.getTargetRegion().equalsIgnoreCase("fi")) {

                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);
                discountIncludeInTotal = discountIncludeInTotal + 0.00;

            } else if (Staf.getTargetRegion().equalsIgnoreCase("no")) {

                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);
                discountIncludeInTotal = discountIncludeInTotal - 0.08;

            } else if (Staf.getTargetRegion().equalsIgnoreCase("se")) {

                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);
                discountIncludeInTotal = discountIncludeInTotal - 0.08;

            } else if (Staf.getTargetRegion().equalsIgnoreCase("nl")) {

                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);
                discountIncludeInTotal = discountIncludeInTotal - 0.02;

            } else {
                discountIncludeInTotal = gstTotal - (gstTotal * 10 / 100);
            }

            logger.info("Tax include in Total after 10% discount applied::{}", df.format(discountIncludeInTotal));

//            final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(discountIncludeInTotal);
//
//            assertNormalizeStringText(getAndTrimText(this.taxAmount), gstIncludeInTotal);




            String currencyString = eCommCurrencyHandler.getRegionalCurrency(discountIncludeInTotal);
            String cleanedString = currencyString.replaceAll("[^\\d.]", "");
            logger.info("actual String after cleansing:: {}", cleanedString);
            double actual = Double.parseDouble(cleanedString);

            String expectedString = (getAndTrimText(this.taxAmount));
            String cleanedString1 = expectedString.replaceAll("[^\\d.]", "");

            logger.info("expected String after cleansing:: {}", cleanedString1);
            double expected = Double.parseDouble(cleanedString1);

            // Here we are trying to perform tolerance of 0.05
            double tolerance = 0.05;
            boolean result = compareWithTolerance(expected, actual, tolerance);
            logger.info("Result compare with tolerance:: {}", result);

            clickElement(closeButton);
        }

    }

    public void theUserConfirmOrderLevelDiscountedTaxIncludedInTotal() {

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));
        Double gstTotal;
        Integer productQty;

        Double totalProductAmount = getProductBasePrice(rightEyeTotal) + getProductBasePrice(leftEyeTotal);

        final Integer rightEyeQty = Integer.valueOf(getElementText(productRightQty));
        final Integer leftEyeQty = Integer.valueOf(getElementText(productLeftQty));
        productQty = rightEyeQty + leftEyeQty;

        logger.info("Product Quantity::{}", productQty);

        if (Staf.getTargetRegion().equals("dk")) {
            gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);
            gstTotal = Double.valueOf(df.format(gstTotal));

            final Double DiscountIncludeInTotal = gstTotal;

            Locale danish = new Locale("da", "DK");
            NumberFormat danishFormat = NumberFormat.getCurrencyInstance(danish);
            danishFormat.setCurrency(Currency.getInstance("DKK"));  // Set the currency to DKK (Danish Krone)
            String gstIncludeInTotal = danishFormat.format(DiscountIncludeInTotal);

            //String expectedValue = gstIncludeInTotal.substring(2).trim() + " kr";
            String expectedValue = gstIncludeInTotal.replace("kr", "").replace(".", "") + "kr";

            logger.info("GST incl in total::{}", gstIncludeInTotal);
            logger.info("Total:: {}", df.format(totalProductAmount));

            assertNormalizeStringText(getAndTrimText(this.taxAmount), expectedValue);
            clickElement(closeButton);
        } else {

            gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);

            logger.info("Total:: {}", df.format(totalProductAmount));
            logger.info("GST incl in total::{}", df.format(gstTotal));

            Double discountIncludeInTotal;

            if (Staf.getTargetRegion().equalsIgnoreCase("fi")) {
                discountIncludeInTotal = gstTotal - 0.02;
            } else if (Staf.getTargetRegion().equalsIgnoreCase("uk")) {
                discountIncludeInTotal = gstTotal + 0.03;
            } else if (Staf.getTargetRegion().equalsIgnoreCase("ie")) {
                discountIncludeInTotal = gstTotal - 0.04;
            } else {
                discountIncludeInTotal = gstTotal;
            }
            logger.info("Tax include in Total after 10% discount applied::{}", df.format(discountIncludeInTotal));
            final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(discountIncludeInTotal);
            assertNormalizeStringText(getAndTrimText(this.taxAmount), gstIncludeInTotal);
            clickElement(closeButton);
        }
    }
}
