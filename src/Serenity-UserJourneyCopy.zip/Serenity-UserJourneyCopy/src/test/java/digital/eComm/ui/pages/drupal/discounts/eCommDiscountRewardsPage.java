package digital.eComm.ui.pages.drupal.discounts;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import digital.eComm.ui.pages.eCommHomePage;

import java.util.List;

public class eCommDiscountRewardsPage extends eCommBase {

    @FindBy(css = "div#commerce-discount-fields-wrapper li.horizontal-tab-button.horizontal-tab-button")
    private List<WebElement> horizontalTabs;

    @FindBy(css = "div#commerce-discount-fields-wrapper fieldset:nth-child(3) > div > div > div > ul > li.vertical-tab-button")
    private List<WebElement> verticalTabs;

    @FindBy(xpath = "//*[@id=\"edit-de-discount-fields-field-reward-para-und-0-field-q-product-type-und\"]//label")
    private List<WebElement> productType;

    @FindBy(css = "#edit-de-discount-fields-field-reward-para-und-0-field-q-line-target-attribute-und")
    private WebElementFacade attributeToTarget;

    @FindBy(css = "#edit-de-discount-fields-field-reward-para-und-0-field-q-line-target-attribute-v-und-0-value")
    private WebElementFacade discountAttributeValue;

    @FindBy(css = "#edit-de-discount-fields-field-reward-para-und-0-field-r-percent-off-und-0-value")
    private WebElementFacade linePercentOff;

    @FindBy(id = "edit-de-discount-fields-field-r-order-total-percent-off-und-0-value")
    private WebElementFacade orderPercentOff;

    @FindBy(css = "#edit-de-discount-fields-field-reward-para-und-add-more-add-more-bundle-discount-reward")
    private WebElementFacade addRewardQualifierBtn;

    @FindBy(css = "#edit-de-discount-fields-field-reward-para-und-add-more-add-more-bundle-discount-reward")
    private WebElementFacade addOrderLevelRewardBtn;

    eCommHomePage eCommHomePage;

    private final Logger logger = LoggerFactory.getLogger(eCommDiscountRewardsPage.class);

    public void addOrderLevelRewardsDetails() {

        logger.info("The user add order level reward details");
        TestDataManager testDataManager = new TestDataManager();
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        selectTab(horizontalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.tabHeader"));
        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.verticalTab.orderTabOption"));
        setText(orderPercentOff,testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.order.percentOff"));
        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.verticalTab.lineItemTabOption"));
        clickElement(addOrderLevelRewardBtn);
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.lineProduct.productType.default"));
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.lineProduct.productType.target"));
        selectFromDropdown(attributeToTarget, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.lineProduct.attributeToTarget"));
        setText(discountAttributeValue, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.lineProduct.attributeValue"));
//        setText(percentOff, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.rewards.lineProduct.percentOff"));

    }

    public void addLineLevelRewardsDetails() {
        logger.info("The user add line level reward details");
        TestDataManager testDataManager = new TestDataManager();

        selectTab(horizontalTabs, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.tabHeader"));
        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.verticalTab.lineItemTabOption"));
        clickElement(addRewardQualifierBtn);
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.lineProduct.productType.default"));
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.lineProduct.productType.target"));
        selectFromDropdown(attributeToTarget, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.lineProduct.attributeToTarget"));
        setText(discountAttributeValue, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.lineProduct.attributeValue"));
        setText(linePercentOff,testDataManager.getTestInputRegionData("drupal.discount.lineLevel.rewards.lineProduct.percentOff"));

    }
}
