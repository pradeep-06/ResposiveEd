package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.pages.checkout.*;
import digital.eComm.ui.pages.checkout.invoice.eCommInvoicePage;
import digital.eComm.ui.pages.checkout.invoice.eCommOrderInvoicePage;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.pages.sharedModules.eCommCardDetails.eCommCardDetailsPage;
import digital.eComm.ui.pages.sharedModules.eCommWebsiteHeader;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import digital.eComm.ui.pages.checkout.customeraccount.eCommPaymentMethod;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class OrderCheckOut extends ScenarioSteps {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
    final Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    static String emailId = null;
    static String cost = null;
    static String installment_cost = null;
    static String orderNo = null;

    eCommHomePage eCommHomePage;

    @Steps
    MailosaurEmailTesting emailMailosaur;

    eCommCustomerDetailsPage eCommCustomerDetailsPage;

    eCommCustomerAddressPage eCommCustomerAddressPage;

    eCommPaymentModePage eCommPaymentModePage;

    eCommCardDetailsPage eCommCardDetailsPage;

    eCommPrescriptionPage eCommPrescriptionPage;

    eCommOrderConfirmationPage eCommOrderConfirmationPage;

    eCommHealthFundDetailsPage eCommHealthFundDetailsPage;

    eCommMedipassCardDetailsPage eCommMedipassCardDetailsPage;

    eCommInvoicePage eCommInvoicePage;

    eCommOrderInvoicePage eCommOrderInvoicePage; // For ANZ

    eCommWebsiteHeader eCommWebsiteHeader;

    eCommPaymentMethod eCommPaymentMethod;

    public void theUserClicksImANewCustomer() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommCustomerDetailsPage.clickNewCustomerRadio();
    }

    public void theUserClicksIAmExistingCustomer() {
        eCommCustomerDetailsPage.clickExistingCustomerRadio();
    }

    public void theUserFillsMandatoryInfoForNewCustomerAfterNewCustomerClick() {
        theUserFillsMandatoryInfoForNewCustomerAfterNewCustomerClick("");
    }

    public void theUserFillsMandatoryInfoForNewCustomerAfterNewCustomerClick(String desiredEmail) {
        //Note where userRole = "" the common details for the region will be used.
        logger.info("Enter mandatory personal details for new customer");
        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String gender = testDataManager.getTestInputRegionData("purchasing.checkout.userInformation.gender");
        final String dob = testDataManager.getTestInputRegionData("purchasing.checkout.userInformation.dob");
        final String contactNumber = testDataManager.getTestInputCommonData("userDetails.phoneNumber");
        if (desiredEmail.equals("")) {
            emailId = "test.".concat(dateFormatter.format(timestamp)).concat("@test.com");
        } else {
            emailId = desiredEmail;
        }

        if (testDataManager.getFeatureData("checkoutPages.hasTitle", Boolean.class)) {

            final String title = testDataManager.getTestInputRegionData("purchasing.checkout.userInformation.title");
            eCommCustomerDetailsPage.selectUserTitle(title);
        }
        eCommCustomerDetailsPage.enterUserFirstName(firstName);
        eCommCustomerDetailsPage.enterUserLastName(lastName);
        eCommCustomerDetailsPage.enterUserEmailInputBox(emailId);

        logger.info("Customer email-id ::{}", emailId);
        eCommCustomerDetailsPage.enterUserConfirmEmailInputBox(emailId);

        this.enterBirthDate(dob);

        if (testDataManager.getFeatureData("checkoutPages.gender", Boolean.class)) {
            eCommCustomerDetailsPage.selectGender(
                    testDataManager.getTestInputRegionData("purchasing.checkout.userInformation.gender"));
        }
        if (testDataManager.getFeatureData("checkoutPages.hasPersonNumber", Boolean.class)) {
            eCommCustomerDetailsPage.enterSocialSecurityNumber(
                    testDataManager.getTestInputRegionData("purchasing.checkout.userInformation.personNumber"));
        }
        eCommCustomerDetailsPage.enterContactNumber(contactNumber);
        eCommCustomerDetailsPage.clickContinueButton();
    }

    public OrderCheckOut theUserFillsMandatoryInfoForNewCustomer() {
        theUserClicksImANewCustomer();
        theUserFillsMandatoryInfoForNewCustomerAfterNewCustomerClick();
        return this;
    }

    private void enterBirthDate(String prescriptionDate) {

        final String[] dateSplitter = prescriptionDate.split("-");
        eCommCustomerDetailsPage.selectDayElement(dateSplitter[0]);
        eCommCustomerDetailsPage.selectMonthElement(dateSplitter[1]);
        eCommCustomerDetailsPage.selectYearElement(dateSplitter[2]);
    }

    public void theUserClicksLinkToEnterAddressManually() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();

        if (eCommCustomerAddressPage.featureShowsEnterAddressManuallyLink()) {
            eCommCustomerAddressPage.clickEnterAddressManuallyLinkAndWait();
        }
    }

    public void searchForAfterCareStore(String store) {
        eCommCustomerAddressPage.selectStore(store);
    }

    public void manageTermsAndConditions() {
        if (eCommCustomerAddressPage.featureShowPrivacyPolicyAndTandCs()) {
            eCommCustomerAddressPage.clickAgreeCheckbox();
        }
    }

    public void theUserAddsAddressDetailsManually(String userRole) {

        final String addressLine1 = testDataManager.getTestInputRegionData("purchasing.checkout.address" + userRole + ".addressLine1");
        final String postcode = testDataManager.getTestInputRegionData("purchasing.checkout.address" + userRole + ".postcode");
        final String store = testDataManager.getTestInputRegionData("purchasing.checkout.desiredStoreName");
        final String town = testDataManager.getTestInputRegionData("purchasing.checkout.address" + userRole + ".town");

        eCommCustomerAddressPage.enterAddressLine1(addressLine1);
        eCommCustomerAddressPage.enterCity(town);
        eCommCustomerAddressPage.enterPostCode(postcode); //[30.03.2022 CL switched postcode nad town around to match order on most regional websites as this may be causing a problem auto-populating the aftercare store]

        if (testDataManager.getFeatureData("checkoutPages.hasState", Boolean.class)) {
            final String state = testDataManager.getTestInputRegionData("purchasing.checkout.address.state");
            eCommCustomerAddressPage.selectState(state);
        }
    }

    public void theUserAddsAddressDetailsManually() {
        theUserAddsAddressDetailsManually("");
    }

    public void clickAddressDetailsContinueButton() {
        eCommCustomerAddressPage.clickAddressDetailsContinueButton();
    }

    public void theUserAddAddressDetails() {

        final String store = testDataManager.getTestInputRegionData("purchasing.checkout.desiredStoreName");
        theUserClicksLinkToEnterAddressManually();
        theUserAddsAddressDetailsManually();
        searchForAfterCareStore(store);
        manageTermsAndConditions();
        clickAddressDetailsContinueButton();
    }

    public OrderCheckOut selectVisaCardForThePayment() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();

        logger.info("User select visa card and customer initiated transaction for the payment ");
        eCommPaymentModePage.clickVisaCard();
        eCommPaymentModePage.clickCustomerInitiatedTransactionsCheckBox();
        eCommPaymentModePage.clickPlaceOrderSecurely();
        return this;
    }

    private void addCardDetails() {

        final String cardNumber = testDataManager.getTestInputCommonData("cardDetails.visaNumber");
        final String cardholdersName = testDataManager.getTestInputCommonData("cardDetails.cardholdersName");
        final String expiryMonth = testDataManager.getTestInputCommonData("cardDetails.expiryMonth");
        final String expiryYear = testDataManager.getTestInputCommonData("cardDetails.expiryYear");
        final String securityCode = testDataManager.getTestInputCommonData("cardDetails.securityCode");

        eCommCardDetailsPage.waitForCredCardNumberField();
        eCommCardDetailsPage.enterCardNumber(cardNumber);
        eCommCardDetailsPage.enterCardholdersName(cardholdersName);
        eCommCardDetailsPage.enterExpiryMonth(expiryMonth);
        eCommCardDetailsPage.enterExpiryYear(expiryYear);
        eCommCardDetailsPage.enterSecurityCode(securityCode);
    }

    public void clickMakePayment() {
        eCommCardDetailsPage.clickMakePayment();
    }

    public void clickXroCheckoutSecurelyButton() {
        eCommCardDetailsPage.XroclickMakePayment();
    }

    public void theUserAddsCardDetailsAndClicksCheckout() {

        addCardDetails();
        clickMakePayment();
    }

    public void theXROUserAddsCardDetailsAndClicksCheckout() {
        addCardDetails();
        clickXroCheckoutSecurelyButton();
    }

    public void theUserAddCardDetails() {
        //ToDo this function has historically been used to add card details AND check out however it doesnt suggest
        //ToDo that in the name so I have created another method (which does) with the aim to repurpose this to adding
        //ToDo card details only.
        addCardDetails();
        clickMakePayment();
    }

    public OrderCheckOut theUserEnterPassword() {

        final String password = testDataManager.getTestInputCommonData("checkoutDetails.confirmPassword");

        eCommOrderConfirmationPage.enterEditPassword(password);
        eCommOrderConfirmationPage.enterEditConfirmPassword(password);
        eCommOrderConfirmationPage.clickSaveDetailsButton();
        return this;
    }

    public void checkInvoiceAndVerifyDiscount() {

        final String password = testDataManager.getTestInputCommonData("checkoutDetails.confirmPassword");

        eCommOrderConfirmationPage.enterEditPassword(password);
        eCommOrderConfirmationPage.enterEditConfirmPassword(password);
        eCommOrderConfirmationPage.clickSaveDetailsButton();
        logger.info("Order Number::{}", eCommOrderConfirmationPage.getOrderIdText());
        eCommOrderConfirmationPage.selectPrintInvoiceButton();
        logger.info("Discount price::{}", eCommOrderConfirmationPage.getDiscountPrice());

        // need to update this because assertions contains hardcoded value : Dipak
        Assertions.assertThat(eCommOrderConfirmationPage.getDiscountPrice()).contains("25.00");
    }

    public void selectVisaCardForTheSubscriptionPayment() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        logger.info("User select visa card and merchant initiated transaction for the payment ");
        eCommPaymentModePage.clickVisaCard();
        eCommPaymentModePage.clickMerchantInitiatedTransactionsCheckBox();
        eCommPaymentModePage.clickPlaceOrderSecurely();
    }

    //Checkout Page: Verify Prescription
    public void theUserConfirmsTheyHaveSpecsPrescription() {
        if (theRegionHasAPrescriptionPage()) {
            eCommPrescriptionPage.clickUserWithPrescription();
        }
    }

    public void theUserSelectsFromTheAftercareStoreDropDown(String userRole) {

        String afterCareStore = testDataManager.getTestInputRegionData("purchasing.checkout.desiredStoreName");
        eCommCustomerAddressPage.selectStore(afterCareStore);
    }

    public void theUserSearchStoreWithPostcode(String userRole) {

        String afterCareStorePostcode = testDataManager.getTestInputRegionData("purchasing.checkout.desiredStorePostcode");
        eCommCustomerAddressPage.clickPostcodeField(afterCareStorePostcode);
    }

    public void theUserClicksToContinueOnVerifyPrescriptionPage() {
        if (theRegionHasAPrescriptionPage()) {
            eCommPrescriptionPage.clickPrescriptionContinueButton();
        }
    }

    public Boolean theRegionHasAPrescriptionPage() {
        return testDataManager.getFeatureData(
                "checkoutPages.contactLensJourney.checkoutPrescriptionPagePresent", Boolean.class);
    }

    public Boolean theRegionHasAPrescriptionPageAvailable() {
        return testDataManager.getFeatureData(
                "checkoutPages.glassesJourney.checkoutPrescriptionPagePresent", Boolean.class);
    }

    public void theUserConfirmPrescriptionDetails() {

        if (theRegionHasAPrescriptionPage()) {
            theUserConfirmsTheyHaveSpecsPrescription();
            theUserSelectsFromTheAftercareStoreDropDown("");
            theUserClicksToContinueOnVerifyPrescriptionPage();
        }
    }

    public void theUserConfirmPrescriptionInformation() {

        if (theRegionHasAPrescriptionPageAvailable()) {

            theUserConfirmsTheyHaveSpecsPrescription();
            theUserSelectsFromTheAftercareStoreDropDown("");
            theUserClicksToContinueOnVerifyPrescriptionPage();
        }
    }

    public void selectMedipassForThePayment() {

        logger.info("the user select medipass payment option during checkout journey");

        if (testDataManager.getFeatureData("checkoutPages.medipassRadio", Boolean.class)) {

            final String healthFund1 = testDataManager.getTestInputRegionData("purchasing.checkout.basket.healthFund1");

            eCommPaymentModePage.clickMedipass();
            eCommPaymentModePage.selectHealthFundDropdown(healthFund1);
            eCommPaymentModePage.clickPlaceOrderSecurely();
        }
    }

    public void selectMedipassForThePaymentISF() {

        logger.info("the user select medipass ISF payment option during checkout journey");

        if (testDataManager.getFeatureData("checkoutPages.medipassRadio", Boolean.class)) {

            final String healthFund1 = testDataManager.getTestInputRegionData("purchasing.checkout.basket.healthFund1");

            eCommPaymentModePage.clickMedipass();
            eCommPaymentModePage.selectHealthFundDropdown(healthFund1);
            eCommPaymentModePage.clickPlaceOrderSecurely();
        }
    }

    public void theUserHealthFundDetails() {

        final String membershipNumber = testDataManager.getTestInputCommonData("medipassCardDetails.membershipNumber");
        final String patientNumber = testDataManager.getTestInputCommonData("medipassCardDetails.patientNumber");
        final String cardIssueNumber = testDataManager.getTestInputCommonData("medipassCardDetails.cardIssueNumber");

        eCommHealthFundDetailsPage.enterMembershipNumber(membershipNumber);
        eCommHealthFundDetailsPage.enterPatientNumber(patientNumber);
        eCommHealthFundDetailsPage.enterCardIssueNumber(cardIssueNumber);
        eCommHealthFundDetailsPage.clickContinueButton();
    }

    public void theUserHealthFundDetailsSkipAndPayFull() {

        final String membershipNumber = testDataManager.getTestInputCommonData("medipassCardDetails.membershipNumber");
        final String patientNumber = testDataManager.getTestInputCommonData("medipassCardDetails.patientNumber");
        final String cardIssueNumber = testDataManager.getTestInputCommonData("medipassCardDetails.cardIssueNumber");

        eCommHealthFundDetailsPage.enterMembershipNumber(membershipNumber);
        eCommHealthFundDetailsPage.enterPatientNumber(patientNumber);
        eCommHealthFundDetailsPage.enterCardIssueNumber(cardIssueNumber);
        eCommMedipassCardDetailsPage.clickSkipAndPayAmount();
    }

    public void medipassCardDetails() {

        final String cardNumber = testDataManager.getTestInputCommonData("medipassCardDetails.cardNumber");
        final String expiryDate = testDataManager.getTestInputCommonData("medipassCardDetails.expiryDate");
        final String cvc = testDataManager.getTestInputCommonData("medipassCardDetails.cvc");

        eCommMedipassCardDetailsPage.clickCardButton();
        eCommMedipassCardDetailsPage.enterCardNumber(cardNumber);
        eCommMedipassCardDetailsPage.enterExpiryDate(expiryDate);
        eCommMedipassCardDetailsPage.enterCvc(cvc);
        eCommMedipassCardDetailsPage.clickApproveButton();
    }

    public void medipassCardDetailsISF() {
        eCommMedipassCardDetailsPage.clickCardButtonISF();
        eCommMedipassCardDetailsPage.clickApproveButton();
    }

    public void checkDiscountDetails() {
        waitABit(10000); //Need to remove hard coded wait
        logger.info("SubTotal::{}", eCommOrderConfirmationPage.getSubTotal());
        logger.info("DiscountAmount::{}", eCommOrderConfirmationPage.getDiscountAmount());
    }

    public OrderCheckOut theExistingUserLoginWithTheCredentials() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();

        final String password = testDataManager.getTestInputCommonData("checkoutDetails.confirmPassword");

        eCommCustomerDetailsPage.theUserLoginWithTheCredentials(emailId, password);
        return this;
    }

    public void theUserContinueWithTheExistingAddressDetails() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        if (eCommCustomerAddressPage.featureShowPrivacyPolicyAndTandCs()) {
            eCommCustomerAddressPage.clickAgreeCheckbox();
        }
        eCommCustomerAddressPage.clickAddressDetailsContinueButton();
    }

    public OrderCheckOut selectSavedCardForThePayment() {

        eCommPaymentModePage.theUserSelectSavedCardRadio();
        eCommPaymentModePage.theUserSelectsSavedCard();
        eCommPaymentModePage.clickPlaceOrderSecurely();
        return this;
    }

    public String theUserRetrieveOrderNumber() {
        logger.info("Order Number  ::{}", eCommOrderConfirmationPage.getOrderIdText());
        return eCommOrderConfirmationPage.getOrderIdText();
    }

    public String theUserRetrieveLensReplacementOrderNumber() {
        logger.info("Order Number  ::{}", eCommOrderConfirmationPage.getLensReplacementOrderIdText());
        return eCommOrderConfirmationPage.getLensReplacementOrderIdText();
    }

    public String theUserRetrieveEmailID() {
        logger.info("Email ID  ::{}", emailId);
        return emailId;
    }

    public String theUserRetrieveOrderCost() {
        logger.info("Order Cost   ::{}", eCommOrderConfirmationPage.getCostIdText());
        if ((Staf.getTargetRegion().equals("dk")) || (Staf.getTargetRegion().equals("se")) || (Staf.getTargetRegion().equals("fi"))) {
            String[] getCostIdText = eCommOrderConfirmationPage.getCostIdText().split("\\s");
            return getCostIdText[0];
        } else {
            return eCommOrderConfirmationPage.getCostIdText();
        }
    }

    public String theUserRetrieveOrderSubscriptionInstallmentCost() {
        logger.info("Order Subscription Installment Cost   ::{}", eCommOrderConfirmationPage.getInstallmentCostText());
        if ((Staf.getTargetRegion().equals("se")) || (Staf.getTargetRegion().equals("fi"))) {
            String[] getInstallmentCostText = eCommOrderConfirmationPage.getInstallmentCostText().split("\\s");
            return getInstallmentCostText[0];
        } else {
            return eCommOrderConfirmationPage.getInstallmentCostText();
        }
    }

    public void theUserConfirmsOrderConfirmationMessage() {
        theUserConfirmsOrderConfirmationMessage(true);
    }

    public void theUserConfirmsOrderConfirmationMessage(Boolean closeDriver) {
        eCommOrderConfirmationPage.assertOrderConfirmationMessage(
                testDataManager.getTestAssertionData("orderConfirmationMessage"));

        orderNo = theUserRetrieveOrderNumber();
        cost = theUserRetrieveOrderCost();

        if ((testDataManager.getFeatureData("emailConfirmation.subscription", Boolean.class)) && (!Staf.getTargetRegion().equals("fi")) && (!Staf.getTargetRegion().equals("se"))) {
            installment_cost = theUserRetrieveOrderSubscriptionInstallmentCost();
        }
        if (closeDriver) {
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        }
    }

    public void theUserConfirmsOrderConfirmationMessageOnly() {
        theUserConfirmsOrderConfirmationMessageOnly(true);
    }

    public void theUserConfirmsOrderConfirmationMessageOnly(Boolean closeDriver) {
        eCommOrderConfirmationPage.assertOrderConfirmationMessage(
                testDataManager.getTestAssertionData("orderConfirmationMessage"));

        orderNo = theUserRetrieveOrderNumber();
        cost = theUserRetrieveOrderCost();

        if (closeDriver) {
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        }
    }

    public void selectSavedCardPaymentOption() {
        eCommPaymentModePage.theUserSelectSavedCardRadio();
        eCommPaymentModePage.theUserSelectsSavedCardWithConsent();
        eCommPaymentModePage.clickPlaceOrderSecurely();
    }

    public void theUserSelectsAftercareStoreFromTheDropDown(String userRole) {

        if (theRegionHasAPrescriptionPage()) {
            String afterCareStore = testDataManager.getTestInputRegionData("purchasing.checkout.desiredStoreName");
            eCommPrescriptionPage.selectStoreDropdown(afterCareStore);
        }
    }

    public void skipAndPayAmount() {
        waitABit(10000);
        eCommMedipassCardDetailsPage.clickSkipAndPayAmount();
    }

    public void selectPaypalForThePayment() {
        eCommPaymentModePage.theUserSelectsPaypalPayment();
        eCommPaymentModePage.clickPlaceOrderSecurely();
    }

    public void selectIdealForThePayment() {
        eCommPaymentModePage.theUserSelectsIdealPayment();
        eCommPaymentModePage.clickPlaceOrderSecurely();
    }

    public void theUserCheckOrderInvoice(String payableAmount) {

        eCommOrderConfirmationPage.selectPrintInvoiceButton();

        if (Staf.getTargetRegion().equals("au")) {
            eCommOrderInvoicePage.theUserConfirmProductInformationAndPayableAmount(payableAmount);
            eCommOrderInvoicePage.theUserConfirmGSTIncludedInTotal();
        } else if (Staf.getTargetRegion().equals("nz")) {
            eCommOrderInvoicePage.theUserConfirmProductInformationAndPayableAmount(payableAmount);
            eCommOrderInvoicePage.theUserConfirmGSTIncludedInTotalWithoutDeliveryCharges();
        } else {
            eCommInvoicePage.theUserConfirmProductInformationPayableAmount(payableAmount);
            eCommInvoicePage.theUserConfirmGSTIncludedInTotal();
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        }
    }

    public void theUserCheckDiscountedOrderInvoice(String payableAmount) {

        eCommOrderConfirmationPage.selectPrintInvoiceButton();

        if (Staf.getTargetRegion().equals("au") | Staf.getTargetRegion().equals("nz")) {
            eCommOrderInvoicePage.theUserConfirmProductInformationAndPayableAmount(payableAmount);
            eCommOrderInvoicePage.theUserConfirmDiscountedTaxIncludedInTotal();
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        } else {
            eCommInvoicePage.theUserConfirmProductInformationPayableAmount(payableAmount);
            eCommInvoicePage.theUserConfirmDiscountedTaxIncludedInTotal();
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        }
    }

    public void theUserCheck2for1DiscountOrderConfirmation() {
        String discountText = testDataManager.getTestAssertionData("discount.glasses2for1Discount");
        eCommOrderConfirmationPage.check2for1Discount(discountText);
    }

    public void checkeCommEmailInMailosaur(String customerEmailAddress, String orderNo, boolean lensReplacement, boolean subscriptionOrEazyPay) {
        try {
            waitABit(10000);
            if (!lensReplacement) {
                emailMailosaur.checkWelcomeEmail(customerEmailAddress);
            }
            if (testDataManager.getFeatureData("emailConfirmation.mailosaurcheck", Boolean.class) && !lensReplacement) {
                emailMailosaur.checkOrderReferenceEmail(customerEmailAddress, orderNo);
            }
            if (testDataManager.getFeatureData("emailConfirmation.easypay", Boolean.class) && subscriptionOrEazyPay) {
                emailMailosaur.checkEasyPayActivationEmail(customerEmailAddress, cost);
            }
            if (testDataManager.getFeatureData("emailConfirmation.subscription", Boolean.class) && subscriptionOrEazyPay) {
                emailMailosaur.checkSubscriptionEmail(customerEmailAddress, orderNo, installment_cost);
            } else {
                emailMailosaur.checkOrderConfirmationEmail(customerEmailAddress, orderNo, cost);
            }
        } catch (Exception e) {
            logger.info("Exception   :: " + e);
        }
    }


    public void checkeCommEmailInMailosaur2(String customerEmailAddress, String orderNo, boolean lensReplacement, boolean subscriptionOrEazyPay) {
        try {
            waitABit(10000);
            if (!lensReplacement) {
                emailMailosaur.checkWelcomeEmail(customerEmailAddress);
            }
            if (testDataManager.getFeatureData("emailConfirmation.mailosaurcheck", Boolean.class) && !lensReplacement) {
                emailMailosaur.checkOrderReferenceEmail(customerEmailAddress, orderNo);
            }
            if (testDataManager.getFeatureData("emailConfirmation.easypay", Boolean.class) && subscriptionOrEazyPay) {
                emailMailosaur.checkEasyPayActivationEmail(customerEmailAddress, cost);
            }
            if (testDataManager.getFeatureData("emailConfirmation.subscription", Boolean.class) && subscriptionOrEazyPay) {
                emailMailosaur.checkSubscriptionEmail(customerEmailAddress, orderNo, installment_cost);
            } else {
                emailMailosaur.checkOrderConfirmationEmail2(customerEmailAddress, orderNo, cost);
            }
        } catch (Exception e) {
            logger.info("Exception   :: " + e);
        }
    }


    public void checkeCommEmailInMailosaur(String customerEmailAddress) {
        try {
            waitABit(10000);
            emailMailosaur.checkPasswordResetEmail(customerEmailAddress);
        } catch (Exception e) {
            logger.info("Exception   :: " + e);
        }
    }


    public void navigateToMyWalletPage() {
        eCommOrderConfirmationPage.clickMyAccountLink();
        eCommOrderConfirmationPage.clickMyOrderLink();
        eCommOrderConfirmationPage.clickMyWallet();
        eCommOrderConfirmationPage.clickDeleteButton();
    }

    public void theUserVerifyTheUnableToDeleteCardMessage() {
        String deleteCardText = testDataManager.getTestAssertionData("attemptToDeleteCard.deleteCardMessage");
        eCommOrderConfirmationPage.verifyDeleteCardMessage(deleteCardText);
        eCommWebsiteHeader.selectLogoutFromAccountDropDown();
    }

    public void guestUserPerformsOrderlevelInvoiceCheckToConfirmDiscountIsApplied(String payableAmount) {

        eCommOrderConfirmationPage.selectPrintInvoiceButton();

        if (Staf.getTargetRegion().equals("au") | Staf.getTargetRegion().equals("nz")) {
            eCommOrderInvoicePage.theUserConfirmProductInformationAndPayableAmount(payableAmount);
            eCommOrderInvoicePage.theUserConfirmOrderLevelDiscountedTaxIncludedInTotal();
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        } else {
            eCommInvoicePage.theUserConfirmProductInformationPayableAmount(payableAmount);
            eCommInvoicePage.theUserConfirmOrderLevelDiscountedTaxIncludedInTotal();
            eCommWebsiteHeader.selectLogoutFromAccountDropDown();
        }
    }

    public void navigateToMyOrderDetailsPage() {
        eCommOrderConfirmationPage.clickMyAccountLink();
        eCommOrderConfirmationPage.clickMyOrderLink();
    }

    public void verifyOrderDetailsPageIsDisplayed() {
        eCommPaymentMethod.verifyOrderDetailsPageTitleIsDispalyed();
    }

    public void checkeCommEmailInMailosaur3(String customerEmailAddress) {
        emailMailosaur.checkSpanishBookingEmail(customerEmailAddress);
    }

    public void theUserFillsEsBookingEmail(String desiredEmail) {
        if (desiredEmail.equals("")) {
            emailId = "test.".concat(dateFormatter.format(timestamp)).concat("@test.com");
        } else {
            emailId = desiredEmail;
        }

        eCommCustomerDetailsPage.enterUserEmailInputBoxEs(emailId);

        logger.info("Customer email-id ::{}", emailId);
        eCommCustomerDetailsPage.enterUserConfirmEmailInputBox(emailId);
    }

    public void checkeCommEmailInMailosaur4(String customerEmailAddress, String orderNo, boolean lensReplacement, boolean subscriptionOrEazyPay) {
        try {
            waitABit(10000);
            if (!lensReplacement) {
                emailMailosaur.checkWelcomeEmail(customerEmailAddress);
            }
            if (testDataManager.getFeatureData("emailConfirmation.mailosaurcheck", Boolean.class) && !lensReplacement) {
                emailMailosaur.checkOrderReferenceEmail(customerEmailAddress, orderNo);
            }
            if (testDataManager.getFeatureData("emailConfirmation.easypay", Boolean.class) && subscriptionOrEazyPay) {
                emailMailosaur.checkEasyPayActivationEmail(customerEmailAddress, cost);
            }
            if (testDataManager.getFeatureData("emailConfirmation.subscription", Boolean.class) && subscriptionOrEazyPay) {
                emailMailosaur.checkSubscriptionEmail(customerEmailAddress, orderNo, installment_cost);
            } else {
                emailMailosaur.checkOrderConfirmationEmail4(customerEmailAddress, orderNo, cost);
            }
        } catch (Exception e) {
            logger.info("Exception   :: " + e);
        }
    }
}