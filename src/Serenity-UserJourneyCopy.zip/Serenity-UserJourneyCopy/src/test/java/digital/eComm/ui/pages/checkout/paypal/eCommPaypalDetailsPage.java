package digital.eComm.ui.pages.checkout.paypal;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

public class eCommPaypalDetailsPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommPaypalDetailsPage.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(id = "email")
    private WebElementFacade inputEmail;

    @FindBy(id = "btnNext")
    private WebElementFacade btnNext;

    @FindBy(id = "password")
    private WebElementFacade inputPassword;

    @FindBy(id = "btnLogin")
    private WebElementFacade loginButton;

    @FindBy(id = "acceptAllButton")
    private List<WebElementFacade> acceptAllButton;


    public void theUserLoginWithPapalAccount() {

        if (Staf.getTargetRegion().equals("uk")) {
            if(acceptAllButton.size()>0)
                clickElement(acceptAllButton.get(0));
            else
                logger.info("Accept All button is not displayed in uk region");
        }
        setText(inputEmail, testDataManager.getTestInputCommonData("paypalDetails.emailId"));
        clickElement(btnNext);
        setText(inputPassword, testDataManager.getTestInputCommonData("paypalDetails.password"));
        clickElement(loginButton);
    }
}
