package digital.eComm.ui.pages.checkout;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class eCommMedipassCardDetailsPage extends eCommBase {

    @FindBy(xpath = "//button[contains(text(),'Card')]")
    private WebElementFacade cardButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[1]/form/div/div/div[4]/div/div/div[3]/button[1]")
    private WebElementFacade cardButtonISF;

    @FindBy(css = "input[name='cardNumber']")
    private WebElementFacade cardNumber;

    @FindBy(css = "input[name='expiry']")
    private WebElementFacade expiryDate;

    @FindBy(css = "input[name='cvc']")
    private WebElementFacade cvc;

    @FindBy(css = "button[type='submit']")
    private WebElementFacade approveButton;

    @FindBy(xpath = "//*[contains(text(),'Skip & pay full amount')]")
    private WebElementFacade skipAndPayButton;

    public void clickCardButton() {
        clickElement(this.cardButton);
    }

    public void clickCardButtonISF() {
        clickElement(this.cardButtonISF);
    }

    public void enterCardNumber(String cardNumber) {
        setText(this.cardNumber, cardNumber);
    }

    public void enterExpiryDate(String expiryDate) {
        setText(this.expiryDate, expiryDate);
    }

    public void enterCvc(String cvc) {
        setText(this.cvc, cvc);
    }

    public void clickApproveButton() {
        clickElement(this.approveButton);
    }

    public void clickSkipAndPayAmount() {
        clickElement(skipAndPayButton);
    }
}
