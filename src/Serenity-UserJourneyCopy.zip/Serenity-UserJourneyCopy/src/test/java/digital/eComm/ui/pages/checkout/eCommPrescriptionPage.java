package digital.eComm.ui.pages.checkout;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommPrescriptionPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    eCommPaymentModePage eCommPaymentModePage;

    @FindBy(id = "edit-prescription-upload-options-specsavers")
    private WebElementFacade userWithPrescription;

    @FindBy(id = "edit-prescription-upload-specsavers-field-rx-store-und-0-target-id-button")
    private WebElementFacade storeDropdown;

    @FindBy(id = "edit-continue")
    private WebElementFacade prescriptionContinueButton;

    public void clickUserWithPrescription() {

        clickElement(this.userWithPrescription);
        logger.info("VALIDATE: The store selection drop down is visible");
        assertPageObjectIsDisplayed(storeDropdown);
    }

    public void selectStoreDropdown(String preferredStore) {
        selectOptionFromDropdown(this.storeDropdown, preferredStore);
    }

    public void clickPrescriptionContinueButton() {
        clickElement(this.prescriptionContinueButton);
        logger.info("VALIDATE: The Review and pay page is displayed");
        assertElementText(eCommPaymentModePage.pageTitle, testDataManager.getTestAssertionData("contentTitles.payAndReviewPage"));
    }


    public WebElementFacade getRadioUserWithPrescription() {return userWithPrescription;}
}
