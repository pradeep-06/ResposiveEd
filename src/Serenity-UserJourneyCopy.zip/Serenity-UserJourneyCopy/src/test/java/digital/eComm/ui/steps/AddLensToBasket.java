package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.pages.contactlens.eCommContactLensLandingPage;
import digital.eComm.ui.pages.contactlens.eCommContactLensPrescriptionPage;
import digital.eComm.ui.pages.contactlens.eCommContactLensProductDetailedPage;
import digital.eComm.ui.pages.eCommBasketPage;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.pages.eCommProductSearchPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddLensToBasket extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(AddLensToBasket.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    private final String FEATURE_NOT_SUPPORTED = "Step skipped - feature not supported for this region";

    eCommHomePage homePage;
    eCommContactLensLandingPage eCommContactLensLandingPage;
    eCommProductSearchPage eCommProductSearchpage;
    eCommHomePage eCommHomePage;
    eCommContactLensProductDetailedPage eCommContactLensProductDetailedpage;
    eCommContactLensPrescriptionPage eCommContactLensPrescriptionPage;
    eCommBasketPage eCommBasketPage;

    //Product selection
    public void selectContactLensProduct(String product) {
        //[2022.01.21 CL] Split out each task.  Also, think we should rename this to make it more specific - see name method below
        searchForContactLensProductBySku(product);
        clickOnSkuSearchResult();
    }

    public void searchAndSelectContactLensProductBySku() {
        String product = testDataManager.getTestInputRegionData("purchasing.contactLens.availableProduct.sku");
        searchForContactLensProductBySku(product);
        clickOnSkuSearchResult();
    }

    public void searchAndSelectContactLensProductBySkuMerken() {
        String product = testDataManager.getTestInputRegionData("purchasing.contactLens.availableProduct.skumerken");
        searchForContactLensProductBySku(product);
        clickOnSkuSearchResult();
    }

    public void searchForContactLensProductBySku(String product) {
            homePage.clickOn(homePage.searchMagnifierIcon);
            eCommProductSearchpage.enterInputSearchBox(product);
        }

    public void clickOnSkuSearchResult() {
 //       eCommHomePage.bannerStaticHeader();
 //       eCommHomePage.bannerStaticFooter();
        eCommProductSearchpage.clickOnContactLensesProduct();
    }

    public void selectFirstProductListed() {
        eCommContactLensLandingPage.selectFirstProductListed();
    }

    public void selectCommonBrand(String userRole) {

        String brand = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".filterPreferences.brand");
        String brandDomText = brand.toLowerCase();
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        logger.info("Clicking on common brand: " + brand);
        eCommContactLensLandingPage.clickOnDynamicLinkViaAttribute("class", "menus-" + brandDomText);
        logger.info("VALIDATE: Check first product listed is of brand: " + brand);
    //    eCommContactLensLandingPage.assertElementContainsText(eCommContactLensLandingPage.getFirstProductListed(), brand); DB : To avoid IE failure commenting out assertion
    }

    //Select Prescription values
    public AddLensToBasket selectPrescriptionButton() {

        eCommContactLensProductDetailedpage.clickSelectPrescription();
        return this;
    }

    public void theUserSelectPrescriptionValues() {
        theUserSelectsPrescriptionValuesAndAddsToBasket("");
    }

    public void theUserSelectsPrescriptionValuesAndAddsToBasket(String userRole) {
        theUserSelectsPrescriptionValues(userRole);
        clickToAddPrescriptionToBasket();
    }

    public void theUserSelectsPrescriptionValuesAndAddsToBasketMerken(String userRole) {
        theUserSelectsPrescriptionValuesMerken(userRole);
        clickToAddPrescriptionToBasket();
    }

    public void clickToAddPrescriptionToBasket() {

        if (testDataManager.getFeatureData("contactLensPrescription.singlePaymentRadio", Boolean.class)) {
            eCommContactLensPrescriptionPage.clickOneOffRadioButton();
//            eCommContactLensPrescriptionPage.theUserConfirmsPayableAmountBasedOnTheQty();
            eCommContactLensPrescriptionPage.clickAddOneOffToBasket();
        } else {
            eCommContactLensPrescriptionPage.clickAddToBasketButton();
        }
    }

    public void clickToAddSubscriptionToBasket() {

        if (testDataManager.getFeatureData("contactLensPrescription.subscriptionPaymentRadio", Boolean.class)) {

            if (eCommContactLensPrescriptionPage.getSubscriptionRadioButton().isSelected()) {
                eCommContactLensPrescriptionPage.clickAddSubscriptionToBasket();
            }

        } else {
            eCommContactLensPrescriptionPage.clickAddOneOffToBasket();
        }
    }

    public void theUserSelectsPrescriptionValues(String userRole) {

        final String leftBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftBaseCurve");
        final String rightBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightBaseCurve");
        final String leftSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftSphere");
        final String rightSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightSphere");

        eCommContactLensPrescriptionPage.selectRightEyeBaseCurve(rightBaseCurve);
        eCommContactLensPrescriptionPage.selectLeftEyeBaseCurve(leftBaseCurve);
        eCommContactLensPrescriptionPage.selectRightEyeSphere(rightSphere);
        eCommContactLensPrescriptionPage.selectLeftEyeSphere(leftSphere);

    }

    public void theUserSelectsPrescriptionValuesMerken(String userRole) {
        final String leftBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftBaseCurveMerken");
        final String rightBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightBaseCurveMerken");
        final String leftStrength = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftStrength");
        final String rightStrength = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightStrength");
//        final String leftType = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftType");
//        final String rightType = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightType");

        eCommContactLensPrescriptionPage.selectRightEyeBaseCurve(rightBaseCurve);
        eCommContactLensPrescriptionPage.selectLeftEyeBaseCurve(leftBaseCurve);
        eCommContactLensPrescriptionPage.selectRightEyeStrenght(rightStrength);
        eCommContactLensPrescriptionPage.selectLeftEyeStrenght(leftStrength);
//        eCommContactLensPrescriptionPage.selectRightEyeType(rightType);
//        eCommContactLensPrescriptionPage.selectLeftEyeType(leftType);

    }

    public void clickToSpecifyPrescriptionDetails() {

        logger.info("Clicking on 'select prescription' button from product page");
        eCommContactLensProductDetailedpage.clickSelectPrescription();
    }

    public void theUserSelectPrescription() {

        final String leftBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftBaseCurve");
        final String rightBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightBaseCurve");
        final String leftSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftSphere");
        final String rightSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightSphere");

        eCommContactLensPrescriptionPage.selectRightEyeBaseCurve(rightBaseCurve);
        eCommContactLensPrescriptionPage.selectLeftEyeBaseCurve(leftBaseCurve);
        eCommContactLensPrescriptionPage.selectRightEyeSphere(rightSphere);
        eCommContactLensPrescriptionPage.selectLeftEyeSphere(leftSphere);

        if (testDataManager.getFeatureData("contactLensPrescription.subscriptionPaymentRadio", Boolean.class)) {

            if (eCommContactLensPrescriptionPage.getSubscriptionRadioButton().isSelected()) {
                eCommContactLensPrescriptionPage.clickAddSubscriptionToBasket();
            }

        } else {
            eCommContactLensPrescriptionPage.clickAddOneOffToBasket();
        }
    }

    //Select Quantity of lenses
    public void selectProductQuantity(String rightEyeQty, String leftEyeQty) {
        //if (featureContactLensQuantityEnabled()) { //Moved the feature check to the individual page class so that we dont have to duplicate it multiple times on this page.
        eCommContactLensProductDetailedpage.selectRightEyeQuantity(rightEyeQty);
        eCommContactLensProductDetailedpage.selectLeftEyeQuantity(leftEyeQty);
        //}
        //else logger.info(FEATURE_NOT_SUPPORTED);
    }

    public void selectRightEyeQuantity(String userRole) {
        String quantity = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".prescriptionData.rightEyeQty");
        eCommContactLensProductDetailedpage.selectRightEyeQuantity(quantity);

    }

    public void selectRightEyeQuantityAndClickSelectPrescription(String userRole) {

        String quantity = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".prescriptionData.rightEyeQty");
        eCommContactLensProductDetailedpage.selectRightEyeQuantity(quantity);

        clickToSpecifyPrescriptionDetails(); //: DB : unable to perform total amount check so adding this method after adding left and right eye quantity and user confirm total price for one off order
    }

    public void selectLeftEyeQuantity(String userRole) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        String quantity = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".prescriptionData.leftEyeQty");
        eCommContactLensProductDetailedpage.selectLeftEyeQuantity(quantity);

    }

    public void selectLeftEyeQuantityMerken(String userRole) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        String quantity = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".prescriptionData.leftEyeQty");
        eCommContactLensProductDetailedpage.selectLeftEyeQuantityMerken(quantity);

    }


    //Continue to Checkout
    public void checkoutSecurelyWithSubscription() {
      //  eCommHomePage.bannerStaticHeader();
     //   eCommHomePage.bannerStaticFooter();
        if (testDataManager.getFeatureData("basket.hasFrequencyDropDown", Boolean.class)) {

            final String frequency = testDataManager.getTestInputRegionData("purchasing.checkout.basket.frequency");

            logger.info("User select easy buy option with {} frequency", frequency);
            eCommBasketPage.selectFrequency(frequency);

        }

    }

    public void selectCheckOutSecurely() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommBasketPage.clickCheckoutSecurelyButton();
    }

    public void enterPromocodeDetails() {

        final String applyPromo = testDataManager.getTestInputCommonData("basket.promocode");
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommBasketPage.clickSelectPromocode();
        eCommBasketPage.applyPromocode(applyPromo);
        eCommBasketPage.enterPromocode();

        Assertions.assertThat(eCommBasketPage.promoCodeMsg()).doesNotContain("Please enter a valid promotion code or proceed to checkout");
        Assertions.assertThat(eCommBasketPage.promoCodeMsg()).contains(applyPromo);

    }

    public void theUserSelectsPrescriptionValuesAndAddSubscriptionToBasket(String userRole) {
        theUserSelectsPrescriptionValues(userRole);
        clickToAddSubscriptionToBasket();
    }

    public void checkDiscountHasBeenApplied() {

        String discountText = testDataManager.getTestAssertionData("discount.discountTitle");
        logger.info("User confirm discount is applied to basket:: {}", discountText);
        eCommBasketPage.theUserConfirmsLineLevelDiscountAppliedToTheBasket
                (discountText);

    }

    public void checkProductPriceAfterSelectingQty() {

        final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");
        final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");

        eCommContactLensProductDetailedpage.getPrice(rightEyeQty, leftEyeQty);

    }

    public void checkProductDetails() {
        final String productAmount = eCommContactLensProductDetailedpage.getProductAmount();
        eCommBasketPage.theUserChecksProductInformationFromTheBasket(productAmount);

    }

    public String theUserRetrievePayableAmount() {
        return eCommBasketPage.theUserRetrieveAmount();
    }


    public void theUserStartConfirmingProductDetailsFromTheBasket(String amount) {
        eCommBasketPage.theUserChecksProductInformationFromTheBasket(amount);

    }

    public String theUserRetrieveAmountFromPrescriptionModel() {
        return eCommContactLensPrescriptionPage.theUserRetrievePayableAmount();
    }

    public void selectAddSolutionCTA() {
        eCommBasketPage.clickOnAddSolutionCta();
    }
}

