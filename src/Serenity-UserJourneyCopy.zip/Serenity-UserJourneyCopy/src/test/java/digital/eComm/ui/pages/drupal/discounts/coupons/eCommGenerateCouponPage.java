package digital.eComm.ui.pages.drupal.discounts.coupons;

import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.eCommHomePage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommGenerateCouponPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommGenerateCouponPage.class);

    @FindBy(css = "fieldset#edit-single a")
    private WebElementFacade generateCouponLink;

    @FindBy(id = "edit-title")
    private WebElementFacade couponTitle;

    @FindBy(id = "edit-single-coupon-code")
    private WebElementFacade inputCouponCode;

    @FindBy(id = "edit-single-redemptions")
    private WebElementFacade inputRedemptions;

    @FindBy(id = "edit-single-create")
    private WebElementFacade createButton;

    @FindBy(css = "form#de-coupon-batch-form td:nth-child(2) > a")
    private WebElementFacade couponCodeName;

    @FindBy(id = "edit-submit")
    private WebElementFacade saveButton;

    @FindBy(css = "div#console > div")
    private WebElementFacade confirmationMsg;

    eCommHomePage eCommHomePage;

    public void theUserCreateAndSaveCouponCode(String couponCode, String redemptionNo) {
        logger.info("the admin user setup coupon code");
        clickElement(this.generateCouponLink);
        setText(this.inputCouponCode, couponCode);
        setText(this.inputRedemptions, redemptionNo);
        clickElement(this.createButton);
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        clickElement(this.saveButton);

    }
}
