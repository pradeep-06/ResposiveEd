package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.audiology.audiologyHomePage;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;

public class AudiologyFindStorePage extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(AudiologyFindStorePage.class);
    private final TestDataManager testDataManager = new TestDataManager();

    @Steps
    NavigateToeComm navigateToeComm;

    @Steps
    audiologyHomePage audiologyfindStorePage;

    public void enterAudiologyFindLocationDetails() {
        navigateToeComm.theUserAcceptCookies();
        audiologyfindStorePage.UserClicksOnHearingButton();
        audiologyfindStorePage.UserClicksOnbookFreeHearingTestButton();
        final String storeLocation = testDataManager.getTestInputRegionData("appointmentData.storeLocation.locationSearchString");
        audiologyfindStorePage.theUserSearchesForTheStore(storeLocation);
        audiologyfindStorePage.UserClicksOnBookOnlineButton();
    }
}
