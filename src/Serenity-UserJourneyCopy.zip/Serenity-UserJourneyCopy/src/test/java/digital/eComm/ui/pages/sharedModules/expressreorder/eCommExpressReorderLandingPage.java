package digital.eComm.ui.pages.sharedModules.expressreorder;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.LensExpressReorder;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommExpressReorderLandingPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(LensExpressReorder.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = "#edit-edit-quantity-select-0-qty-button")
    public WebElementFacade xroRightEyeQty;

    @FindBy(css = "#edit-edit-quantity-select-1-qty-button")
    public WebElementFacade xroLeftEyeQty;

    @FindBy(css = "div#block-system-main div.panel-pane.pane-xro-cart-order-place-order > a")
    public WebElementFacade xroPlaceOrder;

    @FindBy(css = ".alert.alert-block.alert-success")
    public WebElementFacade xroSuccessMsg;

    @FindBy(css = "div#block-system-main label > input")
    public WebElementFacade xroAgreeCheckBox;

    @FindBy(id = "edit-details-billing-details-select")
    public WebElementFacade billingDetailsDropdown;

    @FindBy(css="[class='xro-agree form-checkbox required']")
    private WebElementFacade confirmConsentCheckBox;

    @FindBy(css="[class='panel-pane pane-xro-cart-order-place-order'] a")
    private WebElementFacade placeOrderSafelyButton;

    @FindBy(css="div.checkout-completion-message>h2")
    private WebElementFacade orderNumber;

    @FindBy(xpath="//*[@id=\"block-system-main\"]/div/div[3]/div/div/div[2]/div[3]/div/label/input")
    private WebElementFacade consentConfirm;

    public void xroLeftEyeQty(String leftEyeQty) {
        if (xroFeatureSelectLensQuantityFromPDPIsOn()) {
            selectOptionFromDropdown(this.xroLeftEyeQty, leftEyeQty);
            logger.info("Left Eye Qty is Amended");

        }
    }

    public void xroRightEyeQty(String rightEyeQty) {
        if (xroFeatureSelectLensQuantityFromPDPIsOn()) {
            selectOptionFromDropdown(this.xroRightEyeQty, rightEyeQty);
            logger.info("Right Eye Qty is Amended");
        }
    }


    public String SucessMsg() {
        return (xroSuccessMsg.getText());
    }

    public void agreeCheckBox() {
        evaluateScriptClick(this.xroAgreeCheckBox);
    }

    public void placeOrder() {
        scrollToView(xroPlaceOrder);
        clickElement(this.xroPlaceOrder);
    }

    public void alertMessage() {
        logger.info("alert message ::{}", alertText());
        alertAccept();
    }

    public Boolean xroFeatureSelectLensQuantityFromPDPIsOn() {
        return testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class);
    }

    public void selectMasterCard() {
        billingDetailsDropdown.selectByIndex(2);
    }

    public void selectLeftEyeQuantity(String quantity){
        logger.info("Select left eye quanity as "+quantity);
        selectOptionFromDropdown(this.xroLeftEyeQty,quantity);
    }

    public void selectRightEyeQuantity(String quantity){
        logger.info("Select right eye quanity as "+quantity);
        selectOptionFromDropdown(this.xroRightEyeQty, quantity);
    }

    public void selectCardTypeAs(String cardType){
        waitABit(5000);
        logger.info("Select card type as "+ cardType);
        selectFromDropdown(this.billingDetailsDropdown,cardType);
    }

    public void clickOnConfirmConsent(){
        logger.info("Click on confirm consent");
        scrollToView(this.confirmConsentCheckBox);
        clickElement(this.confirmConsentCheckBox);
    }

    public void clickOnPlaceOrderSafelyButton(){
        logger.info("Click on Place order safely button");
        clickElement(this.placeOrderSafelyButton);
    }

    public String getOrderNumber(){
        logger.info("New Order Number is "+orderNumber.getText());
        String text= orderNumber.getText().replace(".","");
        String values[]=text.split(" ");
        return values[values.length-1];
    }

    public void consentConfirmButton(){
        logger.info("Click on consent button");
        clickElement(this.consentConfirm);
    }

}


