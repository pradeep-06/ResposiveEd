package digital.eComm.ui.pages.audiology;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;

public class audiologyDateAndTimePage extends BasePageObject {

    @FindBy(css = "div > button.calendar-ab--days__day.is-active")
    private WebElementFacade dateLabel;

    @FindBy(className = "calendar-ab--slots")
    private List<WebElementFacade> calenderDays;

    @FindBy(xpath = "//div[contains(@class, 'calendar-ab--slots')]/button[@datalayer='bookingslot']")
    private WebElementFacade timeSlot;

    @FindBy(css = "#calendar-book-btn > div")
    private WebElementFacade continueButton;

    public void UserSelectsTimeSlot() {
        clickElement(this.timeSlot);
    }

    public void UserSelectsDateSlot() {

        clickElement(this.dateLabel);
    }

    public void UserSelectsContinueButton() {
        evaluateScriptClick(this.continueButton);
    }
}
