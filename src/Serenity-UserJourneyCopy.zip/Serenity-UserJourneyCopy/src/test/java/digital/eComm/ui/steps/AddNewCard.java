package digital.eComm.ui.steps;


import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.checkout.customeraccount.eCommPaymentMethod;
import digital.eComm.ui.pages.sharedModules.eCommCardDetails.eCommAddCard;
import digital.eComm.ui.pages.sharedModules.eCommCardDetails.eCommCardDetailsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import digital.eComm.ui.pages.eCommHomePage;

public class AddNewCard extends ScenarioSteps {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(AddNewCard.class);
    eCommPaymentMethod eCommPaymentMethod;
    eCommAddCard addCard;
    eCommHomePage eCommHomePage;
    eCommCardDetailsPage  eCommCardDetailsPage;
    public void theUserSelectAddsNewCard() {
        eCommPaymentMethod.theUserSelectAddNewCardButton();
    }

    public void theUserSelectMasterCard() {
        addCard.selectMasterCard();
    }

    public void selectConsents() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        addCard.theUserConfirmConsent();
    }

    public void theUserSelectAddressFromTheDropdown() {
        addCard.selectPreviousAddress();
    }

    public void theUserSelectNextButton() {
        addCard.selectNextButton();
    }

    public void theUserAddMasterCardPaymentDetails() {
        final String cardNumber = testDataManager.getTestInputCommonData("cardDetails.mastercardNumber");
        final String cardholdersName = testDataManager.getTestInputCommonData("cardDetails.cardholdersName");
        final String expiryMonth = testDataManager.getTestInputCommonData("cardDetails.expiryMonth");
        final String expiryYear = testDataManager.getTestInputCommonData("cardDetails.expiryYear");
        final String securityCode = testDataManager.getTestInputCommonData("cardDetails.securityCode");

        eCommCardDetailsPage.waitForCredCardNumberField();
        eCommCardDetailsPage.enterMasterCardNumber(cardNumber);
        eCommCardDetailsPage.enterCardholdersName(cardholdersName);
        eCommCardDetailsPage.enterExpiryMonth(expiryMonth);
        eCommCardDetailsPage.enterExpiryYear(expiryYear);
        eCommCardDetailsPage.enterSecurityCode(securityCode);
        eCommCardDetailsPage.clickMakePaymentButton();
    }

    public void theUserSelectIdealCard() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        addCard.selectIdealCard();
    }
    public void selectConsentsForIdealCard() {
        addCard.theUserConfirmConsentForIdealCard();
    }
}
