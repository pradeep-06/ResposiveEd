package digital.eComm.ui.pages.glasses;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.Keys;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class eCommSearchAndFindStorePage extends eCommBase {
    private static final Logger logger = LoggerFactory.getLogger(eCommSearchAndFindStorePage.class);

    @FindBy(css="[class='store-search-form-field input-group input-group-lg']>input")
    public WebElementFacade storeSearchTextField;

    @FindBy(css="[class='views-field views-field-link-store-booking']")
    public List<WebElementFacade> bookAnAppointmentButtons;

    @FindBy(css="[id='edit-submit']")
    public WebElementFacade searchButton;

    public void enterStoreLocation(String storeLocation){
      setText(this.storeSearchTextField,storeLocation);
      this.storeSearchTextField.sendKeys(Keys.TAB);
      this.storeSearchTextField.click();
    }

    public void clickOnSearchButton(){
      clickElement(this.searchButton);
    }

    public void verifyBookAnAppointmentButtonsAreDisplayed(){
      logger.info("Verify Store names were displayed with Book appointment buttons after searching with location name");
      logger.info("Number of stores being displayed in Store location search is "+this.bookAnAppointmentButtons.size());
      assertTrue(this.bookAnAppointmentButtons.size()>0);
    }

}
