package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.audiology.audiologyPersonalDetailsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;

public class AudiologyPersonalDetails extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(AudiologyPersonalDetails.class);
    private final TestDataManager testDataManager = new TestDataManager();

    audiologyPersonalDetailsPage AudiologyPersonalDetailsPage;

    public void UserEntersPersonalDetails() {
        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String dob = testDataManager.getTestInputCommonData("userDetails.dateOfBirth");
        final String email = testDataManager.getTestInputCommonData("userDetails.email");
        final String phoneNumber = testDataManager.getTestInputCommonData("userDetails.phoneNumber");

        AudiologyPersonalDetailsPage.UserSelectsTitle();
        AudiologyPersonalDetailsPage.UserEntersFirstName(firstName);
        AudiologyPersonalDetailsPage.UserEntersLastName(lastName);
        this.enterBirthDate(dob);
        AudiologyPersonalDetailsPage.UserEntersEmail(email);
        AudiologyPersonalDetailsPage.UserEntersMobileNo(phoneNumber);
        AudiologyPersonalDetailsPage.UserClicksOnContinueButton();
    }

    private void enterBirthDate(String prescriptionDate) {

        final String[] dateSplitter = prescriptionDate.split("-");
        AudiologyPersonalDetailsPage.UserEntersDayOfDOB(dateSplitter[0]);
        AudiologyPersonalDetailsPage.UserEntersMonthOfDOB(dateSplitter[1]);
        AudiologyPersonalDetailsPage.UserEntersYearOfDOB(dateSplitter[2]);
    }
}
