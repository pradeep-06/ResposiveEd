package digital.eComm.ui.pages.drupal.discounts;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class eCommDiscountTabPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommDiscountTabPage.class);

    @FindBy(css = "div#branding li:nth-child(1) > a")
    private WebElementFacade discountTab;

    @FindBy(css = "div#content li:nth-child(1) > a")
    private WebElementFacade addDiscountLink;

    @FindBy(css = "table#de-discounts-overview-active >tbody >tr >td:first-child>a:last-child")
    private List<WebElement> activeDiscountCodes;

    @FindBy(css = "#de-discounts-overview-active > tbody > tr:nth-child(18) > td:nth-child(1) > a:nth-child(2)")
    private WebElementFacade selectActiveDiscountCodes;

    public boolean theUserCheckActiveDiscounts(String discountName) {

        clickElement(this.discountTab);
        return checkPresence(activeDiscountCodes, discountName);
    }

    public void selectActiveDiscountCode(String discountName) {
        moveTo("//*[contains(@href, 'discount_line_level_discount')]|//*[contains(@href, 'discount_order_level_discount')]");
        selectTab(activeDiscountCodes, discountName);
    }

    public void theUserSelectAddDiscountLink() {
        clickElement(addDiscountLink);
    }
}
