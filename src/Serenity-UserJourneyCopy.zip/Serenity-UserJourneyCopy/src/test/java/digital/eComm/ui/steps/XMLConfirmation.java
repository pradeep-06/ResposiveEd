package digital.eComm.ui.steps;

import digital.eComm.ui.pages.drupal.worldpay.eCommRecentLogPage;
import digital.eComm.ui.pages.drupal.worldpay.eCommRecentWorldpayPage;
import digital.eComm.ui.pages.drupal.worldpay.eCommSavedMessagePage;
import digital.eComm.ui.pages.drupal.worldpay.eCommXMLMessagePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XMLConfirmation extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(XMLConfirmation.class);

    eCommRecentLogPage eCommRecentLogMessagePage;
    eCommXMLMessagePage eCommXMLMessagePage;
    eCommRecentWorldpayPage eCommRecentWorldpayPage;
    eCommSavedMessagePage eCommSavedCardXMLMessagePage;

    public void theUserConfirmWorldpayMessageForANewCard(String OrderNumber) {
        eCommRecentLogMessagePage.theUserEnteredOrderID(OrderNumber);
        eCommXMLMessagePage.assertStoreCredentialLogsDetails();
    }

    public void theUserConfirmWorldpayMessageForASavedCard(String orderNumber) {
        eCommRecentWorldpayPage.theUserEnteredOrderID(orderNumber);
        eCommSavedCardXMLMessagePage.assertStoreCredentialDetails();
    }
}
