package digital.eComm.ui.pages.drupal.discounts.coupons;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

public class eCommCouponTabPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommCouponTabPage.class);

    @FindBy(css = "div#branding li:nth-child(2) > a")
    private WebElementFacade couponTab;

    @FindBy(css = "form#de-coupon-batch-overview-form table.table-no-striping.sticky-enabled.tableheader-processed.sticky-table >  tbody > tr >td:first-child>a:last-child")
    private List<WebElement> activeCouponCodes;

    @FindBy(css = "div#content ul > li > a")
    private WebElementFacade addCouponLink;

    @FindBy(css = "fieldset#edit-filter a")
    private WebElementFacade filterLink;

    @FindBy(id = "edit-filter-description")
    private WebElementFacade inputDescription;

    @FindBy(id = "edit-filter-do-filter")
    private WebElementFacade filterButton;

    @FindBy(css = "form#de-coupon-batch-overview-form a:nth-child(2)")
    private WebElementFacade deleteCouponCodeLink;

    @FindBy(css = "div#console > div")
    private WebElementFacade deleteHeaderTextLabel;


    public void deleteCouponCode(String couponCode) {

        clickElement(this.filterLink);
        setText(inputDescription,couponCode);
        clickElement(filterButton);
        clickElement(deleteCouponCodeLink);

    }

    public Boolean theUserCheckActiveCoupon(String couponCode) {

        clickElement(this.couponTab);
        return checkPresence(activeCouponCodes, couponCode);
    }

    public void assertCouponDeletionMessage(String deleteCouponHeader) {
        assertElementText(deleteHeaderTextLabel,deleteCouponHeader );
    }

    public void selectAddCouponLink() {
        clickElement(this.addCouponLink);
    }
}
