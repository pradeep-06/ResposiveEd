package digital.eComm.ui.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@DefaultUrl("page:eComm.home.url")
public class eCommHomePage extends eCommBase {

    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = "header#header span > a")
    public WebElementFacade closeattraqtModal;

    @FindAll({@FindBy(css = "#popup-buttons > button"), @FindBy(id = "onetrust-accept-btn-handler"),})
    public WebElementFacade closeCookieModal;

    @FindBy(css = "header#header ul.ss-nav__right-col > li:nth-child(2) > a > span")
    public WebElementFacade searchMagnifierIcon;

    @FindBy(css = "#header-modal-open > path")
    public WebElementFacade searchMagnifierIconAzure;

    @FindBy(xpath = "//a[@class='ss-nav-primary__link' and @trackaid='menus-contact-lenses']|//*[@id=\"contact-lenses\"]/span")
    public WebElementFacade primaryNavLinkContactLenses;

    @FindBy(xpath = "//*[@id=\"contact-lenses\"]/span")
    public WebElementFacade primaryNavLinkContactLenses2;

    @FindBy(xpath = "//a[@class='ss-nav-primary__link' and @trackaid='menus-glasses']")
    public WebElementFacade primaryNavLinkGlasses;

    @FindBy(xpath = "//div[@class='login-destination-panel--text-wrapper']/a[@href='/user/login']")
    public WebElementFacade onlineOrderLogin;

    @FindBy(css = "[trackaid='menus-glasses']")
    public WebElementFacade glassesMenu;

    @FindBy(css = ".ss-top-bar__login-btn")
    public WebElementFacade signIn;

    @FindBy(css = "#siteBannerHeaderBanner")
    public WebElementFacade bannerHeader;

    @FindBy(css = "#siteBannerFooterBanner")
    public WebElementFacade bannerFooter;

    @FindBy(css = "li>a[class*=\"find-a-store\"]")
    private WebElementFacade findAStoreButton;

    @FindBy(css = "form.store-search-form.compact-form>div>input,#customer--location,input#search,input#specs-location-search-form_input,#specs-location-search-form_input")
    private WebElementFacade searchEntryField;  //supports v3 and v4

    @FindBy(css = "button#edit-submit,div.ss-form-group.ng-dirty.ng-valid.ng-touched>span,button#specs-location-search-form_button,svg[class='form__icon js-search-submit'],button#specs-location-search-form_button")
    private WebElementFacade findButton;  //supports v3 and v4

    @FindBy(xpath = "//*[contains(@class, '__book-button--desktop')]|//*[contains(@class, 'btn btn-primary')]")
    private WebElementFacade v3_bookOnlineButton;

    @FindBy(css = "#header-topbar-location > div")
    private WebElementFacade v4_findAStore;

    @FindBy(css = "ul.ss-top-bar__left-col-group a[trackaid=\"header-find-store-icon\"]")
    private WebElementFacade v3_findAStore;

    @FindBy(css = "a[trackaid=\"header-request-appointment-cta\"]")
    private WebElementFacade bookAppointmentButton;

    @FindBy(css="iframe[name*='healow-oa-ifrm']")
    private WebElementFacade frameinNzRegion;

    @FindBy(css="button.green.book-appointment")
    private WebElementFacade requestAnAppointment;

    @FindBy(css = "#appointment-type_footer-text2 > a:nth-child(2)")
    private WebElementFacade RequestFormLink;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[1]/div|//*[@id=\"choose1\"]/div[2]/div/div")
    private List<WebElementFacade> appointmentTypeList;

    @FindBy(css = "h2#appointment-type-title,div[id='edit-ap-type'] label[class='control-label'],label.appointment-type-label,div.choose-panel.clearfix.SelectorBtn div:nth-child(2),[class*='specs-appointment-type__title'],div.booking-type__content span.booking-type__title,h2[id*='specs-appointment-type']")
    private List<WebElementFacade> v3_appointmentTypeList;

    @FindBy(css = "h1#page-header_title")
    private WebElementFacade appointmentTypePageTitle;

    @FindBy(xpath = "//a[contains(@class,'booking--book-appointment')]")
    private WebElementFacade clickBookAppointmentBtn;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[1]/div[1]/label")
    private WebElementFacade appointmentTypeEs;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[2]/div/div[1]/label")
    private WebElementFacade appointmentDateAndTimeEs;

    @FindBy(xpath = "//*[@id=\"date-time\"]")
    private WebElementFacade enterAppointmentDateAndTime;

    @FindBy(xpath = "//*[@id=\"customer-title\"]/option[2]")
    private WebElementFacade customerTitle;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[3]/div[1]/div[2]/div[1]/label")
    private WebElementFacade nameES;

    @FindBy(xpath = "//*[@id=\"first-name\"]")
    private WebElementFacade enterNameES;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[3]/div[1]/div[3]/div[1]/label")
    private WebElementFacade surnameES;

    @FindBy(xpath = "//*[@id=\"last-name\"]")
    private WebElementFacade entersSurnameES;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[3]/div[1]/div[6]/div[1]/label")
    private WebElementFacade mobileES;

    @FindBy(xpath = "//*[@id=\"customer-mobile\"]")
    private WebElementFacade enterMobileES;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[3]/div[1]/div[7]/div[1]/label")
    private WebElementFacade emailES;

    @FindBy(xpath = "//*[@id=\"customer-email\"]")
    private WebElementFacade enterEmailES;

    @FindBy(xpath = "//*[@id=\"edit-your-details-wrapper-submit\"]")
    private WebElementFacade requestBtn;

    @FindBy(css = "textarea#customer-notes")
    private WebElementFacade customerAnythingElseWeShouldKnow;

    public void closeAttraqtModel() {
        clickElement(closeattraqtModal);
    }

    public void clickGlassesLink() {
        clickElement(primaryNavLinkGlasses);
    }

    private final Logger logger = LoggerFactory.getLogger(eCommHomePage.class);

    public void inititiateScanIdCookies() {
        final String scanId = testDataManager.getTestInputRegionData("purchasing.glasses.vto.scanId");
        scanIdCookies("scan_id", scanId);
        scanIdExpiryDate("expires", "Thu, 01 Jan 2035 00:00:00 GMT");
    }

    public void allGlassesLink() {
        clickElement(glassesMenu);
    }

    public void bannerStaticHeader() {
        if (Staf.getEnvironment().equals("daily")) {
            clickElement(bannerHeader);
            hideBannerStaticHeader(bannerHeader);
        } else {
            logger.info("Skipping bannerStaticHeader for non-daily environment.");
        }
    }

    public void bannerStaticFooter() {
        if (Staf.getEnvironment().equals("daily")) {
            clickElement(bannerFooter);
            hideBannerStaticFooter(bannerFooter);
        } else {
            logger.info("Skipping bannerStaticHeader for non-daily environment.");
        }
    }

    public void clickOnFindAStore() {
        clickElement(this.findAStoreButton);
    }

    public void enterSearchLocation(String location) {
        setText(this.searchEntryField, location);
        this.searchEntryField.sendKeys(Keys.TAB);
        this.searchEntryField.click();
    }

    public void clickFindButton() {
        clickElement(findButton);
    }

    public void v4_VerifyFindAStoreLinkIsDisplayed() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_bookOnlineButton));
        if (Staf.getTargetRegion().equals("uk") || Staf.getTargetRegion().equals("no") || Staf.getTargetRegion().equals("nl") || Staf.getTargetRegion().equals("ie") || Staf.getTargetRegion().equals("au")) {
            assertPageObjectIsDisplayed(this.v4_findAStore);
        }
        else {assertPageObjectIsDisplayed(this.v3_findAStore);
     }
    }

    public void clickOnBookAppointment() {
        clickElement(this.bookAppointmentButton);
    }

    public void switchToFrameForAppointments() {
        getDriver().switchTo().frame(frameinNzRegion);
    }

    public void verifyRequestAnAppointmentButtonIsDisplayed() {
        assertPageObjectIsDisplayed(requestAnAppointment);
    }

    public void clickRequestFormLink() {
        clickElement(this.RequestFormLink);
    }

    public void SelectAppointmentTestAs(String appointmentTypeName) {
        clickElement(this.appointmentTypeList.stream().filter(x->
        {
            String name = x.getText().toLowerCase();
            return name.contains(appointmentTypeName.toLowerCase());
        }).findFirst().get());
    }

    public void v3_selectAppointmentTestAs(String appointmentTypeName) {
        clickElement(this.v3_appointmentTypeList.stream().filter(x ->
        {
            String name = x.getText().toLowerCase();
            return name.contains(appointmentTypeName.toLowerCase());
        }).findFirst().get());
}

    public boolean cancelAndGoBannerTitleIsDisplayed() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(appointmentTypePageTitle));
        return appointmentTypePageTitle.isDisplayed();
    }

    public void requestAnAppointmentRafBtn() {
        clickElement(clickBookAppointmentBtn);
    }

    public void EsSelectAppointmentTestAs(String appointmentTypeName) {
        clickElement(this.appointmentTypeEs);
    }

    public void inputAppointmentDateAndTime(String dateAndTime) {
        appointmentDateAndTimeEs.click();
        enterAppointmentDateAndTime.sendKeys("Tuesday at 3:00 p.m.");
    }

   public void selectCustomerTitle(String title) {
       logger.info("The user selects title");
       clickElement(customerTitle);
       selectDropdown(customerTitle);
    }

    public void inputCustomerFirstName(String firstName) {
        logger.info("enter name");
        nameES.click();
        enterNameES.sendKeys("Agnes");
    }

    public void inputCustomerLastName(String lastName) {
        logger.info("enter surname");
        surnameES.click();
        entersSurnameES.sendKeys("Sanchez");
    }

    public void inputCustomerMobile(String mobile) {
        logger.info("enter mobile");
        mobileES.click();
        enterMobileES.sendKeys("07498585765");
    }

    public void inputCustomerEmail(String email) {
        logger.info("enter email");
        emailES.click();
        enterEmailES.sendKeys("espagna@specsaver.co.uk");
    }

    public void focusOnAnythingElseWeShouldKnow() {
        clickElement(this.customerAnythingElseWeShouldKnow);
    }
}