package digital.eComm.ui.pages.sharedModules.expressreorder;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.LensExpressReorder;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommExpressReorderCardDetailPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(LensExpressReorder.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = "div#edit-details-billing-details-body>div>a")
    public WebElementFacade XroaddNewCard;

    @FindBy(css = "#edit-commerce-payment-payment-details-payment-code-nav-visa-ssl")
    public WebElementFacade XroSelectVisa;

    @FindBy(css = "#edit-consent-cit")
    public WebElementFacade XroSelectConsent;

    @FindBy(css = "#edit-submit")
    public WebElementFacade XroSaveNewCard;

    public void XroSaveCard() {
        clickElement(this.XroSaveNewCard);
    }

    public void clickAddNewCard() {
        clickElement(this.XroaddNewCard);
    }

    public void clickVisaCard() {
        clickElement(this.XroSelectVisa);
    }

    public void customerAgreestoSaveCard() {
        clickElement(this.XroSelectConsent);
    }
}
