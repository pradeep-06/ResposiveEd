package digital.eComm.ui.pages.glasses;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class eCommChooseLensPage extends eCommBase {

    @FindBy(css = "section#main div.ng-tns-c12-3 > button")
    public WebElementFacade clearLensButton;

    @FindBy(css = "section#main div.ng-tns-c12-9 > button")
    public WebElementFacade standardThickness;

    @FindBy(css = "section#main li.lens-option-group.last-item.ng-star-inserted > ss-lens-option-group > div > div.lens-option-group__content.ng-trigger.ng-trigger-expandCollapse > div > ul > li:nth-child(1) > ss-lens-option > div > div.lens-option__content-wrapper > div > div:nth-child(2) > button")
    public WebElementFacade scratchResistant;

    @FindBy(css = "section#main ss-summary > div > button")
    public WebElementFacade addToBasket;

    public void clickClearLensButton() {
        clickElement(clearLensButton);
    }

    public void clickStandardThickness() {
        clickElement(standardThickness);
    }

    public void clickAddToBasket() {
        clickElement(addToBasket);
        waitOnPage();
    }

    public void clickScratchResistant() {
        waitABit(2000L);
        clickElement(scratchResistant);
        waitOnPage();
    }
}