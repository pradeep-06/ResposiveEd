package digital.eComm.ui.pages.checkout.customeraccount;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommPaymentMethod extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = "form#spec-ecomm-myaccount-wallet-select-card div.row > div > a")
    private WebElementFacade addCard;

    @FindBy(css = "[id='page-title']")
    private WebElementFacade orderDetailsHeaderTitle;

    public void theUserSelectAddNewCardButton() {
        logger.info("VALIDATING the user is on Payment methods page and able to selects add new card button");
        clickElement(addCard);
    }

    public void verifyOrderDetailsPageTitleIsDispalyed(){
        String expectedTitle=testDataManager.getTestAssertionData("OrderDetailsPageTile");
        logger.info("Verify title "+ expectedTitle +" is displayed");
        assertElementContainsText(orderDetailsHeaderTitle,expectedTitle);
    }
}
