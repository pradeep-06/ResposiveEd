package digital.eComm.ui.pages.audiology;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;

public class audiologyPersonalDetailsPage extends BasePageObject {

    private final Logger logger = LoggerFactory.getLogger(audiologyPersonalDetailsPage.class);

    @FindBy(css = "#customerTitle")
    private WebElementFacade selectTitle;

    @FindBy(css = "#customerFirstName")
    private WebElementFacade firstName;

    @FindBy(css = "#customerLastName")
    private WebElementFacade lastName;

    @FindBy(css = "div > input#customerDoBDay")
    private WebElementFacade day;

    @FindBy(css = "div > input#customerDoBMonth")
    private WebElementFacade month;

    @FindBy(css = "div > input#customerDoBYear")
    private WebElementFacade year;

    @FindBy(css = "div > input#customerEmail")
    private WebElementFacade email;

    @FindBy(css = "div > input#customerMobile")
    private WebElementFacade mobileNumber;

    @FindBy(css = "div > textarea#customerNotes")
    private WebElementFacade additionalTextArea;

    @FindBy(css = "#customer-details-submit-button > div")
    private WebElementFacade continueButton;

    public void UserSelectsTitle() {
        selectTitle.selectByIndex(0);
    }
    public void UserEntersFirstName(String firstname){ setText(this.firstName, firstname); }
    public void UserEntersLastName(String lastName){ setText(this.lastName, lastName); }
    public void UserEntersDayOfDOB(String day){ setText(this.day, day); }
    public void UserEntersMonthOfDOB(String month){ setText(this.month, month); }
    public void UserEntersYearOfDOB(String year){ setText(this.year, year); }
    public void UserEntersEmail(String email){ setText(this.email, email); }
    public void UserEntersMobileNo(String mobileno){ setText(this.mobileNumber, mobileno); }
    public void UserClicksOnContinueButton(){ continueButton.click(); }

}
