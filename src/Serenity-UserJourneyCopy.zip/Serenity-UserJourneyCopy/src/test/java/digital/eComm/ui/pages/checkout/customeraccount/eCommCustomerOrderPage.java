package digital.eComm.ui.pages.checkout.customeraccount;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommCustomerOrderPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//div[contains(@class,'form-item-custom-order-number')]")
    private WebElementFacade orderNumber;

    public WebElementFacade getOrderNumber() {
        logger.info("ORDER number on ORDER page = " + orderNumber.getText());
        return orderNumber;
    }
}
