package digital.eComm.ui.pages.audiology;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class audiologyRecapPage extends BasePageObject {

    @FindBy(xpath = "//*[@id=\"page\"]/ss-app/div/ss-tracker/nav/div/ss-tracker-route[5]/a")
    private WebElementFacade recapHeader;

    @FindBy(css = "#who-email")
    private WebElementFacade emailDisplayed;

    @FindBy(css = "#who-tel")
    private WebElementFacade mobileNoDisplayed;

    @FindBy(css = "#recap-confirm-button")
    private WebElementFacade confirmationButton;

    public void UserValidatesDetailsOnRecapPage()
    {
        recapHeader.isPresent();
        emailDisplayed.isPresent();
        mobileNoDisplayed.isPresent();
        confirmationButton.click();
    }

}
