package digital.eComm.ui.pages.checkout;

import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommPaymentModePage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);

    @FindBy(id = "edit-commerce-payment-payment-details-payment-code-nav-visa-ssl")
    private WebElementFacade visaCard;

    @FindBy(id = "edit-commerce-payment-payment-details-payment-code-nav-ecmc-ssl")
    private WebElementFacade masterCard;

    @FindBy(id = "edit-commerce-payment-payment-method-paypal-eccommerce-payment-paypal-ec")
    private WebElementFacade payPal;

    @FindBy(id = "edit-commerce-payment-payment-method-medipasscommerce-payment-medipass")
    private WebElementFacade medipass;

    @FindBy(id = "edit-commerce-payment-payment-details-healthfund")
    private WebElementFacade healthfund;

    @FindBy(id = "healthfunds-policy-list")
    private WebElementFacade healthfundPolicy;

    @FindBy(id = "edit-commerce-payment-payment-details-payment-code-visa-ssl-save-my-details")
    public WebElementFacade customerInitiatedTransactionsCheckBox;

    @FindBy(css = "div#consent-pane label")
    private WebElementFacade merchantInitiatedTransactionsCheckBox;

    @FindBy(id = "edit-commerce-payment-payment-method-unipro-walletcommerce-payment-unipro-wallet")
    public WebElementFacade savedCardRadioBtn;

    @FindBy(className = "wallet-card-card")
    public WebElementFacade walletCard;

    @FindBy(css = "#edit-continue")
    private WebElementFacade placeOrderSecurely;

    @FindBy(id = "showOrderSummaryDesktop")
    private WebElementFacade orderSummaryHeading;

    @FindBy(css = "div#edit-commerce-payment-payment-details-unipro-wallet-card-consent label > div")
    public WebElementFacade mitConsent;

    @FindBy(id = "edit-commerce-payment-payment-details-payment-code-nav-ideal-ssl")
    private WebElementFacade idealPayment;

    @FindBy(xpath = "//h1[@id='page-title']")
    public WebElementFacade pageTitle;

    eCommHomePage eCommHomePage;

    public void clickVisaCard() {
        clickElement(this.visaCard);
    }

    public void clickMedipass() {
        clickElement(this.medipass);
        waitForLoadingIconTobeDisappear();

    }

    public void clickCustomerInitiatedTransactionsCheckBox() {
        clickElement(this.customerInitiatedTransactionsCheckBox);
    }

    public void clickPlaceOrderSecurely() {
        clickElement(placeOrderSecurely);
    }

    public void clickMerchantInitiatedTransactionsCheckBox() {
        clickElement(this.merchantInitiatedTransactionsCheckBox);
    }

    public void theUserSelectSavedCardRadio() {
        clickElement(this.savedCardRadioBtn);
    }

    public void theUserSelectsSavedCard() {
        clickElement(this.walletCard);
    }

    public void selectHealthFundDropdown(String healthFund) {
        selectFromDropdown(this.healthfund, healthFund);
        waitForLoadingIconTobeDisappear();
    }

    public void waitForCardPage() {
        waitFor(WebElementExpectations.elementIsDisplayed(orderSummaryHeading));
    }

    public void theUserSelectsSavedCardWithConsent() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        clickElement(this.walletCard);
        clickElement(this.mitConsent);
    }

    public WebElementFacade getVisaCard() {
        return visaCard;
    }

    public void theUserSelectsPaypalPayment() {
        logger.info("the User selected paypal option");
        clickElement(payPal);
    }

    public void theUserSelectsIdealPayment() {
        logger.info("the User selected iDeal option");
        clickElement(idealPayment);
    }

}
