package digital.eComm.ui.pages.checkout;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class eCommHealthFundDetailsPage extends eCommBase {
    @FindBy(css = "input[name='membershipNumber']")
    private WebElementFacade membershipNumber;

    @FindBy(css = "input[name='cardRank']")
    private WebElementFacade patientNumber;

    @FindBy(css = "input[name='cardIssueNumber']")
    private WebElementFacade cardIssueNumber;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    private WebElementFacade continueButton;

    public void enterMembershipNumber(String membershipNumber) {
        setText(this.membershipNumber, membershipNumber);
    }

    public void enterPatientNumber(String cardRank) {
        setText(this.patientNumber, cardRank);
    }

    public void enterCardIssueNumber(String cardIssueNumber) {
        setText(this.cardIssueNumber, cardIssueNumber);
    }


    public void clickContinueButton() {
        clickElement(this.continueButton);
    }
}