package digital.eComm.ui.pages.contactlens;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.extensions.util.eCommCurrencyHandler;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class eCommContactLensProductDetailedPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    String productAmount;

    eCommCurrencyHandler eCommCurrencyHandler;


    @FindBy(xpath = "//div[contains(@class,'prescription-spec')]")
    private WebElementFacade prescriptionModule;

    @FindBy(xpath = "//span[contains(@id,'edit-quantity-right-eye-')]")
    private WebElementFacade rightEyeQuantity;

    @FindBy(xpath = "//span[contains(@id,'edit-quantity-left-eye-')]")
    private WebElementFacade leftEyeQuantity;

    @FindBy(xpath = "//span[contains(@id,'edit-eyes-left-eye-power-button')]")
    private WebElementFacade leftEyeQuantityMerken;

    @FindBy(xpath = "//button//ancestor::div[@class='form-item-container container-button']")
    private WebElementFacade selectPrescription;

    @FindBy(xpath = "//div[contains(@class,'product-main')]//img")
    private WebElementFacade productImage;

    @FindBy(css = "div#block-system-main div.form-item.form-item-cl-price-summary.form-type-item.form-group > div > div > span")
    private WebElementFacade itemPrice;

    @FindBy(xpath = "//*[@class='form-item-container container-amount']//child::label")
    private WebElementFacade totalAmount;

    public void selectRightEyeQuantity(String rightEyeQty) {

        if (featureSelectLensQuantityFromPDPIsOn()) {
            selectOptionFromDropdown(this.rightEyeQuantity, rightEyeQty);
            logger.info("VALIDATE: button 'select prescription' is enabled");
            assertPageObjectExists(selectPrescription);
        }
    }

    public void selectLeftEyeQuantity(String leftEyeQty) {

        if (featureSelectLensQuantityFromPDPIsOn()) {
            selectOptionFromDropdown(this.leftEyeQuantity, leftEyeQty);
            logger.info("VALIDATE: button 'select prescription' is enabled");
            assertObjectIsClickable(selectPrescription);
        }
    }

    public void selectLeftEyeQuantityMerken(String leftEyeQty) {

        if (featureSelectLensQuantityFromPDPIsOn()) {
            selectOptionFromDropdown(this.leftEyeQuantityMerken, leftEyeQty);
            logger.info("VALIDATE: button 'select prescription' is enabled");
            assertObjectIsClickable(selectPrescription);
        }
    }

    public void clickSelectPrescription() {
        clickElement(this.selectPrescription);
        logger.info("VALIDATE: Prescription module is displayed");
        assertPageObjectExists(this.getPrescriptionModule());
    }

    public WebElementFacade getProductImage() {
        return productImage;
    }

    public WebElementFacade getPrescriptionModule() {
        return prescriptionModule;
    }

    //Feature Flags & Region Specific Feature Rules
    public Boolean featureSelectLensQuantityFromPDPIsOn() {
        return testDataManager.getFeatureData("contactLensPrescription.optimisedJourney", Boolean.class);
    }


    public void getPrice(String rightEyeQty, String leftEyeQty) {

        if (featureSelectLensQuantityFromPDPIsOn()) {
            logger.info("User confirm product price for one off order after adding left and right eye quantity on a pdp page");
            logger.info("Product price on a pdp page ::{} ", getProductBasePrice(itemPrice));
            int totalQty = Integer.parseInt(rightEyeQty) + Integer.parseInt(leftEyeQty);

            Double productPrice = getProductBasePrice(itemPrice) * totalQty;
            this.productAmount = eCommCurrencyHandler.getRegionalCurrency(productPrice);

            logger.info("Total qty on a pdp page {}, so calculating total price based on left and right eye qty::{} ", totalQty, productAmount);

            assertNormalizeStringText(getAndTrimText(totalAmount), productAmount);
        }
    }

    public String getProductAmount() {
        return productAmount;
    }

}