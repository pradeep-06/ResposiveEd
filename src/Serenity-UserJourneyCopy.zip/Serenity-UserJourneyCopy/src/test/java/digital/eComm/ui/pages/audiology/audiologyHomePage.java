package digital.eComm.ui.pages.audiology;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class audiologyHomePage extends BasePageObject {

    @FindBy(css = "div.ss-nav__row > ul.ss-nav__right-col > li:nth-child(1)")
    private WebElementFacade bookFreeHearingTestButton;

    @FindBy(css = "#ss-button-change-location > small")
    private WebElementFacade changeLocationButtonButton;

    @FindBy(css = "#customer--location")
    private WebElementFacade customerLocationInputBox;

    @FindBy(css = "div.ss-form-group.ng-untouched.ng-pristine.ng-invalid > span")
    public WebElementFacade searchStoreButton;

    @FindBy(css = "li#ss-nav-primary__item--menu-hearing-aurora > a")
    private WebElementFacade hearingIcon;

    @FindBy(css ="#ss-button-select-store")
    private WebElementFacade BookOnlineButton;

    public void UserClicksOnHearingOption()
    {
        clickElement(this.hearingIcon);
    }

    public void UserClicksOnHearingButton()
    {
        clickElement(this.hearingIcon);
    }

    public void UserClicksOnbookFreeHearingTestButton()
    {
        clickElement(this.bookFreeHearingTestButton);
    }


    public void theUserSearchesForTheStore(String storeLocation) {

        customerLocationInputBox.typeAndEnter(storeLocation);
    }

    public void UserClicksOnChangeLocationButton() {
        clickElement(this.changeLocationButtonButton);
    }

    public void UserClicksOnSearchStoreButton(){
       clickElement(this.searchStoreButton);
    }

    public void UserClicksOnBookOnlineButton()
    {
      clickElement(this.BookOnlineButton);
    }

}
