package digital.eComm.ui.pages.drupal.discounts;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class eComDeleteCodePage extends eCommBase {

    @FindBy(css = "div#branding > h1")
    private WebElementFacade deleteHeader;

    @FindBy(id = "edit-submit")
    private WebElementFacade confirmButton;

    public void theUserConfirmCouponDeletion() {
        clickElement(confirmButton);
    }

    public void theUserConfirmDiscountDeletion() {
        clickElement(confirmButton);
    }
}
