package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import Framework.extensions.StafUtils;
import net.thucydides.core.steps.ScenarioSteps;
import digital.eComm.ui.pages.drupal.eCommCustomerDetailsPage;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashMap;
import java.util.Map;

public class DrupalCustomerDetails extends ScenarioSteps {
    eCommCustomerDetailsPage eCommCustomerDetailsPage;
    private final static String MAILOSAUR = "mailosaur";

    private final Logger logger = LoggerFactory.getLogger(DrupalHome.class);
    protected TestDataManager testDataManager = new TestDataManager();
    Map<String, String> beforeCustomerDetailsUpdate;
    Map<String, String> afterCustomerDetailsUpdate;
    String emailAddress="";
    public void getCustomerDetailsBeforeUpdate(){
            beforeCustomerDetailsUpdate=new HashMap<String, String>();
            if (!(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("dk"))) {
                beforeCustomerDetailsUpdate.put("title", eCommCustomerDetailsPage.getCustomerTitle());
            }
            beforeCustomerDetailsUpdate.put("firstName",eCommCustomerDetailsPage.getFirstName());
            beforeCustomerDetailsUpdate.put("lastName",eCommCustomerDetailsPage.getLastName());
            beforeCustomerDetailsUpdate.put("gender",eCommCustomerDetailsPage.getGender());
            beforeCustomerDetailsUpdate.put("emailAddress",eCommCustomerDetailsPage.getEmailAddress());
        }

        public void updateCustomerDetailsPage() {
            final String title = testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.title");
            final String firstName = testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.firstName");
            final String lastName = testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.lastName");
            final String gender=testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.gender");
            emailAddress = StafUtils.generateNewCustomerEmail(MAILOSAUR);
            final String confirmEmailAddress = emailAddress;

            eCommCustomerDetailsPage.clickOnEdit();

            if (!(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("dk"))){
                eCommCustomerDetailsPage.setToUpdateTitle(title);
            }
            eCommCustomerDetailsPage.setToUpdateFirstName(firstName);
            eCommCustomerDetailsPage.setToUpdatelastName(lastName);
            eCommCustomerDetailsPage.setGender(gender);
            eCommCustomerDetailsPage.setEmailAddress(emailAddress);
            eCommCustomerDetailsPage.setConfirmEmailAddress(confirmEmailAddress);
            eCommCustomerDetailsPage.clickOnSave();
        }

        public void GetCustomerDetailsAfterUpdate(){
            afterCustomerDetailsUpdate=new HashMap<String, String>();
            if (!(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("dk"))) {
                afterCustomerDetailsUpdate.put("title", eCommCustomerDetailsPage.getCustomerTitle());
            }
            afterCustomerDetailsUpdate.put("firstName",eCommCustomerDetailsPage.getFirstName());
            afterCustomerDetailsUpdate.put("lastName",eCommCustomerDetailsPage.getLastName());
            afterCustomerDetailsUpdate.put("gender",eCommCustomerDetailsPage.getGender());
            afterCustomerDetailsUpdate.put("emailAddress",eCommCustomerDetailsPage.getEmailAddress());

        }

        public void verifyCustomerDetailsAreUpdated(){
            if (!(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("dk"))) {
                Assertions.assertEquals(afterCustomerDetailsUpdate.get("title"),(testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.title")));
            }
            Assertions.assertEquals(afterCustomerDetailsUpdate.get("firstName"),(testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.firstName")));
            Assertions.assertEquals(afterCustomerDetailsUpdate.get("lastName"),(testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.lastName")));
            Assertions.assertEquals(afterCustomerDetailsUpdate.get("gender"),(testDataManager.getTestInputRegionData("drupal.updateCustomerDetails.gender")));
            Assertions.assertEquals(afterCustomerDetailsUpdate.get("emailAddress"),(emailAddress));

        }
}