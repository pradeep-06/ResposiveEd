package digital.eComm.ui.pages.audiology;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class audiologyConfirmationPage extends BasePageObject {

    @FindBy(css = "#book-confirm-page > ss-confirmation-header > header > h1" )
    private WebElementFacade confirmationHeader;

    @FindBy(css = "#who-email" )
    private WebElementFacade whoCardEmail;

    @FindBy(css = "#who-tel" )
    private WebElementFacade whoCardMobile;

    public void UserValidatesDataOnConfirmationPage()
    {
        confirmationHeader.isPresent();
        whoCardEmail.isPresent();
        whoCardMobile.isPresent();
    }

}
