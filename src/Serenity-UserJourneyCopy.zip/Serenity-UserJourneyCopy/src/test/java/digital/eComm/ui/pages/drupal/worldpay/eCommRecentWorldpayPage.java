package digital.eComm.ui.pages.drupal.worldpay;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommRecentWorldpayPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommRecentWorldpayPage.class);

    @FindBy(id = "edit-order-code")
    private WebElementFacade inputMessageBox;

    @FindBy(id = "edit-submit-worldpay-log")
    private WebElementFacade applyButton;

    @FindBy(css = "div#block-system-main td.views-field.views-field-message > a")
    private WebElementFacade savedCardMessageLink;

    public void theUserEnteredOrderID(String orderNumber) {
        setText(this.inputMessageBox,orderNumber);
        clickElement(this.applyButton);
        clickElement(this.savedCardMessageLink);
    }

}
