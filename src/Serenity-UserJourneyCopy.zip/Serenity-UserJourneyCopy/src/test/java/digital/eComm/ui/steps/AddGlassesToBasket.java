package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.pages.eCommBasketPage;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.pages.eCommProductSearchPage;
import digital.eComm.ui.pages.glasses.eCommChooseLensPage;
import digital.eComm.ui.pages.glasses.eCommPrescriptionPage;
import digital.eComm.ui.pages.glasses.eCommProductDetailedPage;
import digital.eComm.ui.pages.glasses.eCommSearchAndFindStorePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddGlassesToBasket extends ScenarioSteps {

    eCommHomePage homePage;

    eCommHomePage eCommHomePage;

    eCommProductSearchPage eCommProductSearchPage;

    eCommPrescriptionPage eCommPrescriptionPage;

    eCommProductDetailedPage eCommProductDetailedPage;

    eCommChooseLensPage eCommChooseLensPage;

    eCommBasketPage eCommBasketPage;

    eCommSearchAndFindStorePage eCommSearchAndFindStorePage;

    private final Logger logger = LoggerFactory.getLogger(AddGlassesToBasket.class);
    final TestDataManager testDataManager = new TestDataManager();

    public void selectCheckOutSecurely() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommBasketPage.clickCheckoutSecurelyButton();
    }

    public void theGuestUserSearchesOphthalmicFrames(String ophthalmicFrames) {
        homePage.clickOn(homePage.searchMagnifierIcon);
        eCommProductSearchPage.enterInputSearchBox(ophthalmicFrames);
        if (Staf.getTargetRegion().equals("eses") | Staf.getTargetRegion().equals("esen")) {
            //eCommHomePage.bannerStaticHeader();
            //eCommHomePage.bannerStaticFooter();
            eCommProductSearchPage.clickGlassesProduct();
        } else {
            eCommProductSearchPage.clickGlassesProduct();
        }
    }

    public void theGuestUserSearchesOphthalmicFramesFromBasket(String ophthalmicFrames) {
        eCommBasketPage.clickSearchButton();
        eCommProductSearchPage.enterInputSearchBox(ophthalmicFrames);
        eCommProductSearchPage.clickGlassesProduct();
    }

    public void theUserSelectBuyOnlineButton() {
        eCommProductDetailedPage.clickBuyOnline();
    }

    public void theUserFillPrescriptionDetails() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        logger.info("the user fills prescription details");
        eCommPrescriptionPage.selectPrescriptionType(
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.prescriptionType"));

        eCommPrescriptionPage.setOpticalSettings(
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightSphere"),
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftSphere"),
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightCylinder"),
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftCylinder"),
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightAxis"),
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftAxis"),
                testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.pupillaryDistance"));


        if (testDataManager.getFeatureData("glassesPrescription.hasPrescriptionDate", Boolean.class)) {
            this.enterPrescriptionDate(testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.date"));

        }
        //2022.03.29 this checkbox is not present for all regions: added logic to check regional inout data
        if (testDataManager.getFeatureData("glassesPrescription.confirmOriginalPrescriptionCheckBox", Boolean.class)) {
            eCommPrescriptionPage.clickConsentCheckbox();
        }

        eCommPrescriptionPage.clickNextButton();
        eCommPrescriptionPage.waitForLensSelectorHeading();
    }

    private void enterPrescriptionDate(String prescriptionDate) {

        final String[] dateSplitter = prescriptionDate.split("-");

        eCommPrescriptionPage.enterInputDay(dateSplitter[2]);
        eCommPrescriptionPage.enterInputMonth(dateSplitter[1]);
        eCommPrescriptionPage.enterInputYear(dateSplitter[0]);

    }

    public void theGuestUserSelectLensType() {
        logger.info("the user selects lens type");
        eCommChooseLensPage.clickClearLensButton();
        eCommChooseLensPage.clickStandardThickness();
        eCommChooseLensPage.clickScratchResistant();
        eCommChooseLensPage.clickAddToBasket();
    }

    public void selectHealthFund() {

        if (testDataManager.getFeatureData("basket.healthFunds", Boolean.class)) {

            final String healthFundName = testDataManager.getTestInputRegionData("purchasing.checkout.basket.healthFund");
            final String healthFundPolicyName = testDataManager.getTestInputRegionData("purchasing.checkout.basket.healthfundPolicy");
            eCommHomePage.bannerStaticHeader();
            eCommHomePage.bannerStaticFooter();
            eCommBasketPage.clickHealthFundAvailableButton();
            eCommBasketPage.clickSelectHealthFundButton();
            eCommBasketPage.selectHealthfundsList(healthFundName, healthFundPolicyName);
            eCommBasketPage.clickContinueButton();
            waitABit(8000); // Need to remove hardcoded wait : Dipak
        }
    }

    public void selectHealthFundNotAvailable() {
        if (testDataManager.getFeatureData("basket.healthFunds", Boolean.class)) {
            eCommBasketPage.clickHealthFundNotAvailableButton();
        }
    }

    public void theGuestUserSelectOneOphthalmicFrames(String ophthalmicFrames) {

        homePage.clickOn(homePage.searchMagnifierIcon);
        eCommProductSearchPage.enterInputSearchBox(ophthalmicFrames);
        if (Staf.getTargetRegion().equals("eses") | Staf.getTargetRegion().equals("esen")) {
            //eCommHomePage.bannerStaticHeader();
            //eCommHomePage.bannerStaticFooter();
            eCommProductSearchPage.clickAddToFavourite();
            eCommProductSearchPage.clickOnFavouriteIcon();
            eCommProductSearchPage.productCode();
            logger.info("product number added to favourite in catalogue ::{}", eCommProductSearchPage.productCode());
        } else {
            eCommProductSearchPage.clickAddToFavourite();
            eCommProductSearchPage.clickOnFavouriteIcon();
            eCommProductSearchPage.productCode();
            logger.info("product number added to favourite in catalogue ::{}", eCommProductSearchPage.productCode());
        }

    }

    public void enterPromoCodeDetails() {

        final String applyPromo = testDataManager.getTestInputCommonData("basket.promocode");

        eCommBasketPage.clickSelectPromocode();
        eCommBasketPage.applyPromocode(applyPromo);
        eCommBasketPage.enterPromocode();
        Assertions.assertThat(eCommBasketPage.promoCodeMsg()).contains(applyPromo);
    }

    public void check2for1DiscountHasBeenApplied() {
        if (testDataManager.getFeatureData("promotions.hasGlasses2for1", Boolean.class)) {
            logger.info("asserting 2 for 1 discount has successfully been applied");
            String discountText = testDataManager.getTestAssertionData("discount.glasses2for1Discount");
            eCommBasketPage.theUserConfirmsLineLevelDiscount2for1AppliedToTheBasket(discountText);
        }
    }

    public void glasses1PrescriptionInfo() {
        String rightSphere = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightSphere");
        String rightCylinder = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightCylinder");
        String rightAxis = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightAxis");
        String leftSphere = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftSphere");
        String leftCylinder = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftCylinder");
        String leftAxis = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftAxis");
        String pupillaryDistance = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.pupillaryDistance");
        eCommBasketPage.theUserConfirmsPrescriptionDetailsOfGlasses1Match(rightSphere, rightCylinder, rightAxis,
                leftSphere, leftCylinder, leftAxis,
                pupillaryDistance);
    }

    public void glasses2PrescriptionInfo() {
        String rightSphere = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightSphere");
        String rightCylinder = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightCylinder");
        String rightAxis = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.rightAxis");
        String leftSphere = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftSphere");
        String leftCylinder = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftCylinder");
        String leftAxis = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.leftAxis");
        String pupillaryDistance = testDataManager.getTestInputRegionData("purchasing.glasses.prescriptionData.validPrescription.pupillaryDistance");
        eCommBasketPage.theUserConfirmsPrescriptionDetailsOfGlasses2Match(rightSphere, rightCylinder, rightAxis,
                leftSphere, leftCylinder, leftAxis,
                pupillaryDistance);
    }

    public void navigateToGlassesPageFromHome() {
        homePage.clickGlassesLink();
    }

    public void selectMaleAgeAndGenderFilter() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommProductSearchPage.clickMaleAgeAndGenderFilterButton();
    }

    public void selectOpticalTypeFilter() {
        eCommProductSearchPage.clickOpticalTypeFilterButton();
    }

    public void selectDesignerTypeFilter() {
        eCommProductSearchPage.clickDesignerTypeFilterButton();
    }

    public void selectAvailableOnlineFilter() {
        eCommProductSearchPage.clickAvailableOnlineFilterButton();
    }

    public void selectGlassesWithTryOn() {
        eCommProductSearchPage.clickProductWithTryOn();
    }

    public void selectVirtualTryOn() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommProductDetailedPage.clickVirtualTryOnButton();
    }

    public void selectSearchFromPDP() {
        eCommProductDetailedPage.clickSearchButton();
    }

    public void searchForProduct(String ophthalmicFrames) {
        eCommProductSearchPage.enterInputSearchBox(ophthalmicFrames);
    }

    public void selectGlassesFromSearch() {
        if (Staf.getTargetRegion().equals("eses") | Staf.getTargetRegion().equals("esen")) {
 //           eCommHomePage.bannerStaticHeader();
 //           eCommHomePage.bannerStaticFooter();
            eCommProductSearchPage.clickGlassesProduct();
        } else {
            eCommProductSearchPage.clickGlassesProduct();
        }

    }

    public void selectClearLensOption() {
        eCommChooseLensPage.clickClearLensButton();
    }

    public void selectStandardThicknessOption() {
        eCommChooseLensPage.clickStandardThickness();
    }

    public void selectScratchResistanceOption() {
        eCommChooseLensPage.clickScratchResistant();
    }

    public void selectAddToBasket() {
        eCommChooseLensPage.clickAddToBasket();
    }

    public void selectGlassesPageFromBasket() {
        eCommBasketPage.clickGlassesPage();
    }

    public void selectCheckoutButton() {
        eCommBasketPage.clickCheckoutButton();
    }

    public void clickOnFavouritesIconDisplayAtLeftSideOfPriceValue() {
        eCommProductSearchPage.clickOnFavouritesIconDisplayedAtLeftSideOfPriceValue();
    }

    public void clickOnViewFavouritesButton() {
        eCommProductSearchPage.clickOnViewFavouritesButton();
    }

    public void clickOnFindAStoreButton() {
        eCommProductDetailedPage.clickOnFindAStoreButton();
    }

    public void enterStoreLocationandSearch(String storeName) {
        eCommSearchAndFindStorePage.enterStoreLocation(storeName);
        eCommSearchAndFindStorePage.clickOnSearchButton();
    }

    public void VerifyBookAnAppointmentButtonsAreDisplayed() {
        eCommSearchAndFindStorePage.verifyBookAnAppointmentButtonsAreDisplayed();
    }

    public void selectFrame() {
        eCommProductDetailedPage.chooseFrame();
    }

    public void theGuestUserSelectOneOphthalmicFramesNew(String ophthalmicFrames) {

        homePage.clickOn(homePage.searchMagnifierIcon);
        eCommProductSearchPage.enterInputSearchBox(ophthalmicFrames);
        if (Staf.getTargetRegion().equals("eses") | Staf.getTargetRegion().equals("esen")) {
            eCommHomePage.bannerStaticHeader();
            eCommHomePage.bannerStaticFooter();
            eCommProductSearchPage.clickVirtualTryOn();
        } else {
            eCommProductSearchPage.clickVirtualTryOn();
        }
    }
}