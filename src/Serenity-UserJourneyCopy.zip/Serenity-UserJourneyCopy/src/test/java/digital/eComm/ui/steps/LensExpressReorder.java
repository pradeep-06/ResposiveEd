package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.checkout.ideal.eCommIdealAuthorizePage;
import digital.eComm.ui.pages.checkout.ideal.eCommIdealDetailsPage;
import digital.eComm.ui.pages.customeraccount.eCommMyOrdersPage;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.pages.sharedModules.expressreorder.eCommExpressReorderCardDetailPage;
import digital.eComm.ui.pages.sharedModules.expressreorder.eCommExpressReorderCustomerAddressPage;
import digital.eComm.ui.pages.sharedModules.expressreorder.eCommExpressReorderLandingPage;
import digital.eComm.ui.pages.sharedModules.expressreorder.eCommExpressReorderLoginPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LensExpressReorder extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(LensExpressReorder.class);
    protected final TestDataManager testDataManager = new TestDataManager();


    eCommExpressReorderLoginPage eCommExpressReorderLoginPage;
    eCommExpressReorderLandingPage eCommExpressReorderLandingPage;
    eCommExpressReorderCustomerAddressPage eCommExpressReorderCustomerAddressPage;
    eCommExpressReorderCardDetailPage eCommExpressReorderCardDetailPage;
    eCommIdealDetailsPage eCommIdealDetailsPage;
    eCommIdealAuthorizePage eCommIdealAuthorizePage;
    eCommMyOrdersPage eCommMyOrdersPage;
    eCommHomePage eCommHomePage;

    public void navigateToExpressReorderLink() {
        logger.info("Clicking on LensExpressReorder link");
        eCommExpressReorderLoginPage.clickOn(eCommExpressReorderLoginPage.XroLink);
        logger.info("LensExpressReorder Link clicked");
    }

    public void amendLeftEyeQuantity(String userRole) {
        String quantity = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".prescriptionData.leftEyeQty");
        eCommExpressReorderLandingPage.xroLeftEyeQty(quantity);
    }

    public void amendRightEyeQuantity(String userRole) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        String quantity = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".prescriptionData.rightEyeQty");
        eCommExpressReorderLandingPage.xroRightEyeQty(quantity);
    }

    public void ClicknewAddressButton() {
        eCommExpressReorderCustomerAddressPage.xroAddaNewAddress();
    }


    public void AddnewAddressDetails(String userRole) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String addressLine1 = testDataManager.getTestInputRegionData("purchasing.checkout.address" + userRole + ".addressLine1");
        final String postcode = testDataManager.getTestInputRegionData("purchasing.checkout.address" + userRole + ".postcode");
        final String town = testDataManager.getTestInputRegionData("purchasing.checkout.address" + userRole + ".town");


        eCommExpressReorderCustomerAddressPage.enterXroUserFirstName(firstName);
        eCommExpressReorderCustomerAddressPage.enterXroUserLastName(lastName);
        eCommExpressReorderCustomerAddressPage.XroAddressLine1(addressLine1);
        eCommExpressReorderCustomerAddressPage.XroenterCity(town);
        eCommExpressReorderCustomerAddressPage.xroenterPostCode(postcode);

        if (testDataManager.getFeatureData("checkoutPages.hasState", Boolean.class)) {
            final String state = testDataManager.getTestInputRegionData("purchasing.checkout.address.state");
            eCommExpressReorderCustomerAddressPage.xroselectState(state);
        }
    }

    public void SavenewAddress() {
        eCommExpressReorderCustomerAddressPage.XroSaveAddress();
        logger.info("VALIDATE: Address Saved success Message");
        final String addedAddressConfirmation = testDataManager.getTestAssertionData("AddressConfirmation");
        Assertions.assertThat(eCommExpressReorderLandingPage.SucessMsg()).contains(addedAddressConfirmation);


    }

    public void AddnewCard() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();

        eCommExpressReorderCardDetailPage.clickAddNewCard();
        logger.info("User select visa card and initiated transaction for the payment ");
        eCommExpressReorderCardDetailPage.clickVisaCard();
        eCommExpressReorderCardDetailPage.customerAgreestoSaveCard();

    }

    public void SavenewCard() {
        eCommExpressReorderCardDetailPage.XroSaveCard();
    }

    public void XroPlaceOrderSecurley() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();

        if (testDataManager.getFeatureData("xro.hasPrivacyAndTermsCheckbox", Boolean.class)) {
            eCommExpressReorderLandingPage.agreeCheckBox();
        }
        eCommExpressReorderLandingPage.placeOrder();
        eCommExpressReorderLandingPage.alertAccept();
    }

    public void XroConfirmOrder() {
        eCommExpressReorderLandingPage.alertMessage();
    }

    public String verifyXROUsingNewlyAddedIdealCard(String rightEyeQuanity, String leftEyeQuantity, String paymentMethod){
        eCommExpressReorderLandingPage.selectRightEyeQuantity(rightEyeQuanity);
        eCommExpressReorderLandingPage.selectLeftEyeQuantity(leftEyeQuantity);
        eCommExpressReorderLandingPage.selectCardTypeAs(paymentMethod);
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommExpressReorderLandingPage.clickOnConfirmConsent();
        eCommExpressReorderLandingPage.clickOnPlaceOrderSafelyButton();
      //  eCommIdealDetailsPage.selectBank();
        eCommIdealAuthorizePage.selectAuthorizationButton();

        return eCommExpressReorderLandingPage.getOrderNumber();
    }

    public String verifyReOrderingWithAmendedQuantityUsingSavedVisaCard(String rightEyeQuanity, String leftEyeQuantity, String paymentMethod){
        eCommExpressReorderLandingPage.selectRightEyeQuantity(rightEyeQuanity);
        eCommExpressReorderLandingPage.selectLeftEyeQuantity(leftEyeQuantity);
        eCommExpressReorderLandingPage.selectCardTypeAs(paymentMethod);
        eCommExpressReorderLandingPage.clickOnPlaceOrderSafelyButton();
        eCommExpressReorderLandingPage.alertAccept();
        return eCommExpressReorderLandingPage.getOrderNumber();
    }

    public String verifyReOrderingWithAmendedQuantityUsingSavedVisaCardConsentConfirm(String rightEyeQuanity, String leftEyeQuantity, String paymentMethod){
        eCommExpressReorderLandingPage.selectRightEyeQuantity(rightEyeQuanity);
        eCommExpressReorderLandingPage.selectLeftEyeQuantity(leftEyeQuantity);
        eCommExpressReorderLandingPage.selectCardTypeAs(paymentMethod);
        eCommExpressReorderLandingPage.consentConfirmButton();
        eCommExpressReorderLandingPage.clickOnPlaceOrderSafelyButton();
        eCommExpressReorderLandingPage.alertAccept();
        return eCommExpressReorderLandingPage.getOrderNumber();
    }

    public void verifyOrderNumberIsDisplayedInOrderSummaryPage(String OrderNumber){
        eCommMyOrdersPage.verifyMoreThanOneOrderNumbersAreDisplayed(OrderNumber);
    }


}


