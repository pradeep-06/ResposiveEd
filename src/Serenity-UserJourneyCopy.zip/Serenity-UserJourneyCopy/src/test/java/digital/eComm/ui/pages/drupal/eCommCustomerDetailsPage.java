package digital.eComm.ui.pages.drupal;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommCustomerDetailsPage extends eCommBase {
    private final Logger logger = LoggerFactory.getLogger(eCommDrupalHomePage.class);

    @FindBy(css="[class*='field field-name-field-prefix']>div:nth-child(2)>div")
    WebElementFacade readOnlyTitle;

    @FindBy(css="[class*='field field-name-field-firstname']>div:nth-child(2)>div")
    WebElementFacade readOnlyFirstName;

    @FindBy(css = "[class*='field field-name-field-lastname']>div:nth-child(2)>div")
    WebElementFacade readOnlyLastName;

    @FindBy(css="[class*='field field-name-field-gender']>div:nth-child(2)>div")
    WebElementFacade readOnlyGender;

    @FindBy(css="[class*='form-item form-type-item form-item-customer-support-customer-mail']>a")
    WebElementFacade readOnlyEmailAddress;

    @FindBy(css="[class*='customer-support-edit']>a")
    WebElementFacade editButton;

    @FindBy(css="[id='edit-field-prefix-und']")
    WebElementFacade dropDownTitle;

    @FindBy(css="#edit-field-firstname-und-0-value")
    WebElementFacade editFirstName;

    @FindBy(css="#edit-field-lastname-und-0-value")
    WebElementFacade editLastName;

    @FindBy(css="#edit-field-gender-und")
    WebElementFacade dropdownGender;

    @FindBy(css="#edit-custom-email-address--2")
    WebElementFacade editEmailAddress;

    @FindBy(css="[class='button form-submit']")
    WebElementFacade buttonSave;

    @FindBy(css="[id='edit-custom-email-address-confirm']")
    WebElementFacade editConfirmEmailAddress;

    public String getCustomerTitle(){
        return readOnlyTitle.getText();
    }

    public String getFirstName(){
        return readOnlyFirstName.getText();
    }

    public String getLastName(){
        return readOnlyLastName.getText();
    }

    public String getGender(){
        return readOnlyGender.getText();
    }

    public String getEmailAddress(){
        return readOnlyEmailAddress.getText();
    }

    public void clickOnEdit(){
        clickElement(editButton);
    }

    public void setToUpdateTitle(String value){
       selectDropDownItemByVisibleText(dropDownTitle, value);
    };

    public void setToUpdateFirstName(String value){
        editFirstName.clear();
       setText(editFirstName,value);
    }

    public void setToUpdatelastName(String value){
        editLastName.clear();
        setText(editLastName,value);
    }

    public void setGender(String value){
        selectDropDownItemByVisibleText(dropdownGender, value);
    }

    public void setEmailAddress(String value){
        editEmailAddress.clear();
        setText(editEmailAddress,value);
    }

    public void setConfirmEmailAddress(String value){

        setText(editConfirmEmailAddress,value);
    }

    public void clickOnSave(){
        clickElement(buttonSave);
    }
}