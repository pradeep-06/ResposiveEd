package digital.eComm.ui.pages.glasses;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;

public class eCommPrescriptionPage extends eCommBase {

    @FindBy(css = "select#prescription_type")
    private WebElementFacade selectPrescriptionType;

    @FindBy(css = "select#sphere_right")
    private WebElementFacade selectRightSphere;

    @FindBy(css = "select#sphere_left")
    private WebElementFacade selectLeftSphere;

    @FindBy(css = "select#cylinder_right")
    private WebElementFacade selectRightCylinder;

    @FindBy(css = "select#cylinder_left")
    private WebElementFacade selectLeftCylinder;

    @FindBy(css = "input#axis_right")
    private WebElementFacade inputRightAxis;

    @FindBy(css = "input#axis_left")
    private WebElementFacade inputLeftAxis;

    @FindBy(css = "input#pupillary_distance_both")
    private WebElementFacade inputPDValue;

    @FindBy(css = "input#prescription_date_day")
    private WebElementFacade inputDay;

    @FindBy(css = "input#prescription_date_month")
    private WebElementFacade inputMonth;

    @FindBy(css = "input#prescription_date_year")
    private WebElementFacade inputYear;

    @FindBy(css = "section#main span.ss-icon")
    private WebElementFacade consentCheckbox;

    @FindBy(css = "section#main div.form-submit.prescription-selector-content > div > button")
    private WebElementFacade nextButton;

    @FindBy(className = "lens-selector-content")
    private WebElementFacade lensSelectorHeading;
    protected final TestDataManager testDataManager = new TestDataManager();

    public void selectPrescriptionType(String regionalData) {
        selectDropDownItemByVisibleText(selectPrescriptionType, regionalData);
    }

    public void selectRightSphere(String rightSphere) {
        selectDropDownItemByVisibleText(this.selectRightSphere, rightSphere);
    }

    public void selectLeftSphere(String leftSphere) {
        selectFromDropdown(this.selectLeftSphere, leftSphere);
    }

    public void selectRightCylinder(String rightCylinder) {
        selectDropDownItemByVisibleText(this.selectRightCylinder, rightCylinder);
    }

    public void selectLeftCylinder(String leftCylinder) {
        selectDropDownItemByVisibleText(this.selectLeftCylinder, leftCylinder);
    }

    public void setOpticalSettings(String rightSphere, String leftSphere, String rightCylinder, String leftCylinder, String rightAxis, String leftAxis, String pdValue) {
        selectRightSphere(rightSphere);
        selectLeftSphere(leftSphere);
        selectRightCylinder(rightCylinder);
        selectLeftCylinder(leftCylinder);
        enterInputLeftAxis(leftAxis);
        enterInputRightAxis(rightAxis);
        enterInputPDValue(pdValue);
    }


    public void enterInputRightAxis(String rightAxis) {
        setText(this.inputRightAxis, rightAxis);
    }

    public void enterInputLeftAxis(String leftAxis) {
        setText(this.inputLeftAxis, leftAxis);
    }

    public void enterInputPDValue(String pdValue) {
        setText(this.inputPDValue, pdValue);
    }

    public void clickConsentCheckbox() {
        waitFor(WebElementExpectations.elementIsDisplayed(consentCheckbox));
        moveTo("section#main span.ss-icon");
        clickElement(consentCheckbox);
//        clickElement(consentCheckbox);
    }

    public void clickNextButton() {
        clickElement(nextButton);
    }

    public void enterInputDay(String day) {
        setText(this.inputDay, day);
    }

    public void enterInputMonth(String month) {
        setText(this.inputMonth, month);
    }

    public void enterInputYear(String year) {
        setText(this.inputYear, year);
    }

    public void waitForLensSelectorHeading() {
        waitFor(WebElementExpectations.elementIsDisplayed(lensSelectorHeading));
    }

    //2022.03.29 CL Added
    //Feature Flags & Region Specific Feature Rules
    public Boolean featureConfirmOriginalPrescriptionChecboxIsOn() {
        return testDataManager.getFeatureData("glassesPrescription.confirmOriginalPrescriptionCheckBox", Boolean.class);
    }

}
