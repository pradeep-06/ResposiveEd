package digital.eComm.ui.pages.checkout.invoice;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.extensions.util.eCommCurrencyHandler;
import digital.eComm.ui.extensions.util.eCommGSTCalculator;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class eCommOrderInvoicePage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommOrderInvoicePage.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    eCommGSTCalculator eCommGSTCalculator;
    eCommCurrencyHandler eCommCurrencyHandler;

    //Customer Information
    @FindBy(css = "div#block-system-main div.group-left > div > div > div > div > div > div > div.addressfield-container-inline.name-block > span.first_name")
    private WebElementFacade firstName;

    @FindBy(css = "div#block-system-main div.group-left > div > div > div > div > div > div > div.addressfield-container-inline.name-block > span.last_name")
    private WebElementFacade lastName;

    @FindBy(css = "div#block-system-main div.group-left > div > div > div > div > div > div > div.thoroughfare-block > span")
    private WebElementFacade addressLine1;

    @FindBy(css = "div#block-system-main div.group-left > div > div > div > div > div > div > div.locality-block > span")
    private WebElementFacade city;

    @FindBy(css = "div#block-system-main div.group-left > div > div > div > div > div > div > div.postal_code-block")
    private WebElementFacade postCode;

    //right Eye product locator - gb, ie
    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-line-item-label > div > span")
    private WebElementFacade rightEyeProductName;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-field-base-curve > div")
    private WebElementFacade rightEyeBaseCurve;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-field-diameter > div")
    private WebElementFacade rightEyeDiameter;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-field-power > div")
    private WebElementFacade rightEyePower;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-quantity > div")
    private WebElementFacade rightEyeQty;

    //left Eye product locator - gb, ie

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-line-item-label > div > span")
    private WebElementFacade leftEyeProductName;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-field-base-curve > div")
    private WebElementFacade leftEyeBaseCurve;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-field-diameter")
    private WebElementFacade leftEyeDiameter;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-field-power > div")
    private WebElementFacade leftEyePower;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-quantity")
    private WebElementFacade leftEyeQty;

    @FindBy(css = "div#block-system-main tr.component-type-commerce-price-formatted-amount > td:nth-child(2)")
    private WebElementFacade totalPayableAmount;

    @FindBy(css = "div#block-system-main tr.component-type-flat-rate-delivery > td:nth-child(2)")
    private WebElementFacade deliveryInformation;

    @FindBy(xpath = "//tr[@class='component-type-commerce-price-formatted-amount']//td[3]")
    private WebElementFacade gstAmount;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-commerce-total.views-align-right > div")
    private WebElementFacade rightEyeSubTotal;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-commerce-total.views-align-right > div")
    private WebElementFacade leftEyeSubTotal;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-commerce-total-3 > div")
    private WebElementFacade leftEyeTotal;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-commerce-total-3 > div")
    private WebElementFacade rightEyeTotal;

    @FindBy(css = "div#block-system-main tr.even.views-row-last > td.views-field.views-field-commerce-total-1.column-gray > div")
    private WebElementFacade leftGSTInclInTotal;

    @FindBy(css = "div#block-system-main tr.odd.views-row-first > td.views-field.views-field-commerce-total-1.column-gray > div")
    private WebElementFacade rightGSTInclInTotal;

    public void theUserConfirmProductInformationAndPayableAmount(String productAmount) {

        final String leftEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftEyeQty");
        final String rightEyeQty = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightEyeQty");
        final String leftBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftBaseCurve");
        final String rightBaseCurve = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightBaseCurve");
        final String leftSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.leftSphere");
        final String rightSphere = testDataManager.getTestInputRegionData("purchasing.contactLens.prescriptionData.rightSphere");

        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String addressLine1 = testDataManager.getTestInputRegionData("purchasing.checkout.address.addressLine1");
        final String postcode = testDataManager.getTestInputRegionData("purchasing.checkout.address.postcode");

        logger.info("the guest user start confirming order details along with the qty for {} region ", Staf.getTargetRegion());

        switchToChildWindow();
        assertElementContainsText(this.firstName, firstName);
        assertElementContainsText(this.lastName, lastName);
        assertElementText(this.addressLine1, addressLine1);
        assertElementText(this.postCode, postcode);

        assertElementText(this.leftEyeQty, leftEyeQty.concat(".00 boxes"));
        assertEquals(getTextOfElement(this.leftEyeBaseCurve), leftBaseCurve);
        assertEquals(getTextOfElement(this.leftEyePower), leftSphere);

        assertElementText(this.rightEyeQty, rightEyeQty.concat(".00 boxes"));
        assertEquals(getTextOfElement(this.rightEyeBaseCurve), rightBaseCurve);
        assertEquals(getTextOfElement(this.rightEyePower), rightSphere);

        assertElementText(this.totalPayableAmount, productAmount);

    }

    public void theUserConfirmGSTIncludedInTotal() {

        logger.info("the guest user start confirming GST and payable for {} region ", Staf.getTargetRegion());
        Integer productQty = null;

        final Double rightEyeQty = getProductBasePrice(this.rightEyeQty);
        final Double leftEyeQty = getProductBasePrice(this.leftEyeQty);

        productQty = (int) (rightEyeQty + leftEyeQty);

        logger.info("Product Quantity::{}", productQty);

        Double totalProductAmount = getProductBasePrice(rightEyeSubTotal) + getProductBasePrice(leftEyeSubTotal);

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));

        Double gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);

        logger.info("Total:: {}", df.format(totalProductAmount));
        logger.info("GST incl in total::{}", df.format(gstTotal));


        /*  GE-1586 - Removal of GST from shipping for Australia contact lens orders
        logger.info("Delivery Charges::{}", getProductBasePrice(deliveryInformation));
        Double deliveryAmount = eCommGSTCalculator.getGSTOnADeliveryAmount(getProductBasePrice(deliveryInformation));
        logger.info("Tax calculated on a delivery charges::{}", df.format(deliveryAmount));
        double amount = Math.abs(gstTotal)  + deliveryAmount;
        logger.info("You pay amount ::{}", df.format(amount));*/
       // final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(gstTotal);
        final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(gstTotal);

        withAction().moveToElement(this.gstAmount).build().perform();
        assertElementContainsText(this.gstAmount, df.format(gstTotal));

    }

    public void theUserConfirmDiscountedTaxIncludedInTotal() {

        logger.info("the guest user start confirming GST and payable for {} region ", Staf.getTargetRegion());
        Integer productQty = null;

        final Double rightEyeQty = getProductBasePrice(this.rightEyeQty);
        final Double leftEyeQty = getProductBasePrice(this.leftEyeQty);

        productQty = (int) (rightEyeQty + leftEyeQty);

        logger.info("Product Quantity::{}", productQty);

        Double subTotalProductAmount = getProductBasePrice(rightEyeSubTotal) + getProductBasePrice(leftEyeSubTotal);

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));

        Double gstSubTotal = eCommGSTCalculator.getGSTAmount(subTotalProductAmount, gstValue, productQty);

        logger.info("SubTotal:: {}", df.format(subTotalProductAmount));
        logger.info("GST incl in SubTotal ::{}", df.format(gstSubTotal));

        logger.info("Original line level price before {} discount was :: {} and that includes GST", gstValue, df.format(gstSubTotal));

        Double totalProductAmount = getProductBasePrice(leftEyeTotal) + getProductBasePrice(rightEyeTotal);
        Double gstTotalTax = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);

        logger.info("Total :: {}", df.format(totalProductAmount));
        logger.info("GST incl in Total :: {}", df.format(gstTotalTax));

        /* GE-1586 - Removal of GST from shipping for Australia contact lens orders
        logger.info("So total tax saved is the full price tax of :: {} minus the paid price tax of :: {} ", df.format(gstSubTotal), df.format(gstTotalTax));
        double taxSaved = gstTotalTax - gstSubTotal;
        logger.info("Total tax saved :: {}", df.format(taxSaved));
        withAction().moveToElement(this.gstAmount).build().perform();


        logger.info("Delivery Charges::{}", getProductBasePrice(deliveryInformation));
        Double deliveryAmount = eCommGSTCalculator.getGSTOnADeliveryAmount(getProductBasePrice(deliveryInformation));
        logger.info("Tax calculated on a delivery charges::{}", df.format(deliveryAmount));
        double amount = Math.abs(gstSubTotal) - Math.abs(taxSaved) + deliveryAmount;
        logger.info("You pay amount ::{}", df.format(amount));*/
        //  final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(gstTotalTax);

        assertElementContainsText(this.gstAmount, df.format(gstTotalTax));

        switchToOriginalWindow();

    }

    public void theUserConfirmGSTIncludedInTotalWithoutDeliveryCharges() {

        logger.info("the guest user start confirming GST and payable for {} region ", Staf.getTargetRegion());
        Integer productQty = null;

        final Double rightEyeQty = getProductBasePrice(this.rightEyeQty);
        final Double leftEyeQty = getProductBasePrice(this.leftEyeQty);

        productQty = (int) (rightEyeQty + leftEyeQty);

        logger.info("Product Quantity::{}", productQty);

        Double totalProductAmount = getProductBasePrice(rightEyeSubTotal) + getProductBasePrice(leftEyeSubTotal);

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));

        Double gstTotal = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);

        logger.info("Total:: {}", df.format(totalProductAmount));
        logger.info("GST incl in total::{}", df.format(gstTotal));
 //below lines are commented because it does not required to get the delivery charged (as per the method name)
 /*       logger.info("Delivery Charges::{}", getProductBasePrice(deliveryInformation));
        Double deliveryAmount = eCommGSTCalculator.getGSTOnADeliveryAmount(getProductBasePrice(deliveryInformation));
        logger.info("Tax calculated on a delivery charges::{}", df.format(deliveryAmount));
        double amount = Math.abs(gstTotal)  + deliveryAmount;
        logger.info("You pay amount ::{}", df.format(amount));
        // final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(gstTotal);
        final String gstIncludeInTotal = eCommCurrencyHandler.getRegionalCurrency(gstTotal);
*/
        withAction().moveToElement(this.gstAmount).build().perform();
        assertElementContainsText(this.gstAmount, df.format(gstTotal));
    }

    public void theUserConfirmOrderLevelDiscountedTaxIncludedInTotal() {

        logger.info("the guest user start confirming GST and payable for {} region ", Staf.getTargetRegion());
        Integer productQty = null;

        final Double rightEyeQty = getProductBasePrice(this.rightEyeQty);
        final Double leftEyeQty = getProductBasePrice(this.leftEyeQty);

        productQty = (int) (rightEyeQty + leftEyeQty);

        logger.info("Product Quantity::{}", productQty);

        Double subTotalProductAmount = getProductBasePrice(rightEyeSubTotal) + getProductBasePrice(leftEyeSubTotal);

        final DecimalFormat df = new DecimalFormat("0.00");
        final Double gstValue = Double.valueOf(testDataManager.getTestInputRegionData("purchasing.taxConfiguration.gstValue"));

        Double gstSubTotal = eCommGSTCalculator.getGSTAmount(subTotalProductAmount, gstValue, productQty);

        logger.info("SubTotal:: {}", df.format(subTotalProductAmount));
        logger.info("GST incl in SubTotal ::{}", df.format(gstSubTotal));

        logger.info("Original order level price before {} discount was :: {} and that includes GST", gstValue, df.format(gstSubTotal));

        Double totalProductAmount = getProductBasePrice(leftEyeTotal) + getProductBasePrice(rightEyeTotal);
        Double gstTotalTax = eCommGSTCalculator.getGSTAmount(totalProductAmount, gstValue, productQty);

        logger.info("Total :: {}", df.format(totalProductAmount));
        logger.info("GST incl in Total :: {}", df.format(gstTotalTax));
        Double gSTInclusivePrice=getProductBasePrice(rightGSTInclInTotal)+getProductBasePrice(leftGSTInclInTotal);

        assertEquals(df.format(gSTInclusivePrice), df.format(gstTotalTax));
        switchToOriginalWindow();
    }
}
