package digital.eComm.ui.steps;

import Framework.BaseObject.BasePageObject;
import Framework.DataManager.TestDataManager;
import Framework.Staf;
import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.Message;
import com.mailosaur.models.SearchCriteria;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class MailosaurEmailTesting extends BasePageObject {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(MailosaurEmailTesting.class);
    final String welcomeSubject = testDataManager.getTestInputRegionData("mailosaurValidation.welcomeSubject");
    final String orderConfirmationSubject = testDataManager.getTestInputRegionData("mailosaurValidation.orderConfirmationSubject");
    final String recipientEmail = testDataManager.getTestInputRegionData("mailosaurValidation.recipientEmail");
    final String localeValue = testDataManager.getTestInputRegionData("mailosaurValidation.localeValue");
    final String sentFromEmailAddress = testDataManager.getTestInputRegionData("mailosaurValidation.eCommSentFrom");
    final String trustPilotEmailAddress = testDataManager.getTestInputRegionData("mailosaurValidation.eCommTOTrustPilot");

    final String easyPayActiveSubject = testDataManager.getTestInputRegionData("mailosaurValidation.easyPayActiveSubject");
    final String freeShipping = testDataManager.getTestInputRegionData("mailosaurValidation.freeShipping");
    final String easypayActivationText = testDataManager.getTestInputRegionData("mailosaurValidation.easypayActivationText");
    final String subscriptionSubject = testDataManager.getTestInputRegionData("mailosaurValidation.subscriptionSubject");
    final String subscriptionText1 = testDataManager.getTestInputRegionData("mailosaurValidation.subscriptionText1");
    final String subscriptionText2 = testDataManager.getTestInputRegionData("mailosaurValidation.subscriptionText2");
    final String serverID = testDataManager.getTestInputCommonData("mailosaurInformation.serverID");
    final String apikey = testDataManager.getTestInputCommonData("mailosaurInformation.apiKey");
    final String welcomeSubjectESEN = "Specsavers Book Appointment (Adult sight test)";
    final String subscriptionText1ES = "Mr Agnes Sanchez";
    final String subscriptionText2ES = "espagna@specsaver.co.uk";
    final String subscriptionText3ES = "Opticians";
    final String sentFromEmailAddressES = "customerservice@specsavers.com";
    MailosaurClient mailosaur = new MailosaurClient(apikey);
    SearchCriteria criteria = new SearchCriteria();

    public void checkWelcomeEmail(String emailAddress)  {
        logger.info("********* Welcome to Specsavers Email ******************");
        criteria.withSentFrom(sentFromEmailAddress).withBody(": " + emailAddress);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        logger.info("Subject Value:: " + message.subject());
        logger.info("Subject Validation :: " + message.subject().contains(welcomeSubject));
        assertText(message.subject().contains(welcomeSubject));
        logger.info("TO Email : " + message.to().get(0).email());
        logger.info("TO Email Validation: " + message.to().get(0).email().contains(emailAddress));
        assertText(message.to().get(0).email().contains(emailAddress));
    }

    public void checkPasswordResetEmail(String emailAddress)  {
        logger.info("********* Copy the password reset URL from the Email ******************");
        waitABit(20000);
        criteria.withSentFrom(sentFromEmailAddress).withSentTo(emailAddress);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        String url = String.valueOf(message.html().links().get(0).href());
        logger.info("STEP: user navigate to reset password URL " + "-" +url);
        getDriver().navigate().to(url);
    }

    public void checkOrderConfirmationEmail(String emailAddress, String orderNo, String cost)  {
        logger.info("********* For Order Confirmation Email ******************");

        criteria.withSentFrom(sentFromEmailAddress).withBody(orderNo);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        if(message.subject().contains(orderConfirmationSubject))
        {   logger.info("Subject Value:: " + message.subject());
            logger.info("Subject Validation :: " + message.subject().contains(orderConfirmationSubject));
            assertText(message.subject().contains(orderConfirmationSubject));
        }
        else if(Staf.getTargetRegion().equals("se")||Staf.getTargetRegion().equals("nl")) {
            final String orderConfirmationSubject2 = testDataManager.getTestInputRegionData("mailosaurValidation.orderConfirmationSubject2");
            logger.info("Subject Value:: " + message.subject());
            logger.info("Subject Validation :: " + message.subject().contains(orderConfirmationSubject2));
            assertText(message.subject().contains(orderConfirmationSubject2));
        }
        else
            Assert.fail("Expected was : " + orderConfirmationSubject + "and Actual was: "+message.subject());

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains(emailAddress));
        assertText(message.to().get(0).email().contains(emailAddress));

        logger.info("Order No Validation :: " + message.html().body().contains(orderNo));
        assertText(message.html().body().contains(orderNo));

        logger.info("Cost for email --  :" + cost);
        logger.info("Cost Validation :: " + message.html().body().contains(cost));
        assertText(message.html().body().contains(cost));
    }

    public void checkOrderConfirmationEmail2(String emailAddress, String orderNo, String cost)  {
        logger.info("********* FOR Order Confirmation Email ******************");

        criteria.withSentFrom(sentFromEmailAddress).withBody(orderNo);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        if(message.subject().contains(orderConfirmationSubject))
        {   logger.info("Subject Value:: " + message.subject());
            logger.info("Subject Validation :: " + message.subject().contains(orderConfirmationSubject));
            assertText(message.subject().contains(orderConfirmationSubject));
        }
        else if(Staf.getTargetRegion().equals("uk")) {
            final String orderConfirmationSubject2 = testDataManager.getTestInputRegionData("mailosaurValidation.orderConfirmationSubject2");
            logger.info("Subject Value:: " + message.subject());
            logger.info("Subject Validation :: " + message.subject().contains(orderConfirmationSubject2));
            assertText(message.subject().contains(orderConfirmationSubject2));
        }
        else
            Assert.fail("Expected was : " + orderConfirmationSubject + "and Actual was: "+message.subject());

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains(emailAddress));
        assertText(message.to().get(0).email().contains(emailAddress));

        logger.info("Order No Validation :: " + message.html().body().contains(orderNo));
        assertText(message.html().body().contains(orderNo));

        logger.info("Cost for email --  :" + cost);
        logger.info("Cost Validation :: " + message.html().body().contains(cost));
        assertText(message.html().body().contains(cost));
    }

    public void checkOrderReferenceEmail(String emailAddress,String orderNumber)  {
        logger.info("********* FOR Specsavers Order Email ******************");
        final String orderNo = orderNumber.substring(orderNumber.indexOf("_") + 1);
        criteria.withSentFrom(sentFromEmailAddress).withBody("\""+emailAddress);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        logger.info("Subject Value:: " + message.subject());
        logger.info("Subject Validation :: " + message.subject().contains(orderNo));
        assertText(message.subject().contains(orderNo));

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains(trustPilotEmailAddress));
        assertText(message.to().get(0).email().contains(trustPilotEmailAddress));

        logger.info("Text - RecipientEmail - from Email  :: " + message.text().body().contains(recipientEmail));
        assertText(message.text().body().contains(recipientEmail));

        logger.info("RecipientEmail Validation :: " + message.text().body().contains(emailAddress));
        assertText(message.text().body().contains(emailAddress));

        logger.info("locale :: " + localeValue + "  ::" + message.text().body().contains(localeValue));
        assertText(message.text().body().contains(localeValue));
    }

    public void checkEasyPayActivationEmail(String emailAddress, String cost) {
        logger.info("********* FOR EasyPay Activation Email ******************");
        criteria.withSentFrom(sentFromEmailAddress).withBody(easypayActivationText);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        logger.info("Subject Value:: " + message.subject());
        logger.info("Subject Validation :: " + message.subject().contains(easyPayActiveSubject));
        assertText(message.subject().contains(easyPayActiveSubject));

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains(emailAddress));
        assertText(message.to().get(0).email().contains(emailAddress));

        logger.info("Delivery Value  :: " + freeShipping);
        logger.info("Delivery Validation  :: " + message.html().body().contains(freeShipping));
        assertText(message.html().body().contains(freeShipping));

        logger.info("Easypay ActivationText Value  :: " + easypayActivationText);
        logger.info("Easypay ActivationText Validation  :: " + message.html().body().contains(easypayActivationText));
        assertText(message.html().body().contains(easypayActivationText));

        logger.info("Cost from email --  :" + cost);
        logger.info("Cost Validation :: " + message.html().body().contains(cost));
        assertText(message.html().body().contains(cost));
    }

    public void checkSubscriptionEmail(String emailAddress, String orderNumber, String installment_cost) {
        logger.info("********* FOR Subscription Email ******************");
        criteria.withSentFrom(sentFromEmailAddress).withBody(subscriptionText2);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        logger.info("Subject Value:: " + message.subject());
        logger.info("Subject Validation :: " + message.subject().contains(subscriptionSubject));
        assertText(message.subject().contains(subscriptionSubject));

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains(emailAddress));
        assertText(message.to().get(0).email().contains(emailAddress));

        logger.info("Subscription Text Value1  :: " + subscriptionText1);
        logger.info("Subscription Text1 Validation  :: " + message.html().body().contains(subscriptionText1));
        assertText(message.html().body().contains(subscriptionText1));

        logger.info("Subscription Text Value2 :: " + subscriptionText2);
        logger.info("subscription Text2 Validation  :: " + message.html().body().contains(subscriptionText2));
        assertText(message.html().body().contains(subscriptionText2));

        if(!(Staf.getTargetRegion().equals("fi")||Staf.getTargetRegion().equals("se"))) {
            logger.info("Order Number Value  :: " + orderNumber);
            logger.info("Order Number Validation  :: " + message.html().body().contains(orderNumber));
            assertText(message.html().body().contains(orderNumber));

            logger.info("Installment Cost from email --  :" + installment_cost);
            logger.info("Installment Cost Validation :: " + message.html().body().contains(installment_cost));
            assertText(message.html().body().contains(installment_cost));
        }
    }

    public void checkSpanishBookingEmail(String emailAddress)  {
        logger.info("********* Welcome to Specsavers Email ******************");
        criteria.withSentFrom(sentFromEmailAddressES).withBody(subscriptionText1ES);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }
        logger.info("Subject Value:: " + message.subject());
        logger.info("Subject Validation :: " + message.subject().contains(welcomeSubjectESEN));
        assertText(message.subject().contains(welcomeSubjectESEN));

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains("Support.Specsavers@bjss.com"));
        assertText(message.to().get(0).email().contains("Support.Specsavers@bjss.com"));

        logger.info("Subscription Text Value1  :: " + subscriptionText1ES);
        logger.info("Subscription Text1 Validation  :: " + message.html().body().contains(subscriptionText1ES));
        assertText(message.html().body().contains(subscriptionText1ES));

        logger.info("Subscription Text Value1  :: " + subscriptionText2ES);
        logger.info("Subscription Text1 Validation  :: " + message.html().body().contains(subscriptionText2ES));
        assertText(message.html().body().contains(subscriptionText2ES));

        logger.info("Subscription Text Value1  :: " + subscriptionText3ES);
        logger.info("Subscription Text1 Validation  :: " + message.html().body().contains(subscriptionText3ES));
        assertText(message.html().body().contains(subscriptionText3ES));
    }

    public void checkOrderConfirmationEmail4(String emailAddress, String orderNo, String cost)  {
        logger.info("********* FOR Order Confirmation Email ******************");

        criteria.withSentFrom(sentFromEmailAddress).withBody(orderNo);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverID, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }

        if(message.subject().contains(orderConfirmationSubject))
        {   logger.info("Subject Value:: " + message.subject());
            logger.info("Subject Validation :: " + message.subject().contains(orderConfirmationSubject));
            assertText(message.subject().contains(orderConfirmationSubject));
        }
        else if(Staf.getTargetRegion().equals("se")||Staf.getTargetRegion().equals("nl")||Staf.getTargetRegion().equals("uk")) {
            final String orderConfirmationSubject2 = testDataManager.getTestInputRegionData("mailosaurValidation.orderConfirmationSubject2");
            logger.info("Subject Value:: " + message.subject());
            logger.info("Subject Validation :: " + message.subject().contains(orderConfirmationSubject2));
            assertText(message.subject().contains(orderConfirmationSubject2));
        }
        else
            Assert.fail("Expected was : " + orderConfirmationSubject + "and Actual was: "+message.subject());

        logger.info("TO Email Value  :: " + message.to().get(0).email());
        logger.info("TO Email Validation  :: " + message.to().get(0).email().contains(emailAddress));
        assertText(message.to().get(0).email().contains(emailAddress));

        logger.info("Order No Validation :: " + message.html().body().contains(orderNo));
        assertText(message.html().body().contains(orderNo));

        logger.info("Cost for email --  :" + cost);
        logger.info("Cost Validation :: " + message.html().body().contains(cost));
        assertText(message.html().body().contains(cost));
    }
}