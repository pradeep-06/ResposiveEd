package digital.eComm.ui.pages.drupal.worldpay;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommSavedMessagePage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommSavedMessagePage.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css = "div#block-system-main tr:nth-child(2) > td:nth-child(4) > div > ul > li:nth-child(2) > code")
    public WebElementFacade worldPaySavedCardXmlMessage;


    public void assertStoreCredentialDetails() {

        assertElementContainsText(this.worldPaySavedCardXmlMessage,
                testDataManager.getTestAssertionData("worldPayStoredCredentials.worldPaySavedMessage"));
        assertElementContainsText(this.worldPaySavedCardXmlMessage,
                testDataManager.getTestAssertionData("worldPayStoredCredentials.worldPaySavedCardMerchantCode"));
        logger.info("the user confirmed store credentials XML details for the saved card ::");

    }
}
