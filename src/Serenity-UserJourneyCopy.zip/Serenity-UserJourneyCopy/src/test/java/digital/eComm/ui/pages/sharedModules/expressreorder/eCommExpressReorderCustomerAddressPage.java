package digital.eComm.ui.pages.sharedModules.expressreorder;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.LensExpressReorder;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommExpressReorderCustomerAddressPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(LensExpressReorder.class);
    protected final TestDataManager testDataManager = new TestDataManager();


    @FindBy(css = "div#edit-details-delivery-address-body > a")
    public WebElementFacade XroaddAddressButton;

    @FindBy(css = " #edit-commerce-customer-address-und-0-thoroughfare")
    public WebElementFacade XroAddressline1;

    @FindBy(css = "#edit-commerce-customer-address-und-0-locality")
    private WebElementFacade Xrocity;

    @FindBy(css = "#edit-commerce-customer-address-und-0-administrative-area")
    private WebElementFacade xrostate;

    @FindBy(css = "#edit-commerce-customer-address-und-0-postal-code")
    private WebElementFacade xropostCode;

    @FindBy(css = "#edit-submit")
    public WebElementFacade XroAddressSave;

    @FindBy(css = "#edit-commerce-customer-address-und-0-name-line")
    private WebElementFacade XrouserTitle;

    @FindBy(css = "#edit-commerce-customer-address-und-0-first-name")
    public WebElementFacade XrouserFirstName;

    @FindBy(css = "#edit-commerce-customer-address-und-0-last-name")
    public WebElementFacade XrouserLastName;


    public void xroAddaNewAddress() {
        clickElement(this.XroaddAddressButton);
    }

    public void XroAddressLine1(String addressLineText) {
        clickElement(this.XroAddressline1);
        setText(this.XroAddressline1, addressLineText);
    }

    public void XroenterCity(String city) {
        setText(this.Xrocity, city);
    }

    public void xroenterPostCode(String postCode) {
        setText(this.xropostCode, postCode);
    }

    public void xroselectState(String regionalData) {
        selectFromDropdown(this.xrostate, regionalData);
    }

    public void XroSaveAddress() {
        clickElement(this.XroAddressSave);
    }

    public void selectXroUserTitle(String title) {
        selectOptionFromDropdown(this.XrouserTitle, title);
    }

    public void enterXroUserFirstName(String firstName) {
        setText(this.XrouserFirstName, firstName);
    }

    public void enterXroUserLastName(String lastName) {
        setText(this.XrouserLastName, lastName);
    }


}
