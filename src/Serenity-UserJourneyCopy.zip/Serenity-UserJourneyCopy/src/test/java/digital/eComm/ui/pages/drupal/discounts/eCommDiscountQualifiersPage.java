package digital.eComm.ui.pages.drupal.discounts;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import digital.eComm.ui.pages.eCommHomePage;

import java.util.List;

public class eCommDiscountQualifiersPage extends eCommBase {

    @FindBy(css = "div#commerce-discount-fields-wrapper li.horizontal-tab-button.horizontal-tab-button")
    private List<WebElement> horizontalTabs;

    @FindBy(css = "div#commerce-discount-fields-wrapper fieldset:nth-child(2) > div > div > div > ul > li.vertical-tab-button")
    private List<WebElement> verticalTabs;

    @FindBy(xpath = "//*[@id=\"edit-de-discount-fields-field-qualifier-para-und-0-field-q-product-type-und\"]//label")
    private List<WebElement> productType;

    @FindBy(id = "edit-de-discount-fields-field-qualifier-para-und-0-field-q-line-target-attribute-und")
    private WebElementFacade attributeToTarget;

    @FindBy(css = "#edit-de-discount-fields-field-qualifier-para-und-0-field-q-line-target-attribute-v-und-0-value")
    private WebElementFacade discountAttributeValue;

    @FindBy(id = "edit-de-discount-fields-field-q-coupon-coupon-batch-und-0-target-id")
    private WebElementFacade inputCouponCode;

    @FindBy(xpath = "//div[@id='edit-de-discount-fields-field-q-coll-line-und-0-field-q-product-type']//div//label")
    private List<WebElement> orderType;

    @FindBy(id = "edit-de-discount-fields-field-q-order-type-und-all")
    private WebElementFacade orderTypeAllCheckBox;

    @FindBy(xpath = "//*[@id=\'edit-de-discount-fields-field-qualifier-para-und-add-more-add-more-bundle-discount-qualifier\']")
    private WebElementFacade addDiscountQualifierBtn;

    @FindBy(css = "#edit-de-discount-fields-field-qualifier-para-und-add-more-add-more-bundle-discount-qualifier")
    private WebElementFacade addOrderLevelQualifierBtn;

    eCommHomePage eCommHomePage;

    private final Logger logger = LoggerFactory.getLogger(eCommDiscountQualifiersPage.class);

    public void addOrderLevelQualifiersDetails() {
        logger.info("The user add qualifier details");
        TestDataManager testDataManager = new TestDataManager();
        selectTab(horizontalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.tabHeader"));
        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.verticalTab.couponTabOption"));
        setText(inputCouponCode, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.coupon.code"));
        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.verticalTab.orderTabOption"));

        if (!orderTypeAllCheckBox.isSelected()) {
            clickElement(orderTypeAllCheckBox);
        }

        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.verticalTab.lineItemTabOption"));
        clickElement(addOrderLevelQualifierBtn);
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.lineProduct.productType.default"));
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.lineProduct.productType.target"));
        selectFromDropdown(attributeToTarget, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.lineProduct.attributeToTarget"));
        setText(discountAttributeValue, testDataManager.getTestInputRegionData("drupal.discount.orderLevel.qualifiers.lineProduct.attributeValue"));

    }

    public void addLineLevelQualifiersDetails() {
        logger.info("The user add qualifier details");
        TestDataManager testDataManager = new TestDataManager();
        selectTab(horizontalTabs, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.qualifiers.tabHeader"));
        selectTab(verticalTabs, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.qualifiers.verticalTab.lineItemTabOption"));
        clickElement(addDiscountQualifierBtn);
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.qualifiers.lineProduct.productType.default"));
        selectTab(productType, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.qualifiers.lineProduct.productType.target"));

        selectDropDownItemByVisibleText(attributeToTarget,testDataManager.getTestInputRegionData("drupal.discount.lineLevel.qualifiers.lineProduct.attributeToTarget"));
        setText(discountAttributeValue, testDataManager.getTestInputRegionData("drupal.discount.lineLevel.qualifiers.lineProduct.attributeValue"));

    }
}
