package digital.eComm.ui.pages.contactlens;

import Framework.BaseObject.PageAssertions;
import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommContactLensLandingPage extends eCommBase implements PageAssertions {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    eCommContactLensProductDetailedPage eCommContactLensProductDetailedPage;

    @FindBy(xpath = "//ul[contains(@class,'brand')]")
    private WebElementFacade brandFilterLink;

    @FindBy(xpath = "//ul[contains(@class,'brand')]//label[contains(text(),'vue')]")
    private WebElementFacade brandFilterAcuvue;

    @FindBy(xpath = "(//div[contains(@class,'ss-plp-contact-lenses__container--contact-lenses product-details')])[1]")
    private WebElementFacade firstProductListed;

    @FindBy(xpath = "(//div[contains(@class,'ss-plp-contact-lenses__container--contact-lenses product-details')])[1]//div[contains(@class,'title')]")
    private WebElementFacade firstProductListedText;

    public void filterByBrand(String brand) {
        clickElement(brandFilterLink);
        //clickOnDynamicLabel(brand);
    }

    public WebElementFacade getFirstProductListed(){
        return firstProductListed;
    }

    public void selectFirstProductListed() {
        String firstListingSku = getSkuOfFirstProductListed(); //Get product ID of the first product as this will be used to later validate the correct product page is displayed
        firstProductListed.click();
        logger.info("VALIDATE: Check that the sku against the first item listed matches on the product page selected");
        assertElementContainsTextInAttribute(eCommContactLensProductDetailedPage.getProductImage(), "src", firstListingSku);

    }


    public WebElementFacade getFirstProductListedTextElement() {
        return firstProductListedText;
    }


    public String getSkuOfFirstProductListed() {
        return getElementInnerHTML(getFirstProductListed(),"data-contact-lenses-plu");
    }


    public void clickOnCommonBrand(String userRole) {
        String brand = testDataManager.getTestInputRegionData("purchasing.contactLens" + userRole + ".filterPreferences.brand");
        String brandDomText = brand.toLowerCase();
        logger.info("Clicking on common brand: " + brand);
        clickOnDynamicLinkViaAttribute("trackaid", "menus-" + brandDomText);
        logger.info("VALIDATE: Check first product listed is of brand: " + brand);
        assertElementContainsText(firstProductListed, brand);

    }



}
