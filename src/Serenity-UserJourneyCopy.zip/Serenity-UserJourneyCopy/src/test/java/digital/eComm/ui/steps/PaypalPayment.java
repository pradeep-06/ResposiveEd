package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.checkout.paypal.eCommPaypalCheckoutPage;
import digital.eComm.ui.pages.checkout.paypal.eCommPaypalDetailsPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaypalPayment extends ScenarioSteps {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(PaypalPayment.class);

    eCommPaypalDetailsPage eCommPaypalDetails;
    eCommPaypalCheckoutPage eCommPaypalCheckoutPage;

    public void theUserEnterPaypalDetails() {
        eCommPaypalDetails.theUserLoginWithPapalAccount();
        eCommPaypalCheckoutPage.theUserConfirmThePayment();

    }
}
