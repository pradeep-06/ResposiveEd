package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.drupal.eCommDrupalHomePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import digital.eComm.ui.pages.eCommHomePage;

public class DrupalHome extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(DrupalHome.class);
    protected TestDataManager testDataManager = new TestDataManager();

    eCommDrupalHomePage eCommDrupalHomePage;
    eCommHomePage eCommHomePage;

    public void theUserNavigateThroughMenu(String menu, String subMenu) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommDrupalHomePage.theUserSelectsRecentLogMessage(menu, subMenu);
    }

    public void theAdminUserSelectsLogoutLink() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommDrupalHomePage.theAdminUserSelectsLogoutLink();
    }
    
    public void theUserSearchTheOderID(String orderId){eCommDrupalHomePage.searchTheOrder(orderId);}

    public void theUserSelectsTheWalletandEnsureDeleteButtonIsDisable(){eCommDrupalHomePage.ensureDeleteButtonIsDisable();}
}
