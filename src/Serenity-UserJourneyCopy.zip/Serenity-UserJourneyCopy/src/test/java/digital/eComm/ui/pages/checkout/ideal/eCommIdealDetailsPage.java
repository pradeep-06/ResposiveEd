package digital.eComm.ui.pages.checkout.ideal;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommIdealDetailsPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommIdealDetailsPage.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(id = "idealIssuer")
    private WebElementFacade idealIssuerDropdown;

    @FindBy(id = "submitButton")
    private WebElementFacade submitButton;

    public void selectBank() {
        logger.info("the User selected iDeal Simulator bank option");
        idealIssuerDropdown.selectByVisibleText(testDataManager.getTestInputCommonData("iDealDetails.bankName"));
        clickElement(submitButton);
    }
}
