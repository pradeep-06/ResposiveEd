package digital.eComm.ui.pages;

import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.checkout.eCommCustomerDetailsPage;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommBasketPage extends eCommBase {

    eCommCustomerDetailsPage eCommCustomerDetailsPage;

    private String amount = null;
    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);

    @FindBy(css = "select#edit-frequency")
    private WebElementFacade selectFrequency;

    @FindBy(css = "div#block-system-main div.panel-pane.pane-commerce-cart-order-checkout > a")
    private WebElementFacade checkoutSecurelyButton;

    @FindBy(css = "div#block-system-main div.health-fund-options > label:nth-child(1) > span")
    private WebElementFacade healthFundAvailableButton;

    @FindBy(css = "div#block-system-main div.health-fund-options > label:nth-child(2) > span")
    private WebElementFacade healthFundNotAvailableButton;

    @FindBy(xpath = "//button[contains(text(),'Select health fund')]")
    private WebElementFacade selectHealthFundButton;

    @FindBy(id = "healthfunds-provider-list")
    private WebElementFacade healthfundsList;

    @FindBy(id = "healthfunds-policy-list")
    private WebElementFacade healthfundPolicy;

    @FindBy(xpath = " //button[contains(text(),'Continue')]")
    private WebElementFacade continueButton;

    @FindBy(css = "div#block-system-main label > span")
    private WebElementFacade selectPromocode;

    @FindBy(xpath = "//*[@id=\"edit-de-coupon-coupon-code\"]")
    private WebElementFacade applyPromocode;

    @FindBy(id = "edit-de-coupon-redeem")
    private WebElementFacade enterPromocode;

    @FindBy(xpath = "//*[@id=\"messages-help-wrapper\"]/div")
    private WebElementFacade promoCodeMsg;

    @FindBy(xpath = "//h1[@id='page-title']")
    private WebElementFacade nonEmptyBasketTitle;

    @FindBy(css = "div#block-system-main span.discount-title")
    private WebElementFacade discountTitle;

    @FindBy(css = "div.line.additional-discounts span.discount-title")
    private WebElementFacade discountTitle2for1;

    @FindBy(css = "div#block-system-main li:nth-child(2) > span.discount-title")
    private WebElementFacade discountName;

    @FindBy(css = "div#block-system-main div.commerce-cart-order-savings.panel.panel-body.panel-default > ul > li > a")
    private WebElementFacade discountPanel;

    @FindBy(css = " div#block-system-main div.panel-pane.pane-commerce-cart-order-summary-tl > div > div > div > div > span.value")
    private WebElementFacade payableAmount;

    @FindBy(css = "div#block-system-main div.product-summary.clearfix > div > div#cl-product-info > a > h3")
    private WebElementFacade productName;

    @FindBy(xpath = "//*[@id=\"header\"]/div[2]/nav/div[1]/ul[2]/li[2]/a/span")
    public WebElementFacade glassesPageButton;

    @FindBy(css = "header#header ul.ss-nav__right-col > li:nth-child(2) > a > span")
    public WebElementFacade searchMagnifierIcon;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1")
    public WebElementFacade product1PrescriptionDetailsButton;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1")
    public WebElementFacade product2PrescriptionDetailsButton;

    public void selectFrequency(String frequency) {
        selectFromDropdown(selectFrequency, frequency);
    }

    // Product 1 Prescription Details
    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-right > ul > li:nth-child(1) > span")
    public WebElementFacade product1_rightSphere;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-right > ul > li:nth-child(2) > span")
    public WebElementFacade product1_rightCylinder;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-right > ul > li:nth-child(3) > span")
    public WebElementFacade product1_rightAxis;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-left > ul > li:nth-child(1) > span")
    public WebElementFacade product1_leftSphere;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-left > ul > li:nth-child(2) > span")
    public WebElementFacade product1_leftCylinder;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-left > ul > li:nth-child(3) > span")
    public WebElementFacade product1_leftAxis;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div:nth-child(3) > span")
    public WebElementFacade product1_pupillaryDistance;

    @FindBy(css = "div#block-system-main div.views-row.views-row-1.views-row-odd.views-row-first > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div:nth-child(4) > span")
    public WebElementFacade product1_testDate;

    // Product 2 Prescription Details
    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-right > ul > li:nth-child(1) > span")
    public WebElementFacade product2_rightSphere;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-right > ul > li:nth-child(2) > span")
    public WebElementFacade product2_rightCylinder;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-right > ul > li:nth-child(3) > span")
    public WebElementFacade product2_rightAxis;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-left > ul > li:nth-child(1) > span")
    public WebElementFacade product2_leftSphere;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-left > ul > li:nth-child(2) > span")
    public WebElementFacade product2_leftCylinder;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div.prescription-left > ul > li:nth-child(3) > span")
    public WebElementFacade product2_leftAxis;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div:nth-child(3) > span")
    public WebElementFacade product2_pupillaryDistance;

    @FindBy(css = "div#block-system-main div.views-row.views-row-2.views-row-even.views-row-last > div > div.lens-selection-accordion > div.lens-selection-accordion__tab.row-1 > div > div > div:nth-child(4) > span")
    public WebElementFacade product2_testDate;

    @FindBy(css = "#edit-add-solutions-to-basket")
    public WebElementFacade solutionLiquidCTA;


    public void clickCheckoutSecurelyButton() {
        clickElement(checkoutSecurelyButton); // Updated bcoz observed issue with NZ subscription - Dipak
        logger.info("VALIDATE: Customer details page displayed");
    }

    public void clickHealthFundNotAvailableButton() {
        clickElement(healthFundNotAvailableButton);
    }

    public void clickSearchButton() {
        clickElement(searchMagnifierIcon);
    }

    public void clickSelectPromocode() {
        clickElementAndWaitForPresenceOf(selectPromocode, applyPromocode);
    }

    public void enterPromocode() {
        clickElement(enterPromocode);
        waitABit(5000);
    }

    public void applyPromocode(String promocode) {
        setText(this.applyPromocode, promocode);
    }

    public String promoCodeMsg() {
        return (promoCodeMsg.getText());
    }

    public void clickHealthFundAvailableButton() {
        clickElement(healthFundAvailableButton);
    }

    public void clickSelectHealthFundButton() {
        clickElement(selectHealthFundButton);
    }

    public void clickContinueButton() {
        clickElement(continueButton);
    }

    public void selectHealthfundsList(String healthFundName, String healthFundPolicyName) {

        selectFromDropdown(healthfundsList, healthFundName);
        selectFromDropdown(healthfundPolicy, healthFundPolicyName);
    }

    public WebElementFacade getNonEmptyBasketTitle() {
        return nonEmptyBasketTitle;
    }

    public void theUserConfirmsLineLevelDiscountAppliedToTheBasket(String discountText) {
//        if(Staf.getTargetRegion().equalsIgnoreCase("fi") || Staf.getTargetRegion().equalsIgnoreCase("no") )
//            assertElementContainsText(discountName, discountText);
//        else
            assertElementContainsText(discountTitle, discountText);
        //  assertElementContainsText(discountPanel,discountText);
    }

    public void theUserConfirmsLineLevelDiscount2for1AppliedToTheBasket(String discountText) {
        assertElementContainsText(discountTitle2for1, discountText);
    }

    public void theUserConfirmsPrescriptionDetailsOfGlasses1Match(String expectedRightSphere, String expectedRightCylinder, String expectedRightAxis,
                                                                  String expectedLeftSphere, String expectedLeftCylinder, String expectedLeftAxis,
                                                                  String expectedPupillaryDistance) {
        clickElement(product1PrescriptionDetailsButton);
        assertElementContainsText(product1_rightSphere, expectedRightSphere);
        assertElementContainsText(product1_rightCylinder, expectedRightCylinder);
        assertElementContainsText(product1_rightAxis, expectedRightAxis);
        assertElementContainsText(product1_leftSphere, expectedLeftSphere);
        assertElementContainsText(product1_leftCylinder, expectedLeftCylinder);
        assertElementContainsText(product1_leftAxis, expectedLeftAxis);
        assertElementContainsText(product1_pupillaryDistance, expectedPupillaryDistance);
    }

    public void theUserConfirmsPrescriptionDetailsOfGlasses2Match(String expectedRightSphere, String expectedRightCylinder, String expectedRightAxis,
                                                                  String expectedLeftSphere, String expectedLeftCylinder, String expectedLeftAxis,
                                                                  String expectedPupillaryDistance) {
        clickElement(product2PrescriptionDetailsButton);
        assertElementContainsText(product2_rightSphere, expectedRightSphere);
        assertElementContainsText(product2_rightCylinder, expectedRightCylinder);
        assertElementContainsText(product2_rightAxis, expectedRightAxis);
        assertElementContainsText(product2_leftSphere, expectedLeftSphere);
        assertElementContainsText(product2_leftCylinder, expectedLeftCylinder);
        assertElementContainsText(product2_leftAxis, expectedLeftAxis);
        assertElementContainsText(product2_pupillaryDistance, expectedPupillaryDistance);
    }

    public void theUserChecksProductInformationFromTheBasket(String productAmount) {

      /*  assertElementText(payableAmount, productAmount);
        logger.info("the user confirmed product payable amount on pdp page and basket page is matching");*/
        setAmount(getAndTrimText(payableAmount));
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String theUserRetrieveAmount() {
        return amount;
    }

    public void clickGlassesPage() {
        clickElement(glassesPageButton);
    }

    public void clickCheckoutButton() {
        clickElement(checkoutSecurelyButton);
    }

    public void clickOnAddSolutionCta() {
        clickElement(solutionLiquidCTA);
    }
}
