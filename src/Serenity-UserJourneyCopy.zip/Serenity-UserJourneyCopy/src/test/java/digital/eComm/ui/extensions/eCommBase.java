package digital.eComm.ui.extensions;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

public class eCommBase extends BasePageObject {

    private final Logger logger = LoggerFactory.getLogger(eCommBase.class);
    String parent;

public void selectOptionFromDropdown(WebElementFacade element, String text) {

        final String id = element.getAttribute("id").replaceAll("-button", "-menu");
        clickElement(element);
        WebElementFacade dropdownOption = $(By.xpath(String.format("//*[@id='%s']//*[contains(text(), '%s')]", id, text)));
        clickElement(dropdownOption);
        waitForLoadingIconTobeDisappear();
    }

    public String getElementText(WebElementFacade element) {

        String text = null;

        for (int i = 0; i <= 2; i++) {
            try {
                text = element.waitUntilVisible().getText().replaceAll("[^\\d_]", "").trim();
                break;
            } catch (NoSuchElementException | StaleElementReferenceException e) {
                logger.info(e.getMessage());
            }
        }
        return text;
    }

    public void selectTab(List<WebElement> webElementList, String text) {

        webElementList.stream()
                .filter((element) -> element.getText().contains(text))
                .findFirst()
                .ifPresent(element -> withAction().moveToElement(element).click().build().perform());
        logger.info("Tab selected: " + text);
    }

    public Boolean checkPresence(List<WebElement> webElementList, String text) {

        return !webElementList.stream()
                .filter((element) -> element.getText().contains(text))
                .findFirst()
                .isPresent();
    }

    public Double getProductBasePrice(WebElementFacade element) {

        Double text = null;

        for (int i = 0; i <= 2; i++) {
            try {
                element.waitUntilVisible();
                text = Double.valueOf(element.getText().replaceAll("[^0-9.,]", "").replaceAll(",", ".").trim());
                break;
            } catch (NoSuchElementException | StaleElementReferenceException e) {
                logger.info(e.getMessage());
            }
        }
        return text;
    }


    public String getTextOfElement(WebElementFacade element) {

        String text = null;

        for (int i = 0; i <= 2; i++) {
            try {
                text = element.waitUntilVisible().getText().replaceAll("[^\\d_.+-]", "").trim();
                break;
            } catch (NoSuchElementException | StaleElementReferenceException e) {
                logger.info(e.getMessage());
            }
        }
        return text;
    }

    public void scanIdCookies(String name, String value) {
        Cookie scanId= new Cookie(name, value);
        getDriver().manage().addCookie(scanId);
    }

    public void scanIdExpiryDate(String name, String value) {
        Cookie expDate= new Cookie(name, value);
        getDriver().manage().addCookie(expDate);
    }
    public void hideBannerStaticHeader(WebElement element){
        evaluateJavascript("arguments[0].style.display = 'none';", element);
    }
    public void hideBannerStaticFooter(WebElement element){
        evaluateJavascript("arguments[0].style.display = 'none';", element);
    }
    public void selectDropdown(WebElementFacade element) {
        clickElement(element);
    }

    public boolean compareWithTolerance(double expected, double actual, double tolerance) {
        double upperLimit = expected + tolerance;
        double lowerLimit = expected - tolerance;
        return actual >= lowerLimit && actual <= upperLimit;
    }
}