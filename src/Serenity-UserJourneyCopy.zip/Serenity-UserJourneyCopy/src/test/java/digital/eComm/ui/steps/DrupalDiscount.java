package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.drupal.discounts.coupons.eCommAddCouponPage;
import digital.eComm.ui.pages.drupal.discounts.coupons.eCommCouponTabPage;
import digital.eComm.ui.pages.drupal.discounts.coupons.eCommGenerateCouponPage;
import digital.eComm.ui.pages.drupal.discounts.*;
import digital.eComm.ui.pages.eCommHomePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DrupalDiscount extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(DrupalDiscount.class);
    protected  final TestDataManager testDataManager = new TestDataManager();

    eCommDiscountTabPage eCommDiscountTabPage;
    eCommCouponTabPage eCommCouponTabPage;
    eCommAddCouponPage eCommAddCouponPage;
    eCommGenerateCouponPage eCommGenerateCouponPage;
    eCommDiscountMessagePage eCommDiscountMessage;
    eCommDiscountQualifiersPage eCommDiscountQualifiers;
    eCommDiscountRewardsPage eCommDiscountRewards;
    eCommDiscountPromotionPage eCommDiscountPromotion;
    eComDeleteCodePage eComDeleteCodePage;
    eCommHomePage eCommHomePage;

    public void theUserConfirmAvailabilityOfDiscount() {

        final String discountName = testDataManager.getTestInputRegionData("drupal.discount.orderLevel.promoAdminTitle");
        logger.info("the user start checking of existing {} discount code", discountName);

        final Boolean flag = eCommDiscountTabPage.theUserCheckActiveDiscounts(discountName);

        if (!flag) {
            logger.info("{} :: discount code is available so deleting existing discount", discountName);
            eCommDiscountTabPage.selectActiveDiscountCode(discountName);
            eCommDiscountMessage.deleteDiscountCode();
            eComDeleteCodePage.theUserConfirmDiscountDeletion();
        }
        logger.info("{} :: discount code is not available so creating new one", discountName);
        eCommDiscountTabPage.theUserSelectAddDiscountLink();
        eCommDiscountMessage.addOrderLevelPromoCodeMessage();
        eCommDiscountQualifiers.addOrderLevelQualifiersDetails();
        eCommDiscountRewards.addOrderLevelRewardsDetails();
        eCommDiscountPromotion.theUserStartsPromotingOnProductPages().userSavedDiscount();
    }

    public void theUserConfirmAvailabilityOfCoupon() {

        final String couponCode = testDataManager.getTestInputRegionData("drupal.discount.orderLevel.coupon.code");
        final String redemptionNumber = testDataManager.getTestInputRegionData("drupal.discount.orderLevel.coupon.redemptionNumber");
        final String deleteCouponHeader = testDataManager.getTestAssertionData("deletedCouponMessage");

        logger.info("Coupon code ::{}", couponCode);
        final Boolean flag = eCommCouponTabPage.theUserCheckActiveCoupon(couponCode);

        if (!flag) {
            logger.info("Coupon code is already available::{}", couponCode);
            eCommCouponTabPage.deleteCouponCode(couponCode);
            eComDeleteCodePage.theUserConfirmCouponDeletion();
//            eCommCouponTabPage.assertCouponDeletionMessage(deleteCouponHeader);

        }
        logger.info("Coupon code is not available so creating new coupon ::{}", couponCode);
        eCommCouponTabPage.selectAddCouponLink();
        eCommAddCouponPage.theUserAddCouponTitle(couponCode);
        eCommGenerateCouponPage.theUserCreateAndSaveCouponCode(couponCode, redemptionNumber);
    }

    public void theUserConfirmAvailabilityOfLineLevelDiscount() {
        final String discountName = testDataManager.getTestInputRegionData("drupal.discount.lineLevel.promoAdminTitle");
        logger.info("the user start checking of existing {} discount code", discountName);

        final Boolean flag = eCommDiscountTabPage.theUserCheckActiveDiscounts(discountName);

        if (!flag) {
            logger.info("{} :: discount code is available so deleting existing discount", discountName);
            eCommHomePage.bannerStaticHeader();
            eCommHomePage.bannerStaticFooter();
            eCommDiscountTabPage.selectActiveDiscountCode(discountName);
            eCommDiscountMessage.deleteDiscountCode();
            eComDeleteCodePage.theUserConfirmDiscountDeletion();
        }
        logger.info("{} :: line level discount code is not available so creating new one", discountName);
        eCommDiscountTabPage.theUserSelectAddDiscountLink();
        eCommDiscountMessage.addLineLevelPromoCodeMessage();
        eCommDiscountQualifiers.addLineLevelQualifiersDetails();
        eCommDiscountRewards.addLineLevelRewardsDetails();
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommDiscountPromotion.theUserStartsPromotingOnProductPages().userSavedDiscount();

    }

    public void theUserConfirmUnavailabilityOfDiscount() {
        final String discountName = testDataManager.getTestInputRegionData("drupal.discount.lineLevel.promoAdminTitle");
        logger.info("the user start checking of existing {} discount code", discountName);

        final Boolean flag = eCommDiscountTabPage.theUserCheckActiveDiscounts(discountName);

        if (!flag) {
            logger.info("{} :: discount code is available so deleting existing discount", discountName);
            eCommHomePage.bannerStaticHeader();
            eCommHomePage.bannerStaticFooter();
            eCommDiscountTabPage.selectActiveDiscountCode(discountName);
            eCommDiscountMessage.deleteDiscountCode();
            eComDeleteCodePage.theUserConfirmDiscountDeletion();
        }

    }

    public void theUserConfirmUnavailabilityOfOrderLevelDiscount() {

        final String discountName = testDataManager.getTestInputRegionData("drupal.discount.orderLevel.promoAdminTitle");
        logger.info("the user start checking of existing {} discount code", discountName);

        final Boolean flag = eCommDiscountTabPage.theUserCheckActiveDiscounts(discountName);

        if (!flag) {
            logger.info("{} :: discount code is available so deleting existing discount", discountName);
            eCommDiscountTabPage.selectActiveDiscountCode(discountName);
            eCommDiscountMessage.deleteDiscountCode();
            eComDeleteCodePage.theUserConfirmDiscountDeletion();
        }

    }
}
