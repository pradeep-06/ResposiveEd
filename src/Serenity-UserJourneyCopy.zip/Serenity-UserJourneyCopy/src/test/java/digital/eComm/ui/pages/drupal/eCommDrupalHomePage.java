package digital.eComm.ui.pages.drupal;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class eCommDrupalHomePage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommDrupalHomePage.class);

    @FindBy(css = "ul#admin-menu-menu > li >a")
    private List<WebElement> drupalMenu;

    @FindBy(css = "ul[style*='display: block'] li")
    private List<WebElement> drupalSubMenu;

    @FindBy(css = "ul#admin-menu-account li:nth-child(1) > a")
    private WebElementFacade logout;

    @FindBy(css = "a[title='Cust/Order search']")
    private WebElementFacade orderSearchTab;

    @FindBy(css = "#edit-order-number")
    private WebElementFacade orderNumberInputBox;

    @FindBy(css = "#edit-search--2")
    private WebElementFacade search;

    @FindBy(css = ".customer-details-wallet")
    private WebElementFacade wallet;

    @FindBy(css = ".form-checkbox")
    private WebElementFacade deleteCheckBox;

    public void theUserSelectsRecentLogMessage(String menuName, String submenuName) {

        hoverMouseThroughMenu(drupalMenu, menuName);

        final String[] individualMenuItems = splitMenuOptions(submenuName);
        selectMenuOption(drupalSubMenu, individualMenuItems[0]);

        if (individualMenuItems.length > 1) {
            Arrays.stream(individualMenuItems).skip(1).forEach(
                    menuItem -> selectMenuOption(drupalSubMenu, menuItem)
            );
        }
        logger.info("Selected menu option: " + Arrays.toString(individualMenuItems));
    }

    private void hoverMouseThroughMenu(List<WebElement> webElementList, String menuItem) {

        webElementList.stream()
                .filter(element -> waitForCondition().until(ExpectedConditions.elementToBeClickable(element)).isDisplayed() &&
                        element.getText().equals(menuItem))
                .findFirst()
                .ifPresent(element -> withAction().moveToElement(element).build().perform());
    }

    private void selectMenuOption(List<WebElement> webElementList, String menuItem) {
        webElementList.stream()
                .filter((element) -> element.getText().contains(menuItem))
                .findFirst()
                .ifPresent(element -> withAction().moveToElement(element).click().build().perform());
        logger.info("Hover mouse pointer thought menu: " + menuItem);
    }

    private String[] splitMenuOptions(String menuOptions) {
        return menuOptions.split("[\\s]*>[\\s]*");
    }

    public void theAdminUserSelectsLogoutLink() {
        logger.info("Validate user select logout link ");
        clickElement(logout);
    }

    public void searchTheOrder(String orderID){
        clickElement(orderSearchTab);
        setText(this.orderNumberInputBox, orderID);
        clickElement(search);
    }

    public void ensureDeleteButtonIsDisable(){
        logger.info("Validate user select Wallet button");
        clickElement(wallet);
        logger.info("Validate delete check box has been greyed out");
        assertObjectIsNotInteractable(deleteCheckBox);
    }
}
