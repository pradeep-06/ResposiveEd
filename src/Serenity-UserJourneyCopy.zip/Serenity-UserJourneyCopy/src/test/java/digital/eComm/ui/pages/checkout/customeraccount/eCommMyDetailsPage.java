package digital.eComm.ui.pages.checkout.customeraccount;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommMyDetailsPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(xpath = "//div[contains(@class,'field-name-custom-email-address')]//div[contains(@class,'field-items')]")
    private WebElementFacade customerEmailAddress;


    public WebElementFacade getCustomerEmailAddress() {
        return this.customerEmailAddress;
    }

}
