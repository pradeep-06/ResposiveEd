package digital.eComm.ui.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.NavigateToeComm;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;

import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.Assert.*;

public class eCommProductSearchPage extends eCommBase {
    private final Logger logger = LoggerFactory.getLogger(NavigateToeComm.class);

    @FindBy(id = "search-box-locale")
    private WebElementFacade inputSearchBox;

    @FindBy(css = "#modal-search-input")
    private WebElementFacade inputSearchBoxAzure;

    @FindBy(xpath = "//*[@id=\"contactLenses-search-results\"]/div[3]/div/div[2]/ol/li/div/div[2]/div/h3/a|//*[@id=\"contactLenses-paged-results\"]/div[2]/ol/li/div/div[2]/div/h3/a")
    private WebElementFacade contactLensesProduct;

    @FindBy(xpath = "//*[@id=\"frames-search-results\"]/div[3]/div/div[2]/ol/li/div/div[2]/div/h3|//*[@id=\"main\"]/div[2]/div[2]/div[1]/div[2]/div[1]|//*[@id=\"frames-paged-results\"]/div[2]/ol/li/div/div[2]/div/h3")
    private WebElementFacade glassesProduct;

 //   @FindBy(xpath = "//*[@id=\"frames-search-results\"]/div[3]/div/div[2]/ol/li/div/div[2]/label|//span[contains(@class,'ss-checkbox-inline--favourite-select')]")
//    private WebElementFacade addToFavourite;

    @FindBy(xpath = "//*[@id=\"frames-paged-results\"]/div[2]/ol/li/div/div[2]/label")
    private WebElementFacade addToFavourite;

    @FindBy(css = "#header-topbar-favourites > div > svg > path")
    private WebElementFacade favouriteIcon;

    @FindBy(id = "fav-item-0-product-code")
    private WebElementFacade productcode;

    @FindBy(css = "div#Facets > ul.nav.navmenu-nav.frame_gender")
    private WebElementFacade ageAndGenderFilterButton;

    @FindBy(css = "#frame_gender > li > ul > li:nth-child(2) > div > label")
    private WebElementFacade maleFilter;

    @FindBy(css = "div#Facets > ul.nav.navmenu-nav.frame_type")
    private WebElementFacade typeFilterButton;

    @FindBy(css = "#frame_type > li > ul > li:nth-child(1) > div > label")
    private WebElementFacade opticalFilter;

    @FindBy(css = "#frame_type > li > ul > li:nth-child(2) > div > label")
    private WebElementFacade designerFilter;

    @FindBy(css = "div#Facets > ul.nav.navmenu-nav.available_online")
    private WebElementFacade availableOnlineFilterButton;

    @FindBy(css = "#available_online > li > ul > li > div > label")
    private WebElementFacade buyOnlineFilter;

    @FindBy(css = "div.initial-load > div:nth-child(10)")
    private WebElementFacade firstProductWithTryOn;

    @FindBy(css = "div.initial-load > div:nth-child(2),div.initial-load > div:nth-child(9)")
    private WebElementFacade secondProductWithTryOn;

    @FindBy(css = "div.initial-load > div:nth-child(8)")
    private WebElementFacade thirdProductWithTryOn;

    @FindBy(css = "#frames-search-results > div.container > div > div.ais-Hits.hits > ol > li:nth-child(5) > div > div.wrapper > button")
    public WebElementFacade vtoButton;

    @FindBy(xpath = "//*[@id='specs-modal_footer']/button[2]|//*[@id=\"specs-modal_body\"]/div[1]/div[2]/div/button")
    public WebElementFacade understoodButton;

    @FindBy(xpath = "//*[@id='specs-modal_footer']/button[2]")
    public WebElementFacade nextButton;

    @FindBy(xpath = "//*[@id='specs-modal_footer']/button[1]")
    public WebElementFacade previousButton;

    @FindBy(css = ".frame__image")
    public WebElementFacade frameImage;

    @FindBy(css = ".specs-vto-viewer")
    public WebElementFacade vtoViewerBanner;

    @FindBy(css = "[class='favourites-icon favourites-toggle']>span>i")
    public WebElementFacade favouritesIcon;

    @FindBy(xpath = "//*[@id=\"header\"]/div[2]/div[1]/div/div/div[3]/ul/li[2]/a/span")
    public WebElementFacade viewFavouritesButton;

    @FindBy(css = ".landing-content .landing-header, .landing-content .legal-header")
    public WebElementFacade modalHeader;

    @FindBy(css = "#specs-modal_header .specs-button-icon")
    public WebElementFacade modalControlIcon;

    @FindBy(css = "div > .landing-link")
    public WebElementFacade modalDataLink;

    @FindBy(css = ".legal-body .specs-link")
    public WebElementFacade modalPrivacyLink;

    @FindBy(css = ".ss-plp__button-panel")
    public WebElementFacade loadMoreButton;

    @FindBy(css = "[href*='hitsperpage=60']")
    public WebElementFacade pageSelector;

    @FindBy(css = "#top-section > section > div > div.card-grid.no-highlight-card > div > a:nth-child(1) > div > img")
    public WebElementFacade selectQuickFilter;

    @FindBy(css = "strong > a[href]")
    public WebElementFacade returnToFullSearch;

    @FindBy(css = "#frames-search-results > div.container > div > div.ais-Hits.hits > ol > li > div > div.images-wrapper")
    public WebElementFacade iframeGlass;

    @FindBy(xpath = "//a[contains(@class,'ss-top-bar__right-col-link ss-top-bar__espanol-btn')]")
    public WebElementFacade languageChangeBtn;

    @FindBy(xpath = "//a[contains(@class,'ss-nav__book-btn-desktop')]")
    public WebElementFacade appointmentBtn;

    @FindBy(xpath = "//a[contains(@class,'ss-top-bar__left-col-link ss-top-bar__store-btn find-a-store')]")
    public WebElementFacade findStoreBtn;

    @FindBy(xpath = "//*[@id=\"block-system-main\"]/div/div[1]/div/div[1]/div/div[2]/section/div/div/div")
    public WebElementFacade findAStoreText;

    @FindBy(xpath = "//*[@id=\"block-system-main\"]/div/div[1]/div/div[3]/div/section/div/div/div[1]/div[3]/div/div[3]/a")
    public WebElementFacade viewStoreBtn;

    @FindBy(xpath = "//span[contains(@class,'directions--store-directions__text')]")
    public WebElementFacade storePage;

    @FindBy(xpath = "//*[contains(@class, '__book-button--desktop')]|//*[contains(@class, 'btn btn-primary')]")
    private WebElementFacade v3_bookOnlineButton;

    @FindBy(css = "#appointment-type_tab-button-hearing")
    private WebElementFacade hearingServicesButton;

    @FindBy(css = "#specs-modal_header > button > svg > path")
    private WebElementFacade xbutton;

    @FindBy(xpath = "//*[@id=\"specs-appointment-type-hearing_test_triage_title\"]|//*[@id=\"specs-appointment-type-hearing_test_title\"]")
    private WebElementFacade hearingAppointment;

    @FindBy(xpath = "//*[@id=\"edit-your-details-wrapper-submit\"]")
    private WebElementFacade requestBtn;

    @FindBy(xpath = "//*[@id=\"frames-search-results\"]/div[3]/div/div[2]/ol/li/div/div[3]/button/div")
    private WebElementFacade vtoNew;

    @FindBy(css = "h2#specs-appointment-type-optics_title")
    private WebElementFacade opticsAppointment;

    private static final String requestBTN_DATA_En = "Request appointment";

    private static final String requestBTN_DATA_Es = "Pedir una cita";

    private static final String MODAL_LANDING_HEADER = "Welkom in de virtuele paskamer";

    private static final String MODAL_DATA_HEADER = "Hoe wij uw gegevens gebruiken";

    private static final String storeTextBTN_DATA_Es = "Encuentra una \u00F3ptica";

    private static final String storeTextBTN_DATA_En = "Find a store";

    private static final String storePageBTN_DATA_En = "Get directions";

    private static final String storePageBTN_DATA_Es = "C\u00F3mo llegar";

    protected final TestDataManager testDataManager = new TestDataManager();
    eCommHomePage eCommHomePage;

    public void enterInputSearchBox(String product) {
        setText(this.inputSearchBox, product);
        this.inputSearchBox.sendKeys(Keys.ENTER);
    }

    public void enterInputSearchBoxAzure(String product) {
        setText(this.inputSearchBoxAzure, product);
        this.inputSearchBoxAzure.sendKeys(Keys.ENTER);
    }

    public void clickOnContactLensesProduct() {
        clickElement(this.contactLensesProduct);
    }

    public void clickGlassesProduct() {
        clickElement(this.glassesProduct);
    }

    public void clickAddToFavourite() {
            moveTo("//*[@id=\"frames-paged-results\"]/div[2]/ol/li/div/div[2]/label");
            clickElement(this.addToFavourite);
    }
    public void clickOnFavouriteIcon() {
        moveTo("#header-topbar-favourites > div > svg > path");
        clickElement(this.favouriteIcon);
    }

    public String productCode() {
        return getElementText(productcode);
    }

    public void clickMaleAgeAndGenderFilterButton() {
        hoverMenuAndClickOption(ageAndGenderFilterButton, maleFilter);
    }

    public void clickOpticalTypeFilterButton() {
        hoverMenuAndClickOption(typeFilterButton, opticalFilter);
    }

    public void clickDesignerTypeFilterButton() {
        hoverMenuAndClickOption(typeFilterButton, designerFilter);
    }

    public void clickAvailableOnlineFilterButton() {
        hoverMenuAndClickOption(availableOnlineFilterButton, buyOnlineFilter);
    }

    public void clickProductWithTryOn() {
        if (Staf.getTargetRegion().equals("") || Staf.getTargetRegion().equals("nl")) {
            clickElement(thirdProductWithTryOn);
        } else if (Staf.getTargetRegion().equals("dk") || Staf.getTargetRegion().equals("no")) {
            clickElement(secondProductWithTryOn);
        } else {
            clickElement(firstProductWithTryOn);
        }
    }

    public void clickTryOnIcon() {
        this.clickLunaVtoIcon();
        clickElement(understoodButton);
        this.isScanDisplayed();
    }

    public void clickLunaVtoIcon() {
//        withAction().moveToElement(frameImage).perform();
        clickElement(vtoButton);
    }

    public void clickToNextFrame() {
        this.navigateToNextFrame();
    }

    public void clickToPreviousFrame() {
        this.navigateToPreviousFrame();
    }

    public void navigateToNextFrame() {
        clickElement(nextButton);
    }

    public void navigateToPreviousFrame() {
        if (previousButton.isDisplayed()) {
            clickElement(previousButton);
        } else {
            throw new NoSuchElementException("Could not find element: " + previousButton);
        }
    }

    public void isScanDisplayed() {
        clickElement(xbutton);
  //      assertPageObjectExists(vtoViewerBanner);
    }

    public void clickOnFavouritesIconDisplayedAtLeftSideOfPriceValue() {
        clickElement(this.favouritesIcon);
    }

    public void clickOnViewFavouritesButton() {
        clickElement(this.viewFavouritesButton);
    }

    public void onModalLanding() {
        assertPageObjectIsDisplayed(modalHeader);
        assertElementContainsText(modalHeader, MODAL_LANDING_HEADER);
    }

    public void goToHowWeUseDataInModal() {
        clickElement(modalDataLink);
        this.onModalHowToUseData();
    }

    public void onModalHowToUseData() {
        assertPageObjectIsDisplayed(modalHeader);
        assertElementContainsText(modalHeader, MODAL_DATA_HEADER);
    }

    public void openPrivacyPolicyPage() {
        clickElement(modalPrivacyLink);
        switchToChildWindow();
        clickAcceptOnCookies();
        assertTrue("Privacy page is not displayed", getDriver().getCurrentUrl().contains("privacybeleid"));
        switchToOriginalWindow();
    }

    public void closeLiveVTOModal() {
        clickElement(modalControlIcon);
        if (!modalControlIcon.isClickable()) {
            clickElement(modalControlIcon);
        }
    }

    public void filterByQuickFilter() {
        clickElement(selectQuickFilter);
        if (!returnToFullSearch.isVisible()) {
            getDriver().navigate().back();
        } else {
            clickElement(returnToFullSearch);
        }

    }

    public void loadMoreFrames() {
        clickElement(loadMoreButton);
    }

    public void selectPageSize() {
        clickElement(pageSelector);
    }

    public void openAndCloseVTOModal() {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        clickLunaVtoIcon();
        withAction().sendKeys(Keys.ESCAPE).perform();
    }

    public void openAndCloseVTOModalNoBanner() {
        clickLunaVtoIcon();
        withAction().sendKeys(Keys.ESCAPE).perform();
    }

    public void clickChangeLanguageButton() {
        clickElement(languageChangeBtn);
        clickAcceptOnCookies();
    }

    public void languageChanges() {
        if (Staf.getTargetRegion().equals("eses")) {
            assertPageObjectIsDisplayed(appointmentBtn);
            assertElementContainsText(appointmentBtn, requestBTN_DATA_En);
        } else if (Staf.getTargetRegion().equals("esen")) {
            assertPageObjectIsDisplayed(appointmentBtn);
            assertElementContainsText(appointmentBtn, requestBTN_DATA_Es);
        } else {
            throw new NoSuchElementException("Could not find element: " + appointmentBtn);
        }
    }

    public void clickFindStore() {
        clickElement(findStoreBtn);
        if (Staf.getTargetRegion().equals("eses")) {
            assertPageObjectIsDisplayed(findAStoreText);
            assertElementContainsText(findAStoreText, storeTextBTN_DATA_Es);
        } else if (Staf.getTargetRegion().equals("esen")) {
            assertPageObjectIsDisplayed(findAStoreText);
            assertElementContainsText(findAStoreText, storeTextBTN_DATA_En);
        } else {
            throw new NoSuchElementException("Could not find element: " + findAStoreText);
        }
    }

    public void clickViewStoreButton() {
        clickElement(viewStoreBtn);
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        if (Staf.getTargetRegion().equals("eses")) {
            assertPageObjectIsDisplayed(storePage);
            assertElementContainsText(storePage, storePageBTN_DATA_Es);
        } else if (Staf.getTargetRegion().equals("esen")) {
            assertPageObjectIsDisplayed(storePage);
            assertElementContainsText(storePage, storePageBTN_DATA_En);
        } else {
            throw new NoSuchElementException("Could not find element: " + storePage);
        }
    }

    public void v3_inputSASStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.sASStore1");
        logger.info("Searching for SAS Store : " + searchString);
        eCommHomePage.enterSearchLocation(searchString);
    }

    public void v3_clickFind() {
        logger.info("Click On find/search button");
        eCommHomePage.clickFindButton();
    }

    public void v4_VerifyFindAStoreLinkIsdisplayed() {
        eCommHomePage.v4_VerifyFindAStoreLinkIsDisplayed();
    }

    public void v3_bookOnlineInSelectedLocation() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_bookOnlineButton));
        clickElement(v3_bookOnlineButton);
    }

    public void enterRAFStoreNameAndClickOnSearchButton() {
        inputRAFStore(testDataManager.getTestInputRegionData("storeName.rAFStore1"));
        eCommHomePage.clickFindButton();
    }

    private void inputRAFStore(String searchString) {
        eCommHomePage.enterSearchLocation(searchString);
    }

    public void clickOnAppointment(String appointmentName) {
        logger.info("Select appointment type as " + appointmentName);
        if (Staf.getTargetRegion().equals(("nz"))) {
            eCommHomePage.switchToFrameForAppointments();
        }
        if (Staf.getTargetRegion().equals(("au"))) {
            eCommHomePage.clickRequestFormLink();
        }

        // eCommHomePage.SelectAppointmentTestAs(appointmentName);
    }

    public void verifyRequestAnAppointmentButtonIsDisplayed() {
        eCommHomePage.verifyRequestAnAppointmentButtonIsDisplayed();
    }

    public void SelectAppointmentTypeAs(String appointmentName) {
        logger.info("select appointment type : " + appointmentName);
        if (Staf.getTargetRegion().equals(("nz"))) {
            eCommHomePage.switchToFrameForAppointments();
        }
        eCommHomePage.v3_selectAppointmentTestAs(appointmentName);
    }

    public void clickBookASlotButton() {
        assertThat(eCommHomePage.cancelAndGoBannerTitleIsDisplayed());
    }

    public void clickHearingServices() {
        clickElement(this.hearingServicesButton);
    }

    public void clickHearingAppointment() {
        clickElement(this.hearingAppointment);
    }

    public void clickRafRequestAnAppointmentBtn(){
        eCommHomePage.requestAnAppointmentRafBtn();
    }

    public void clickOnAppointmentEs(String appointmentName) {
        logger.info("Select appointment type as " + appointmentName);
        eCommHomePage.EsSelectAppointmentTestAs(appointmentName);
    }

    public void inputRAFPersonalDetails(String dateAndTime, String title, String firstName, String lastName, String phoneNumber, String email) {
        eCommHomePage.bannerStaticHeader();
        eCommHomePage.bannerStaticFooter();
        eCommHomePage.inputAppointmentDateAndTime(dateAndTime);
        eCommHomePage.selectCustomerTitle(title);
        eCommHomePage.inputCustomerFirstName(firstName);
        eCommHomePage.inputCustomerLastName(lastName);
        eCommHomePage.inputCustomerMobile(phoneNumber);
        eCommHomePage.inputCustomerEmail(email);
        eCommHomePage.focusOnAnythingElseWeShouldKnow();
    }

    public void submitBtn() {
        logger.info("request button");
        clickElement(requestBtn);
    }

    public void clickVirtualTryOn() {
        moveTo("//*[@id=\"frames-search-results\"]/div[3]/div/div[2]/ol/li/div/div[3]/button/div");
        clickElement(this.vtoNew);
    }

    public void clickOnOptometryServices(String appointmentTypeName) {
        logger.info(" Select appointment type as {}", appointmentTypeName);
        clickElement(opticsAppointment);
    }
}