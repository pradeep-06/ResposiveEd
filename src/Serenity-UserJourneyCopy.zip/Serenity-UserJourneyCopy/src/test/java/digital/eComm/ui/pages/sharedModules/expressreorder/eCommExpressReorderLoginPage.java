package digital.eComm.ui.pages.sharedModules.expressreorder;

import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommExpressReorderLoginPage extends eCommBase {

    digital.eComm.ui.pages.checkout.eCommCustomerDetailsPage eCommCustomerDetailsPage;
    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);

    @FindBy(css = "#edit-name")
    public WebElementFacade XroUserName;

    @FindBy(css = "#edit-pass")
    public WebElementFacade XroUserPassword;

    @FindBy(css = "#edit-submit")
    public WebElementFacade XroUserLoginButton;

    @FindBy(css = ".reorder-text")
    public WebElementFacade XroLink;

}


