package digital.eComm.ui.pages.drupal.worldpay;

import digital.eComm.ui.extensions.eCommBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class eCommRecentLogPage extends eCommBase {

    private final Logger logger = LoggerFactory.getLogger(eCommRecentLogPage.class);

    @FindBy(id = "edit-message")
    private WebElementFacade inputMessageBox;

    @FindBy(id = "edit-submit-recent-log-messages-extended")
    private WebElementFacade applyButton;

    @FindBy(xpath = "//a[contains(.,'Sending')]")
    public WebElementFacade worldPayMessageLink;

    public void theUserEnteredOrderID(String orderNumber) {
        setText(this.inputMessageBox,orderNumber);
        clickElement(this.applyButton);
        clickElement(this.worldPayMessageLink);
    }
}
