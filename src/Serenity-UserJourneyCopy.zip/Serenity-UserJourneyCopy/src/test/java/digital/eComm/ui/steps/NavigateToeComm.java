package digital.eComm.ui.steps;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.eComm.ui.pages.eCommHomePage;
import digital.eComm.ui.pages.eCommLoginPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NavigateToeComm extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(NavigateToeComm.class);
    protected final TestDataManager testDataManager = new TestDataManager();

    eCommHomePage homePage;
    eCommLoginPage loginPage;

    public void theHomePage() {
        homePage.open();
        homePage.inititiateScanIdCookies();
    }

    public void theUserAcceptCookies() {
        logger.info("Starting accept cookies module");
    /*    Integer cookieModel = testDataManager.getFeatureData("models.cookieModel", Boolean.class);
        logger.info("cookie model = " + cookieModel);
        homePage.clickAcceptOnCookies(cookieModel);*/

        if (testDataManager.getFeatureData("models.cookieModel", Boolean.class)) {
            homePage.clickAcceptOnCookies();
            homePage.bannerStaticHeader();
            homePage.bannerStaticFooter();
        }
    }

    public NavigateToeComm theLoginHomePage() {
        loginPage.open();
        return this;
    }

    public void theAdminUserLoginWithCredentials() {
        String username = testDataManager.getTestInputCommonData("adminCredentials.userName");
        String password = testDataManager.getTestInputCommonData("adminCredentials.password");
        loginPage.enterCredentials(username, password);
    }

    public void theContactLensLandingPage() {
        logger.info("Clicking on contact lens link");
        homePage.clickOn(homePage.primaryNavLinkContactLenses);
        logger.info("Link clicked");
    }

    public void theSignInPage() {
        logger.info("Clicking on Sign in button");
        homePage.clickOn(homePage.signIn);
        logger.info("Sign in button clicked");
        if(Staf.getTargetRegion().equals("uk") || Staf.getTargetRegion().equals("ie"))
        {
            homePage.clickOn(homePage.onlineOrderLogin);
        }
    }

    public void navigateToAllGlassesPage() {
        homePage.allGlassesLink();
    }

    public void v3_UserClicksOnFinaAStoreLink() {
        homePage.clickOnFindAStore();
    }

    public void clickOnBookAppointmentButton() {
        logger.info("Click on Book Appointment button");
        homePage.clickOnBookAppointment();
    }

    public void clickOnFindAStoreButton() {
        logger.info("Click on Find a Store Button");
        homePage.clickOnFindAStore();
    }
}