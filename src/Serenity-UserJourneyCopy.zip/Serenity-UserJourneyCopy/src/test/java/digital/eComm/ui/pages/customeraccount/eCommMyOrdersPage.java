package digital.eComm.ui.pages.customeraccount;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.extensions.eCommBase;
import digital.eComm.ui.pages.checkout.customeraccount.eCommCustomerOrderPage;
import digital.eComm.ui.pages.checkout.eCommOrderConfirmationPage;
import digital.eComm.ui.steps.OrderCheckOut;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class eCommMyOrdersPage extends eCommBase {

    eCommCustomerOrderPage customerOrderPage;
    eCommOrderConfirmationPage eCommOrderConfirmationPage;
    private final Logger logger = LoggerFactory.getLogger(OrderCheckOut.class);
    protected final TestDataManager testDataManager = new TestDataManager();


    @FindBy(xpath = "(//div[contains(@class,'views-field-order-number')]//a)[1]")
    private WebElementFacade lastOrderNumber;

    @FindBy(css = "div#block-menu-block-4 li.collapsed > a")
    private WebElementFacade paymentCard;

    @FindBy(css = "header#header a > div")
    private WebElementFacade expressReorderLink;

    @FindBy(css="div[class='views-field views-field-order-number']>span:nth-child(2)>a")
    private List<WebElementFacade> orderNumbersList;

    public WebElementFacade getLastOrderNumber() {
        return this.lastOrderNumber;
    }

    public void clickOnLastOrder() {
        String orderNumber = getElementText(getLastOrderNumber());
        clickElement(lastOrderNumber);
        logger.info("VALIDATING order number on detailed order page matches " + orderNumber);
        assertElementContainsText(customerOrderPage.getOrderNumber(),orderNumber);
    }

    public void theUserSelectsPaymentCards() {
        logger.info("VALIDATING the user is on Orders page and selects payment card");
        clickElement(paymentCard);
    }

    public void selectExpressReorderLink() {
        clickElement(expressReorderLink);
    }

    public void verifyMoreThanOneOrderNumbersAreDisplayed(String orderNumber){
        eCommOrderConfirmationPage.clickMyAccountLink();
        eCommOrderConfirmationPage.clickMyOrderLink();

        Assertions.assertTrue(orderNumbersList.size()>1);

        logger.info("Order Numbers present in Order summary page are :");
        String text="";
        for(WebElementFacade element:orderNumbersList ){            ;
            logger.info("====>"+element.getText());
            text=text+element.getText();
        }

       Assertions.assertTrue(text.contains(orderNumber));
    }

}
