package digital.fabr.ui.pages.fabrPages;

import Framework.Staf;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class FabrRecapPage extends FabrBase {

    @FindBy(css = "a#continue-button")
    private WebElementFacade confirmAppointmentButton;

    @FindBy(css="#page-header")
    private WebElementFacade recapPageHeader;

    @FindBy(css = "p#recap-card-who_email,p#recap-card_recap-card-section-who_email")
    private WebElementFacade recapPageCustomerEmailAddress;

    @FindBy(css = "p#recap-card-who_phone-number,p#recap-card_recap-card-section-who_phone-number")
    private WebElementFacade recapPageCustomerMobileNumber;

    @FindBy(css = "h3#recap-card-who_full-name,h3#recap-card_recap-card-section-who_full-name")
    private WebElementFacade recapPageCustomerName;

    @FindBy(css = "a#recap-card_recap-card-section-where_change-link")
    private WebElementFacade changeStore;

    @FindBy(css = "a#recap-card_recap-card-section-what_change-link")
    private WebElementFacade changeAppointmentType;

    @FindBy(css = "a#recap-card_recap-card-section-when_change-link")
    private WebElementFacade changeDateAndTimeLink;

    @FindBy(id = "recap-card_recap-card-section-who_change-link")
    private WebElementFacade recapCardWhoChangeLink;

    @FindBy(xpath = "//span[@class=\"specs-stepper-label__step-name\"]")
    private List<WebElementFacade> breadcrumbLinks;

    @FindBy(css = "a[aria-label='Step 3 - Date and time']")
    private WebElementFacade dateAndTimeBreadcrumb;

    @FindBy(css = "a[aria-label='Step 4 - Personal details']")
    private WebElementFacade personalDetailsBreadcrumb;

    @FindBy(css="#recap-confirm-button,#continue-button,button[class='button button--primary js-action-recap']")
    private WebElementFacade v3_confirmAppointmentButton;

    @FindBy(css = "p.recap__subtitle.ss-sas--summary,#page-header_subtitle,h1[id='page-header_title'],div[class='oas-application__header oas-application__header--white']")
    private WebElementFacade v3_recapPageHeader;

    @FindBy(css = "p#who-email,p#recap-card_recap-card-section-who_email,div.booking-email")
    private WebElementFacade v3_recapPageCustomerEmailAddress;

    @FindBy(css = "p#who-tel,p#recap-card_recap-card-section-who_phone-number,div.booking-phone")
    private WebElementFacade v3_recapPageCustomerMobileNumber;

    @FindBy(css = "h4#who-subtitle,div[class='data-box js-data-box-who']>h1,h3#recap-card_recap-card-section-who_full-name")
    private WebElementFacade v3_recapPageCustomerName;

    @FindBy(css="a#amend-recap-confirm-button,button#edit-submit,div#journey-page-footer_button-list a,#journey-page-footer_continue-button,#continue-button")
    private WebElementFacade v3_confirmYourBooking;

    public void recapPageIsDisplayed() {
        waitForElement();
        waitForTimeoutInMilliseconds();
       assertPageObjectIsDisplayed(recapPageHeader);
    }

    public void recapCustomerEmailAddressISDisplayed(String email) {
        assertElementContainsText(recapPageCustomerEmailAddress,email);
    }

    public void recapCustomerMobileNumberISDisplayed(String mobileno) {
        assertElementContainsText(recapPageCustomerMobileNumber,mobileno);
    }

    public boolean recapCustomerNameISDisplayed(String title, String firstname, String lastName) {
        return recapPageCustomerName.getText().equals(title + firstname + lastName);
    }

    public void clickContinueButton() {//evaluateScriptClick(confirmAppointmentButton);
       waitForElement();
       clickElement(this.confirmAppointmentButton);
    }

    public void changeStore() {
        evaluateScriptClick(changeStore);
    }

    public void clickChangeAppointmentType() {
        evaluateScriptClick(this.changeAppointmentType);
    }

    public void clickChangeDateAndTime() {
        evaluateScriptClick(changeDateAndTimeLink);
    }

    public void clickChangePersonalDetailsLink() {
        evaluateScriptClick(recapCardWhoChangeLink);
    }

    public void clickLocationBreadcrumb() {
        clickElement(this.breadcrumbLinks.get(0));
    }

    public void clickAppointmentTypeBreadcrumb() {
        clickElement(this.breadcrumbLinks.get(1));
    }

    public void clickDateAndTimeBreadcrumb() {
        clickElement(this.breadcrumbLinks.get(2));
    }

    public void clickPersonalDetailsBreadcrumb() {
        clickElement(this.breadcrumbLinks.get(3));
    }

    public boolean v3_recapPageIsDisplayed() {
        return v3_recapPageHeader.waitUntilVisible().isDisplayed();
    }

    public boolean v3_recapCustomerNameIsDisplayed(String title, String firstname, String lastName) {
        return v3_recapPageCustomerName.getText().equals(title +" "+ firstname +" "+lastName);
    }

    public boolean v3_recapCustomerEmailAddressIsDisplayed(String email) {
        return v3_recapPageCustomerEmailAddress.getText().equals(email);
    }

    public boolean v3_recapCustomerMobileNumberIsDisplayed(String mobileno) {
        return v3_recapPageCustomerMobileNumber.getText().replace(" ","").equals(mobileno);
    }

    public void v3_clickContinueButton() {
        clickElement(this.v3_confirmAppointmentButton);
    }

    public boolean v3_recapCustomerNameIsDisplayed(String firstname, String lastName) {
        return v3_recapPageCustomerName.getText().equals(firstname +" "+ lastName);
    }

    public void v3_confirmYourBookingButton(){
        waitABit(2000);
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(this.v3_confirmYourBooking));
        clickElement(this.v3_confirmYourBooking);
    }
}
