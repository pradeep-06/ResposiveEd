package digital.fabr.ui.steps.fabrSteps;

import Framework.Staf;
import digital.fabr.ui.pages.fabrPages.FabrAppointmentTypePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FabrAppointmentTypeStepLib extends ScenarioSteps {

    private String dobDate;
    private String dobMonth;
    private String dobYear;
    FabrAppointmentTypePage fabrAppointmentTypePage;
    private final Logger logger = LoggerFactory.getLogger(FabrAppointmentTypeStepLib.class);

    public void assertAppointmentTypePage() {
        assertThat(fabrAppointmentTypePage.appointmentSearchPageIsDisplayed());
    }

    public void clickAdultEyeTest() {
        fabrAppointmentTypePage.clickAdultEyeTest();
    }

    public void clickAdultEyeTestWithOCTScan() {
        fabrAppointmentTypePage.clickAdultEyeTestWithOCTScan();
    }

    public void clickChildEyeTest() {
        fabrAppointmentTypePage.clickChildEyeTest();
    }

    public void clickEyeTestWithContactLensConsultationAndTrial() {
        fabrAppointmentTypePage.clickEyeTestWithContactLensConsultationAndTrial();
    }

    public void clickEyeTestWithContactLensHealthCheck() {
        fabrAppointmentTypePage.clickEyeTestWithContactLensHealthCheck();
    }

    public void clickContactLensConsultationAndTrial() {
        fabrAppointmentTypePage.clickContactLensConsultationAndTrial();
    }

    public void clickContactlensHealthCheck() {
        fabrAppointmentTypePage.clickContactlensHealthCheck();
    }

    public void clickBookASlotButton() {
        fabrAppointmentTypePage.clickBookASlotButton();
    }

    public void assertCancelAndGoBannerTitle() {
        assertThat(fabrAppointmentTypePage.cancelAndGoBannerTitleIsDisplayed());
    }

    public void clickCancelAndGoBackButton() {
        fabrAppointmentTypePage.clickCancelAndGoBackButton();
    }

    public void clickHearingServices() {
        fabrAppointmentTypePage.clickHearingServices();
    }

    public void assertNHSInformationBanner() {
        assertThat(fabrAppointmentTypePage.nhsInformationBannerIsDisplayed());
    }

    public void assertNHSInformationBannerText() {
        assertThat(fabrAppointmentTypePage.nhsInformationBannerTextIsDisplayed());
    }

    public void clickNHSInformationBannerContentLink() {
        fabrAppointmentTypePage.clickNHSInformationBannerContentLink();
    }

    public void clickHearingTest() {
        fabrAppointmentTypePage.clickHearingTest();
    }

    public void clickHearingTestAndHearingAidConsultation() {
        fabrAppointmentTypePage.clickHearingTestAndHearingAidConsultation();
    }

    public void clickCheckUpForExistingHearingAidWearers() {
        fabrAppointmentTypePage.clickCheckUpForExistingHearingAidWearers();
    }

    public void clickHearingAidMaintenanceOrRepair() {
        fabrAppointmentTypePage.clickHearingAidMaintenanceOrRepair();
    }

    public void clickHearingProtectionConsultation() {
        fabrAppointmentTypePage.clickHearingProtectionConsultation();
    }

    public void clickEarwaxRemoval() {
        fabrAppointmentTypePage.clickEarwaxRemoval();
    }

    public void assertBookingUnavailabilityBannerTitle() {
        assertThat(fabrAppointmentTypePage.bookingUnavailabilityBannerTitleIsDisplayed());
    }

    public void clickRequestAnAppointmentButton() {
        fabrAppointmentTypePage.clickRequestAnAppointmentButton();
    }

    public void assertRequestAnAppointmentButton() {
        fabrAppointmentTypePage.requestAnAppointmentButtonIsDisplayed();
    }

    public void acceptCookie() {
        fabrAppointmentTypePage.acceptCookies();
    }

    public void clickATTNoButton() {
        fabrAppointmentTypePage.clickATTNoButton();
    }

    public void clickATTChooseDateAndTimeButton() {
        fabrAppointmentTypePage.clickATTChooseDateAndTimeButton();
    }

    public void clickATTYesButton() {
        fabrAppointmentTypePage.clickATTYesButton();
    }

    public void clickContactLensAppointment() {
        fabrAppointmentTypePage.clickContactLenseAppointment();
    }

    public void clickOnGotToHomePage() {
        fabrAppointmentTypePage.clickOnGoBackToHomePage();
    }

    public void verifySTAACANDOCTAppointmentTypes() {
        fabrAppointmentTypePage.verifySTAACANDOCTAppointmentTypes();
    }

    //this method works for both v3 and v4 versions
    public void SelectAppointmentTypeAs(String appointmentName){
        logger.info("select appointment type : "+appointmentName);
        if(Staf.getTargetRegion().equals(("nz"))){
            fabrAppointmentTypePage.switchToFrameForAppointments();
        }
        fabrAppointmentTypePage.v3_selectAppointmentTestAs(appointmentName);
    }

    public void v3_clickOnBookAppointmenButton(){
        fabrAppointmentTypePage.v3_ClickBookAppointmentButton();
    }

    public void v4_clickOnBookAppointmenButton(){
        fabrAppointmentTypePage.v4_ClickBookAppointmentButton();
    }

    public void v3_selectMedicalCardAvailabilityAs(String value){
        fabrAppointmentTypePage.v3_selectMedicalCardAvailabilityAs(value);
    }

    public void v4_selectNoMedicalCard(){
        fabrAppointmentTypePage.v4_ClickNoMedicalCardButton();
    }

    public void v4_selectNoPRSI(){
        fabrAppointmentTypePage.v4_ClickNoPRSIButton();
    }

    public void v4_chooseYourAppointment(){
        fabrAppointmentTypePage.v4_ChooseYourAppointmentBtn();

    }

    public void v3_selectAppointmentCategoryAs(String value){
        fabrAppointmentTypePage.v3_selectAppointmentCategoryAs(value);
    }

    //method for slot selection in nz and IE regions
    public void v3_selectDateAndTime(){
        fabrAppointmentTypePage.v3_SelectDateAndTime();
    }

    public void dateOfBirth(int age) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -age);
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        String dobString = format1.format(cal.getTime());
        dobYear = dobString.substring(0, 4);
        dobMonth = dobString.substring(5, 7);
        dobDate = dobString.substring(8, 10);
    }

    public void v3_enterPersonalDetails(String title, String firstName, String lastName, int age, String email, String mobileNumber){
        dateOfBirth(age);
        fabrAppointmentTypePage.enterTitleAs(title);
        fabrAppointmentTypePage.enterFirstName(firstName);
        fabrAppointmentTypePage.enterLastName(lastName);
        fabrAppointmentTypePage.enterDate(this.dobDate);
        fabrAppointmentTypePage.enterMonth(this.dobMonth);
        fabrAppointmentTypePage.enterYear(this.dobYear);
        fabrAppointmentTypePage.enterEmail(email);
        fabrAppointmentTypePage.enterMobileNumber(mobileNumber);
    }

    public void v3_clickBookNowForAppointment(){
        fabrAppointmentTypePage.clickOnBookNowButton();
    }

    public void v4_clickBookNowForAppointment(){
        fabrAppointmentTypePage.clickOnBookNowButtonV4();
    }

    public void v3_enterPersonalDetails(String firstName, String lastName, String dob, String email, String mobileNumber){
        fabrAppointmentTypePage.enterFirstName(firstName);
        fabrAppointmentTypePage.enterLastName(lastName);
        fabrAppointmentTypePage.enterDOB(dob);
        fabrAppointmentTypePage.enterEmail(email);
        fabrAppointmentTypePage.enterMobileNumber(mobileNumber);
    }

    public void v3_enterPersonalDetails(String firstName,String email, String mobileNumber){
        fabrAppointmentTypePage.enterFirstName(firstName);
        fabrAppointmentTypePage.enterEmail(email);
        fabrAppointmentTypePage.enterMobileNumber(mobileNumber);
    }

    public void v3_selectLaterDateAndTime(){
        fabrAppointmentTypePage.v3_selectLaterDateAndTime();
    }

    public void v3_ClickOnAppointment(String appointmentName){
        fabrAppointmentTypePage.SelectAppointmentTestAs(appointmentName);
    }

    public void v3_selectEyeTestInAppointmentTypePage(){
        fabrAppointmentTypePage.v3_selectEyeTestInAppointmentTypePage();
    }
}
