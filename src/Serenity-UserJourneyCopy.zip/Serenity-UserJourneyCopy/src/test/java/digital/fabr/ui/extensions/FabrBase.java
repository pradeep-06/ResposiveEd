package digital.fabr.ui.extensions;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FabrBase extends BasePageObject {

    private final Logger logger = LoggerFactory.getLogger(FabrBase.class);

    public String getElementText(WebElementFacade element) {

        String text = null;

        for (int i = 0; i <= 2; i++) {
            try {
                text = element.waitUntilVisible().getText().replaceAll("[^\\d_]", "").trim();
            } catch (NoSuchElementException | StaleElementReferenceException e) {
                logger.info(e.getMessage());
            }
        }
        return text;
    }
}

