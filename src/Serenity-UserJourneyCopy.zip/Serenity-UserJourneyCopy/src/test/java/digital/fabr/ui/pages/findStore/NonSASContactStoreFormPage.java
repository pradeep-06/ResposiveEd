package digital.fabr.ui.pages.findStore;

import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class NonSASContactStoreFormPage extends FabrBase {

    @FindBy(className = "booking--book-appointment")
    private WebElementFacade requestAppointment;

    @FindBy(xpath = "//span[contains(text(),'For customers who are 16 and above')]/parent::*")
    private WebElementFacade adultSightTestCheckbox;

    @FindBy(xpath = "//span[contains(text(),'For existing contact lens wearers')]/parent::*")
    private WebElementFacade contactLensAftercare;

    @FindBy(xpath = "//span[contains(text(),'For new wearers of contact lenses or those custome')]/parent::*")
    private WebElementFacade contactLensInitial;

    @FindBy(xpath = "//span[contains(text(),'Parent or guardian must be present')]/parent::*")
    private WebElementFacade childEyeTestCheckbox;

    @FindBy(id = "date-time")
    private WebElementFacade timeDate;

    @FindBy(id = "customer-title")
    private WebElementFacade custTitle;

    @FindBy(id = "first-name")
    private WebElementFacade custFirstName;

    @FindBy(id = "last-name")
    private WebElementFacade custLastName;

    @FindBy(css = "label[for=existing-customer]")
    private WebElementFacade existingCustomerCheck;

    @FindBy(id = "customer-email")
    private WebElementFacade customerEmail;

    @FindBy(id = "customer-mobile")
    private WebElementFacade customerMobileNumber;

    @FindBy(id = "customer-notes")
    private WebElementFacade customerNotes;

    @FindBy(id = "customer-dob-day")
    private WebElementFacade customerDobDay;

    @FindBy(id = "customer-dob-month")
    private WebElementFacade customerDobMonth;

    @FindBy(id = "customer-dob-year")
    private WebElementFacade customerDobYear;

    @FindBy(id = "edit-your-details-wrapper-submit")
    private WebElementFacade submitButton;

    public void clickRequestAppointmentButton() {
        clickElement(this.requestAppointment);
    }

    public void checkAdultSightTestCheckBox(String appointmentType) {
        if (appointmentType.contains("Adult sight test")) {
            this.clickElement(adultSightTestCheckbox);
        } else if (appointmentType.contains("Child sight test")) {
            this.clickElement(childEyeTestCheckbox);
        } else if (appointmentType.contains("Contact lens initial appointment")) {
            this.clickElement(contactLensInitial);
        } else if (appointmentType.contains("Contact lens aftercare appointment")) {
            this.clickElement(contactLensAftercare);
        }

    }

    public void enterInDesiredDayAndTime(String desiredTime) {
        setText(this.timeDate, desiredTime);
    }

    public void selectCustomersTitle(String title) {
        selectFromDropdown(this.custTitle, title);
    }

    public void enterInFirstName(String firstName) {
        setText(this.custFirstName, firstName);
    }

    public void enterInLastName(String lastName) {
        setText(this.custLastName, lastName);
    }

    public void setExistingCustomerCheckbox() {
        clickElement(this.existingCustomerCheck);
    }

    public void enterInCustomerEmail(String emailAddress) {
        setText(this.customerEmail, emailAddress);
    }

    public void enterInCustomerPhoneNumber(String customerMobile) {
        setText(this.customerMobileNumber, customerMobile);
    }

    public void enterInCustomerNotes(String custnotes) {
        setText(this.customerNotes, custnotes);
    }

    public void enterDayOfBirth(String day) {
        setText(this.customerDobDay, day);
    }

    public void enterMonthOfBirth(String month) {
        setText(this.customerDobMonth, month);
    }

    public void enterYearOfBirth(String year) {
        setText(this.customerDobYear, year);
    }

    public void clickSubmitButton() {
        clickElement(this.submitButton);
    }
}
