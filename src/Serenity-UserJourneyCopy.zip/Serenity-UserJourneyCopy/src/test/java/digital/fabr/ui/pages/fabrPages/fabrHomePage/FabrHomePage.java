package digital.fabr.ui.pages.fabrPages.fabrHomePage;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindBy;

import java.util.List;

@DefaultUrl("page:fabr.home.url")
public class FabrHomePage extends BasePageObject {

    @FindBy(css = "header#specs-header > a > svg")
    private WebElementFacade siteLogoImage;

    @FindBy(css = "a[trackaid=\"header-request-appointment-cta\"]")
    private WebElementFacade bookAppointmentButton;

    @FindBy(css="li>a[class*=\"find-a-store\"]")
    private WebElementFacade findAStoreButton;

    @FindBy(css="li a.ss-nav-primary__link")
    private List<WebElementFacade> v3_primaryLinks;

    @FindBy(css="li a.ss-nav-desktop__menu-link ")
    private List<WebElementFacade> v3_subMenuLinks;

    @FindBy(css="a.ss-nav__search-btn-desktop")
    private WebElementFacade v3_searchIcon;

    @FindBy(css="input#search-box-locale")
    private WebElementFacade v3_searchinputBox;

    @FindBy(css = "section[data-module='objective'] >div>a:nth-child(2)")
    private WebElementFacade bookHearingTestButton;

    public boolean siteLogoDisplayed() {
        return siteLogoImage.isDisplayed();
    }

    public void clickOnBookAppointment(){
        clickElement(this.bookAppointmentButton);
    }

    public void clickOnBookHearingTestButton(){
        clickElement(this.bookHearingTestButton);
    }

    public void clickOnFindAStore(){
        clickElement(this.findAStoreButton);
    }

    public void v3_selectPrimaryLinkAs(String primaryLinkName){
        withAction().moveToElement(this.v3_primaryLinks.stream().filter(x-> {
              String name = x.getAttribute("title").toLowerCase();
              return name.contains(primaryLinkName.toLowerCase());
          }).findFirst().get()).build().perform();
    }

    public void v3_selectSubMenuLinkAs(String subMenuName){
        clickOn(this.v3_subMenuLinks.stream().filter(x-> {
            String name = x.getAttribute("title").toLowerCase();
            return name.contains(subMenuName.toLowerCase());
        }).findFirst().get());
    }

    public void v3_clickOnSearchIcon(){
         clickOn(v3_searchIcon);
    }

    public void v3_enterIntoSearchInputBox(String value){
           setText(v3_searchinputBox,value);
           this.v3_searchinputBox.sendKeys(Keys.ENTER);
    }
}
