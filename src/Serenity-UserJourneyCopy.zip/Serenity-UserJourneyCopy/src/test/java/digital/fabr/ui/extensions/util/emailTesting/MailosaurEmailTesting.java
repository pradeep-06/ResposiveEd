package digital.fabr.ui.extensions.util.emailTesting;

import Framework.DataManager.TestDataManager;
import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.*;
import digital.fabr.ui.extensions.FabrBase;
import digital.fabr.ui.pages.fabrPages.FabrDateAndTimePage;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import digital.fabr.ui.steps.NavigateToFabr;
import digital.fabr.ui.steps.fabrSteps.FabrBookingConfirmationStepLib;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.Steps;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class MailosaurEmailTesting extends FabrBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(FabrStepDefinitions.class);
    private final Random random = new Random();

    final MailosaurClient mailosaur = new MailosaurClient(testDataManager.getTestInputCommonData("mailosaurInformation.apiKey"));
    final SearchCriteria criteria = new SearchCriteria();
    private static Message message;
    private List<MessageSummary> emails;

    @Steps
    NavigateToFabr navigateTo;

    @Steps
    FabrDateAndTimePage fabrDateAndTime;

    @Steps
    FabrBookingConfirmationStepLib fabrBookingConfirmationSteplib;
    @FindBy(xpath = "//*[contains(text(),'Keep existing appointment')]")
    private WebElementFacade keepAppointmentButton;

    @FindBy(id = "journey-page-footer_continue-button")
    private WebElementFacade continueButton;

    @FindBy(id = "recap_amend-button")
    private WebElementFacade recapAmendButton;

    @FindBy(xpath = "//fieldset[@id='appointment-times'] /div/label)[1]")
    private WebElementFacade selectTimeSlot;

    @FindBy(id = "journey-page-footer_continue-button")
    private WebElementFacade updateMyAppointment;

    @FindBy(id = "journey-page-footer_continue-button")
    private WebElementFacade confirmBooking;

    @FindBy(css = "p#date-and-time_cancel-link a")
    private WebElementFacade cancelMyBooking;

    @FindBy(id="journey-page-footer_continue-button")
    private WebElementFacade cancelAppointment;

    @FindBy(id = "page-header_title")
    WebElementFacade cancelPageHeaderTitle;

    public void checkEmail(String emailAddress, String serverID){
        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.timeOutForMessage")));
        params.withServer(serverID);
        criteria.withSentTo(emailAddress);
        try {
            message=mailosaur.messages().get(params,criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        assertNotNull(message);
       }

    public void deleteAllMailosaurMessages(String apiKey,String serverID) throws MailosaurException {
        MailosaurClient mailosaur = new MailosaurClient(apiKey);
        mailosaur.messages().deleteAll(serverID);
    }

    public String generateEmailAddress(String serverDomain) {
        String randomString = String.valueOf(random.nextInt(10000000));
        return String.format("%s@%s", randomString, serverDomain);
    }

    public void clickOnAmendLinkInEmail(String serverId,String sendToEmailId){
        //Need to recheck without wait of 4000 milli seconds
        waitABit(120000);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverId, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        MessageListResult abc = null;
        try {
            abc = mailosaur.messages().list(serverId);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        List<MessageSummary> items = abc.items();
        if (items.get(0).subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.yourAppointmentInformation"))) {
            String amendHashCode = message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendLinkId"))).href().substring(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendBeginIndex"),Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendEndIndex"))));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForAmend") + amendHashCode);
            //Need to recheck without wait of 10000 milli seconds
            evaluateScriptClick(keepAppointmentButton);
        }
        else{
            logger.info("Not getting message information");
        }
    }

    public void clickOnCancelLinkInEmail(String serverId,String sendToEmailId) {
        //Need to recheck without wait of 20000 milli seconds
        //previouly we are getting 2 mails in mailosaur after booking is done, now only one mail is coming need to change the logic accordingly
       // criteria.withSentFrom("appointment@test.bookings.specsavers.co.uk");
        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.timeOutForMessage")));
        params.withServer(serverId);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(params, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        MessageListParams messageList = new MessageListParams();

        try {
            MessageListResult   result = mailosaur.messages().list(messageList);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        MessageListResult items = null;
        try {
            items = mailosaur.messages().search(params, criteria);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (MailosaurException e) {
            throw new RuntimeException(e);
        }
        //Need to change the subject with latest changes
        if (items.items().get(0).subject().contains(testDataManager.getTestInputCommonData("mailosaurInformation.yourAppointmentInformation"))) {
            //To check we are getting correct cancellation link
            logger.info("Cancellation Link::::"+message.html().links().get(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.cancelLinkId"))).href());
            String cancelHashCode = message.html().links().get(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.cancelLinkId"))).href().substring(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.cancelBeginIndex")),Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.cancelEndIndex")));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForCancel") + cancelHashCode);
            evaluateScriptClick(continueButton);
        }
        if (items.items().get(0).subject().contains(testDataManager.getTestInputCommonData("mailosaurInformation.appointmentCancelledMessage"))) {
            assertNotNull(message);
            assertNotNull(message.subject());
        }
    }

    public void clickCancelToAmendTheAppointment(String serverId,String sendToEmailId) {
        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.timeOutForMessage")));
        params.withServer(serverId);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(params, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        MessageListResult abc = null;
        try {
            abc = mailosaur.messages().list(serverId);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        List<MessageSummary> items = abc.items();
        //Need to change the subject with latest changes
        if (items.get(0).subject().contains("Thanks for booking")) {
            String cancelHashCode = message.html().links().get(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.cancelLinkId"))).href().substring(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.hashCodeIndex")));
            getDriver().navigate().to(testDataManager.getTestInputCommonData("mailosaurInformation.baseURLForAmendAndCancel") + cancelHashCode);
          //  scrollDown();
            evaluateScriptClick(recapAmendButton);
            evaluateScriptClick(selectTimeSlot);
            evaluateScriptClick(updateMyAppointment);
            evaluateScriptClick(confirmBooking);

        }
        //Need to change the subject with latest changes
        if (items.get(0).subject().contains("Appointment changed for")) {
            assertNotNull(message);
            assertNotNull(message.subject());
        }
    }

    public void switchToChildWindowForBooking(){
        waitForTimeoutInMilliseconds();
        switchToChildWindow();
        waitForPageLoader();
    }

    public void switchToOriginalWindowForBooking(){
        switchToOriginalWindow();
    }

    public String getRequiredDateForSlotsSetup(int dateAfter){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime requiredDate = now.plusDays(dateAfter);
        return DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH).format(requiredDate)+"T00:00:00Z";
    }

    public void cancelAppointmentUsingAmendLink(String serverId,String sendToEmailId){
        //Need to recheck without wait of 4000 milli seconds

        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverId, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        MessageListResult abc = null;
        try {
            abc = mailosaur.messages().list(serverId);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        List<MessageSummary> items = abc.items();
        if (items.get(0).subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.yourAppointmentInformation"))) {
            //To check we are getting correct cancellation link
            logger.info("Amend Link::::"+message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendLinkId"))).href());
            String amendHashCode = message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendLinkId"))).href().substring(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendBeginIndex")),Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendEndIndex")));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForAmend") + amendHashCode);
            waitABit(30000);
            scrollDown();
            //getDriver().findElement(By.cssSelector("p#date-and-time_cancel-link a")).click();
          //  waitForElementTextToAppear(cancelMyBooking,testDataManager.getTestInputCommonData("mailosaurInformation.cancelMyBookingText"));
            evaluateScriptClick(cancelMyBooking);
            evaluateScriptClick(continueButton);
        }
//        if (items.get(0).subject().contains(testDataManager.getTestInputCommonData("mailosaurInformation.appointmentCancelledMessage"))) {
//            assertNotNull(message);
//            assertNotNull(message.subject());
//        }
    }

      //ROI test case method
    public void amendBookedAppointUsingDatAndTime(String serverId,String sendToEmailId){
        //Need to recheck without wait of 4000 milli seconds
        MessageSearchParams params = new MessageSearchParams();
        params.withServer(serverId);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(params, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
       getDriver().navigate().to(message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendLinkId"))).href());
        waitForTimeoutInMilliseconds();
            navigateTo.theUserAcceptCookies();
            String urlForAmendHashCode=getDriver().getCurrentUrl();
            //To check the current URL is correct or not
            //System.out.print("Current URL:::::"+urlForAmendHashCode);
            String amendHashCode = urlForAmendHashCode.substring(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendBeginIndex")),Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendEndIndex")));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForAmend") + amendHashCode);

            //Need to recheck without wait of 10000 milli seconds
            fabrDateAndTime.selectNewDateAndTime();
            clickElement(updateMyAppointment);
            waitABit(2000);
            clickElement(confirmBooking);
           fabrBookingConfirmationSteplib.assertConfirmationCardWhoSection();


        if (message.subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.appointmentAmendMessage"))) {
            assertNotNull(message);
        }

    }


    //ROI method for booking cancellation from Email link
    public void cancelBookedAppointUsingCancellationLinkInEmail(String serverId,String sendToEmailId) {
        //Need to recheck without wait of 4000 milli seconds
        MessageSearchParams params = new MessageSearchParams();
        params.withServer(serverId);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(params, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
           getDriver().get(message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.cancelLinkId"))).href());
            navigateTo.theUserAcceptCookies();
            String urlForAmendHashCode = getDriver().getCurrentUrl();
            System.out.print("Current URL:::::" + urlForAmendHashCode);
            String cancelHashCode = urlForAmendHashCode.substring(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.cancelBeginIndex")), Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.cancelEndIndex")));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForCancel") + cancelHashCode);
            //Need to recheck without wait of 10000 milli seconds
            waitFor(cancelAppointment);
            clickElement(cancelAppointment);
            waitFor(cancelPageHeaderTitle);
        if (message.subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.appointmentCancelledMessage"))) {
            assertNotNull(message);
        }
    }

    public void cancelBookedAppointUsingChangeDateAndTimeLinkInEmail(String serverId,String sendToEmailId) {
        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.timeOutForMessage")));
        params.withServer(serverId);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(params, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
          getDriver().get(message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendLinkId"))).href());
            navigateTo.theUserAcceptCookies();
            String urlForAmendHashCode=getDriver().getCurrentUrl();
            String amendHashCode = urlForAmendHashCode.substring(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendBeginIndex")),Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.amendEndIndex")));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForAmend") + amendHashCode);
           waitOnPage();
           waitFor(cancelMyBooking);
           clickElement(cancelMyBooking);
            waitOnPage();
            clickElement(cancelAppointment);
            waitFor(cancelPageHeaderTitle);
        if (message.subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.appointmentCancelledMessage"))) {
            assertNotNull(message);
        }
    }

    public void keepBookedAppointUsingCancellationLinkInEmail(String serverId,String sendToEmailId) {
        //Need to recheck without wait of 4000 milli seconds
        waitABit(30000);
        criteria.withSentTo(sendToEmailId);
        Message message = null;
        try {
            message = mailosaur.messages().get(serverId, criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        MessageListResult abc = null;
        try {
            abc = mailosaur.messages().list(serverId);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        List<MessageSummary> items = abc.items();
        if (items.get(0).subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.yourAppointmentInformation"))) {
            getDriver().get(message.html().links().get(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.cancelLinkId"))).href());
            navigateTo.theUserAcceptCookies();
            String urlForAmendHashCode = getDriver().getCurrentUrl();
            System.out.print("Current URL:::::" + urlForAmendHashCode);
            String cancelHashCode = urlForAmendHashCode.substring(Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.cancelBeginIndex")), Integer.parseInt(testDataManager.getTestInputRegionData("mailosaurInformation.cancelEndIndex")));
            getDriver().navigate().to(testDataManager.getTestInputRegionData("mailosaurInformation.baseURLForCancel") + cancelHashCode);
            //Need to recheck without wait of 10000 milli seconds
            waitFor(cancelAppointment);
            clickElement(cancelAppointment);
            waitFor(cancelPageHeaderTitle);
        }
        if (items.get(0).subject().contains(testDataManager.getTestInputRegionData("mailosaurInformation.appointmentCancelledMessage"))) {
            assertNotNull(message);
        }
    }

    public String getNextMonthDate(){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime requiredDate=now.plusMonths(1);
       return DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH).format(requiredDate)+"T00:00:00Z";
    }

}
