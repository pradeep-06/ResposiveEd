package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.UK_Audio_ATT;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("fabr")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class UKEnhancementForAudiology {
    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;


    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458370", projectId = "102929", testCaseName = "TC_02_Validate 'Hearing test'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_02_AudiologyATTHearingTestScenario1() {
       fabr.validateHearingTestBookingJourneyAudiologyATT();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458373", projectId = "102929", testCaseName = "TC_03_Validate 'Hearing test and hearing aid consultation'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_03_AudiologyATTHearingTestScenario2() {
        fabr.validateHearingTestAndHearingAidConsultationScenario2AudiologyATT();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458375", projectId = "102929", testCaseName = "TC_04_Validate 'Hearing test and hearing aid consultation'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_04_AudiologyATTHearingTestAndHearingAidConsultationScenario2(){
       fabr.validateHearingTestAndHearingAidConsultationBookingWhenATTIsEnable();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458385", projectId = "102929", testCaseName = "TC05_Validate 'Checkup for existing hearing aid wearer'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_05_AudiologyATTCheckupForExistingHearingAidWearerScenario1(){
        fabr.validateCheckupForExistingHearingAidWearerScenario1();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458389", projectId = "102929", testCaseName = "TC_06_Validate 'Checkup for existing hearing aid wearer'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_06_AudiologyATTCheckupForExistingHearingAidWearerScenario2(){
       fabr.validateCheckupForExistingHearingAidWearerScenario2();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458391", projectId = "102929", testCaseName = "TC_07_Validate 'Hearing aid Maintenance or repair'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_07_AudiologyATTHearingAidMaintenanceOrRepair(){
        fabr.validateHearingAidMaintenanceOrRepair();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458392", projectId = "102929", testCaseName = "TC_08_Validate 'NHS funded service Page  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_08_AudiologyATTNHSFundedServicePage(){
          fabr.validateNHSFundedServicePage();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458394", projectId = "102929", testCaseName = "TC_10_Validate 'Hearing protection consultation'  booking journey  - Audiology ATT journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_09_AudiologyATTHearingProtectionConsultation(){
       fabr.validateHearingProtectionConsultation();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458762", projectId = "102929", testCaseName = "TC_01_ 'Earwax removal'  booking journey  - Audiology ATT journey-Customer choose 'Yes' for triage Question ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_10_AudiologyATTEarwaxRemovalScenario1(){
        fabr.earwaxRemovalCustomerChooseYesForATT();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458773", projectId = "102929", testCaseName = "TC_02_ 'Earwax removal'  booking journey  - Audiology ATT journey-Customer choose 'No' for triage Question and click 'I  understand' CTA on model", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_AudiologyATTEarwaxRemovalScenario2(){
        fabr.earwaxRemovalCustomerChooseNoForATT();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458777", projectId = "102929", testCaseName = "TC_03_ 'Earwax removal'  booking journey  - Audiology ATT journey-Customer choose 'No' for triage Question and click 'Go back' CTA on model", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_12_AudiologyATTEarwaxRemovalScenario3() {
      fabr.earwaxRemovalCustomerChooseNoForATTAndClickGoBack();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458813", projectId = "102929", testCaseName = "TC_04_ 'Earwax removal'  booking journey  - Audiology ATT journey-Customer choose 'No' for triage Question and close model using 'x' ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_13_AudiologyATTEarwaxRemovalScenario4() {
     fabr.earwaxRemovalCustomerChooseNoForATTAndCloseTheModelUsingCloseButton();
    }

    @UK_Audio_ATT
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "42458818", projectId = "102929", testCaseName = "TC06_'Earwax removal'  booking journey  - Audiology ATT journey-Validate 'Previous' CTA ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_14_AudiologyATTEarwaxRemovalScenario5() {
     fabr.earwaxRemovalValidatePreviousCTA();
    }

    @AfterEach
    public void tearDown() {

        fabr.closeSession();
    }
}
