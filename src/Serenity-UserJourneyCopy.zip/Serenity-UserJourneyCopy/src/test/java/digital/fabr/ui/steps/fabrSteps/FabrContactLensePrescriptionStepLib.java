package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrContactLensePrescriptionPage;
import net.thucydides.core.steps.ScenarioSteps;

public class FabrContactLensePrescriptionStepLib extends ScenarioSteps {
    FabrContactLensePrescriptionPage fabrContactLensePrescriptionPage;

    public void v3_selectLeftEyeQuantity(){
        fabrContactLensePrescriptionPage.v3_selectLeftEyeQuantity();
    }

    public void v3_selectRightEyeQuantity(){
        fabrContactLensePrescriptionPage.v3_selectRightEyeQuantity();
    }

    public void v3_clickOnPrescriptionButton(){
        waitABit(2000);
        fabrContactLensePrescriptionPage.v3_clickOnPrescriptionButton();
    }

    public void v3_clickOnBookAppointmentLink(){
        fabrContactLensePrescriptionPage.v3_clickOnBookAppointmentLink();
    }

}

