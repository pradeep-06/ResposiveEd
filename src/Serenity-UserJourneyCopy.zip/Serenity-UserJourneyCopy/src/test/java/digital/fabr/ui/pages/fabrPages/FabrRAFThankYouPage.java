package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class FabrRAFThankYouPage extends BasePageObject {

    @FindBy(className="heading")
    private WebElementFacade appointmentConfirmationHeading;

    @FindBy(className = "raf__container")
    private WebElementFacade appointmentRAFContainer;

    public boolean appointmentConfirmationHeadingIsDisplayed(){return this.appointmentConfirmationHeading.isDisplayed();}
    public boolean appointmentRAFContainerIsDisplayed(){return this.appointmentRAFContainer.isDisplayed();}
}
