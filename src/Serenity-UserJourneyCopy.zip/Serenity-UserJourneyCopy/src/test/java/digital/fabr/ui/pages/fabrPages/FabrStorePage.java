package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class FabrStorePage extends BasePageObject {
    @FindBy(xpath = "//*[@id=\"store-overview-group_general-information\"]/ h1")
    private WebElementFacade storeGeneralInformation;

    @FindBy(id = "//a[@id=\"header-book-appointment\"]")
    private WebElementFacade headerBookAppointmentButton;

    @FindBy(css="#book-appointment-button")
    private WebElementFacade bookAppointmentButton;

    public boolean verifyStoreGeneralInformationIsDisplayed(){
      return  this.storeGeneralInformation.isDisplayed();
    }

    public void clickHeaderBookAppointmentButton() {
    clickElement(this.headerBookAppointmentButton);
    }

    public void clickBookAppointmentButton() {
        clickElement(this.bookAppointmentButton);
    }
}
