package digital.fabr.ui.pages.fabrPages;

import Framework.DataManager.TestDataManager;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class FabrNHSHearingAidsPage extends FabrBase {

    protected final TestDataManager testDataManager = new TestDataManager();

    @FindBy(css="div.dev-section h1")
    private WebElementFacade nHSHearingAidsPageHeading;

    @FindBy(xpath = "//div[@class=\"dev-section\"]/a")
    private WebElementFacade  eligibilityChecker;

    public void assertNHSHearingAidsPageHeading(){
        switchToChildWindow();
        clickAcceptOnCookies();
        assertPageObjectExists(nHSHearingAidsPageHeading);
    }

    public void checkEligibilityCheckerTextAvailability(){
        assertElementContainsText(eligibilityChecker,testDataManager.getTestAssertionData("contentTitles.eligibilityChecker"));
    }
}


