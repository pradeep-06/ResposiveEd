package digital.fabr.ui.steps.fabrSteps;

import Framework.Staf;
import digital.fabr.ui.pages.fabrPages.FabrAmendConfirmationPage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

public class FabrAmendConfirmationStepLib extends ScenarioSteps {
    FabrAmendConfirmationPage fabrAmendConfirmationPage;
    public void assertConfirmationHeaderTitle() {
        fabrAmendConfirmationPage.verifyConfirmationHeaderTitleIsDisplayed();
    }

    public void assertConfirmationHeaderSubTitle() {
        fabrAmendConfirmationPage.verifyConfirmationHeaderSubTitleIsDisplayed();
    }

    public void amendAppointmentAgain() {
        fabrAmendConfirmationPage.amendAppointmentAgain();
    }

    public void assertWhenSubtitle() {
        assertThat(fabrAmendConfirmationPage.verifyWhenSubtitleIsDisplayed());
    }

    public void cancelBookingfromAmendConfirmation() {
        fabrAmendConfirmationPage.cancelBooking();
    }

    public void v3_assertConfirmationHeaderTitle() {
        if(!Staf.getTargetRegion().equals("se")) {
            fabrAmendConfirmationPage.v3_verifyConfirmationHeaderTitleIsDisplayed();
        }
    }
}
