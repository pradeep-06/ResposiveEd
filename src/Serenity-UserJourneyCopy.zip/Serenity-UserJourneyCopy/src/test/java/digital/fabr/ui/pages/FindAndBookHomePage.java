package digital.fabr.ui.pages;

import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.annotations.DefaultUrl;
import org.openqa.selenium.support.FindBy;

@DefaultUrl("page:fabr.home.url")
public class FindAndBookHomePage extends FabrBase {

    @FindBy(css = "header#header span > a")
    public WebElementFacade closeattraqtModal;

    public void closeAttraqtModel() {
        clickElement(closeattraqtModal);
    }

}
