package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class FabrAppointmentKeptPage extends BasePageObject {
    @FindBy(id = "confirmation-page-template_specs-success-banner_title")
    private WebElementFacade headerConfirmationTitle;
    public boolean headerConfirmationTitleIsDisplayed(){
        this.headerConfirmationTitle.waitUntilPresent();
        return this.headerConfirmationTitle.isDisplayed();
    }
}
