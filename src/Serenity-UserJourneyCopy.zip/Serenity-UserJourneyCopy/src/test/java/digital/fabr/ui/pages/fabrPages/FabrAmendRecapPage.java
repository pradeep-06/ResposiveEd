package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class FabrAmendRecapPage extends BasePageObject {
    @FindBy(id="page-header_title")
    private WebElementFacade amendRecapTitle;
    @FindBy(css="a#journey-page-footer_continue-button")
    private WebElementFacade amendRecapConfirmButton;

    public boolean amendRecapTitleIsDisplayed(){
        waitForTimeoutInMilliseconds();
        waitForElement();
        return this.amendRecapTitle.isDisplayed();
    }
    public void clickAmendRecapConfirmButton(){

         scrollToView(this.amendRecapConfirmButton);
         waitForTimeoutInMilliseconds();
        waitForElement();
        clickElement(this.amendRecapConfirmButton);

        //valuateScriptClick(this.amendRecapConfirmButton);
    }
}
