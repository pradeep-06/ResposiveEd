package digital.fabr.ui.steps.fabrSteps;

import Framework.BaseObject.BasePageObject;
import digital.fabr.ui.extensions.util.Monetate.MonetateCookieUtils;
import org.openqa.selenium.Cookie;

public class MonetateCookieSteps  extends BasePageObject {

    private static final String COOKIE_NAME = "mt.v";

    public void givenTheFeatureFlagIsEnabled(String featureName, int percentage) {
        setMonetateCookie(MonetateCookieUtils.generateMonetateIdWithFeatureEnabled(featureName, percentage));

    }


    public void givenTheFeatureFlagIsDisabled(String featureName, int percentage) {
        setMonetateCookie(MonetateCookieUtils.generateMonetateIdWithFeatureDisabled(featureName, percentage));
    }

    private void setMonetateCookie(String cookieId) {
        getDriver().manage().addCookie(new Cookie(COOKIE_NAME, cookieId));

    }

}
