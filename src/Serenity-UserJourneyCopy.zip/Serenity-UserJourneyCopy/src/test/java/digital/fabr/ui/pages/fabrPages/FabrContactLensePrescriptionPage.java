package digital.fabr.ui.pages.fabrPages;

import Framework.Staf;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;

public class FabrContactLensePrescriptionPage extends FabrBase {

    @FindBy(css = "#edit-quantity-left-eye-button")
    private WebElementFacade v3_leftEyeQuantity;

    @FindBy(css = ".ui-selectmenu-menu.ui-selectmenu-open ul[id*=edit-quantity-left-eye] li")
    private List<WebElementFacade> v3_leftEyeQuantitySelector;

    @FindBy(css = "#edit-quantity-right-eye-button")
    private WebElementFacade v3_rightEyeQuantity ;

    @FindBy(css = ".ui-selectmenu-menu.ui-selectmenu-open ul[id*=edit-quantity-right-eye] li")
    private List<WebElementFacade> v3_rightEyeQuantitySelector;

    @FindBy(css = "[id*=edit-submit-button]")
    private WebElementFacade v3_prescriptionButton;

    @FindBy(css="div.modal-footer a")
    private WebElementFacade v3_bookAppointmentLink;


     public void v3_selectLeftEyeQuantity(){
         if(!(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("nl")||Staf.getTargetRegion().equals("se"))) {
             waitABit(2000);
             Staf.wait.until(webDriver -> v3_leftEyeQuantity.isEnabled());
             clickOn(this.v3_leftEyeQuantity);
             clickOn(this.v3_leftEyeQuantitySelector.get(1));
         }
     }

    public void v3_selectRightEyeQuantity(){
        clickOn(this.v3_rightEyeQuantity);
        clickOn(this.v3_rightEyeQuantitySelector.get(1));
    }

    public void v3_clickOnPrescriptionButton(){
         Staf.wait.until(webDriver ->this.v3_prescriptionButton.isEnabled());
         clickOn(this.v3_prescriptionButton);
         if(!this.v3_bookAppointmentLink.isVisible()){ //AG: had to insert his condition to reclick on presription for DK and Fi region as itis not getting clicked in first attempt
             clickOn(this.v3_prescriptionButton);
         }
    }

    public void v3_clickOnBookAppointmentLink(){
         clickOn(this.v3_bookAppointmentLink);
    }
}

