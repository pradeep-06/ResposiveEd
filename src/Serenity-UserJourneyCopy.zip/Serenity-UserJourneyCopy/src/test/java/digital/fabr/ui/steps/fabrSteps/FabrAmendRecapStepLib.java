package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrAmendRecapPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.junit.jupiter.api.Assertions;

public class FabrAmendRecapStepLib extends ScenarioSteps {
    FabrAmendRecapPage fabrAmendRecapPage;

    public void assertAmendRecapTitle() {
        Assertions.assertTrue(fabrAmendRecapPage.amendRecapTitleIsDisplayed());
    }

    public void clickAmendRecapConfirmButton() {
        fabrAmendRecapPage.clickAmendRecapConfirmButton();
    }
}
