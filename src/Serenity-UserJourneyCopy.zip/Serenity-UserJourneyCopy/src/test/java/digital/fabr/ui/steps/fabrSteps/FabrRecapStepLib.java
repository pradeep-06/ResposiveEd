package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrRecapPage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.assertj.core.api.Assertions.assertThat;

public class FabrRecapStepLib extends ScenarioSteps {
    private FabrRecapPage recapPage;

    public void assertRecapPageIsDisplayed() {
        recapPage.recapPageIsDisplayed();
    }


    public void assertCustomerName(String title, String firstname, String surname) {
        assertThat(recapPage.recapCustomerNameISDisplayed(title, firstname, surname)).isTrue();
    }

    public void clickConfirmYourBooking() {
        recapPage.clickContinueButton();
    }

    public void changeStore() {

        recapPage.changeStore();
    }

    public void clickChangeAppointmentType() {
        recapPage.clickChangeAppointmentType();
    }

    public void clickChangeDateAndTime() {

        recapPage.clickChangeDateAndTime();
    }

    public void clickChangePersonalDetailsLink() {
        recapPage.clickChangePersonalDetailsLink();
    }

    public void clickLocationBreadcrumb() {
        recapPage.clickLocationBreadcrumb();
    }

    public void clickAppointmentTypeBreadcrumb() {
        recapPage.clickAppointmentTypeBreadcrumb();
    }

    public void clickDateAndTimeBreadcrumb() {
        recapPage.clickDateAndTimeBreadcrumb();
    }

    public void clickPersonalDetailsBreadcrumb() {
        recapPage.clickPersonalDetailsBreadcrumb();
    }

    public void v3_assertRecapPageIsDisplayed() {
        assertThat(recapPage.v3_recapPageIsDisplayed()).isTrue();
    }

    public void v3_assertCustomerName(String title, String firstname, String surname) {
        assertThat(recapPage.v3_recapCustomerNameIsDisplayed(title, firstname, surname)).isTrue();
    }

    public void v3_assertEmailAddress(String email) {
        assertThat(recapPage.v3_recapCustomerEmailAddressIsDisplayed(email)).isTrue();
    }

    public void v3_assertCustomerMobileNumber(String mobileno) {
        assertThat(recapPage.v3_recapCustomerMobileNumberIsDisplayed(mobileno)).isTrue();
    }

    public void v3_clickConfirmYourBooking() {
        recapPage.v3_clickContinueButton();
    }

    public void v3_assertCustomerName(String firstname, String surname) {
        assertThat(recapPage.v3_recapCustomerNameIsDisplayed(firstname, surname)).isTrue();
    }

    public void v3_confirmYourBookingButton(){
        recapPage.v3_confirmYourBookingButton();
    }
}
