package digital.fabr.ui.stepdefinitions;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import digital.fabr.ui.extensions.util.emailTesting.MailosaurEmailTesting;
import digital.fabr.ui.pages.FindAndBookHomePage;
import digital.fabr.ui.pages.fabrPages.*;
import digital.fabr.ui.steps.NavigateToFabr;
import digital.fabr.ui.steps.fabrSteps.*;
import net.serenitybdd.annotations.Screenshots;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;


public class FabrStepDefinitions extends ScenarioSteps {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(FabrStepDefinitions.class);
    Date receivedAfter=new Date(System.currentTimeMillis() - 3600 * 1000);

    @Steps
    NavigateToFabr navigateTo;

    @Steps
    FindAndBookHomePage bookingPage;

    @Steps
    FabrPersonalDetailsPage fabrPersonalDetailsPage;

    @Steps
    FabrLocationPage locationPageSteps;

    @Steps
    FabrAppointmentTypePage fabrAppointment;

    @Steps
    FabrDateAndTimePage fabrDateAndTime;

    @Steps
    FabrPersonalDetailsStepLib fabrPersonalDetailsLib;

    @Steps
    FabrRecapStepLib fabrRecapStepLib;

    @Steps
    FabrBookingConfirmationStepLib fabrBookingConfirmationSteplib;

    @Steps
    FabrDateAndTimeStepLib fabrDateAndTimeStepLib;

    @Steps
    FabrLocationStepLib fabrLocationStepLib;

    @Steps
    FabrAppointmentTypeStepLib fabrAppointmentTypeStepLib;

    @Steps
    FabrRAFAppointmentTypeStepLib fabrRAFAppointmentTypeStepLib;

    @Steps
    FabrRAFThankYouStepLib fabrRAFThankYouStepLib;

    @Steps
    FabrStoreStepLib fabrStoreStepLib;

    @Steps
    FabrAmendCalendarBookingConfirmationStepLib fabrAmendCalendarBookingConfirmationStepLib;

    @Steps
    FabrBookingCancelationStepLib fabrBookingCancelationStepLib;

    @Steps
    FabrAmendRecapStepLib fabrAmendRecapStepLib;

    @Steps
    FabrAmendConfirmationStepLib fabrAmendConfirmationStepLib;

    @Steps
    FabrAppointmentKeptStepLib fabrAppointmentKeptStepLib;

    @Steps
    FabrAppointmentCancelledStepLib fabrAppointmentCancelledStepLib;

    @Steps
    MailosaurEmailTesting emailTestingHandler;

    @Steps
    FabrContactLensesListStepLib fabrContactLensesListStepLib;

    @Steps
    FabrContactLensePrescriptionStepLib fabrContactLensePrescriptionStepLib;

    final String apiKey = testDataManager.getTestInputCommonData("mailosaurInformation.apiKey");
    final  String serverID = testDataManager.getTestInputCommonData("mailosaurInformation.serverID");
    final String serverDomain=testDataManager.getTestInputCommonData("mailosaurInformation.serverDomain");
    @Steps
    MonetateCookieSteps monetateCookiesSteps;

    @Steps
    FabrNHSHearingAidsPage fabrNHSHearingAidsPage;

    @Steps
    FabrRecapPage fabrRecapPage;

    @Steps
    FabrBookingConfirmationPage fabrBookingConfirmationPage;

    static String emailAddress;
    static String mobileNumber;
    final  String sentFromEmailId=testDataManager.getTestInputCommonData("mailosaurInformation.sentFrom");


   @Step("Open fabr site")
    public void openFabrHome() {
        navigateTo.theHomePage();
    }

    @Step("Continue in personal details page")
    @Screenshots(afterEachStep = true)
    public void clickOnContinueInPersonalDetailPage() {
        fabrPersonalDetailsLib.clickContinueBookingButton();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.enterLocationTown();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore1() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore1();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findKirkstallStore() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.inputKirkstallStore();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findCoventryStoreWithOutCookies() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        fabrLocationStepLib.inputStore1();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore5() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore5();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findBedworthStoreWithoutCookies() {
        //Need to recheck without wait of 2000 milli seconds
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputStore5();
        fabrLocationStepLib.clickSearch();
        locationPageSteps.waitForElementTextToAppear(locationPageSteps.getSearchedStoreText(),testDataManager.getTestInputRegionData("storeName.store5"));
        //Need to recheck without wait of 3000 milli seconds
    }

    @Step("Performs a text search or geolocation search")
    public void findStore9() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore9();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore2() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore2();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findLeedsCrownPointStore() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.inputLeedsCrownPointStore();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findWarwickStore() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.inputWarwickStore();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore2WithoutCookies() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputStore2();
        fabrLocationStepLib.clickSearch();
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }

    @Step("Select a store")
    public void selectStore() {
        logger.info("Select a store");
        String region = Staf.getTargetRegion();
        fabrLocationStepLib.bookOnlineInSelectedLocation(region);

    }

    @Step("Choose adult eye test appointment type")
    public void chooseAdultEyeTestAppointmentType() {
         fabrAppointmentTypeStepLib.clickAdultEyeTest();
        fabrAppointmentTypeStepLib.clickBookASlotButton();
        if(Staf.getTargetRegion().equals("uk")) {
            clickOnNoAndProceed();
            clickChooseDateAndTime();
        }

    }

    @Step("Choose OCT appointment")
    public void chooseOCTAppointmentType() {
        fabrAppointment.clickAdultEyeTestWithOCTScan();
        fabrAppointment.clickBookASlotButton();
    }

    @Step("Choose Child eye test appointment type")
    public void chooseChildEyeTestAppointmentType() {
       if(Staf.getTargetRegion().equals("uk")||Staf.getTargetRegion().equals("ie")) {
           fabrAppointment.clickChildEyeTest();
       }
       if(Staf.getTargetRegion().equals("au") || Staf.getTargetRegion().equals("no")|| Staf.getTargetRegion().equals("nl")){
           fabrAppointment.clickAdultEyeTest();
       }
          fabrAppointment.clickBookASlotButton();
    }

    @Step("Choose date and time")
    public void selectTimeSlotForBooking() {
        selectLaterTimeSlot();
        fabrDateAndTime.clickDateAndTime();
        fabrDateAndTime.clickContinueButton();
    }

    @Step("Enter personal details")
    public void enterPersonalDetails() {
        emailAddress=emailTestingHandler.generateEmailAddress(serverDomain);
        if(Staf.getTargetRegion().equals("uk")){
        fabrPersonalDetailsLib.completePersonalDetailsForm(
                testDataManager.getTestInputRegionData("userInformation.title"),
                testDataManager.getTestInputRegionData("userInformation.firstName"),
                testDataManager.getTestInputRegionData("userInformation.lastName"),
                testDataManager.getTestInputRegionData("userInformation.postCode"),
                Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),emailAddress,
                testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }

        if(Staf.getTargetRegion().equals("no")){
            fabrPersonalDetailsLib.completePersonalDetailsFormForNO(
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    testDataManager.getTestInputRegionData("userInformation.postCode"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }

        if(Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("ie")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("userInformation.title"),
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }
        if(Staf.getTargetRegion().equals("nl")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }
    }

    @Step("Verify details on recap page")
    public void verifyDetailsAndContinueWithBooking() {
        final String firstName = testDataManager.getTestInputRegionData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputRegionData("userInformation.lastName");
        final String mobileno = testDataManager.getTestInputRegionData("userInformation.mobileNumber");
        fabrRecapPage.recapCustomerEmailAddressISDisplayed(emailAddress);
        fabrRecapStepLib.clickConfirmYourBooking();
    }

    @Step("Confirm the booking")
    public void confirmBooking() {
        //Need to recheck without wait of 8500 milli seconds
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        fabrBookingConfirmationSteplib.assertBookingConfirmationPageTitle();
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
        fabrBookingConfirmationSteplib.assertConfirmationCardWhoSection();
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

       }

    @Step
    public void closeBrowser() {
        getDriver().quit();
    }

    @Step("Clicks on the 'change' link on the what card")
    public void clickOnChangeAppointmentLink() {
        fabrRecapStepLib.clickChangeAppointmentType();
    }

    @Step("Customer is directed to the appointment type page")
    public void verifyAppointmentPage() {
        fabrAppointmentTypeStepLib.assertCancelAndGoBannerTitle();
    }

    @Step("Customer chooses adult eye appointment type")
    public void selectAdultEyeTestWithOCTScan() {
        final String appointmentType = testDataManager.getTestInputRegionData("appointmentData.appointmentType.adultEyeTestAndOCTScan");
        if (appointmentType.equals("Adult eye test and OCT scan")) {
            fabrAppointment.clickAdultEyeTestWithOCTScan();
        } else {
            logger.info("Not a valid appointment type");
        }
        fabrAppointment.clickBookASlotButton();
    }

    @Step("Customer chooses new date and time")
    public void selectNewDateAndTime() {
        fabrDateAndTime.selectNewDateAndTime();
        fabrDateAndTime.clickContinueButton();
    }

    @Step("Personal details are already filled->Reaches recap page")
    public void verifyCustomerDetails() {
        final String mobileno = testDataManager.getTestInputCommonData("userInformation.mobileNumber");
        final String firstName = testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userInformation.lastName");
        fabrPersonalDetailsPage.assertPersonalDetailsEmailIsDisplayed(emailAddress);
        fabrPersonalDetailsPage.assertPersonalDetailsFirstNameIsDisplayed(firstName);
        fabrPersonalDetailsPage.assertPersonalDetailsLastNameIsDisplayed(lastName);
        fabrPersonalDetailsLib.clickContinueBookingButton();
    }

    @Step("Clicks on the cancel and go back link")
    public void clickOnCancelAndGoLink() {
        fabrAppointment.clickCancelAndGoBackButton();
    }

    @Step("User is redirected to the reacp page")
    public void verifyRecapPage() {
        fabrRecapStepLib.assertRecapPageIsDisplayed();
        fabrRecapStepLib.clickConfirmYourBooking();
    }

    @Step("Clicks on the 'change' link on the when card")
    public void changeDateAndTimeFromRecapPage() {
        fabrRecapStepLib.clickChangeDateAndTime();
    }

    @Step("Customer is directed to the date and time page")
    public void verifyDateAndTimePage() {
        fabrDateAndTimeStepLib.assertDateAndTimePage();
        fabrDateAndTimeStepLib.assertDateAndTimePageTitle();
    }

    @Step("Clicks on cancel and go back link")
    public void clickOnCancelAndGoLinkInDateAndTime() {
        fabrDateAndTimeStepLib.clickCancelAndGoLink();
    }

    @Step("Clicks on the 'change' link on the who card")
    public void changePersonalDetailsFromRecapPage() {
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        fabrRecapStepLib.clickChangePersonalDetailsLink();
    }

    @Step("Customer is directed to the personal details page")
    public void verifyPersonalDetailsPage() {
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        fabrPersonalDetailsLib.assertCancelAndGoBannerTitle();
    }

    @Step("Clicks on cancel and go back link")
    public void clickOnCancelAndGoBackLinkInPersonalDetails() {
        fabrPersonalDetailsLib.clickCancelAndGoBackLink();
    }

    @Step("Clicks on the 'change' link on the where card")
    public void clickOnChangeLocationLink() {
        fabrRecapStepLib.changeStore();
    }

    @Step("Re enter personal details in recap page")
    public void reEnterPersonalDetailsInRecapPage() {
        emailAddress=emailTestingHandler.generateEmailAddress(serverDomain);
        if(Staf.getTargetRegion().equals("uk")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("updatedUserInformation.title"),
                    testDataManager.getTestInputRegionData("updatedUserInformation.firstName"),
                    testDataManager.getTestInputRegionData("updatedUserInformation.lastName"),
                    testDataManager.getTestInputRegionData("updatedUserInformation.postCode"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("updatedUserInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("updatedUserInformation.mobileNumber"));
        }

        if(Staf.getTargetRegion().equals("no")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("updatedUserInformation.firstName"),
                    testDataManager.getTestInputRegionData("updatedUserInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("updatedUserInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("updatedUserInformation.mobileNumber"));
        }

        if(Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("ie")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("userInformation.title"),
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }

        if(Staf.getTargetRegion().equals("nl")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }

    }

    @Step("Customer is directed to the location selector page")
    public void verifyLocationPage() {
        fabrLocationStepLib.assertCancelAndGoBanner();
    }

    @Step("Clicks on cancel and go back link")
    public void clickCancelAndGoBackLink() {
        fabrLocationStepLib.clickCancelAndGoLink();
    }

    @Step("Enter personal details for child eye test")
    public void enterPersonalDetailsForChildEyeTest() {
          emailAddress=emailTestingHandler.generateEmailAddress(serverDomain);
          if(Staf.getTargetRegion().equals("uk") ||Staf.getTargetRegion().equals("nl")) {
              fabrPersonalDetailsLib.completePersonalDetailsForm(
                      testDataManager.getTestInputRegionData("userInformation.title"),
                      testDataManager.getTestInputRegionData("userInformation.firstName"),
                      testDataManager.getTestInputRegionData("userInformation.lastName"),
                      testDataManager.getTestInputRegionData("userInformation.postCode"),
                      Integer.parseInt(testDataManager.getTestInputRegionData("childUserInformation.age")),
                      emailAddress,
                      testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
          }
          if(Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("ie")){
              fabrPersonalDetailsLib.completePersonalDetailsForm(
                      testDataManager.getTestInputRegionData("userInformation.title"),
                      testDataManager.getTestInputRegionData("userInformation.firstName"),
                      testDataManager.getTestInputRegionData("userInformation.lastName"),
                      Integer.parseInt(testDataManager.getTestInputCommonData("childUserInformation.age")),
                      emailAddress,
                      testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
          }
        if(Staf.getTargetRegion().equals("no")){
            fabrPersonalDetailsLib.completePersonalDetailsFormForNO(
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    testDataManager.getTestInputRegionData("userInformation.postCode"),
                    Integer.parseInt(testDataManager.getTestInputCommonData("childUserInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }
    }

    @Step("Verify child details on recap page")
    public void verifyChildDetailsAndContinueWithBooking() {
        final String title = testDataManager.getTestInputCommonData("userInformation.title");
        final String firstName = testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userInformation.lastName");
        final String email = testDataManager.getTestInputCommonData("userInformation.email");
        final String mobileno = testDataManager.getTestInputCommonData("userInformation.mobileNumber");
        fabrRecapStepLib.assertRecapPageIsDisplayed();
        fabrRecapStepLib.assertCustomerName(title, firstName, lastName);
        fabrRecapPage.recapCustomerEmailAddressISDisplayed(emailAddress);
        fabrRecapStepLib.clickConfirmYourBooking();
    }

    @Step("Continue with booking in personal details page")
    public void continueWithBookingInPersonalDetailsPage() {
        fabrPersonalDetailsLib.clickContinueBookingButton();
    }

    @Step("Verify validation message for wrong appointment type selection")
    public void verifyValidationMessageForWrongAppointmentSelection() {
        fabrPersonalDetailsLib.assertPersonalDetailsDOBErrorTitle();
    }

    @Step("verify select another appointment link is available")
    public void verifyChangeAppointmentTypeLinkIsAvailable() {
        fabrPersonalDetailsLib.assertChangeAppointmentTypeLink();
    }

    @Step("Click on select another appointment type")
    public void clickAnotherAppointmentTypeLink() {
        fabrPersonalDetailsLib.clickOnChangeAppointmentTypeLink();
    }

    @Step("Customer click on other store link in DTP")
    public void clickOtherStoreLinkInDTP() {
        fabrDateAndTimeStepLib.clickCheckOutOtherStoreLink();
    }

    @Step("Customer clicks on later link to select future date and time for appointment")
    public void clickOnLaterIconForDateAndTimeSelection() {

        fabrDateAndTimeStepLib.clickLaterTimeSlotsIcon();
    }

    @Step("Verify no appointment message appears")
    public void verifyCalendarNoAvailabilityPeriodBannerTitleDisplayed() {
        fabrDateAndTimeStepLib.assertCalendarNoAvailabilityPeriodBannerTitle();
    }

    @Step("Verify other Store link is displayed")
    public void otherStoreLinkIsAvailable() {
        fabrDateAndTimeStepLib.assertOtherStoreLink();
    }

    @Step("Verify error message for required fields in personal details page")
    public void verifyErrorMessageIsDisplayedForRequiredFields() {
        fabrPersonalDetailsLib.assertErrorBannerListItems();
    }

    @Step("Click on location using breadcrumb")
    public void clickLocationBreadcrumb() {
        fabrRecapStepLib.clickLocationBreadcrumb();
    }

    @Step("Click on Appointment Type using breadcrumb")
    public void clickAppointmentTypeBreadcrumb() {
        fabrRecapStepLib.clickAppointmentTypeBreadcrumb();

    }

    @Step("Click on Date and Time using breadcrumb")
    public void clickDateAndTimeBreadcrumb() {
        fabrRecapStepLib.clickDateAndTimeBreadcrumb();
    }

    @Step("Click on Personal Details using breadcrumb")
    public void clickPersonalDetailsBreadcrumb() {
        fabrRecapStepLib.clickPersonalDetailsBreadcrumb();
    }

    @Step("Click cancel and go link in location page")
    public void clickCancelAndGoInLocationPage() {
        fabrLocationStepLib.clickCancelAndGoLink();
    }

    @Step("Click cancel and go link in Appointment Type page")
    public void clickCancelAndGoInAppointmentTypePage() {
        fabrAppointmentTypeStepLib.clickCancelAndGoBackButton();
    }

    @Step("Click cancel and go link in date and time page")
    public void clickCancelAndGoLinkInDateAndTimePage() {
        fabrDateAndTimeStepLib.clickCancelAndGoLink();
    }

    @Step("Click cancel and go back link in Personal details page")
    public void clickCancelAndGOBackLinkInPersonaldetailsPage() {
        fabrPersonalDetailsLib.clickCancelAndGoBackLink();
    }

    @Step("Verify recap page for personal data")
    public void verifyPersonalDataInRecapPage() {
        final String mobileno = testDataManager.getTestInputCommonData("userInformation.mobileNumber");
        fabrRecapPage.recapCustomerEmailAddressISDisplayed(emailAddress);
    }

    @Step("Select future time slot for booking")
    public void selectLaterTimeSlot() {
        fabrDateAndTimeStepLib.clickLaterTimeSlotsIcon();
    }

    @Step("Click on Hearing services in appointment type page")
    public void clickOnHearingServices() {
        fabrAppointment.clickHearingServices();
    }

    @Step("Choose hearing test appointment type")
    public void chooseHearingTestAppointmentType() {
        fabrAppointment.clickHearingTest();
        fabrAppointment.clickBookASlotButton();
    }

    @Step("Enter personal details for audiology test")
    public void enterPersonalDetailsforAudiologyTest() {
        emailAddress=emailTestingHandler.generateEmailAddress(serverDomain);
        if(Staf.getTargetRegion().equals("uk")){
            fabrPersonalDetailsLib.completePersonalDetailsFormForAudiology(
                    testDataManager.getTestInputRegionData("userInformation.title"),
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }

        if(Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("ie")){
            fabrPersonalDetailsLib.completePersonalDetailsForm(
                    testDataManager.getTestInputRegionData("userInformation.title"),
                    testDataManager.getTestInputRegionData("userInformation.firstName"),
                    testDataManager.getTestInputRegionData("userInformation.lastName"),
                    Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
                    emailAddress,
                    testDataManager.getTestInputRegionData("userInformation.mobileNumber"));
        }
    }

    @Step("Verify audiology details on recap page")
    public void verifyAudiologyDetailsAndContinueWithBooking() {
        final String title = testDataManager.getTestInputCommonData("userInformation.title");
        final String firstName = testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userInformation.lastName");
        final String email = testDataManager.getTestInputCommonData("userInformation.email");
        final String mobileno = testDataManager.getTestInputCommonData("userInformation.mobileNumber");
        fabrRecapStepLib.assertRecapPageIsDisplayed();
        fabrRecapStepLib.assertCustomerName(title, firstName, lastName);
        fabrRecapPage.recapCustomerEmailAddressISDisplayed(emailAddress);
        fabrRecapPage.recapCustomerMobileNumberISDisplayed(mobileno);
        fabrRecapStepLib.clickConfirmYourBooking();
    }

    @Step("Choose Hearing test and hearing aid consultation appointment type")
    public void chooseHearingTestAndHearingAidConsultationAppointmentType() {
           fabrAppointment.clickHearingTestAndHearingAidConsultation();
           fabrAppointment.clickBookASlotButton();
    }

    @Step("Choose Earwax Removal appointment type")
    public void chooseEarwaxRemovalAppointmentType() {
          fabrAppointment.clickEarwaxRemoval();
          fabrAppointment.clickBookASlotButton();
    }

    @Step("Re enter personal details for audiology")
    public void reEnterAudiologyPersonalDetailsInRecapPage() {
        fabrPersonalDetailsLib.completePersonalDetailsFormForAudiology(testDataManager.getTestInputCommonData("updatedUserInformation.title"), testDataManager.getTestInputCommonData("updatedUserInformation.firstName"), testDataManager.getTestInputCommonData("updatedUserInformation.lastName"), Integer.parseInt(testDataManager.getTestInputCommonData("updatedUserInformation.age")), testDataManager.getTestInputCommonData("updatedUserInformation.email"), testDataManager.getTestInputCommonData("updatedUserInformation.mobileNumber"));
    }


    @Step("Input personal details for RAF booking")
    public void inputRAFPersonalDetailsForBooking() {

        final String dateAndTime=testDataManager.getTestInputCommonData("rafUserInformation.dateAndTime");
        final String title=testDataManager.getTestInputCommonData("rafUserInformation.title");
        final String firstName=testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName=testDataManager.getTestInputCommonData("userInformation.lastName");
        final String mobileNumber=testDataManager.getTestInputCommonData("rafUserInformation.mobileNumber");
        final String email=testDataManager.getTestInputCommonData("userInformation.email");

        if(Staf.getTargetRegion().equals("au")){
            fabrRAFAppointmentTypeStepLib.inputRAFPersonalDetailsForBooking(dateAndTime,firstName,lastName,mobileNumber,email);
        }
        else if(Staf.getTargetRegion().equals("eses")){
            final String esesTitle=testDataManager.getTestInputCommonData("rafUserInformation.esesTitle");
            fabrRAFAppointmentTypeStepLib.inputRAFPersonalDetailsForBooking(dateAndTime,esesTitle,firstName,lastName,mobileNumber,email);
        }
        else {
            fabrRAFAppointmentTypeStepLib.inputRAFPersonalDetailsForBooking(dateAndTime,title,firstName,lastName,mobileNumber,email);
        }
    }

    @Step("assert booking unavailability banner is displayed")
    public void assertBookingUnavailabilityBannerTitle() {
        fabrAppointmentTypeStepLib.assertBookingUnavailabilityBannerTitle();
    }

    @Step("Click on request an appointment button")
    public void clickRequestAnAppointmentButton() {
        fabrAppointmentTypeStepLib.clickRequestAnAppointmentButton();
      //  fabrAppointmentTypeStepLib.acceptCookie();
    }

    @Step("Select hearing test for RAF booking journey")
    public void clickHearingTestForRAF() {
        fabrRAFAppointmentTypeStepLib.clickHearingTest();
    }

    @Step("click on submit button for RAF booking journey")
    public void clickRAFSubmitButton() {
        fabrRAFAppointmentTypeStepLib.clickOnSubmitButtonForRAFBooking();
    }

    @Step("verify booking confirmation for RAF")
    public void verifyRAFBooking() {
        fabrRAFThankYouStepLib.assertAppointmentConfirmationHeading();
        fabrRAFThankYouStepLib.assertAppointmentRAFContainer();
    }

    @Step("Select adult eye test for RAF booking journey")
    public void clickRAFAdultEyeTest() {
         fabrRAFAppointmentTypeStepLib.clickAdultSightTest();
    }

    @Step("click on store details link")
    public void clickStoreDetails() {
        fabrLocationStepLib.clickStoreDetails();
    }

    @Step("verify that store general information is displayed")
    public void verifyStoreGeneralInformation() {
        fabrStoreStepLib.assertStoreGeneralInformation();
    }

    @Step("Click on book appointment in store page")
    public void clickBookAppointmentInStorePage() {
        fabrStoreStepLib.clickBookAppointment();
    }

    @Step("Click on change appointment date and time in booking confirmation page")
    public void clickChangeAppointmentDateAndTimeInBookingConfirmationPage() {
        fabrBookingConfirmationSteplib.clickChangeAppointmentDateAndTimeLink();
    }

    @Step("Accept cookies on amend calendar booking confirmation page")
    public void acceptCookiesForAmendCalenderBookingConfirmationPage() {
        navigateTo.theUserAcceptCookies();
    }

    @Step("Click on keep current appointment in calender amend page from boking confirmation")
    public void clickOnKeepCurrentAppointment() {
        emailTestingHandler.switchToChildWindow();
        //Need to recheck without wait of 4000 milli seconds
         /*Cookies is not displayed for now
                acceptCookiesForAmendCalenderBookingConfirmationPage();*/
        //   emailTestingHandler.scrollDown();
        fabrAmendCalendarBookingConfirmationStepLib.clickOnKeepCurrentAppointment();
        emailTestingHandler.switchToOriginalWindow();
    }

    @Step("Click on cancel booking on booking confirmation page")
    public void clickCancelBookingInBookingConfirmationPage() {
        fabrBookingConfirmationSteplib.clickCancelBooking();
    }

    @Step("verify that recap appointment cancellation title is displayed")
    public void verifyAmendCancellationTitleIsDisplayed() {

    }

    @Step("verify that amend cancellation page title is displayed")
    public void verifyAmendCancellationTitle() {
        fabrBookingCancelationStepLib.assertAppointmentCancellationTitle();
    }

    @Step("click on amend date and time button")
    public void clickChangeDateAndTimeInBookingCancellationPage() {
        fabrBookingCancelationStepLib.clickChangeDateAndTimeButton();
    }

    @Step("verify amend calender title is available")
    public void amendCalenderTitle() {
        fabrBookingCancelationStepLib.assertAmendCalenderTitle();
    }

    @Step("Select first slot to amend date and time")
    public void selectFirstSlotForDateAndTimeChange() {
        fabrBookingCancelationStepLib.selectFirstSlot();
    }

    @Step("Select second timeslot to amend date and time ")
    public void selectSecondSlotForDateAndTimeChange() {
        fabrBookingCancelationStepLib.selectSecondSlot();
    }

    @Step("click on change appointment button in amend page")
    public void clickChangeAppointmentInAmendCalender() {
        fabrBookingCancelationStepLib.clickChangeAppointment();
    }

    @Step("verify amend recap title is available")
    public void assertAmendRecapTitle() {
        fabrAmendRecapStepLib.assertAmendRecapTitle();
    }

    @Step("click on confirm your booking button")
    public void clickConfirmYourBookingInAmendRecapPage() {
        fabrAmendRecapStepLib.clickAmendRecapConfirmButton();
    }

    @Step("verify amend confirmation header title is available")
    public void verifyAmendConfirmationHeaderTitle() {
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        fabrAmendConfirmationStepLib.assertConfirmationHeaderTitle();
    }

    @Step("verify amend confirmation header sub title is available")
    public void verifyAmendConfirmationSubTitle() {
        fabrAmendConfirmationStepLib.assertConfirmationHeaderSubTitle();
    }

    @Step("click cancel appointment link in booking cancellation page")
    public void clickCancelAppointmentLink() {
        fabrBookingCancelationStepLib.clickCancelAppointmentButton();
    }

    @Step("click on keep current booking link in booking cancellation page")
    public void clickKeepCurrentBookingInBookingCancellationPage() {
        fabrBookingCancelationStepLib.clickKeepCurrentAppointmentButton();
    }

    @Step("verify header confirmation title on appointment kept page")
    public void verifyHeaderConfirmationTitleOnAppointmentkeptPage() {
        fabrAppointmentKeptStepLib.assertHeaderConfirmationTitle();
    }

    @Step("verify appointment cancelled header title is displayed")
    public void verifyAppointmentCancelledPageTitle() {
        //Need to recheck without wait of 2000 milli seconds
        fabrAppointmentCancelledStepLib.assertAppointmentCancelledHeading();
    }


    @Step("Amend appointment date and time in booking cancellation page")
    public void amendConfirmedBookingDateAndTimeInCancellationPage() {
        emailTestingHandler.switchToChildWindow();
        /* Cookie is not displayed for now
                 acceptCookiesForAmendCalenderBookingConfirmationPage(); */
        verifyAmendCancellationTitle();
                /* In local execution scrollDown is required
                scrollDown();*/
        clickChangeDateAndTimeInBookingCancellationPage();
        selectFirstSlotForDateAndTimeChange();
        clickChangeAppointmentInAmendCalender();
        assertAmendRecapTitle();
        clickConfirmYourBookingInAmendRecapPage();
        verifyAmendConfirmationHeaderTitle();
        verifyAmendConfirmationSubTitle();
        emailTestingHandler.switchToOriginalWindow();
    }

    @Step("Keep current appointment journey using cancel booking link on confirmation page")
    public void keepCurrentBookingJourneyUsingCancelBookingOnConfirmationPage() {
        emailTestingHandler.switchToChildWindowForBooking();
        /*cookies are not coming now
                acceptCookiesForAmendCalenderBookingConfirmationPage(); */
        verifyAmendCancellationTitle();
        clickChangeDateAndTimeInBookingCancellationPage();
        amendCalenderTitle();
        //   emailTestingHandler.scrollDown();
        clickKeepCurrentBookingInBookingCancellationPage();
        verifyHeaderConfirmationTitleOnAppointmentkeptPage();
        emailTestingHandler.switchToOriginalWindowForBooking();
    }

    @Step("cancel appointment using canel appointment link in amend page")
    public void cancelBookingUsingWhenCard() {
        emailTestingHandler.switchToChildWindow();
        /*Cookie is not coming for now
                acceptCookiesForAmendCalenderBookingConfirmationPage(); */
        verifyAmendCancellationTitle();
        // need to implement the scroll functionality
        clickCancelMyBookingInBookingCancelationPage();
        clickCancelAppointmentLink();
        verifyAppointmentCancelledPageTitle();
        emailTestingHandler.switchToOriginalWindow();
    }

    @Step("amend appointment from amend confirmation page")
    public void amendAppointmentDateAndTimeFromAmendConfirmationPage() {
        fabrAmendConfirmationStepLib.amendAppointmentAgain();
    }

    @Step("verify when subtitle is available in amend confirmation page")
    public void verifyWhenSubtitleInAmendConfirmationPage() {
        fabrAmendConfirmationStepLib.assertWhenSubtitle();
    }

    @Step("cancel booking in amend confirmation page")
    public void cancelBookingInAmendConfirmationPage() {
       emailTestingHandler.switchToChildWindow();
         fabrAmendConfirmationStepLib.cancelBookingfromAmendConfirmation();

    }

    @Step("Amend amended appointment date and time on booking confirmation page")
    public void amendAmendedBookingDateAndTimeInConfirmationPage() {
        emailTestingHandler.switchToChildWindow();
       /*Cookies are not displaying for now
                acceptCookiesForAmendCalenderBookingConfirmationPage();*/
        amendCalenderTitle();
        selectFirstSlotForDateAndTimeChange();
        clickChangeAppointmentInAmendCalender();
        clickConfirmYourBookingInAmendRecapPage();
        amendAppointmentDateAndTimeFromAmendConfirmationPage();
        //Need to update below windows handling code with the latest windows handling method
        ArrayList<String> newTab = new ArrayList<String>(getDriver().getWindowHandles());
        getDriver().switchTo().window(newTab.get(2));
        //Need to recheck without wait of 2000 milli seconds
        selectSecondSlotForDateAndTimeChange();
        clickChangeAppointmentInAmendCalender();
        clickConfirmYourBookingInAmendRecapPage();
        verifyAmendConfirmationHeaderTitle();
        emailTestingHandler.switchToOriginalWindow();
    }

    @Step("cancel amended appointment booking confirmation page")
    public void cancelAmendedBookingInConfirmationPage() {
        emailTestingHandler.switchToChildWindow();
        /*Cookies is not displayed for now  acceptCookiesForAmendCalenderBookingConfirmationPage(); */
        amendCalenderTitle();
        selectFirstSlotForDateAndTimeChange();
        clickChangeAppointmentInAmendCalender();
        assertAmendRecapTitle();
        clickConfirmYourBookingInAmendRecapPage();
        verifyAmendConfirmationHeaderTitle();
        verifyAmendConfirmationSubTitle();
        verifyWhenSubtitleInAmendConfirmationPage();
        amendAppointmentDateAndTimeFromAmendConfirmationPage();
        emailTestingHandler.switchToChildWindow();
        cancelBookingInAmendConfirmationPage();
        clickCancelAppointmentLink();
        emailTestingHandler.switchToOriginalWindow();
    }

    @Step("click cancel booking in booking cancellation page")
    public void clickCancelBookingInBookingCancelationPage() {
        fabrBookingCancelationStepLib.clickCancelBooking();
    }

    @Step("click cancel my booking in booking cancelation page")
    public void clickCancelMyBookingInBookingCancelationPage() {
        fabrBookingCancelationStepLib.clickCancelMyBooking();
        //Need to recheck without wait of 2000 milli seconds
    }

    @Step("Choose eye test with contact lens health appointment")
    public void chooseEyeTestWithContactLensHealthCheck() {
        final String appointmentType = testDataManager.getTestInputRegionData("appointmentData.appointmentType.eyeTestWithContactLensHealthCheck");
        if (appointmentType.equals("Eye test with contact lens health check")) {
            fabrAppointment.clickEyeTestWithContactLensHealthCheck();
        } else {
            logger.info("Not a valid appointment type");
        }
        fabrAppointment.clickBookASlotButton();
    }

    @Step("Click on 'No' radio button and proceed to next page")
    public void clickOnNoAndProceed() {
        fabrAppointmentTypeStepLib.clickATTNoButton();
    }

    @Step("Click on 'Yes' radio button and proceed to next page")
    public void clickOnYesAndProceed() {
        fabrAppointmentTypeStepLib.clickATTYesButton();
    }

    @Step("Click on Choose date and time and proceed")
    public void clickChooseDateAndTime() {
        fabrAppointmentTypeStepLib.clickATTChooseDateAndTimeButton();
    }

    @Step("Input personal details and validate booking")
    public void inputPersonalDetailsAndValidateBooking() {
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
    }

    @Step("Choose contact lens appointment type")
    public void chooseContactLensAppointmentType() {
         fabrAppointmentTypeStepLib.clickContactLensAppointment();
         fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Click on go to homepage")
    public void clickOnGotToHomePage() {
        fabrAppointmentTypeStepLib.clickOnGotToHomePage();
        closeBrowser();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore4() {
       final String targetEnvironment=Staf.getTargetEnvironmentWithRegion()[0];
       if(Staf.getTargetRegion().equals("uk") || Staf.getTargetRegion().equals("no") || Staf.getTargetRegion().equals("ie") || Staf.getTargetRegion().equals("nl")) {
           navigateTo.theUserAcceptCookies();
       }
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore4();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore6() {
        String targetEnvironment=Staf.getTargetEnvironmentWithRegion()[0];
        navigateTo.theUserAcceptCookies();
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        if(targetEnvironment.equals("beta")) {
            navigateTo.clickOnBookAppointmentButton();
        }
        fabrLocationStepLib.inputStore6();
        fabrLocationStepLib.clickSearch();
    }

    @Step
    public void findLeedsAlbionStreetStore() {
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.inputLeedsAlbionStreet();
        fabrLocationStepLib.clickSearch();
    }

    @Step
    public void findLeedsAlbionStreetStoreWithoutCookies() {
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputLeedsAlbionStreet();
        fabrLocationStepLib.clickSearch();
        //Need to recheck without wait of 4000 milli seconds
    }

    @Step("Choose contact lens appointment and trial type")
    public void chooseCLConsultationAndTrialType() {

           fabrAppointmentTypeStepLib.clickContactLensConsultationAndTrial();
           fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Choose Contact lense health check appointment")
    public void chooseContactLensHealthCheck() {
         fabrAppointment.clickContactlensHealthCheck();
         fabrAppointment.clickBookASlotButton();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore4WithoutCookies() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputStore4();
        fabrLocationStepLib.clickSearch();
       // locationPageSteps.waitForElementTextToAppear(locationPageSteps.getSearchedStoreText(),testDataManager.getTestInputRegionData("storeName.store4"));

        //Need to recheck without wait of 4000 milli seconds
    }

    @Step("[STAC+OCT]Customer tries to change appointment type from recap page switches from Adult eye test triage category to CL triage category")
    public void customerTriesToChangeAppointmentTypeFromAdultToCLTriageCategory(){
        //TODO: need to update test cases once ATT functionality is available and mailosaur account is activated
        openFabrHome();
        findStore2();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnYesAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        clickOnChangeAppointmentLink();
        verifyAppointmentPage();
        chooseCLConsultationAndTrialType();
        //clickOnYesAndProceed();
        //clickOnYesAndProceed();
        //clickOnYesAndProceed();
        //clickChooseDateAndTime();
        selectNewDateAndTime();
        verifyCustomerDetails();
        verifyRecapPage();
        confirmBooking();
        checkEmailInMailosaur();
    }

    @Step("Customer tries to change location from recap page from STAC to Non STAC store")
    public void customerChangesLocationFromSTACToNonSTACStore(){
        //TODO: need to update test cases once ATT functionality is available and mailosaur account is activated
        openFabrHome();
        findStore2();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnYesAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        clickOnChangeLocationLink();
        verifyLocationPage();
        findStore4WithoutCookies();
        selectStore();
        chooseAdultEyeTestAppointmentType();
        selectTimeSlotForBooking();
        continueWithBookingInPersonalDetailsPage();
        verifyRecapPage();
        confirmBooking();
        checkEmailInMailosaur();
    }

    @Step
    public void checkEmailInMailosaur() {
       if(Staf.getTargetRegion().equals("uk") || Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("nl") || Staf.getTargetRegion().equals("no")|| Staf.getTargetRegion().equals("ie")) {
           //Need to wait for the mail to be available in mailosaur dashboard
              emailTestingHandler.checkEmail(emailAddress, serverID);
        }
     }

    @Step("Click on amend link in email")
    public void clickOnAmendLinkInEmail() {
      emailTestingHandler.clickOnAmendLinkInEmail(serverID,emailAddress);
    }

    @Step
    public void clickOnCancelLinkInEmail() {
        emailTestingHandler.clickOnCancelLinkInEmail(serverID,emailAddress);
    }

    @Step
    public void clickConfirmBooking() {
        fabrRecapStepLib.clickConfirmYourBooking();
    }

    @Step
    public void appointmentCancellationJourneyUsingCancelLinkInEmail(){
        openFabrHome();
        findStore10();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        clickConfirmBooking();
        clickOnCancelLinkInEmail();
    }

    @Step
    public void appointmentAmendmentJourneyUsingCancelLinkInEmail(){
        openFabrHome();
        findStore1();
        selectStore();
        chooseAdultEyeTestAppointmentType();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        clickConfirmBooking();
        clickCancelToAmendTheAppointment();
    }

    @Step
    public void clickCancelToAmendTheAppointment() {
       emailTestingHandler.clickCancelToAmendTheAppointment(serverID,emailAddress);
    }

    @Step
    public void validateBookingDataAndCheckMailosaurForEmail(){
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
        //Check email in mailosaur is not working fine working with mailosaur team to resolve it
        checkEmailInMailosaur();
    }

    @Step
    public void confirmBookingAndValidateEmail(){
        confirmBooking();
       //check email in mailosaur is not working we are working with mailosaur team to resolve the issue
        checkEmailInMailosaur();
    }

    @Step
    public void keepCurrentAppointmentAndValidateEmailInMailosaur(){
        clickOnKeepCurrentAppointment();
        checkEmailInMailosaur();
    }

    @Step
    public void amendConfirmedBookingDateAndTimeAndValidateEmailInMailosaur(){
        amendConfirmedBookingDateAndTimeInCancellationPage();
        checkEmailInMailosaur();
    }

    @Step
    public void keepCurrentBookingJourneyUsingCancelAndValidateEmailInMailosaur(){
        keepCurrentBookingJourneyUsingCancelBookingOnConfirmationPage();
        checkEmailInMailosaur();
    }

    @Step
    public void cancelBookingUsingWhoCardAndValidateEmailInMailosaur(){
        cancelBookingUsingWhenCard();
        checkEmailInMailosaur();
    }

    @Step
    public void amendAmendedBookingDateAndTimeAndValidateEmailInMailosaur(){
        amendAmendedBookingDateAndTimeInConfirmationPage();
        checkEmailInMailosaur();
    }

    @Step
    public void confirmBookingAndCloseBrowser() {
        confirmBooking();
    }

    @Step
    public void verifyCorrectStoreAppointmentTypesDisplayed() {
        fabrAppointmentTypeStepLib.verifySTAACANDOCTAppointmentTypes();
    }

    @Step
    public void verifyAppointmentTypeForNonSTACAndNonOCT() {
        fabrAppointment.verifyNonSTACAnsNonOCTAppointmentTypes();
    }

    @Step
    public void cancelBookingAndValidateMailInMailosaur() {
        emailTestingHandler.switchToChildWindowForBooking();
        /*cookies are not coming now acceptCookiesForAmendCalenderBookingConfirmationPage();*/
        verifyAmendCancellationTitle();
        clickCancelAppointmentLink();
        fabrAppointmentCancelledStepLib.assertAppointmentCancelledHeading();
        emailTestingHandler.switchToOriginalWindowForBooking();
    }

    @Step("Performs a text search or geolocation search")
    public void findFordeStore() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.inputFordeStore();
        fabrLocationStepLib.clickSearch();
    }

    public void openFabrHomeWithMonatateCookie() {
        navigateTo.theHomePage();
        monetateCookiesSteps.givenTheFeatureFlagIsEnabled("FBMVP-598",100);
        waitABit(5000);
    }

    public void openFabrHomeWithOldAppointmentTypes() {
        navigateTo.theHomePage();
        monetateCookiesSteps.givenTheFeatureFlagIsEnabled("FBMVP-598",10);
        waitABit(5000);
    }

    public void closeSession() {
        if (getDriver() != null) {
            logger.info(("Destroy the web driver instance"));
            getDriver().quit();
        }
    }
    @Step("Click hearing appointment")
    public void clickHearingAppointment() {

        fabrAppointment.clickHearingAppointment();
        fabrAppointment.clickBookASlotButton();
    }

    @Step("Click on Yes for Audiology ATT flow")
    public void clickAudiologyATTYesOption(){
        fabrAppointment.clickAudiologyATTYesOption();
    }

    @Step("Click on No for Audiology ATT flow")
    public void clickAudiologyATTNoOption(){
        fabrAppointment.clickAudiologyATTNoOption();
    }

    @Step("Choose Hearing protection consultation appointment type")
    public void chooseHearingProtectionConsultationAppointmentType() {
        fabrAppointment.clickHearingProtectionConsultation();
        fabrAppointment.clickBookASlotButton();
    }

    @Step("Click earwax removal appointment")
    public void clickEarwaxRemovalAppointment() {
        fabrAppointment.clickEarwaxRemovalAudiologyATT();
        fabrAppointment.clickBookASlotButton();
    }

    @Step("click I Understand for earwax removal")
    public void clickIUnderstandForEarwaxRemoval(){
        fabrAppointment.clickIUnderstandForEarwaxRemoval();
    }

    @Step("Validate NHS Hearing Aids page header")
    public void validateNHSHearingAidsPageHeading(){

        fabrNHSHearingAidsPage.assertNHSHearingAidsPageHeading();
    }

    @Step("click go back for earwax removal")
    public void clickGoBackForEarwaxRemoval(){
        fabrAppointment.clickGoBackForEarwaxRemoval();
    }

    @Step("Validate ATTContainer Question Headline")
    public void validateATTContainerQuestionHeadline(){
        fabrAppointment.validateATTContainerQuestionHeadline();
    }

    @Step("Validate previous button")
    public void validatePreviousButton(){
        fabrAppointment.validatePreviousButton();
    }

    @Step("Click on close button")
    public void clickOnCloseButton(){
        fabrAppointment.clickOnCloseButton();
    }

    @Step("Click on Previous link")
    public void clickOnPreviousLink(){
        fabrAppointment.clickPreviousLink();
    }

    @Step("validate Earwax RemovalAudiology ATT is selected")
    public void assertEarwaxRemovalAudiologyATTIsSelected(){
        fabrAppointment.assertEarwaxRemovalAudiologyATTIsSelected();
    }

    @Step("Choose adult eye test ATT appointment type")
    public void chooseAdultEyeTestATTAppointmentType() {
        fabrAppointment.clickAdultEyeTestATT();
        fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore10() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore10();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore12() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        fabrLocationStepLib.inputStore12();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore12WithoutCookies() {
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputStore12();
        fabrLocationStepLib.clickSearch();
       locationPageSteps.waitForElementTextToAppear(locationPageSteps.getSearchedStoreText(),testDataManager.getTestInputRegionData("storeName.store12"));
    }

    @Step("Performs a text search or geolocation search")
    public void findStore3WithoutCookies() {
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputStore3();
        fabrLocationStepLib.clickSearch();
   }

    @Step
    public void confirmPersonalDetailsAndBooking(){
        continueWithBookingInPersonalDetailsPage();
        verifyRecapPage();
        confirmBookingAndValidateEmail();
    }

    @Step("User accept cookies for RAF page")
    public void acceptCookiesForRAFPage(){
        navigateTo.theUserAcceptCookies();
        emailTestingHandler.switchToChildWindow();
    }

    @Step("verify RAF appointment container")
    public void verifyRAFAppointmentContainerInformation(){
        fabrRAFThankYouStepLib.assertAppointmentRAFContainer();
    }


    @Step
    public void verifyDetailsAndConfirmBooking(){
        final String firstName = testDataManager.getTestInputRegionData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputRegionData("userInformation.lastName");
        final String mobileno = testDataManager.getTestInputRegionData("userInformation.mobileNumber");
        fabrRecapPage.recapCustomerEmailAddressISDisplayed(emailAddress);
        fabrRecapStepLib.clickConfirmYourBooking();
        confirmBooking();
        //check email in mailosaur is not working we are working with mailosaur team to resolve the issue
        checkEmailInMailosaur();
    }

    @Step("Appointment cancellation journey using cancel booking link on confirmation page")
    public void appointmentCancellationJourneyUsingLinkInEmail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
        clickCancelBookingInBookingConfirmationPage();
        cancelBookingAndValidateMailInMailosaur();
    }

    @Step("continue with booking and confirm booking data")
    public void continueWithBookingAndConfirm(){
        continueWithBookingInPersonalDetailsPage();
        verifyRecapPage();
        confirmBooking();
        checkEmailInMailosaur();
    }

    @Step("verify details and continue with optical booking")
    public void verifyDetailsAndContinueBooking(){
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
        checkEmailInMailosaur();
    }

    @Step("verify breadcrumb functionality")
    public void verifyBreadCrumbFunctionality(){
        clickLocationBreadcrumb();
        findStore4WithoutCookies();
        selectStore();
        verifyAppointmentTypeForNonSTACAndNonOCT();
        clickLocationBreadcrumb();
        findStore3WithoutCookies();
        selectStore();
        verifyCorrectStoreAppointmentTypesDisplayed();
    }

    @Step("Validate Hearing test booking journey - Audiology ATT journey")
    public void validateHearingTestBookingJourneyAudiologyATT(){
        openFabrHomeWithMonatateCookie();
        // TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickStoreDetails();
        verifyStoreGeneralInformation();
        clickBookAppointmentInStorePage();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

    @Step("Validate 'Hearing test and hearing aid consultation'  booking journey  - Audiology ATT journey")
    public void validateHearingTestAndHearingAidConsultationScenario2AudiologyATT(){
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTYesOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

    @Step("Need to update the test case")
    public void validateHearingTestAndHearingAidConsultationScenario1AudiologyATT() {

        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

     @Step("Validate 'Hearing test and hearing aid consultation'  booking journey  - Audiology ATT journey")
    public void validateHearingTestAndHearingAidConsultationBookingWhenATTIsEnable(){
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTYesOption();
        clickAudiologyATTYesOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
     }

     @Step("Validate 'Checkup for existing hearing aid wearer'  booking journey  - Audiology ATT journey")
    public void validateCheckupForExistingHearingAidWearerScenario1(){
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTYesOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
     }

    @Step("Validate 'Checkup for existing hearing aid wearer'  booking journey  - Audiology ATT journey")
    public void validateCheckupForExistingHearingAidWearerScenario2() {
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTYesOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTYesOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

    @Step("Validate 'Hearing aid Maintenance or repair'  booking journey  - Audiology ATT journey")
    public void validateHearingAidMaintenanceOrRepair(){
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickHearingAppointment();
        clickAudiologyATTYesOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTYesOption();
        clickAudiologyATTYesOption();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

    @Step("Validate 'NHS funded service Page  - Audiology ATT journey")
    public void validateNHSFundedServicePage(){
       openFabrHomeWithMonatateCookie();
       //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
       findStore9();
       selectStore();
       clickOnHearingServices();
       clickHearingAppointment();
       clickAudiologyATTNoOption();
       clickAudiologyATTYesOption();
       validateNHSHearingAidsPageHeading();
    }

    @Step("Validate 'Hearing protection consultation'  booking journey  - Audiology ATT journey")
    public void validateHearingProtectionConsultation(){
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        chooseHearingProtectionConsultationAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

    @Step("'Earwax removal booking journey Customer choose 'Yes' for triage Question")
    public void earwaxRemovalCustomerChooseYesForATT(){
       openFabrHomeWithMonatateCookie();
       //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
       findStore9();
       selectStore();
       clickOnHearingServices();
       clickEarwaxRemovalAppointment();
       clickAudiologyATTYesOption();
       clickChooseDateAndTime();
       selectTimeSlotForBooking();
       enterPersonalDetailsforAudiologyTest();
       continueWithBookingInPersonalDetailsPage();
       verifyDetailsAndContinueWithBooking();
       confirmBookingAndCloseBrowser();
    }

    @Step("'Earwax removal booking journey Customer choose 'No' for triage Question")
    public void earwaxRemovalCustomerChooseNoForATT() {
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickOnHearingServices();
        clickEarwaxRemovalAppointment();
        clickAudiologyATTNoOption();
        clickIUnderstandForEarwaxRemoval();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBookingAndCloseBrowser();
    }

    @Step("Earwax removal booking journey-Customer choose 'No' for triage Question and click 'Go back' CTA on model")
    public void earwaxRemovalCustomerChooseNoForATTAndClickGoBack(){
        openFabrHomeWithMonatateCookie();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore9();
        selectStore();
        clickStoreDetails();
        clickBookAppointmentInStorePage();
        clickOnHearingServices();
        clickEarwaxRemovalAppointment();
        clickAudiologyATTNoOption();
        clickGoBackForEarwaxRemoval();
        validateATTContainerQuestionHeadline();
        validatePreviousButton();
    }

    @Step("Earwax removal-Customer choose 'No' for triage Question and close model using 'x' ")
    public void earwaxRemovalCustomerChooseNoForATTAndCloseTheModelUsingCloseButton(){
       openFabrHomeWithMonatateCookie();
       //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
       findStore9();
       selectStore();
       clickStoreDetails();
       verifyStoreGeneralInformation();
       clickBookAppointmentInStorePage();
       selectStore();
       clickOnHearingServices();
       clickEarwaxRemovalAppointment();
       clickAudiologyATTNoOption();
       clickOnCloseButton();
       validateATTContainerQuestionHeadline();
       validatePreviousButton();
    }

    @Step("Earwax removal validate 'Previous' CTA ")
    public void earwaxRemovalValidatePreviousCTA(){
       openFabrHomeWithMonatateCookie();
       //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
       findStore9();
       selectStore();
       clickStoreDetails();
       verifyStoreGeneralInformation();
       clickBookAppointmentInStorePage();
       selectStore();
       clickOnHearingServices();
       clickEarwaxRemovalAppointment();
       clickAudiologyATTNoOption();
       clickIUnderstandForEarwaxRemoval();
       clickOnPreviousLink();
       validateATTContainerQuestionHeadline();
       assertEarwaxRemovalAudiologyATTIsSelected();
    }
    @Step("Select a store")
    public void selectAStore() {
        logger.info("click on book Appointment against searched store");
        fabrLocationStepLib.v3_bookOnlineInSelectedLocation();
    }

    @Step("Select RAF appointment type as Adult eye test")
    public void selectRAFAppointmentAs_AdultEyeTest() {
        if(Staf.getTargetRegion().equals("au")) {
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.eyeTest"));
        }
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.adultEyeTest"));
    }

    @Step("Select RAF appointment type as Contact lens initial appointment")
    public void selectRAFAppointmentAs_ContactLensInitialappointment(){
        if(Staf.getTargetRegion().equals("au")) {
            fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.contactLensAssessment"));
        }
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.contactLensInitialAppointment"));
    }

    @Step("Select RAF appointment type as child Eye test")
    public void selectRAFAppointmentAs_ChildEyeTest(){
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.childEyeTest"));
    }

    @Step("Select Raf Request an appointment tab")
    public void rafSelectRequestAnAppointmentTab(){
        fabrRAFAppointmentTypeStepLib.clickRafRequestAnAppointmentBtn();
    }

    @Step("Select RAF appointment type as Eye test")
    public void selectRAFAppointmentAs_EyeTest(){
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.eyeTest"));
    }

    @Step("Select RAF appointment type as Contact Lens Assessment")
    public void selectRAFAppointmentAs_ContactLensAssessment(){
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.contactLensAssessment"));
    }

    @Step("Select SAS appointment type as Contact lens consultation and trial")
    public void selectSASAppointmentAs_ContactLensConsultationAndTrial(){
        logger.info("select an appointment ContactLensConsultationAndTrial ");
        fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.contactLensConsultationAndTrial"));
        fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Select RAF appointment type as Adult sight test")
    public void selectRAFAppointmentAs_AdultSightTest(){
        logger.info("select an appointment Adult Sight Test ");
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.adultSightTest"));
    }

    @Step("Select RAF appointment type as Contact lens consultation and trial")
    public void selectRAFAppointmentAs_ContactLensConsultationAndTrial(){
        logger.info("select an appointment Contact Lens Consultation And Trial");
        fabrRAFAppointmentTypeStepLib.clickOnAppointment(testDataManager.getTestInputRegionData("rAFAppointmentData.appointmentType.contactLensConsultationAndTrial"));
    }

    @Step("Perform a RAF store search")
    public void findRAFStore() {
        logger.info("Search a RAF Store");
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.enterRAFStoreNameAndClickOnSearchButton();
    }

    @Step("Perform a SAS store search ")
    public void findSASStore() {
        logger.info("Search a SAS Store");
        String targetEnvironment=Staf.getTargetEnvironmentWithRegion()[0];
        navigateTo.theUserAcceptCookies();

        if(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("se"))
        {
            navigateTo.clickOnFindAStoreButton();
        }else {
            navigateTo.clickOnBookAppointmentButton();
        }

        fabrLocationStepLib.v3_inputSASStore();
        fabrLocationStepLib.v3_clickFind();
    }

    @Step("Select SAS appointment type as Eye Test")
    public void selectSASAppointmentAs_EyeOrAdultEyeTest(){
        logger.info("Select appointment type as Eye test");
        if(Staf.getTargetRegion().equals("ie")) {
            fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.adultEyeTest"));
            fabrAppointmentTypeStepLib.v3_selectMedicalCardAvailabilityAs(testDataManager.getTestInputRegionData("customerInfo.medicalCardAvailability"));
            fabrAppointmentTypeStepLib.v3_selectAppointmentCategoryAs(testDataManager.getTestInputRegionData("customerInfo.appointmentCategory"));
        }
        else if(Staf.getTargetRegion().equals("se")) {
            fabrAppointmentTypeStepLib.v3_selectEyeTestInAppointmentTypePage();
        }
        else
            fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.eyeTest"));
    }

    @Step("Select SAS appointment type as Contact Lens assessment")
    public void selectSASAppointmentAs_ContactLensAssessment(){
        logger.info("Select appointment type as Contact Lens Assessment");
        fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.contactLensAssessment"));
    }

    @Step("Select SAS appointment type as Adult sight Test")
    public void selectSASAppointmentAs_AdultSightTest(){
        logger.info("Select appointment type as Adult Sight Test");
        fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.adultEyeTest"));
        fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Select SAS appointment type as Child eye Test")
    public void selectSASAppointmentAs_ChildEyeTest(){
        logger.info("Select appointment type as Child eye test");
        if(Staf.getTargetRegion().equals("ie")){
            fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.childEyeTest"));
            fabrAppointmentTypeStepLib.clickBookASlotButton();
        }
        else {
            fabrAppointmentTypeStepLib.SelectAppointmentTypeAs(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.childEyeTest"));
            fabrAppointmentTypeStepLib.clickBookASlotButton();
        }
    }

    @Step("Click on Book appointment button in Appointment Type page")
    public void clickOnBookAppointmentButtonInAppointTypePage(){
        logger.info("Click on Book Appointment button in Appointment type page");
        if(!(Staf.getTargetRegion().equals("ie")||Staf.getTargetRegion().equals("nz"))){
            fabrAppointmentTypeStepLib.v3_clickOnBookAppointmenButton();
        }
    }

    @Step("Click on Book appointment button in Appointment Type page")
    public void clickOnBookAppointmentButtonInAppointTypePageV4(){
        fabrAppointmentTypeStepLib.v4_clickOnBookAppointmenButton();
    }

    @Step("Enter mandatory personal details")
    public void enterMandatoryPersonalDetails() {
        logger.info("Enter mandatory personal details ");
        emailAddress = emailTestingHandler.generateEmailAddress(serverDomain);
        final String title = testDataManager.getTestInputCommonData("userInformation.title");
        final String firstName = testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userInformation.lastName");
        final String mobileNo = testDataManager.getTestInputCommonData("userInformation.mobileNumber");
        final String mobileNo2=testDataManager.getTestInputCommonData("userInformation.mobileNumber2");
        final String mobileNo5=testDataManager.getTestInputCommonData("userInformation.mobileNumber5");
        final Integer age=Integer.parseInt(testDataManager.getTestInputCommonData("userInformation.age"));
        final String dob=testDataManager.getTestInputCommonData("userInformation.dob");
        final String postCode=testDataManager.getTestInputCommonData("userInformation.postCode");

        if(Staf.getTargetRegion().equals("au")) {
            mobileNumber=mobileNo2;
            fabrPersonalDetailsLib.v3_completePersonalDetailsForm(title,firstName,lastName,age,emailAddress,mobileNo2);
        }
        else if(Staf.getTargetRegion().equals("nl")) {
            mobileNumber=mobileNo5;
            fabrPersonalDetailsLib.v3_completePersonalDetailsForm(firstName,lastName,age,emailAddress,mobileNo5);
        }
        else if(Staf.getTargetRegion().equals("no")) {
            final String postCodeNoRegion=testDataManager.getTestInputRegionData("userInformation.postCode");
            final String mobileNoRegionNo=testDataManager.getTestInputRegionData("userInformation.mobileNumber");
            mobileNumber=mobileNoRegionNo.replace("+47","");
            fabrPersonalDetailsLib.v3_completePersonalDetailsForm(firstName,lastName,age,emailAddress,mobileNoRegionNo,postCodeNoRegion);
        }
        else if(Staf.getTargetRegion().equals("ie")){
            fabrPersonalDetailsLib.v3_completePersonalDetailsForm(title, firstName,lastName, age,emailAddress,mobileNo);
            mobileNumber=mobileNo;
        }
        else if(Staf.getTargetRegion().equals("nz")){
            mobileNumber=mobileNo;
            fabrAppointmentTypeStepLib.v3_enterPersonalDetails(firstName,lastName,dob,emailAddress,mobileNo);
        }
        else if(Staf.getTargetRegion().equals("se")){
            final String firstNameLastName=testDataManager.getTestInputCommonData("userInformation.firstNameLastName");
            final String mobileNumber3=testDataManager.getTestInputCommonData("userInformation.mobileNumber3");
            fabrAppointmentTypeStepLib.v3_enterPersonalDetails(firstNameLastName,emailAddress,mobileNumber3);
            mobileNumber=mobileNumber3;
        }
        else if(Staf.getTargetRegion().equals("uk")){
            final String mobileNumber4=testDataManager.getTestInputCommonData("userInformation.mobileNumber4");
            fabrPersonalDetailsLib.v3_completePersonalDetailsForm(title,firstName,lastName,age,postCode,emailAddress,mobileNumber4);
            mobileNumber=mobileNumber4;
        }

        if (Staf.getTargetRegion().equals("nz")){
            fabrAppointmentTypeStepLib.v3_clickBookNowForAppointment();
   }
        else if(Staf.getTargetRegion().equals("ie")){
            fabrAppointmentTypeStepLib.v4_clickBookNowForAppointment();
        }
        else
            fabrPersonalDetailsLib.v3_clickContinueBookingButton();
    }

    @Step("Choose date and time for slot booking")
    public void selectATimeSlotForBooking() {
        logger.info("Select time and slot for booking");
        if(Staf.getTargetRegion().equals("")){
            fabrAppointmentTypeStepLib.v3_selectDateAndTime();
        }else if(Staf.getTargetRegion().equals("nz")){
            fabrAppointmentTypeStepLib.v3_selectDateAndTime();
        }
        else {
            //fabrDateAndTime.v3_clickLaterTimeSlotsIcon();
            fabrDateAndTime.v3_clickDateAndTime();
            fabrDateAndTime.v3_clickContinueButton();
        }
    }

    @Step("Verify Booking data, confirm booking and perform email check")
    public void validateBookingInformationAndCheckMailosaurForEmail() {
        logger.info("verify appoinment confirmation email being received");
        if (!(Staf.getTargetRegion().equals("ie") || Staf.getTargetRegion().equals("nz"))){
            verifyRecapPageDetailsAndConfirmBooking();
         }
        verifyBookingConfirmationPage();
        checkEmailInMailosaur();
    }

    @Step("Verify recap page details and confirm booking")
    public void verifyRecapPageDetailsAndConfirmBooking() {
        logger.info("Verify recap page details and click on confirm button");
        final String title = testDataManager.getTestInputCommonData("userInformation.title");
        final String firstName = testDataManager.getTestInputCommonData("userInformation.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userInformation.lastName");
        final String email = emailAddress;
        final String mobileno = mobileNumber;

        fabrRecapStepLib.v3_assertRecapPageIsDisplayed();
        if(Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("uk")) {
            fabrRecapStepLib.v3_assertCustomerName(title, firstName, lastName);
        }
        else {
            fabrRecapStepLib.v3_assertCustomerName(firstName, lastName);
        }
        fabrRecapStepLib.v3_assertEmailAddress(email);
        fabrRecapStepLib.v3_assertCustomerMobileNumber(mobileno);
        fabrRecapStepLib.v3_clickConfirmYourBooking();
    }

    @Step("Verify booking confirmation details")
    public void verifyBookingConfirmationPage() {
        logger.info("Verify confirmation page details");
        fabrBookingConfirmationSteplib.v3_assertBookingConfirmationPageTitle();
        fabrBookingConfirmationSteplib.v3_assertConfirmationCardWhoSection();
    }

    @Step("Confirm availability of Medical Card")
    public void confirmAvailabilityOfMedicalCard(){
        logger.info("Confirm availability of Medical Card");
        fabrAppointmentTypeStepLib.v3_selectMedicalCardAvailabilityAs(testDataManager.getTestInputRegionData("customerInfo.medicalCardAvailability"));
    }

    @Step("Choose No for Medical Card")
    public void chooseNoMedicalCard(){
        logger.info("Confirm availability of Medical Card");
        fabrAppointmentTypeStepLib.v4_selectNoMedicalCard();
    }

    @Step("Are you eligible for a PRSI eye test?")
    public void areYouEligibleForAPRSI(){
        logger.info("Are you eligible for a PRSI eye test?");
        fabrAppointmentTypeStepLib.v4_selectNoPRSI();
    }

    @Step("Choose Your appointment")
    public void chooseYourAppointment(){
        logger.info("Choose Your appointment");
        fabrAppointmentTypeStepLib.v4_chooseYourAppointment();
    }


    @Step("Enter child personal details")
    public void enterChildPersonalDetails(){
        logger.info("Enter Child personal details ");
        emailAddress=emailTestingHandler.generateEmailAddress(serverDomain);
        fabrAppointmentTypeStepLib.v3_enterPersonalDetails(
                testDataManager.getTestInputCommonData("userInformation.title"),
                testDataManager.getTestInputCommonData("userInformation.firstName"),
                testDataManager.getTestInputCommonData("userInformation.lastName"),
                Integer.parseInt(testDataManager.getTestInputCommonData("childUserInformation.age")),
                emailAddress,
                testDataManager.getTestInputCommonData("userInformation.mobileNumber")
        );
    }

    @Step("Click Book Now button for appointment")
    public void clickBookNowForAppointment(){
        logger.info("click on Book now button");
        fabrAppointmentTypeStepLib.v3_clickBookNowForAppointment();
    }
    @Step("Performs a text search or geolocation search")
    public void findStore13() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore13();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore3() {
        final String targetEnvironment=Staf.getTargetEnvironmentWithRegion()[0];
        if(Staf.getTargetRegion().equals("uk") || Staf.getTargetRegion().equals("no") || Staf.getTargetRegion().equals("ie")) {
            navigateTo.theUserAcceptCookies();
        }
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore3();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Customer cancelling the appointment using the cancellation link in email")
    public void customerCancelTheAppointmentUsingCancelLinkInEmail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
        emailTestingHandler.clickOnCancelLinkInEmail(serverID,emailAddress);

    }

    @Step("Customer cancelling the appointment using the change date/time link in email")
    public void customerCancelTheAppointmentUsingAmendLinkInEmail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetails();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
        emailTestingHandler.cancelAppointmentUsingAmendLink(serverID,emailAddress);

    }

   // ROI test case
   @Step("Verify user receives appointment booking confirmation email")
    public void verifyUserReceivesBookingConfirmationMail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
       // emailTestingHandler.amendBookedAppointUsingDatAndTime(serverID,emailAddress);
    }

    @Step("Verify user receives appointment booking confirmation email for PRSI treatment")
    public void verifyUserReceivesBookingConfirmationMailForPRSITreatment(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickOnYesAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsForPRSITreatmentAndValidateBooking();
        checkEmailInMailosaur();
        // emailTestingHandler.amendBookedAppointUsingDatAndTime(serverID,emailAddress);
    }

    // ROI test case
    @Step("Verify user receives appointment amendment email")
    public void verifyUserReceivesAmendEmail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
        emailTestingHandler.amendBookedAppointUsingDatAndTime(serverID,emailAddress);
    }


    @Step("Verify user receives appointment cancellation email")
    public void verifyUserReceivesCancellationEmail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
        emailTestingHandler.cancelBookedAppointUsingCancellationLinkInEmail(serverID,emailAddress);
    }

    @Step("Customer cancelling the appointment using the change date/time link in AMC email")
    public void customerCancelBookingUsingChangeDateAndTimeLinkInEmail(){
        openFabrHome();
        findStore4();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
        emailTestingHandler.cancelBookedAppointUsingChangeDateAndTimeLinkInEmail(serverID,emailAddress);
    }

    @Step("verify 'Request an appointment' button is displayed")
    public void verifyRequestAnAppointmentButtonIsDisplayed(){
        fabrRAFAppointmentTypeStepLib.verifyRequestAnAppointmentButtonIsDisplayed();
    }

    @Step("User clicks on 'Cancel booking' link in 'Appointment confirmation' page")
    public void clicksOnCancelBookingLinkInAppointmentConfirmationPage(){
        logger.info("Click on Cancel booking link in appointment confirmation page");
        fabrBookingConfirmationSteplib.v3_clickOnCancelBookingLinkInAppointmentConfirmationPage();
    }

    @Step("User clicks on 'Cancel Appointment' button")
    public void clicksOnConfirmCancelBookingButton(){
        logger.info("Click on confirm Cancel booking button");
        fabrBookingConfirmationSteplib.v3_clickOnConfirmCancelBookingButton();
    }

    @Step("Verify Appointment cancellation confirmation title in Cancellation confirmatin Page")
    public void v3_verifyAppointmentCancellationConfirmationTitleInCancellationConfirmationPage(){
        fabrBookingCancelationStepLib.v3_verifyAppointmentCancellationConfirmationTitleInCancellationConfirmationPage();
    }

    @Step("user clicks on 'Change' link in appointment confirmation page")
    public void clickOnChangeDateAndTime(){
        if (!Staf.getTargetRegion().equals("se")) {
            logger.info("click on Change Date and Time button");
            fabrBookingConfirmationSteplib.clickOnChangeDateAndTime();
        }
    }

    @Step("Select second time slot for the appointment")
    public void selectSecondTimeSlotAvailable(){

        if(!Staf.getTargetRegion().equals("se")) {
            if (Staf.getTargetRegion().equals("")) {
                logger.info("Select to change The Appointment slot");
                fabrAppointmentTypeStepLib.v3_selectLaterDateAndTime();
            } else {
                logger.info("Select to change The Appointment slot");
                fabrDateAndTimeStepLib.v3_selectSecondTimeSlot();
            }

        }
    }

    @Step("User clicks on change appointment button")
    public void  clickOnChangeAppointmentButton(){
        if(!(Staf.getTargetRegion().equals("ie")||Staf.getTargetRegion().equals("se"))) {
            logger.info("Click on Change appointment button");
            fabrDateAndTime.v3_clickOnChangeAppointmentButton();
        }
    }

    @Step("User clicks on confirm your booking button")
    public void confirmYourBookingButton(){
       if(!Staf.getTargetRegion().equals("se")) {
           logger.info("Confirm your booking button");
           fabrRecapStepLib.v3_confirmYourBookingButton();
       }
    }

    @Step("Verify confirmation title message for change of appointment ")
    public void verifyConfirmationTitleMessageForChangeOfAppointment() {
        fabrBookingConfirmationSteplib.verifyConfirmationTitleMessageForChangeOfAppointment();
    }

    @Step("Select appointment type as Contact lens consultation and trial")
    public void v3_selectSASAppointmentAs_ContactLensConsultationAndTrial(){
        fabrAppointmentTypeStepLib.v3_ClickOnAppointment(testDataManager.getTestInputRegionData("sASAppointmentData.appointmentType.contactLensConsultationAndTrial"));
        fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Verify amend confirmation page title")
    public void verifyAmendConfirmationPageTitle() {
        logger.info("Verify confirmation page");
        fabrAmendConfirmationStepLib.v3_assertConfirmationHeaderTitle();
    }

    @Step("verify cancel confirmation page title")
    public void verifyCancelConfirmationPageTitle() {
        waitABit(5000);
        logger.info("Verify Appointment cancellation");
        fabrAppointmentCancelledStepLib.v3_assertAppointmentCancelledHeading();
    }

    @Step("verify cancel confirmation page title")
    public void verifyCancelConfirmationPageTitleV4() {
        waitABit(5000);
        logger.info("Verify Appointment cancellation");
        fabrAppointmentCancelledStepLib.v4_assertAppointmentCancelledHeading();
    }

    @Step("Verify amend confirmation page title and verify email being received")
    public void VerifyAmendConfirmationPageTitleAndEmailBeingReceived()
    {
        verifyAmendConfirmationPageTitle();
        checkEmailInMailosaur();
    }

    @Step("verify cancel confirmation page title and verify email being received")
    public void VerifyCancelConfirmationPageTitleAndEmailBeingReceived() {
        verifyCancelConfirmationPageTitle();
        checkEmailInMailosaur();
    }

    @Step("verify cancel confirmation page title and verify email being received")
    public void VerifyCancelConfirmationPageTitleAndEmailBeingReceivedV4() {
        verifyCancelConfirmationPageTitleV4();
        checkEmailInMailosaur();
    }

    @Step("User accepts cookies")
    public void acceptCookies() {
       logger.info("User accepts cookies");
        navigateTo.theUserAcceptCookies();
    }

    @Step("Search for contact lense product")
    public void searchContactLenseProduct(){
        logger.info("Search for contact lense product");
        navigateTo.v3_searchContactLensesByValue("contactLens.availableProduct.sku"); //au region
    }

    @Step("Search for Store via Find store link")
    public void v3_searchStoreViaFindStoreLink(){
        navigateTo.theUserAcceptCookies();
        navigateTo.v3_UserClicksOnFinaAStoreLink();
        fabrLocationStepLib.v3_inputSASStore();
        fabrLocationStepLib.v3_clickFind();
    }

    @Step("Verify 'Find a store' link is displayed")
    public void v3_verifyFindAStoreLinkIsDisplayed(){
        logger.info("Verify find A store link is displayed");
        fabrLocationStepLib.v3_VerifyFindAStoreLinkIsdisplayed();
    }

    @Step("Verify 'Find a store' link is displayed")
    public void v4_verifyFindAStoreLinkIsDisplayed(){
        logger.info("Verify find A store link is displayed");
        fabrLocationStepLib.v4_VerifyFindAStoreLinkIsdisplayed();
    }

    @Step("Select 'Contact lenses' the primary link in Home Page")
    public void selectPrimaryLinkAsContactLensesInPrimaryLink() {
        logger.info("Select 'Contact lenses' the primary link in Home Page ");
        navigateTo.selectPrimaryLinkAs(testDataManager.getTestInputRegionData("drap_productDetails.productType"));
    }

    @Step("Select sub menu link as Acuvue")
    public void selectSubMenuLinkAsAcuvue(){
        logger.info("Select Acuvue sub menu link");
        navigateTo.selectSubMenuLinkAs(testDataManager.getTestInputRegionData("drap_productDetails.productName"));
    }

    @Step("Select first contact lens item")
    public void selectFirstContactLensItem(){
        logger.info("Select first contact lens item");
        fabrContactLensesListStepLib.v3_selectFirstContactLensItem();
    }

    @Step("Select left eye quantity")
    public void selectLeftEyeQuantity(){
        logger.info("Select left eye quantity");
        fabrContactLensePrescriptionStepLib.v3_selectLeftEyeQuantity();
    }

    @Step("Click on Prescription Button")
    public void clickOnPrescriptionButton(){
       logger.info("Click on Prescription Button");
        fabrContactLensePrescriptionStepLib.v3_clickOnPrescriptionButton();
    }

    @Step("Click on Book Appointment link")
    public void clickOnBookAppointmentLink(){
        logger.info("Click on Book Appointment link");
        fabrContactLensePrescriptionStepLib.v3_clickOnBookAppointmentLink();
    }

    @Step("Verify PostCode Search Field Is Displayed")
    public void VerifyPostCodeSearchFieldIsDisplayed(){
        fabrLocationStepLib.v3_VerifyPostCodeSearchFieldIsDisplayed();
    }
    @Step("Performs a text search or geolocation search")
    public void findStore11() {
        //TODO: Need to delete below line for cookies once Home Page of eComm is available to click on Book Appointment
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookAppointmentButton();
        fabrLocationStepLib.inputStore11();
        fabrLocationStepLib.clickSearch();
    }

    @Step("Cancelling an Amended Appointment Via Email")
    public void cancellingAnAmendedAppointmentViaEmail(){
        openFabrHome();
        findStore3();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
        emailTestingHandler.amendBookedAppointUsingDatAndTime(serverID,emailAddress);
        emailTestingHandler.clickOnCancelLinkInEmail(serverID,emailAddress);
    }

    @Step("Performs a text search or geolocation search")
    public void findStore4AfterClickingOnHearingTestButton() {
        fabrLocationStepLib.inputStore4();
        fabrLocationStepLib.clickSearch();
    }

    @Step("ROI book audiology appointment Via Book appointment CTA")
    public void bookROIAudiologyAppointmentViaBookAppointmentCTA(){
        openFabrHome();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore4();
        selectStore();
        clickOnHearingServices();
        chooseHearingTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        checkEmailInMailosaur();
    }

    @Step("ROI book audiology appointment using store page")
    public void bookAppointmentFromStorePage(){
        openFabrHome();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore4();
        clickStoreDetails();
        verifyStoreGeneralInformation();
        clickBookAppointmentInStorePage();
        clickOnHearingServices();
        chooseHearingTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        checkEmailInMailosaur();
    }

    @Step("ROI audiology booking by clicking on Book Hearing Test in home page")
    public void bookAppointmentUsingBookAHearingTestFromHomePage(){
        openFabrHome();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        navigateTo.theUserAcceptCookies();
        navigateTo.clickOnBookHearingTestButton();
        findStore4AfterClickingOnHearingTestButton();
        selectStore();
        clickOnHearingServices();
        chooseHearingTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        checkEmailInMailosaur();
    }

    @Step("ROI audiology booking by book appointment CTS for audiology only store")
    public void bookAppointmentUsingFindAStoreCTAForAudiologyOnlyStore(){
        openFabrHome();
        //TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        findStore4();
        selectStore();
        clickOnHearingServices();
        chooseHearingTestAppointmentType();
        selectTimeSlotForBooking();
        enterPersonalDetailsforAudiologyTest();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        checkEmailInMailosaur();
    }

    @Step("Confirm audiology booking")
    public void confirmAudiologyBooking() {
        //Need to recheck without wait of 8500 milli seconds
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
        fabrBookingConfirmationSteplib.assertConfirmationCardWhoSection();
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

    }

    @Step("Amend the amended booking journey from Email")
    public void amendAmendedJourneyFromEmail(){
        openFabrHome();
        findStore3();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
        emailTestingHandler.amendBookedAppointUsingDatAndTime(serverID,emailAddress);
        emailTestingHandler.amendBookedAppointUsingDatAndTime(serverID,emailAddress);
    }

    @Step("Keep current appointment using cancel link in Email")
    public void keepCurrentAppointmentUsingCancelLinkInEmail(){
        openFabrHome();
        findStore3();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        clickOnNoAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        inputPersonalDetailsAndValidateBooking();
        checkEmailInMailosaur();
    }

    @Step("click hearing appointment with att questions selection")
    public void clickHearingAppointmentWithATTQuestionSelection(){
        clickHearingAppointment();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTNoOption();
        clickChooseDateAndTime();
    }

    @Step("Earwax removal with ATT questions")
    public void earwaxRemovalWithATTQuestions(){
        clickEarwaxRemovalAppointment();
        clickAudiologyATTYesOption();
        clickChooseDateAndTime();
    }

    @Step("click hearing appointment with ATT Yes, No Yes option")
    public void clickHearingAppointmentWithYesAndNoOption(){
        clickHearingAppointment();
        clickAudiologyATTYesOption();
        clickAudiologyATTNoOption();
        clickAudiologyATTYesOption();
        clickAudiologyATTYesOption();
        clickChooseDateAndTime();
    }

    @Step("Perform a SAS store search for hearing appointment ")
    public void findSASStoreForHearing() {
        logger.info("Search a SAS Store");
        String targetEnvironment=Staf.getTargetEnvironmentWithRegion()[0];
        navigateTo.theUserAcceptCookies();

        if(Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("se"))
        {
            navigateTo.clickOnFindAStoreButton();
        }else {
            navigateTo.clickOnBookAppointmentButton();
        }

        fabrLocationStepLib.v3_inputSASStoreForHearing();
        fabrLocationStepLib.v3_clickFind();
    }

    @Step("Performs a text search or geolocation search")
    public void findStore1WithoutCookies() {
        locationPageSteps.clickChangeLocationLink();
        fabrLocationStepLib.inputStore1();
        fabrLocationStepLib.clickSearch();
        locationPageSteps.waitForElementTextToAppear(locationPageSteps.getSearchedStoreText(),testDataManager.getTestInputRegionData("storeName.store1"));
    }

    @Step
    public void selectAdultEyeTestATTWithAnswer(){
        chooseAdultEyeTestATTAppointmentType();
        if(Staf.getTargetRegion().equals("uk")) {
            clickOnNoAndProceed();
            clickChooseDateAndTime();
        }
    }

    @Step("Choose contact lens appointment type")
    public void chooseContactLensAppointmentTypeWithATTAnswers() {
        fabrAppointmentTypeStepLib.clickContactLensAppointment();
        fabrAppointmentTypeStepLib.clickBookASlotButton();
        if(Staf.getTargetRegion().equals("uk")) {
            clickOnYesAndProceed();
            clickOnYesAndProceed();
            clickOnNoAndProceed();
            clickChooseDateAndTime();
        }
    }

    @Step
    public void cancelBookingFromAmendPage(){
        cancelBookingInAmendConfirmationPage();
        clickCancelAppointmentLink();
        emailTestingHandler.switchToOriginalWindow();
    }

    public void editBookingDateUsingManageYourBookingSection(){
       fabrRecapPage.clickContinueButton();
       fabrBookingConfirmationPage.clickOnManageBookingEditButton();
       emailTestingHandler.switchToChildWindow();
       fabrDateAndTime.selectNewDateAndTime();
       fabrDateAndTime.clickContinueButton();
       fabrAmendRecapStepLib.clickAmendRecapConfirmButton();

    }

    public void cancelBookingUsingEditBookingInManageYourBookingSection(){
        fabrRecapPage.clickContinueButton();
        fabrBookingConfirmationPage.clickOnManageBookingEditButton();
        emailTestingHandler.switchToChildWindow();
        clickCancelAppointmentLink();
    }

    @Step("Choose adult eye test appointment type")
    public void chooseAdultEyeTestAppointmentTypeWithoutATT() {
        fabrAppointmentTypeStepLib.clickAdultEyeTest();
        fabrAppointmentTypeStepLib.clickBookASlotButton();
    }

    @Step("Input personal details for PRSI treatment")
    public void enterPersonalDetailsForPRSITreatment(){
        emailAddress=emailTestingHandler.generateEmailAddress(serverDomain);
        fabrPersonalDetailsLib.completePersonalDetailsFormForPRSITreatment(
               testDataManager.getTestInputRegionData("userInformation.title"),
               testDataManager.getTestInputRegionData("userInformation.firstName"),
               testDataManager.getTestInputRegionData("userInformation.lastName"),
               Integer.parseInt(testDataManager.getTestInputRegionData("userInformation.age")),
               emailAddress,
               testDataManager.getTestInputRegionData("userInformation.mobileNumber"),
               testDataManager.getTestInputRegionData("userInformation.ppsNumber"));
    }

    @Step("Input personal details and validate booking")
    public void inputPersonalDetailsForPRSITreatmentAndValidateBooking() {
        enterPersonalDetailsForPRSITreatment();
        continueWithBookingInPersonalDetailsPage();
        verifyDetailsAndContinueWithBooking();
        confirmBooking();
    }

    @Step
    public void keepCurrentAppointmentOptionJourneyViaEmailUsingChangeDateAndTimeLink(){
        openFabrHome();
        findStore2();
        selectStore();
        chooseAdultEyeTestATTAppointmentType();
        //Need to enable it once it is available
        clickOnNoAndProceed();
        clickOnYesAndProceed();
        clickChooseDateAndTime();
        selectTimeSlotForBooking();
        enterPersonalDetailsForPRSITreatment();
        continueWithBookingInPersonalDetailsPage();
        clickConfirmBooking();
        clickOnAmendLinkInEmail();
    }
}
