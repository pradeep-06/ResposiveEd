package digital.fabr.ui.steps.fabrSteps;

import Framework.Staf;
import digital.fabr.ui.pages.fabrPages.FabrBookingCancelationPage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.assertj.core.api.Assertions.assertThat;

public class FabrBookingCancelationStepLib extends ScenarioSteps {
    FabrBookingCancelationPage fabrBookingCancelationPage;

    public void assertAppointmentCancellationTitle() {
        fabrBookingCancelationPage.appointmentCancellationTitleIsDisplayed();
    }

    public void clickCancelAppointmentButton() {
        fabrBookingCancelationPage.clickCancelAppointmentButton();
        if(Staf.getTargetRegion().equals("uk") ||Staf.getTargetRegion().equals("au")||Staf.getTargetRegion().equals("ie")||Staf.getTargetRegion().equals("no")) {
            fabrBookingCancelationPage.clickOnConfirmCancellationButton();
        }
    }

    public void clickChangeDateAndTimeButton() {
        fabrBookingCancelationPage.clickChangeDateAndTimeButton();
    }

    public void assertAmendCalenderTitle() {
        boolean result=fabrBookingCancelationPage.assertAmendCalenderTitleIsDisplayed();
        assertThat(result).isTrue();
    }

    public void clickExitButton() {
        fabrBookingCancelationPage.clickExitButton();
    }

    public void clickNextSetOfDaysIcon() {
        fabrBookingCancelationPage.clickNextSetOfDaysIcon();
    }

    public void selectFirstSlot() {
        fabrBookingCancelationPage.selectFirstSlot();
    }

    public void selectSecondSlot() {
        fabrBookingCancelationPage.selectSecondSlot();
    }

    public void selectThirdSlot() {
        fabrBookingCancelationPage.selectThirdSlot();
    }

    public void clickChangeAppointment() {
        fabrBookingCancelationPage.clickChangeAppointment();
    }

    public void clickKeepCurrentAppointmentButton() {
        fabrBookingCancelationPage.clickKeepCurrentAppointmentButton();
    }

    public void clickAmendCancelButton() {
        fabrBookingCancelationPage.clickAmendCancelButton();
    }

    public void clickCancelBooking() {
        fabrBookingCancelationPage.clickCancelBooking();
    }

    public void clickCancelMyBooking() {
        fabrBookingCancelationPage.clickCancelMyBooking();
    }

    public void v3_verifyAppointmentCancellationConfirmationTitleInCancellationConfirmationPage() {
        fabrBookingCancelationPage.verifyAppointmentCancellationConfirmationTitle();
    }
}
