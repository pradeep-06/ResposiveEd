package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrRAFThankYouPage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FabrRAFThankYouStepLib extends ScenarioSteps {
    FabrRAFThankYouPage fabrRAFThankYouPage;

    public void assertAppointmentConfirmationHeading() {
        assertThat(fabrRAFThankYouPage.appointmentConfirmationHeadingIsDisplayed()).isTrue();
    }
    public void assertAppointmentRAFContainer() {
        assertThat(fabrRAFThankYouPage.appointmentRAFContainerIsDisplayed()).isTrue();
    }
}
