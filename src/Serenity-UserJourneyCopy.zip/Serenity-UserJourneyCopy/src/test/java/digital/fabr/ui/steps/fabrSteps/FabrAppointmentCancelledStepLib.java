package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrAppointmentCancelledPage;
import net.thucydides.core.steps.ScenarioSteps;

public class FabrAppointmentCancelledStepLib extends ScenarioSteps {
    FabrAppointmentCancelledPage fabrAppointmentCancelledPage;
    public void assertAppointmentCancelledHeading() {
        fabrAppointmentCancelledPage.verifyAppointmentCancelledHeadingIsDisplayed();

       }

    public void v3_assertAppointmentCancelledHeading() {
        fabrAppointmentCancelledPage.v3_verifyAppointmentCancelledHeadingIsDisplayed();
    }

    public void v4_assertAppointmentCancelledHeading() {
        fabrAppointmentCancelledPage.v4_verifyAppointmentCancelledHeadingIsDisplayed();
    }
}
