package digital.fabr.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.fabr.ui.pages.findStore.NonSASContactStoreFormPage;
import digital.fabr.ui.pages.findStore.NonSASYourAppointmentPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StoreAvailability extends ScenarioSteps {

    private final Logger logger = LoggerFactory.getLogger(StoreAvailability.class);
    private final TestDataManager testDataManager = new TestDataManager();
    NonSASContactStoreFormPage contactStore;
    NonSASYourAppointmentPage appointmentPage;

    public void requestAppointment() {

        final String title = testDataManager.getTestInputCommonData("userDetails.title");
        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String contactNumber = testDataManager.getTestInputRegionData("appointmentData.userDetails.contactDetails");
        final String email = testDataManager.getTestInputCommonData("userDetails.email");

        contactStore.clickRequestAppointmentButton();
        contactStore.checkAdultSightTestCheckBox(testDataManager.getTestInputRegionData("appointmentData.appointmentType.name"));
        contactStore.enterInDesiredDayAndTime(testDataManager.getTestInputRegionData("appointmentData.appointmentType.preferredDayAndTime"));
        contactStore.selectCustomersTitle(title);
        contactStore.enterInFirstName(firstName);
        contactStore.enterInLastName(lastName);
        contactStore.enterInCustomerPhoneNumber(contactNumber);
        contactStore.enterInCustomerEmail(email);
        contactStore.clickSubmitButton();
    }

    public void checkDataMatches() {

        final String title = testDataManager.getTestInputCommonData("userDetails.title");
        final String firstName = testDataManager.getTestInputCommonData("userDetails.firstName");
        final String lastName = testDataManager.getTestInputCommonData("userDetails.lastName");
        final String contactNumber = testDataManager.getTestInputRegionData("appointmentData.userDetails.contactDetails");
        final String email = testDataManager.getTestInputCommonData("userDetails.email");
        final String storeLocation = testDataManager.getTestInputRegionData("appointmentData.storeLocation.storeName");


        Assertions.assertThat(appointmentPage.getWhereSection().containsText(storeLocation)).isTrue();
        Assertions.assertThat(appointmentPage.getWhenSection().containsText(
                testDataManager.getTestInputRegionData("appointmentData.appointmentType.preferredDayAndTime"))).isTrue();
        Assertions.assertThat(appointmentPage.getWhatSection().containsText(testDataManager.getTestInputRegionData("appointmentData.appointmentType.name"))).isTrue();


        StringBuilder name = new StringBuilder();
        name.append(title)
                .append(" ")
                .append(firstName)
                .append(" ")
                .append(lastName);

        Assertions.assertThat(appointmentPage.getWhoSection().containsText(name.toString())).isTrue();
        Assertions.assertThat(appointmentPage.getWhoSection().containsText(email)).isTrue();
        Assertions.assertThat(appointmentPage.getWhoSection().containsText(contactNumber)).isTrue();
    }
}
