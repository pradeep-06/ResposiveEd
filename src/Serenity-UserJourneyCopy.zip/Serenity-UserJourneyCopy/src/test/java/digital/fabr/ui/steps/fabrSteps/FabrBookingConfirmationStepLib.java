package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrBookingConfirmationPage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.assertj.core.api.Assertions.assertThat;

public class FabrBookingConfirmationStepLib extends ScenarioSteps {
    FabrBookingConfirmationPage fabrBookingConfirmation;

    public void assertBookingConfirmationPageTitle() {
        fabrBookingConfirmation.bookingConfirmationPageTitleIsDisplayed();
    }

    public void assertremindCardText() {
        boolean result=fabrBookingConfirmation.remindCardTextIsDisplayed();
        assertThat(result).isTrue();
    }

    public void clickStartQuestionnaire() {
        fabrBookingConfirmation.clickStartQuestionnaire();
    }

    public void clickAddToCalendar() {
        fabrBookingConfirmation.clickAddToCalendar();
    }

    public void clickChangeAppointmentDateAndTimeLink() {
        fabrBookingConfirmation.clickChangeAppointmentDateAndTimeLink();
    }

    public void clickWhatToExpectDuringTheAppointment() {
        fabrBookingConfirmation.clickWhatToExpectDuringTheAppointment();
    }

    public void assertConfirmationCardWhoSection() {
        fabrBookingConfirmation.confirmationCardWhoSectionIsDisplayed();
    }

    public void assertPromoCardTitleIsDisplayed() {
        boolean result=fabrBookingConfirmation.promoCardTitleIsDisplayed();
        assertThat(result).isTrue();
    }

    public void assertPromoCardBodyText() {
        boolean result=fabrBookingConfirmation.promoCardBodyTextIsDisplayed();
        assertThat(result).isTrue();
    }

    public void clickBrowseGlasses() {
        fabrBookingConfirmation.clickBrowseGlasses();
    }

    public void assertCancelAppointmentTitle() {
        boolean result=fabrBookingConfirmation.cancelAppointmentTitleIsDisplayed();
        assertThat(result).isTrue();
    }

    public void assertCancelCardBodyText() {
        boolean result=fabrBookingConfirmation.cancelCardBodyTextIsDisplayed();
        assertThat(result).isTrue();
    }

    public void clickCancelBooking() {
        fabrBookingConfirmation.clickCancelBooking();
    }

    public void assertConfirmationCustomerEmailAddress(String email) {
        boolean result=fabrBookingConfirmation.confirmationCustomerEmailAddressISDisplayed(email);
        assertThat(result).isTrue();
    }

    public void assertConfirmationCustomerMobileNumber(String mobileno) {
        assertThat(fabrBookingConfirmation.confirmationCustomerMobileNumberISDisplayed(mobileno)).isTrue();
    }

    public void assertConfirmationCustomerName(String title, String firstname, String lastName) {
        assertThat(fabrBookingConfirmation.confirmationCustomerNameISDisplayed(title, firstname, lastName)).isTrue();
    }

    public void assertConfirmationPostCode(String postcode) {
        assertThat(fabrBookingConfirmation.confirmationPostCodeISDisplayed(postcode)).isTrue();
    }

    public void assertBookingSuccessTitle() {
        fabrBookingConfirmation.bookingSuccessTitleIsDisplayed();
    }

    public void v3_assertBookingConfirmationPageTitle() {
        fabrBookingConfirmation.v3_bookingConfirmationPageTitleIsDisplayed();
    }

    public void v3_assertConfirmationCardWhoSection() {
        fabrBookingConfirmation.v3_confirmationCardWhoSectionIsDisplayed();
    }

    public void clickOnChangeDateAndTime(){
        fabrBookingConfirmation.clickOnChangeDateAndTime();
    }

    public void v3_clickOnCancelBookingLinkInAppointmentConfirmationPage(){
        fabrBookingConfirmation.v3_clickOnCancelBookingLink();
    }

    public void v3_clickOnConfirmCancelBookingButton(){
        fabrBookingConfirmation.v3_clickOnConfirmCancelAppointmentButton();
    }

    public void verifyConfirmationTitleMessageForChangeOfAppointment() {
        fabrBookingConfirmation.verifyConfirmationTitleMessageForChangeOfAppointment();
    }
}
