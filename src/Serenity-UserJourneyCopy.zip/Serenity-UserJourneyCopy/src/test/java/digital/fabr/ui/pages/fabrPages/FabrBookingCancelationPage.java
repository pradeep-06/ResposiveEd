package digital.fabr.ui.pages.fabrPages;

import Framework.Staf;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class FabrBookingCancelationPage extends FabrBase {
    @FindBy(id = "page-header_title")
    private WebElementFacade appointmentCancellationTitle;
    @FindBy(id = "recap_exit-link")
    private WebElementFacade recapExitLink;

    @FindBy(id="page-header_title")
    private WebElementFacade amendCalenderTitle;

    @FindBy(css = "button.calendar-ab--days__next")
    private WebElementFacade selectNextSetofDays;

    @FindBy(css = "#appointment-times label p")
    private List<WebElementFacade> selectAvailableSlot;

    @FindBy(css = "#journey-page-footer_button-list a")
    private WebElementFacade updateMyAppointment;

    @FindBy(id="date-and-time_keep-appointment-button")
    private WebElementFacade keepCurrentAppointmentButton;

    @FindBy(id = "amend-calendar-footer-cancel")
    private WebElementFacade amendCancelBookingButton;

    @FindBy(css = "a#amend-calendar-footer-cancel")
    private WebElementFacade cancelBooking;

    @FindBy(css = "#date-and-time_cancel-link > a")
    private WebElementFacade cancelMyBooking;

    @FindBy(css ="div[class=\"calendar-ab--date\"] div")
    private WebElementFacade dateHeading;

    @FindBy(id = "journey-page-footer_continue-button")
    private WebElementFacade cancelAppointmentButton;

    @FindBy(id = "recap_amend-button")
    private WebElementFacade changeDateAndTimeButton;

    @FindBy(css="#cancel-confirmation-modal__cta1")
    private WebElementFacade confirmCancellation;

    @FindBy(css="h1[class=\"cancelled__title ss-sas--heading\"]")
    private WebElementFacade v3_appointmentCancellationTitle;

    public void appointmentCancellationTitleIsDisplayed() {
        assertPageObjectIsDisplayed(this.appointmentCancellationTitle);
    }

    public void clickCancelAppointmentButton() {
        clickElement(this.cancelAppointmentButton);
    }

    public void clickChangeDateAndTimeButton() {
        clickElement(this.changeDateAndTimeButton);
    }

    public boolean assertAmendCalenderTitleIsDisplayed(){
        return this.amendCalenderTitle.isDisplayed();
    }

    public void clickExitButton() {
        clickElement(this.recapExitLink);
    }

    public void clickNextSetOfDaysIcon() {
        clickElement(this.selectNextSetofDays);
    }

    public void selectFirstSlot() {
        clickElement(this.selectAvailableSlot.get(0));
    }

    public void selectSecondSlot(){
        clickElement(this.selectAvailableSlot.get(1));
    }

    public void selectThirdSlot(){
        clickElement(this.selectAvailableSlot.get(2));
    }

    public void clickChangeAppointment() {
        waitForTimeoutInMilliseconds();
        waitForElement();
        clickElement(this.updateMyAppointment);
    }

    public void clickKeepCurrentAppointmentButton() {
        clickElement(this.keepCurrentAppointmentButton);
    }

    public void clickAmendCancelButton() {
        clickElement(this.amendCancelBookingButton);
    }

    public void clickCancelBooking(){
        clickElement(this.cancelBooking);
    }

    public void clickCancelMyBooking(){
        clickElement(this.cancelMyBooking);
    }

    public void verifyAppointmentCancellationConfirmationTitle() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_appointmentCancellationTitle));
        assertElementContainsText(this.v3_appointmentCancellationTitle,"We've cancelled your appointment.");
    }

    public void clickOnConfirmCancellationButton(){
        clickElement(confirmCancellation);
    }
}
