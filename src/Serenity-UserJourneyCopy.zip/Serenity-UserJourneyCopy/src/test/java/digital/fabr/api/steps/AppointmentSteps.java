package digital.fabr.api.steps;

import Framework.DataManager.TestDataManager;
import sce.api.queryResponse.CommonAPI;
import digital.fabr.api.query.GraphQLQuery;
import digital.fabr.ui.extensions.util.emailTesting.MailosaurEmailTesting;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.model.environment.EnvironmentSpecificConfiguration;
import net.thucydides.model.util.EnvironmentVariables;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.json.Json;
import javax.json.JsonObject;
import static io.restassured.RestAssured.given;

public class AppointmentSteps extends CommonAPI {

    @Steps
    MailosaurEmailTesting emailTestingHandler;

    private static Response slotsResponse;
    private static Response opticalBookingResponse;
    private static Response audiologyBookingResponse;
    private static Response cancelBookingResponse;
    private static Response amendAppointmentResponse;
    private static Response allServersInformation;
    private static Response audiologySlotsResponse;
    private static Response appointmentInformationUsingHash;
    private static Response getAllMailosaurEmails;

    private static Response octScanResponse;
    private static Response getFirstEmailAndEmailId;
    protected final TestDataManager testDataManager = new TestDataManager();
    private static final Logger logger = LoggerFactory.getLogger(AppointmentSteps.class);
    private EnvironmentVariables env;
    final String serverDomain=testDataManager.getTestInputCommonData("mailosaurInformation.serverDomain");

    private static String storeID;


    @Step("Get Store slots information")
    public void getSlotsInformation(){
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("storeAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::"+query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate",emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotType"))
                                .add("firstAvailableAppointment",true))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(testDataManager.getTestInputRegionData("storesID.store1ID")))
                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical"))
                .build();
        logger.info("Setting up Json model for graphQL variable::"+modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        slotsResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        slotsResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

    @Step("get booked appointment information using hash")
    public void getBookedAppointmentInformationUsingHash(){
        JsonPath jsonPathEvaluator = opticalBookingResponse.jsonPath();
        final String appointmentHash=jsonPathEvaluator.get("data.bookAppointment.appointment.hash");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("appointmentInformationUsingHash.query"));
        JSONObject variables = new JSONObject();
        variables.put("hash", appointmentHash);
        query.setVariables(variables.toString());
        appointmentInformationUsingHash = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        appointmentInformationUsingHash.then().log().all()
                .assertThat().statusCode(200);
    }

    @Step("Book appointment for Optical journey")
    public void bookAppointmentForOpticalJourney(){
       final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
       JsonPath jsonPathEvaluator = slotsResponse.jsonPath();
       final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
       final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
       RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
       GraphQLQuery query = new GraphQLQuery();
       query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store1ID"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate)
                                .add("slotType",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotDescription"))
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","1990-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("userInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        opticalBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        opticalBookingResponse.then().log().all()
                .assertThat().statusCode(200);
        emailTestingHandler.checkEmail(emailAddress, testDataManager.getTestInputCommonData("mailosaurInformation.serverID"));
    }

    @Step("Cancel booked appointment")
    public void cancelAppointmentForOpticalJourney(){
        JsonPath jsonPathEvaluator = opticalBookingResponse.jsonPath();
        final String appointmentID=jsonPathEvaluator.get("data.bookAppointment.appointment.id");
        final String customerID=jsonPathEvaluator.get("data.bookAppointment.appointment.customer.id");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("cancelAppointment.query"));
        JsonObject cancelBookingModel
                = Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("appointmentId",appointmentID)
                                .add("customerId",customerID)
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store1ID"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotDescription")))
                .build();
        query.setVariables(cancelBookingModel.toString());
        cancelBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        cancelBookingResponse.then().log().all()
                .assertThat().statusCode(200);
    }

   @Step("Amend booked appointment")
   public void amendBookedAppointmentDetails(){
       JsonPath getSlotsResponse = slotsResponse.jsonPath();
       final String storeNumber=getSlotsResponse.get("data.storeAppointmentSlots[0].storeNumber");
       final String slotsID=getSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
       final String slotsType=getSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].slotType");
       final String startTime=getSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].startTime");
       final String endTime=getSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].endTime");
       final Integer duration=getSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].duration");
       final String slotDate=getSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
       logger.info("Doing a fresh optical journey booking");
       bookAppointmentForOpticalJourney();
       JsonPath jsonPathEvaluator = opticalBookingResponse.jsonPath();
       logger.info("Optical booking respose:::"+opticalBookingResponse);
       final String appointmentID=jsonPathEvaluator.get("data.bookAppointment.appointment.id");
       final String appointmentHash=jsonPathEvaluator.get("data.bookAppointment.appointment.hash");
       final String customerID=jsonPathEvaluator.get("data.bookAppointment.appointment.customer.id");
       logger.info("getting booked appointment information using hash");
       getBookedAppointmentInformationUsingHash();
       JsonPath getBookingInformationUsingHash=appointmentInformationUsingHash.jsonPath();
       final String lineOfBusiness=getBookingInformationUsingHash.get("data.appointment.lineOfBusiness");
       System.out.println("line of business::::"+lineOfBusiness);
       final String title = testDataManager.getTestInputRegionData("userInformation.title");
       final String firstName=getBookingInformationUsingHash.get("data.appointment.customer.firstName");
       final String lastName=getBookingInformationUsingHash.get("data.appointment.customer.lastName");
       System.out.println("First name::::"+firstName);
       final String email=getBookingInformationUsingHash.get("data.appointment.customer.contactInfo.email");
       final String mobile=getBookingInformationUsingHash.get("data.appointment.customer.contactInfo.mobile");
       //final String healthcareProvider=getBookingInformationUsingHash.get("data.appointment.customer.healthcareProvider");
       getSlotsInformation();
       JsonPath getLatestSlotsResponse = slotsResponse.jsonPath();
       final String nextSlotsID=getLatestSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
       final String updatedSlotsType=getLatestSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].slotType");
       final String updatedSlotDate=getLatestSlotsResponse.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
       RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
       GraphQLQuery query = new GraphQLQuery();
       query.setQuery(testDataManager.getTestInputCommonData("amendAppointment.query"));
       JsonObject amendBookingModel
                = Json.createObjectBuilder()
                .add("appointment", Json.createObjectBuilder()
                        .add("previousAppointment",Json.createObjectBuilder()
                                .add("appointmentId",appointmentID)
                                .add("storeNumber",storeNumber)
                                .add("lineOfBusiness",lineOfBusiness)
                                .add("hash",appointmentHash)
                                .add("date",slotDate)
                                .add("slot",Json.createObjectBuilder()
                                        .add("slotId",slotsID)
                                        .add("slotType",slotsType)
                                        .add("slotTypeDescription",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotDescription"))
                                        .add("startTime",startTime)
                                        .add("endTime",endTime)
                                        .add("duration",duration))
                                .add("customer",Json.createObjectBuilder()
                                        .add("customerId",customerID)
                                        .add("customer",Json.createObjectBuilder()
                                                .add("title",title)
                                                .add("firstName",firstName)
                                                .add("lastName",lastName)
                                                .add("contactInfo",Json.createObjectBuilder()
                                                        .add("email",email)
                                                        .add("mobile",mobile))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private")))))
                        .add("newAppointment",Json.createObjectBuilder()
                                .add("storeNumber",storeNumber)
                                .add("lineOfBusiness",lineOfBusiness)
                                .add("slotId",nextSlotsID)
                                .add("slotDate",updatedSlotDate)
                                .add("slotType",updatedSlotsType)
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotDescription"))
                                .add("customer",Json.createObjectBuilder()
                                        .add("title",testDataManager.getTestInputRegionData("updatedUserInformation.title"))
                                        .add("firstName",testDataManager.getTestInputRegionData("updatedUserInformation.firstName"))
                                        .add("lastName",testDataManager.getTestInputRegionData("updatedUserInformation.lastName"))
                                        .add("contactInfo",Json.createObjectBuilder()
                                                .add("email",email)
                                                .add("mobile",mobile))
                                        .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private")))))
                .build();
        query.setVariables(amendBookingModel.toString());
        amendAppointmentResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        amendAppointmentResponse.then().log().all()
                .assertThat().statusCode(200);
    }

    @Step("Book appointment for Audiology journey")
    public void bookAppointmentForAudiologyJourney(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = audiologySlotsResponse.jsonPath();
        final String storeNumber=jsonPathEvaluator.get("data.storeAppointmentSlots[0].storeNumber");
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date");
        final String clinicId=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].clinicId");
        final String slotsStartTime=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].startTime");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",storeNumber)
                                .add("clinicId",clinicId)
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.audiology"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate+"T"+slotsStartTime+":00Z")
                                .add("slotType",testDataManager.getTestInputRegionData("hearingTestSlot.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("hearingTestSlot.slotDescription"))

                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("dateOfBirth","1990-09-09")
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("rafUserInformation.mobileNumber")))
                                                .add("gender","MALE")
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private")))

                                .add("note",""))
                .add("query",Json.createObjectBuilder()
                        .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                        .add("endDate",emailTestingHandler.getRequiredDateForSlotsSetup(8))
                        .add("slotType",testDataManager.getTestInputRegionData("hearingTestSlot.slotType"))
                        .add("firstAvailableAppointment", true))
                .add("query1",Json.createObjectBuilder()
                        .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                        .add("maxEndDate", emailTestingHandler.getNextMonthDate())
                        .add("maxNumberOfDays",1)
                        .add("slotType",testDataManager.getTestInputRegionData("hearingTestSlot.slotType")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        audiologyBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        audiologyBookingResponse.then().log().all().assertThat().statusCode(200);
    }

    @Step("Get Store slots information for audiology")
    public void getSlotsInformationForAudiology() {
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("storeAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::" + query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate", emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate", emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType", testDataManager.getTestInputRegionData("hearingTestSlot.slotType"))
                                .add("firstAvailableAppointment", false))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(testDataManager.getTestInputRegionData("storesID.store2ID")))
                .add("lineOfBusiness", testDataManager.getTestInputRegionData("lineOfBusiness.audiology"))
                .build();
        logger.info("Setting up Json model for graphQL variable::" + modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        audiologySlotsResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        audiologySlotsResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

    @Step("get all mails from mailosaur")
    public void getAllMailosaurMails(){
        RestAssured.baseURI="https://mailosaur.com";
        getAllMailosaurEmails=  given().log().all()
                              .auth().preemptive().basic("E2eIezhybYCz9fGZ","")
                .param("server","ldcode7r")
                .get("/api/messages");
    }

    @Step("Get first Email and Email Id")
    public void getFirstEmailAndEmailId(){
        JsonPath jsonPathEvaluator = getAllMailosaurEmails.jsonPath();
        String email=jsonPathEvaluator.get("items[0].to[0].email");
        String id=jsonPathEvaluator.get("items[0].id");
        getFirstEmailAndEmailId=  given().log().all()
                .auth().preemptive().basic("E2eIezhybYCz9fGZ","")
                .get("/api/messages/"+id);
    }

    @Step("get all the servers information")
    public void getAllServerInformation(){
        allServersInformation=given().auth()
                .preemptive().basic("vhCoNuTqdS6E17BS","")
                .get("/api/servers");
    }


    @Step("Get Store slots information")
    public void getSlotsInformation(String storeName){
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        if(storeName.equals("Coventry")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Forde")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Noosa")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Dublin")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }

        else if(storeName.equals("Cheylesmore")){
            storeID=testDataManager.getTestInputRegionData("storesID.store4ID");
        }

        else if(storeName.equals("Nijmegen-Centrum")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else{
            logger.info("Input valid store name");
        }
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("storeAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::"+query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate",emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotType"))
                                .add("firstAvailableAppointment",true))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(storeID))
                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical"))
                .build();
        logger.info("Setting up Json model for graphQL variable::"+modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        slotsResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        slotsResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

    @Step("Book appointment for Child Optical journey")
    public void bookAppointmentForChildOpticalJourney(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = slotsResponse.jsonPath();
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store1ID"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate)
                                .add("slotType",testDataManager.getTestInputRegionData("childEyeTestSlot.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("childEyeTestSlot.slotDescription"))
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","2010-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("rafUserInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        opticalBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        opticalBookingResponse.then().log().all()
                .assertThat().statusCode(200);
        emailTestingHandler.checkEmail(emailAddress, testDataManager.getTestInputCommonData("mailosaurInformation.serverID"));
    }

    @Step("Get Store slots information for child eye test")
    public void getSlotsInformationForChildEyeTest(String storeName){
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        if(storeName.equals("Coventry")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Forde")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Noosa")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Dublin")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Nijmegen-Centrum")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else{
            logger.info("Input valid store name");
        }
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("storeAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::"+query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate",emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType",testDataManager.getTestInputRegionData("childEyeTestSlot.slotType"))
                                .add("firstAvailableAppointment",true))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(storeID))
                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical"))
                .build();
        logger.info("Setting up Json model for graphQL variable::"+modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        slotsResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        slotsResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

    @Step("Get Store slots information")
    public void getSlotsInformationForOCTSCAN(String storeName){
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        if(storeName.equals("Coventry")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Forde")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Noosa")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Dublin")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else{
            logger.info("Input valid store name");
        }
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("storeAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::"+query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate",emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType",testDataManager.getTestInputRegionData("octScanSlot.slotType"))
                                .add("firstAvailableAppointment",true))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(storeID))
                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical"))
                .build();
        logger.info("Setting up Json model for graphQL variable::"+modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        octScanResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        octScanResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

    @Step("Book appointment for Oct Scan Optical journey")
    public void bookAppointmentForOCTScanOpticalJourney(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = octScanResponse.jsonPath();
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store1ID"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate)
                                .add("slotType",testDataManager.getTestInputRegionData("octScanSlot.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("octScanSlot.slotDescription"))
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","1990-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("rafUserInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        opticalBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        opticalBookingResponse.then().log().all()
                .assertThat().statusCode(200);
        emailTestingHandler.checkEmail(emailAddress, testDataManager.getTestInputCommonData("mailosaurInformation.serverID"));
    }

    @Step("Get Store slots information for audiology")
    public void getSlotsInformationForAudiology(String storeName) {
        String storeID = null;
        if(storeName.equals(testDataManager.getTestInputRegionData("storeName.store4"))){
            storeID=testDataManager.getTestInputRegionData("storesID.store4ID");
        }
        if(storeName.equals(testDataManager.getTestInputRegionData("storeName.store3"))){
            storeID=testDataManager.getTestInputRegionData("storesID.store3ID");
        }
        if(storeName.equals(testDataManager.getTestInputRegionData("storeName.store2"))){
            storeID=testDataManager.getTestInputRegionData("storesID.store2ID");
        }
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("audiologyStoresAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::" + query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate", emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate", emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType", testDataManager.getTestInputRegionData("hearingTestSlot.slotType"))
                                .add("firstAvailableAppointment", true))
                .add("query1",
                        Json.createObjectBuilder()
                                .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("maxEndDate",emailTestingHandler.getNextMonthDate())
                                .add("maxNumberOfDays",1)
                                .add("slotType",testDataManager.getTestInputRegionData("hearingTestSlot.slotType")))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(storeID))
                .add("lineOfBusiness", testDataManager.getTestInputRegionData("lineOfBusiness.audiology"))
                .build();
        logger.info("Setting up Json model for graphQL variable::" + modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        audiologySlotsResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        audiologySlotsResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

    @Step("Book appointment for Earwax removal journey")
    public void bookAppointmentForEarwaxRemovalJourney(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = audiologySlotsResponse.jsonPath();
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
        final String clinicId=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].clinicId");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store2ID"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate)
                                .add("slotType",testDataManager.getTestInputRegionData("earWaxRemovalSlot.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("earWaxRemovalSlot.slotDescription"))
                                .add("clinicId",clinicId)
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","1990-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("rafUserInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.audiology")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        audiologyBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        audiologyBookingResponse.then().log().all()
                .assertThat().statusCode(200);
    }

    @Step("make sure that adult customer is not able to book child eye test")
    public void validateChildEyeBookingFunctionality(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = slotsResponse.jsonPath();
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store1ID"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate)
                                .add("slotType",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotDescription"))
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","2012-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("userInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        opticalBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        opticalBookingResponse.then().log().all()
                .assertThat().statusCode(200);
        emailTestingHandler.checkEmail(emailAddress, testDataManager.getTestInputCommonData("mailosaurInformation.serverID"));

    }

    public void bookAppointmentForHearingProtectionConsultation(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = audiologySlotsResponse.jsonPath();
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date")+"T11:00:00Z";
        final String clinicId=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].clinicId");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store2ID"))
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate)
                                .add("slotType",testDataManager.getTestInputRegionData("hearingProtectionConsultation.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("hearingProtectionConsultation.slotDescription"))
                                .add("clinicId",clinicId)
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","1990-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("rafUserInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.audiology")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        audiologyBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        audiologyBookingResponse.then().log().all()
                .assertThat().statusCode(200);
    }

    @Step("Cancel booked appointment after ammendment")
    public void cancelAppointmentForOpticalJourneyAfterAmendment(){
        JsonPath jsonPathEvaluator = amendAppointmentResponse.jsonPath();
        final String appointmentID=jsonPathEvaluator.get("data.amendAppointment.appointment.id");
        final String customerID=jsonPathEvaluator.get("data.amendAppointment.appointment.customer.id");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("cancelAppointment.query"));
        JsonObject cancelBookingModel
                = Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("appointmentId",appointmentID)
                                .add("customerId",customerID)
                                .add("storeNumber",testDataManager.getTestInputRegionData("storesID.store1ID"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("adultEyeTestSlot.slotDescription")))
                .build();
        query.setVariables(cancelBookingModel.toString());
        cancelBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        cancelBookingResponse.then().log().all()
                .assertThat().statusCode(200);
    }

    public void bookOpticalAppointmentForContactLensAssessmentAndTrial(){
        final String emailAddress =emailTestingHandler.generateEmailAddress(serverDomain);
        JsonPath jsonPathEvaluator = slotsResponse.jsonPath();
        final String slotsID=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].id");
        final String slotsDate=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].date");
        final String storeNumber=jsonPathEvaluator.get("data.storeAppointmentSlots[0].storeNumber");
        final String slotsStartTime=jsonPathEvaluator.get("data.storeAppointmentSlots[0].appointmentSlots[0].appointmentSlots[0].startTime");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("bookAppointment.query"));
        JsonObject bookAppointmentModel
                =Json.createObjectBuilder()
                .add("appointment",
                        Json.createObjectBuilder()
                                .add("storeNumber",storeNumber)
                                .add("slotId",slotsID)
                                .add("slotDate",slotsDate+"T"+slotsStartTime+":00Z")
                                .add("slotType",testDataManager.getTestInputRegionData("contactLensAssessmentOrTrial.slotType"))
                                .add("slotTypeDescription",testDataManager.getTestInputRegionData("contactLensAssessmentOrTrial.slotDescription"))
                                .add("customer",
                                        Json.createObjectBuilder()
                                                .add("title",testDataManager.getTestInputRegionData("userInformation.title"))
                                                .add("firstName",testDataManager.getTestInputRegionData("userInformation.firstName"))
                                                .add("lastName",testDataManager.getTestInputRegionData("userInformation.lastName"))
                                                .add("healthcareProvider",testDataManager.getTestInputRegionData("healthcareProvider.private"))
                                                .add("dateOfBirth","1990-09-09")
                                                .add("address",
                                                        Json.createObjectBuilder()
                                                                .add("postcode",testDataManager.getTestInputRegionData("userInformation.postCode"))
                                                                .add("countryCode",testDataManager.getTestInputRegionData("userInformation.countryCode")))
                                                .add("contactInfo",
                                                        Json.createObjectBuilder()
                                                                .add("email",emailAddress)
                                                                .add("mobile",testDataManager.getTestInputRegionData("userInformation.mobileNumber"))))
                                .add("note","")
                                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical")))
                .build();
        query.setVariables(bookAppointmentModel.toString());
        opticalBookingResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        opticalBookingResponse.then().log().all()
                .assertThat().statusCode(200);
        emailTestingHandler.checkEmail(emailAddress, testDataManager.getTestInputCommonData("mailosaurInformation.serverID"));

    }

    @Step("Get Store slots information")
    public void getSlotsInformationForContactLensAssessmentAndTrial(String storeName){
        logger.info("Setting baseURI using Environmental variables");
        RestAssured.baseURI = EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        if(storeName.equals("Coventry")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Forde")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Noosa")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Dublin")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }

        else if(storeName.equals("Cheylesmore")){
            storeID=testDataManager.getTestInputRegionData("storesID.store4ID");
        }

        else if(storeName.equals("Nijmegen-Centrum")){
            storeID=testDataManager.getTestInputRegionData("storesID.store1ID");
        }
        else if(storeName.equals("Leamington Spa")){
            storeID=testDataManager.getTestInputRegionData("storesID.store2ID");
        }
        else{
            logger.info("Input valid store name");
        }
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(testDataManager.getTestInputCommonData("storeAppointmentSlots.query"));
        logger.info("Setting up graphQL query using data manager::"+query);
        JsonObject modelForSlotsInformation
                = Json.createObjectBuilder()
                .add("query",
                        Json.createObjectBuilder()
                                .add("startDate",emailTestingHandler.getRequiredDateForSlotsSetup(7))
                                .add("endDate",emailTestingHandler.getRequiredDateForSlotsSetup(8))
                                .add("slotType",testDataManager.getTestInputRegionData("contactLensAssessmentOrTrial.slotType"))
                                .add("firstAvailableAppointment",true))
                .add("storeNumbers",
                        Json.createArrayBuilder().add(storeID))
                .add("lineOfBusiness",testDataManager.getTestInputRegionData("lineOfBusiness.optical"))
                .build();
        logger.info("Setting up Json model for graphQL variable::"+modelForSlotsInformation);
        query.setVariables(modelForSlotsInformation.toString());
        slotsResponse = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        slotsResponse.then().log().all()
                .assertThat().statusCode(200);
        logger.info("returning response to extract data for other APIs calls");
    }

}
