package digital.fabr.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.fabr.ui.pages.fabrPages.fabrHomePage.FabrHomePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NavigateToFabr extends ScenarioSteps {

    FabrHomePage homePage;
    private final Logger logger = LoggerFactory.getLogger(NavigateToFabr.class);
    final TestDataManager testDataManager = new TestDataManager();

    public void theHomePage() {
        homePage.open();
    }

   public void theUserAcceptCookies() {
       logger.info("Starting accept cookies module");
         if (testDataManager.getFeatureData("models.cookieModel", Boolean.class)) {
            homePage.clickAcceptOnCookies();
        }
    }

    public void clickOnBookAppointmentButton(){
        logger.info("Click on Book Appointment button");
        homePage.clickOnBookAppointment();
    }

    public void clickOnFindAStoreButton(){
        logger.info("Click on Find a Store Button");
        homePage.clickOnFindAStore();
    }

    public void selectPrimaryLinkAs(String primaryLinkName){
        waitABit(2000);
        homePage.v3_selectPrimaryLinkAs(primaryLinkName);
    }

    public void selectSubMenuLinkAs(String subMenuName){
        waitABit(2000);
        homePage.v3_selectSubMenuLinkAs(subMenuName);
    }

    public void v3_searchContactLensesByValue(String value){
        homePage.v3_clickOnSearchIcon();
        homePage.v3_enterIntoSearchInputBox(value);
    }

    public void v3_UserClicksOnFinaAStoreLink(){
        homePage.clickOnFindAStore();
    }

    public void clickOnBookHearingTestButton(){
        logger.info("Click on Book Hearing test button");
        homePage.clickOnBookHearingTestButton();
    }
}