package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import Framework.Staf;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;

public class FabrAppointmentCancelledPage extends BasePageObject {
    @FindBy(css = "h1#page-header_title")
    private WebElementFacade appointmentCancelledHeading;

    @FindBy(css = "ss-button ss-button--mobile cancelled__return-home-page-button")
    private WebElementFacade returnToHomePageButton;

    @FindBy(css = "ss-button ss-button--mobile ss-button--tertiary cancelled__book-new-appointment-button")
    private WebElementFacade bookNewAppointmentButton;

    @FindBy(css = "h1[class='cancelled__title ss-sas--heading'],div[id='gateway-api-cancel']>div>h1,div[class='oas-message oas-cancelled']>div>h1,header[class='page-header confirmation__page-header']>h1")
    private WebElementFacade v3_appointmentCancelledHeading;

    @FindBy(css = "header[class='page-header confirmation__page-header']>h1,#page-header_title")
    private WebElementFacade v4_appointmentCancelledHeading;

    public void verifyAppointmentCancelledHeadingIsDisplayed() {
        waitForTimeoutInMilliseconds();
        assertPageObjectExists(appointmentCancelledHeading);
        //assertPageObjectIsDisplayed(appointmentCancelledHeading);
    }

    public void v3_verifyAppointmentCancelledHeadingIsDisplayed() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(this.v3_appointmentCancelledHeading));
        assertPageObjectIsDisplayed(this.v3_appointmentCancelledHeading);
    }

    public void v4_verifyAppointmentCancelledHeadingIsDisplayed() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(this.v4_appointmentCancelledHeading));
        assertPageObjectIsDisplayed(this.v4_appointmentCancelledHeading);
    }
}