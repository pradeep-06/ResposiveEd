package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrStorePage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.junit.Assert.assertTrue;

public class FabrStoreStepLib extends ScenarioSteps {
    FabrStorePage fabrStorePage;

    public void assertStoreGeneralInformation() {
        assertTrue(fabrStorePage.verifyStoreGeneralInformationIsDisplayed());
    }
    public void clickBookAppointment() {
        fabrStorePage.clickBookAppointmentButton();
    }
}
