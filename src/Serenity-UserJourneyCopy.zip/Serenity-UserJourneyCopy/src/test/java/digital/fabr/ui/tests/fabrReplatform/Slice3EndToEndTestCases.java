package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_REG;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("fabr")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class Slice3EndToEndTestCases {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "39796191", projectId = "102929", testCaseName = "TC_01-Audiology-Booking journey via Find a store CTA", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_01_AudiologyBookingJourneyViaFindAStoreCTA() {
        fabr.openFabrHome();
        //  TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBookingAndCloseBrowser();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(2)
    @SSTest(testCaseId = "39796198", projectId = "102929", testCaseName = "TC_02-Audiology-Booking journey via Book Appointment CTA", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_02_AudiologyBookingJourneyViaBookAppointmentCTA() {
        fabr.openFabrHome();
//  TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(3)
    @SSTest(testCaseId = "39796203", projectId = "102929", testCaseName = "TC_06-Audiology-Changing appointment type from recap page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_06_AudiologyChangeAppointmentTypeFromRecapPage() {
        //  TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeAppointmentLink();
        fabr.verifyAppointmentPage();
        fabr.clickHearingAppointmentWithYesAndNoOption();
        fabr.selectNewDateAndTime();
        fabr.verifyCustomerDetails();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(4)
    @SSTest(testCaseId = "39796204", projectId = "102929", testCaseName = "TC_07-Audiology-Changing appointment type from recap page but later cancel and go back", testType = SSTestType.E2E, testCaseVersion = "3.1")
    public void TC_07_AudiologyChangeAppointmentTypeFromRecapPageLaterCancelIt() {
        //  TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeAppointmentLink();
        fabr.verifyAppointmentPage();
        fabr.clickCancelAndGoInAppointmentTypePage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(5)
    @SSTest(testCaseId = "39796201", projectId = "102929", testCaseName = "TC_04-Audiology-Booking Journey when no slots are available for selected store/appointment type", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_04_AudiologyBookingJourneyWhenNoSlotsAreAvailable() {
        fabr.openFabrHome();
        fabr.findStore3();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.chooseEarwaxRemovalAppointmentType();
        fabr.verifyCalendarNoAvailabilityPeriodBannerTitleDisplayed();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(6)
    @SSTest(testCaseId = "39796205", projectId = "102929", testCaseName = "TC_08-Audiology-Changing appointment date/time from recap page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_08_AudiologyChangeAppointmentDateAndTimeFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changeDateAndTimeFromRecapPage();
        fabr.verifyDateAndTimePage();
        fabr.selectNewDateAndTime();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(7)
    @SSTest(testCaseId = "39796206", projectId = "102929", testCaseName = "TC_09-Audiology-Changing appointment date/time from recap page but later cancel and go back", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_09_AudiologyChangeAppointmentDateAndTimeFromRecapPageButLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changeDateAndTimeFromRecapPage();
        fabr.verifyDateAndTimePage();
        fabr.clickCancelAndGoLinkInDateAndTimePage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(8)
    @SSTest(testCaseId = "39796208", projectId = "102929", testCaseName = "TC_10-Audiology-Changing personal details from recap page ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_10_AudiologyChangePersonalDetailsFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changePersonalDetailsFromRecapPage();
        fabr.verifyPersonalDetailsPage();
        fabr.reEnterAudiologyPersonalDetailsInRecapPage();
        fabr.clickOnContinueInPersonalDetailPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(9)
    @SSTest(testCaseId = "39796212", projectId = "102929", testCaseName = "TC_11-Audiology-Changing personal details from recap page but later cancel and go back", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_AudiologyChangePersonalDetailsFromRecapPageButLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changePersonalDetailsFromRecapPage();
        fabr.verifyPersonalDetailsPage();
        fabr.clickCancelAndGOBackLinkInPersonaldetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(10)
    @SSTest(testCaseId = "39796245", projectId = "102929", testCaseName = "TC_12-Audiology-Changing location from recap page", testType = SSTestType.E2E, testCaseVersion = "5.0")
    public void TC_12_AudiologyChangeLocationFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeLocationLink();
        fabr.verifyLocationPage();
        //TODO: need to change the other store to Coventry
        fabr.findStore3WithoutCookies();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(11)
    @SSTest(testCaseId = "39796247", projectId = "102929", testCaseName = "TC_13-Audiology-Changing location from recap page but later cancel and go back", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_13_AudiologyChangeLocationFromRecapPageButLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeLocationLink();
        fabr.verifyLocationPage();
        fabr.clickCancelAndGoInLocationPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(12)
    @SSTest(testCaseId = "39796248", projectId = "102929", testCaseName = "TC_14-Audiology-Navigation to the various pages in book journey using breadcrumbs", testType = SSTestType.E2E, testCaseVersion = "3.0")
    public void TC_14_AudiologyNavigationToVariousPagesUsingBreadcrumbs() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyPersonalDataInRecapPage();
        fabr.clickLocationBreadcrumb();
        fabr.verifyLocationPage();
        fabr.clickCancelAndGoBackLink();
        fabr.clickAppointmentTypeBreadcrumb();
        fabr.verifyAppointmentPage();
        fabr.clickCancelAndGoInAppointmentTypePage();
        fabr.clickDateAndTimeBreadcrumb();
        fabr.verifyDateAndTimePage();
        fabr.clickOnCancelAndGoLinkInDateAndTime();
        fabr.clickPersonalDetailsBreadcrumb();
        fabr.verifyPersonalDetailsPage();
        fabr.clickOnCancelAndGoBackLinkInPersonalDetails();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(13)
    @SSTest(testCaseId = "40861845", projectId = "102929", testCaseName = "TC_22-Audiology-Customer starts a new store search from DTP and completes the booking", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_22_AudiologyCustomerStartsNewStoreSearchFromDTP() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.clickOtherStoreLinkInDTP();
        //TODO: need to change the other store to Coventry
        fabr.findStore2WithoutCookies();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithYesAndNoOption();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(14)
    @SSTest(testCaseId = "40861846", projectId = "102929", testCaseName = "TC_23-Audiology-Changing location from DTP page but later cancel and go back", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_23_AudiologyCustomerStartsNewStoreSearchFromDTPButLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.clickOtherStoreLinkInDTP();
        fabr.clickCancelAndGoInLocationPage();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBookingAndCloseBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(15)
    @SSTest(testCaseId = "39796249", projectId = "102929", testCaseName = "TC_15-Audiology-Appointment book journey-Ear wax removal", testType = SSTestType.E2E, testCaseVersion = "5.0")
    public void TC_15_AudiologyBookingJourneyEarWaxRemoval() {
        fabr.openFabrHome();
        fabr.findStore3();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.earwaxRemovalWithATTQuestions();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();

    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(16)
    @SSTest(testCaseId = "39796251", projectId = "102929", testCaseName = "TC_16-Audiology-RAF journey for stores which are not enabled for online bookings", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_16_AudiologyRAFBookingJourney() {
        fabr.openFabrHome();
        fabr.findStore1();
        fabr.selectStore();
        fabr.clickOnHearingServices();
        fabr.assertBookingUnavailabilityBannerTitle();
        fabr.clickRequestAnAppointmentButton();
        fabr.clickHearingTestForRAF();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
        fabr.closeBrowser();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(17)
    @SSTest(testCaseId = "40928558", projectId = "102929", testCaseName = "TC_24- Appointment booking journey from the Store pages", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_24_AudiologyAppointmentBookingJourneyFromStorePage() {
        fabr.openFabrHome();
        fabr.findStore3();
        fabr.clickStoreDetails();
        fabr.verifyStoreGeneralInformation();
        fabr.clickBookAppointmentInStorePage();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointmentWithATTQuestionSelection();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBookingAndCloseBrowser();
    }

    @AfterEach
    public void tearDown() {

        fabr.closeSession();
    }
}


