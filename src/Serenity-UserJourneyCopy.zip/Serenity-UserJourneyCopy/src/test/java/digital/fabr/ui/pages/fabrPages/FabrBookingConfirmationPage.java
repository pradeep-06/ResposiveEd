package digital.fabr.ui.pages.fabrPages;

import Framework.Staf;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FabrBookingConfirmationPage extends FabrBase {
    private static final Logger logger = LoggerFactory.getLogger(FabrBookingConfirmationPage.class);

    @FindBy(css = "main#main>header>p")
    private WebElementFacade remindCardTitle;

    @FindBy(id = "confirmation-page-template_specs-success-banner_title")
    private WebElementFacade bookingConfirmationPageHeader;

    @FindBy(css = "remind-card_text")
    private WebElementFacade remindCardText;

    @FindBy(css = "a#remind-card_cta")
    private WebElementFacade startQuestionnaire;

    @FindBy(css = "button#confirmation-card-when_calendar-cta")
    private WebElementFacade addToCalendar;

    @FindBy(css = "a#confirmation-card-when_amend-appointment-link")
    private WebElementFacade changeAppointmentDateAndTime;

    @FindBy(css = "a#confirmation-card-what_link")
    private WebElementFacade expectationsDuringAppointment;

    @FindBy(css = "div#confirmation-card-who")
    private WebElementFacade confirmationCardWhoSection;

    @FindBy(css = "p#confirmation-card-who_full-name")
    private WebElementFacade fullName;

    @FindBy(css = "p#confirmation-card-who_postcode")
    private WebElementFacade postCode;

    @FindBy(css = "p#confirmation-card-who_date-of-birth")
    private WebElementFacade dateOfBirth;

    @FindBy(css = "p#confirmation-card-who_email")
    private WebElementFacade emailAddress;

    @FindBy(css = "p#confirmation-card-who_phone-number")
    private WebElementFacade phoneNumber;

    @FindBy(css = "p#confirmation-card-who_healthcare-provider")
    private WebElementFacade nhsEntitlement;

    @FindBy(css = "h2#promo-card_title")
    private WebElementFacade promoCardTitle;

    @FindBy(css = "p#promo-card_body")
    private WebElementFacade promoCardBodyText;

    @FindBy(css = "a#promo-card_cta")
    private WebElementFacade browseGlasses;

    @FindBy(css = "h2#cancel-card_title")
    private WebElementFacade cancelAppointmentTitle;

    @FindBy(css = "p#cancel-card_body")
    private WebElementFacade cancelCardBodyText;

    @FindBy(css = "div#confirmation-page-template_cancel-card a")
    private WebElementFacade cancekBooking;

    @FindBy(css="main#main>header>h1")
    private WebElementFacade bookingSuccessTitle;

    @FindBy(css="[class='confirmation-header__title ss-sas--heading'],#contactTabsCon > div:nth-child(2),#block-system-main > div > div:nth-child(1) > div > h2,#confirmation-page-template_specs-success-banner_title,div.oas-receipt__header>h2")
    private WebElementFacade v3_bookingConfirmationPageHeader;

    @FindBy(css = "#who,div#confirmation-card-who,#contactTabsCon1 > div > div:nth-child(1) > div > span,#appointment-details--for,div[class='data-box js-data-box-who']")
    private WebElementFacade v3_confirmationCardWhoSection;

    @FindBy(css="button#confirmation-footer-cancel-button,a.js-cancel.button.button--secondary,a[trackaid='booking_confirmation_cancel_appointment'],div#confirmation-page-template_cancel-card a:nth-child(3)")
    private WebElementFacade v3_cancelBookingLink;

    @FindBy(css="div.recap--buttons-wrapper a[class*='appointment-cancelled-button'],button.button.button--primary.cancel__button,button#edit-submit,a#journey-page-footer_continue-button,button[aria-label='Continue with cancelling your appointment']")
    private WebElementFacade v3_ConfirmCancelAppointmentButton;

    @FindBy(css="a#when-change,a[trackaid='booking_confirmation_change_appointment'],div.data-box.js-data-box-when div.booking-change.link,a#confirmation-card-when_amend-appointment-link")
    private WebElementFacade v3_changeDateAndTimeLink;

    @FindBy(css="button[aria-label='Continue with cancelling your appointment']")
    private WebElementFacade v3_ConfirmAppointmentCancelButton;

    @FindBy(xpath = "//a[@text='Edit']")
    private WebElementFacade manageBookingEditButton;

    @FindBy(xpath="//a[@text='Cancel']")
    private WebElementFacade manageBookingCancelButton;

    public void bookingConfirmationPageTitleIsDisplayed() {
        waitForTimeoutInMilliseconds();
        assertPageObjectIsDisplayed(this.bookingConfirmationPageHeader);
    }

    public boolean remindCardTextIsDisplayed() {
        return this.remindCardText.isDisplayed();
    }

    public void clickStartQuestionnaire() {
        clickElement(this.startQuestionnaire);
    }

    public void clickAddToCalendar() {
        clickElement(this.addToCalendar);
    }

    public void clickChangeAppointmentDateAndTimeLink() {
        clickElement(this.changeAppointmentDateAndTime);
    }

    public void clickWhatToExpectDuringTheAppointment() {
        clickElement(this.expectationsDuringAppointment);
    }

    public void confirmationCardWhoSectionIsDisplayed() {
        waitForTimeoutInMilliseconds();
        assertPageObjectIsDisplayed(this.confirmationCardWhoSection);
    }

    public boolean promoCardTitleIsDisplayed() {
        return this.promoCardTitle.isDisplayed();
    }

    public boolean promoCardBodyTextIsDisplayed() {
        return this.promoCardBodyText.isDisplayed();
    }

    public void clickBrowseGlasses() {
        clickElement(this.browseGlasses);
    }

    public boolean cancelAppointmentTitleIsDisplayed() {
        return this.cancelAppointmentTitle.isDisplayed();
    }

    public boolean cancelCardBodyTextIsDisplayed() {
        return this.cancelCardBodyText.isDisplayed();
    }

    public void clickCancelBooking() {
         clickElement(this.cancekBooking);
    }

    public boolean confirmationCustomerEmailAddressISDisplayed(String email) {
        return this.emailAddress.getText().equals(email);
    }

    public boolean confirmationCustomerMobileNumberISDisplayed(String mobileno) {
        return this.phoneNumber.getText().equals(mobileno);
    }

    public boolean confirmationCustomerNameISDisplayed(String title, String firstname, String lastName) {
        return this.fullName.getText().equals(title + firstname + lastName);
    }

    public boolean confirmationPostCodeISDisplayed(String postcode) {
        return this.postCode.getText().equals(postcode);
    }

    public void bookingSuccessTitleIsDisplayed(){
        assertPageObjectIsDisplayed(bookingSuccessTitle);
    }

    public void v3_bookingConfirmationPageTitleIsDisplayed() {
          assertPageObjectIsDisplayed(this.v3_bookingConfirmationPageHeader);
    }

    public void v3_confirmationCardWhoSectionIsDisplayed() {
        assertPageObjectIsDisplayed(this.v3_confirmationCardWhoSection);
    }

    public void clickOnChangeDateAndTime(){
        waitABit(5000);
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_changeDateAndTimeLink));
        clickElement(this.v3_changeDateAndTimeLink);
    }

    public void v3_clickOnCancelBookingLink(){
        waitABit(2000);
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_cancelBookingLink));
        clickElement(this.v3_cancelBookingLink);
    }

    public void v3_clickOnConfirmCancelAppointmentButton(){
        if(Staf.getTargetRegion().equals("uk")||Staf.getTargetRegion().equals("no")) {  //this condition is placed as this is requied for uk environment
            switchToChildWindow();
        }
        waitABit(2000);
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_ConfirmCancelAppointmentButton));
        clickElement(this.v3_ConfirmCancelAppointmentButton);

        if(Staf.getTargetRegion().equals("uk")||Staf.getTargetRegion().equals("au")){
            try {
                clickElement(this.v3_ConfirmAppointmentCancelButton);
            }
            catch(Exception e){
                logger.info("Pop up with Confirm cancellation of button is not displayed");
            }
        }
    }

    public void verifyConfirmationTitleMessageForChangeOfAppointment() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_bookingConfirmationPageHeader));
        assertElementContainsText(this.v3_bookingConfirmationPageHeader,"changed your appointment.");
        assertPageObjectIsDisplayed(this.v3_bookingConfirmationPageHeader);
    }

    public void clickOnManageBookingEditButton(){
        clickElement(manageBookingEditButton);
    }

    public void clickOnManageBookingCancelButton(){
        clickElement(manageBookingCancelButton);
    }
}
