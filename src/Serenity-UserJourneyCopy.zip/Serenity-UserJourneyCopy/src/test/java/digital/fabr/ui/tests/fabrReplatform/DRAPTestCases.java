package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.Drap_FABR;
import Framework.Annotations.FABR.FandB_DRAP;
import Framework.DataManager.TestDataManager;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Drap_FABR
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class DRAPTestCases {

    @Managed(driver = "provided")
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;

    protected final TestDataManager testDataManager = new TestDataManager();

    @FandB_DRAP
    @Tags(value = {@Tag("ie"),@Tag("eses"),@Tag("esen")})
    @SSTest(testCaseId = "42513975", projectId = "96896", testCaseName = "RAF Sight Test Appointment Journey 2207", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_10_RAF_AdultEyeTestAppointmentJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectAStore();
        fabr.rafSelectRequestAnAppointmentTab();

        fabr.selectRAFAppointmentAs_AdultEyeTest();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("ie")})
    @SSTest(testCaseId = "42521390", projectId = "96896", testCaseName = "RAF Contact Lens Initial Appointment Journey 2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_RAF_ContactLensInitialAppointmentJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectAStore();
        fabr.rafSelectRequestAnAppointmentTab();
        fabr.selectRAFAppointmentAs_ContactLensInitialappointment();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("ie")})
    @SSTest(testCaseId = "42521420", projectId = "96896", testCaseName = "RAF Child Eye Test Journey 2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_12_RAF_ChildEyeTestJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectAStore();
        fabr.rafSelectRequestAnAppointmentTab();
        fabr.selectRAFAppointmentAs_ChildEyeTest();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("au")})
    @SSTest(testCaseId = "42521427", projectId = "96896", testCaseName = "RAF Eye Test Appointment Journey 2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void Test_14_RAF_EyeTestAppointmentJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectAStore();
        fabr.selectRAFAppointmentAs_AdultEyeTest();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("au")})
    @SSTest(testCaseId = "42521678", projectId = "96896", testCaseName = "RAF Contact Lens Assessment Journey 2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_15_RAF_ContactLensAssessmentJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectAStore();
        fabr.selectRAFAppointmentAs_ContactLensAssessment();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42521680", projectId = "96896", testCaseName = "RAF_Sight-Test_Appointment_Journey_2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_10_RAF_AdultSightTestAppointmentJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectStore();
        fabr.clickRequestAnAppointmentButton();
        fabr.selectRAFAppointmentAs_AdultSightTest();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42521682", projectId = "96896", testCaseName = "RAF_Child_Sight-Test_Appointment_Journey_2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_12_RAF_ChildSightTestAppointmentJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectStore();
        fabr.clickRequestAnAppointmentButton();
        fabr.selectRAFAppointmentAs_ChildEyeTest();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42521733", projectId = "96896", testCaseName = "RAF_Contact_Lens_Consultation_&_Trial_Journey_2203", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_RAF_ContactLensConsultationAndTrialJourney(){
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectStore();
        fabr.clickRequestAnAppointmentButton();
        fabr.selectRAFAppointmentAs_ContactLensConsultationAndTrial();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("au"),@Tag("nl"),@Tag("no")})
    @SSTest(testCaseId = "42521735", projectId = "96896", testCaseName = "Book_Contact_Lens_Assessment_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC02_BookContactLensAssessmentJourney() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_ContactLensAssessment();
        fabr.clickOnBookAppointmentButtonInAppointTypePage();
        fabr.selectATimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("au"),@Tag("nl"),@Tag("no")})
    @SSTest(testCaseId = "42521734", projectId = "96896", testCaseName = "Eye-Test_Appointment_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC01_BookEyeTestAppointmentJourney() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_EyeOrAdultEyeTest();
        fabr.clickOnBookAppointmentButtonInAppointTypePage();
        fabr.selectATimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("ie")})
    @SSTest(testCaseId = "42592893", projectId = "96896", testCaseName = "Book_Adult_Sight-Test_Appointment_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_01_BookAdultSightTestAppointmentJourneyIE() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_AdultSightTest();

        fabr.chooseNoMedicalCard();
        fabr.areYouEligibleForAPRSI();
        fabr.chooseYourAppointment();
        fabr.selectTimeSlotForBooking();

        fabr.enterMandatoryPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42592893", projectId = "96896", testCaseName = "Book_Adult_Sight-Test_Appointment_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_01_BookAdultSightTestAppointmentJourney() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_AdultSightTest();

        fabr.selectTimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk"),@Tag("ie")})
    @SSTest(testCaseId = "42592904", projectId = "96896", testCaseName = "Test_02_Book_Child_Sight-Test_Appointment_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_02_BookChildEyeTestAppointmentJourney() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_ChildEyeTest();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsForChildEyeTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42592906", projectId = "96896", testCaseName = "Book_Contact_Lens_Consultation_&_Trial_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void GB_TC_03_BookContactLensConsultationAndTrialJourney() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectStore();
        fabr.selectSASAppointmentAs_ContactLensConsultationAndTrial();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("nl")})
    @SSTest(testCaseId = "41394853", projectId = "102929", testCaseName = "SAS_Book/Amend/Cancel", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void BookEyeTestAppointmentAmendDateAndTimeAndCancelAppointmentNl() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_EyeOrAdultEyeTest();
        fabr.clickOnBookAppointmentButtonInAppointTypePage();
        fabr.selectATimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();

        //Amend time of appointment
        fabr.clickOnChangeDateAndTime();
        fabr.selectSecondTimeSlotAvailable();
        fabr.clickOnChangeAppointmentButton();
        fabr.confirmYourBookingButton();
        fabr.VerifyAmendConfirmationPageTitleAndEmailBeingReceived();

        ////Amend to cancel appointment
        fabr.clicksOnCancelBookingLinkInAppointmentConfirmationPage(); //Cancellation of the appointment
        fabr.clicksOnConfirmCancelBookingButton();
        fabr.VerifyCancelConfirmationPageTitleAndEmailBeingReceived();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("au")})
    @SSTest(testCaseId = "42554279", projectId = "96896", testCaseName = "SAS_Book/Amend/Cancel", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void BookEyeTestAppointmentAmendDateAndTimeAndCancelAppointmentAU() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_EyeOrAdultEyeTest();
        fabr.clickOnBookAppointmentButtonInAppointTypePage();
        fabr.selectATimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.validateBookingInformationAndCheckMailosaurForEmail();

        //Amend time of appointment
        fabr.clickOnChangeDateAndTime();
        fabr.selectSecondTimeSlotAvailable();
        fabr.clickOnChangeAppointmentButton();
        fabr.confirmYourBookingButton();
        fabr.VerifyAmendConfirmationPageTitleAndEmailBeingReceived();

        ////Amend to cancel appointment
        fabr.clicksOnCancelBookingLinkInAppointmentConfirmationPage(); //Cancellation of the appointment
        fabr.clicksOnConfirmCancelBookingButton();
        fabr.VerifyCancelConfirmationPageTitleAndEmailBeingReceivedV4();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("ie")})
    @SSTest(testCaseId = "42554279", projectId = "96896", testCaseName = "SAS_Book/Amend/Cancel", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void BookEyeTestAppointmentAmendDateAndTimeAndCancelAppointmentIE() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_AdultSightTest();
        fabr.chooseNoMedicalCard();
        fabr.areYouEligibleForAPRSI();
        fabr.chooseYourAppointment();
        fabr.selectTimeSlotForBooking();

        fabr.enterMandatoryPersonalDetails();
        //fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();

        //Amend time of appointment
        fabr.clickOnChangeDateAndTime();
        fabr.selectSecondTimeSlotAvailable();
        fabr.clickOnChangeAppointmentButton();
        fabr.confirmYourBookingButton();
        fabr.VerifyAmendConfirmationPageTitleAndEmailBeingReceived();

        ////Amend to cancel appointment
        fabr.clicksOnCancelBookingLinkInAppointmentConfirmationPage(); //Cancellation of the appointment
        fabr.clicksOnConfirmCancelBookingButton();
        fabr.VerifyCancelConfirmationPageTitleAndEmailBeingReceivedV4();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk"),@Tag("no")})
    @Order(1)
    @SSTest(testCaseId = "41394853", projectId = "102929", testCaseName = "SAS_Book/Amend/Cancel", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void BookEyeTestAppointmentAmendDateAndTimeAndCancelAppointment(){
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectAStore();
        fabr.selectSASAppointmentAs_EyeOrAdultEyeTest();
        fabr.clickOnBookAppointmentButtonInAppointTypePageV4();

        fabr.selectTimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.confirmYourBookingButton();
        fabr.validateBookingInformationAndCheckMailosaurForEmail();

        //Amend time of appointment
        fabr.clickOnChangeDateAndTime();
        fabr.selectSecondTimeSlotAvailable();
        fabr.clickOnChangeAppointmentButton();
        fabr.confirmYourBookingButton();
        fabr.VerifyAmendConfirmationPageTitleAndEmailBeingReceived();

        ////Amend to cancel appointment
        fabr.clicksOnCancelBookingLinkInAppointmentConfirmationPage(); //Cancellation of the appointment
        fabr.clicksOnConfirmCancelBookingButton();
        fabr.VerifyCancelConfirmationPageTitleAndEmailBeingReceivedV4();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42607081", projectId = "96896", testCaseName = "BookRecAmend_ETest_CLCons_&_Trial_Appointment_Journey_2204", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void BookContactLensConsultationAndTrialAppointmentAmendDateAndTime() {
        fabr.openFabrHome();
        fabr.findSASStore();
        fabr.selectStore();
        fabr.selectSASAppointmentAs_ContactLensConsultationAndTrial();
        fabr.clickOnBookAppointmentButtonInAppointTypePage();
        fabr.selectATimeSlotForBooking();
        fabr.enterMandatoryPersonalDetails();
        fabr.validateBookingInformationAndCheckMailosaurForEmail();

        //Amend time of appointment
        fabr.clickOnChangeDateAndTime();
        fabr.selectSecondTimeSlotAvailable();
        fabr.clickOnChangeAppointmentButton();
        fabr.confirmYourBookingButton();
        fabr.VerifyAmendConfirmationPageTitleAndEmailBeingReceived();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("dk"),@Tag("se"),@Tag("fi"),@Tag("nz"),@Tag("eses"),@Tag("esen")})
    @SSTest(testCaseId = "42630867", projectId = "96896", testCaseName = "Find_a_store_via_the_header_store_finder", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void VerifyFindAStoreLinkInStoreSearchResultPage() {
        fabr.openFabrHome();
        fabr.v3_searchStoreViaFindStoreLink();
        fabr.v3_verifyFindAStoreLinkIsDisplayed();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("au"),@Tag("uk"),@Tag("no"),@Tag("nl"),@Tag("ie")})
    @SSTest(testCaseId = "42630867", projectId = "96896", testCaseName = "Find_a_store_via_the_header_store_finder", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void VerifyFindAStoreLinkInStoreSearchResultPageV4() {
        fabr.openFabrHome();
        fabr.v3_searchStoreViaFindStoreLink();
        fabr.v4_verifyFindAStoreLinkIsDisplayed();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("nz")})
    @SSTest(testCaseId = "42630871", projectId = "96896", testCaseName = "RequestForm", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void VerifyRequestForm() {
        fabr.openFabrHome();
        fabr.findRAFStore();
        fabr.selectAStore();
        fabr.selectRAFAppointmentAs_ContactLensAssessment();
        fabr.verifyRequestAnAppointmentButtonIsDisplayed();
    }

    @FandB_DRAP
    @Tags(value = {@Tag("ie"),@Tag("uk"), @Tag("nl"), @Tag("se"), @Tag("au"), @Tag("nz")})
    @SSTest(testCaseId = "42630873", projectId = "96896", testCaseName = "Contact Lens RX entry page - 'Book an appointment' link", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void VerifyBookAnAppointmentlinkNavigatesToFindAStoreSearchPage() {
        fabr.openFabrHome();
        fabr.acceptCookies();
        fabr.selectPrimaryLinkAsContactLensesInPrimaryLink();
        fabr.selectSubMenuLinkAsAcuvue();
        fabr.selectFirstContactLensItem();
        fabr.selectLeftEyeQuantity();
        fabr.clickOnPrescriptionButton();
        fabr.clickOnBookAppointmentLink();
        fabr.VerifyPostCodeSearchFieldIsDisplayed();
    }

    @FandB_DRAP
    @SSTest(testCaseId = "42709632", projectId = "96896", testCaseName = "Drupal Audiology Booking", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void verifyDrupalAudiologyBooking() {
        fabr.openFabrHome();
        fabr.findSASStoreForHearing();
        fabr.selectAStore();
        fabr.clickOnHearingServices();
        fabr.clickHearingAppointment();
        fabr.clickAudiologyATTNoOption();
        fabr.clickAudiologyATTNoOption();
        fabr.clickAudiologyATTNoOption();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsforAudiologyTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.checkEmailInMailosaur();
    }

    @AfterEach
    public void tearDown() {
        fabr.closeSession();
    }
}

