package digital.fabr.api.response.store.storeByURL;

public class GraphQLStoreByURLResponse {
}
