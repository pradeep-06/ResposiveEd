package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class FabrPersonalDetailsPage extends BasePageObject {

    @FindBy(id = "page-header_title")
    private WebElementFacade personalDetailsPageHeader;

    @FindBy(css = "h1#page-header_title")
    private WebElementFacade personalDetailsPageTitle;

    @FindBy(css = "h2#form-section-personal-details_heading")
    private WebElementFacade personalDetailPageHeading;

    @FindBy(css = "#form-section-personal-details_title_select")
    private WebElementFacade selectTitle;

    @FindBy(name = "firstName")
    private WebElementFacade firstName;

    @FindBy(name = "lastName")
    private WebElementFacade lastName;

    @FindBy(name = "postcode")
    private WebElementFacade postCode;

    @FindBy(name = "day")
    private WebElementFacade date;

    @FindBy(name = "month")
    private WebElementFacade month;

    @FindBy(name = "year")
    private WebElementFacade year;

    @FindBy(name = "email")
    private WebElementFacade email;

    @FindBy(name = "mobileNumber")
    private WebElementFacade mobileNumber;

    @FindBy(id = "continue-button")
    private WebElementFacade continueBooking;

    @FindBy(css = "p#form-section-contact-details_mobile-number_footer")
    private WebElementFacade covid19Message;

    @FindBy(css = "button#form-section-contact-details_mobile-number_link")
    private WebElementFacade dontHaveMobileNumberLink;

    @FindBy(css = "fieldset#form-section-additional-information_healthcare-provider_radio_group label")
    private List<WebElementFacade> nhsEyeTestOption;

    @FindBy(id = "journey-page-footer_continue-button")
    private WebElementFacade continueBookingButton;

    @FindBy(css = "p#cancel-and-go-back-banner_title")
    private WebElementFacade cancelAndGoBannerTitle;

    @FindBy(css = "a#journey-page-footer_cancel-and-go-back-link")
    private WebElementFacade cancelAndGoBackLink;

    @FindBy(css = "p#form-section-personal-details_dob_error")
    private WebElementFacade personalDetailsDOBErrorTitle;

    @FindBy(css = "a#form-section-personal-details_dob_link")
    private WebElementFacade changeAppointmentTypeLink;

    @FindBy(css = "ul#error-banner_specs-list_list li")
    private List<WebElementFacade> errorBannerList;

    @FindBy(css = "[id='customerTitle'],[id='form-section-personal-details_title_select']")
    private WebElementFacade v3_selectTitle;

    @FindBy(css = "[id='customerFirstName'],[id='form-section-personal-details_first-name_input']")
    private WebElementFacade v3_firstName;

    @FindBy(css="[id='customerLastName'],[id='form-section-personal-details_last-name_input']")
    private WebElementFacade v3_lastName;

    @FindBy(css="[id='customerDoBDay'],[id='form-section-personal-details_dob_input_day_input']")
    private WebElementFacade v3_date;

    @FindBy(css="[id='customerDoBMonth'],[id='form-section-personal-details_dob_input_month_input']")
    private WebElementFacade v3_month;

    @FindBy(css="[id='customerDoBYear'],[id='form-section-personal-details_dob_input_year_input']")
    private WebElementFacade v3_year;

    @FindBy(css="[id='customerEmail'],[id='form-section-contact-details_email_input']")
    private WebElementFacade v3_email;

    @FindBy(css="[id ='customerMobile'],[id='form-section-contact-details_mobile-number_input']")
    private WebElementFacade v3_mobileNumber;

    @FindBy(css="[id='customer-details-submit-button'],[id='journey-page-footer_continue-button'], button[class='button button--primary js-action-submit'],a[id='journey-page-footer_continue-button'],[id='continue-button']")
    private WebElementFacade v3_continueBookingButton;

    @FindBy(css="[id='form-section-personal-details_postcode_input']")
    private WebElementFacade v3_postCode;

    @FindBy(name = "ppsNumber")
    private WebElementFacade ppsNumber;

    public boolean personalDetailsPageIsDisplayed() {

        return this.personalDetailsPageHeader.waitUntilVisible().isDisplayed();
    }

    public void selectTitle(String title) {
        try {
            this.selectTitle.selectByValue(title);
        }
        catch(Exception e){
            this.selectTitle.selectByVisibleText(title);
        }
    }

    public boolean personalDetailsPageTitleDisplayed() {
        return this.personalDetailsPageTitle.isDisplayed();
    }

    public boolean personalDetailPageHeadingDisplayed() {
        return this.personalDetailPageHeading.isDisplayed();
    }

    public void enterFirstName(String firstName) {
        this.firstName.clear();
        setText(this.firstName, firstName);
    }

    public void enterLastName(String lastName) {
        this.lastName.clear();
        setText(this.lastName, lastName);
    }

    public void enterPostCode(String postCode) {
        this.postCode.clear();
        setText(this.postCode, postCode);
    }

    public void enterDate(String date) {
        setText(this.date, date);
    }

    public void enterMonth(String month) {
        this.month.clear();
        setText(this.month, month);
    }

    public void enterYear(String year) {
        this.year.clear();
        setText(this.year, year);
    }

    public void enterEmail(String email) {
        this.email.clear();
        setText(this.email, email);
    }

    public void enterMobileNumber(String mobileNumber) {
        this.mobileNumber.clear();
        setText(this.mobileNumber, mobileNumber);
    }

    public void clickContinueBookingButton() {
        clickElement(this.continueBookingButton);
    }

    public boolean personalDetailsEmailIsDisplayed(String email) {
        return this.email.getText().equals(email);
    }

    public void assertPersonalDetailsEmailIsDisplayed(String email){
        assertElementContainsValue(this.email,email);
    }

    public boolean personalDetailsMobileNoIsDisplayed(String mobileno) {
        return this.mobileNumber.getText().equals(mobileno);
    }

    public boolean personalDetailsFirstNameIsDisplayed(String firstName) {
        return this.firstName.getText().equals(firstName);
    }

    public boolean personalDetailsLastNameIsDisplayed(String lastName) {
        return this.lastName.getText().equals(lastName);
    }

    public void cancelAndGoBannerTitleIsDisplayed() {
        assertPageObjectIsDisplayed(this.cancelAndGoBannerTitle);
    }

    public void clickCancelAndGoBackLink() {
        clickElement(this.cancelAndGoBackLink);
    }

    public boolean personalDetailsDOBErrorTitleIsDisplayed() {
        return this.personalDetailsDOBErrorTitle.waitUntilVisible().isDisplayed();
    }

    public boolean changeAppointmentTypeLinkIsDisplayed() {
        return this.changeAppointmentTypeLink.waitUntilVisible().isDisplayed();
    }

    public void clickOnChangeAppointmentTypeLink() {
        clickElement(changeAppointmentTypeLink);
    }

    public void errorBannerListItemsIsDisplayed() {
        boolean status = false;
        for (WebElementFacade itr : errorBannerList) {
            if (itr.isDisplayed()) {
                status = true;
            }
        }
    }

    public void v3_selectTitle(String title) {
        this.v3_selectTitle.selectByVisibleText(title);
    }

    public void assertPersonalDetailsFirstNameIsDisplayed(String firstName) {
        assertElementContainsValue(this.firstName,firstName);
    }

    public void  assertPersonalDetailsLastNameIsDisplayed(String lastName) {
        assertElementContainsValue(this.lastName,lastName);
    }

    public void v3_enterFirstName(String firstName) {
        this.v3_firstName.clear();
        setText(this.v3_firstName, firstName);
    }

    public void v3_enterLastName(String lastName) {
        this.v3_lastName.clear();
        setText(this.v3_lastName, lastName);
    }

    public void v3_enterDate(String date) {
        setText(this.v3_date, date);
    }

    public void v3_enterMonth(String month) {
        this.v3_month.clear();
        setText(this.v3_month, month);
    }

    public void v3_enterYear(String year) {
        this.v3_year.clear();
        setText(this.v3_year, year);
    }

    public void v3_enterEmail(String email) {
        this.v3_email.clear();
        setText(this.v3_email, email);
    }

    public void v3_enterMobileNumber(String mobileNumber) {
        this.v3_mobileNumber.clear();
        setText(this.v3_mobileNumber, mobileNumber);
    }

    public void v3_enterPostCode(String postCode) {
        this.v3_postCode.clear();
        setText(this.v3_postCode, postCode);
    }

    public void v3_clickContinueBookingButton() {
        clickElement(v3_continueBookingButton);
    }

    public void inputPPSNumber(String ppsNumber){
        this.ppsNumber.clear();
        setText(this.ppsNumber,ppsNumber);
    }
}
