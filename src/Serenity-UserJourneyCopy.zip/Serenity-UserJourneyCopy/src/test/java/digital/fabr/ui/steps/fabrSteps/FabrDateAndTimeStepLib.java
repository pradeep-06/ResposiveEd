package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrDateAndTimePage;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FabrDateAndTimeStepLib {
    FabrDateAndTimePage fabrDateAndTime;
    public void assertDateAndTimePage() {
        assertThat(fabrDateAndTime.dateAndTimeIsDisplayed());
    }

    public void assertDateAndTimePageTitle() {
        assertThat(fabrDateAndTime.dateAndTimeTitleIsDisplayed());
    }

    public void clickDateAndTime() {
        fabrDateAndTime.clickDateAndTime();
    }

    public void clickContinueButton() {
        fabrDateAndTime.clickContinueButton();
    }

    public void selectNewDateAndTime() {
        fabrDateAndTime.selectNewDateAndTime();

    }

    public void clickCancelAndGoLink() {
        fabrDateAndTime.clickCancelAndGoLink();
    }

    public void clickCheckOutOtherStoreLink() {
        fabrDateAndTime.clickCheckOutOtherStoreLink();
    }

    public void selectPreviousTimeSlots() {
        fabrDateAndTime.selectPreviousTimeSlots();
    }

    public void clickLaterTimeSlotsIcon() {
        fabrDateAndTime.clickLaterTimeSlotsIcon();
    }

    public void assertCalendarNoAvailabilityPeriodBannerTitle() {
        fabrDateAndTime.calendarNoAvailabilityPeriodBannerTitleIsDisplayed();
    }

    public void assertOtherStoreLink() {
        fabrDateAndTime.otherStoreLinkIsDisplayed();
    }

    public void waitForLoadingWrapperToDisappear() {
        fabrDateAndTime.waitForLoadingWrapperToDisappear();
    }

    public void v3_selectSecondTimeSlot(){
        fabrDateAndTime.v3_selectSecondTimeSlot();
    }
}
