package digital.fabr.ui.extensions.util.Monetate;

import digital.fabr.ui.extensions.FabrBase;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.function.DoublePredicate;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class MonetateCookieUtils extends FabrBase {

    /**
     * Generates a MonetateId that can be used to enable the feature at the given percentage
     * @param featureName   The name of the feature to enable
     * @param percentage    The percentage of users currently seeing that feature
     * @return              A MonetateId that will put the user within the percentage
     */
    public static String generateMonetateIdWithFeatureEnabled(final String featureName, final int percentage) {
        return generateMonetateIdForPredicate(featureName, hash -> (hash % 100) <= percentage);
    }

    /**
     * Generates a MonetateId that can be used to disable the feature at the given percentage
     * @param featureName   The name of the feature to disable
     * @param percentage    The percentage of users currently seeing that feature
     * @return              A MonetateId that will put the user outside the percentage
     */
    public static String generateMonetateIdWithFeatureDisabled(final String featureName, final int percentage) {
        return generateMonetateIdForPredicate(featureName, hash -> (hash % 100) > percentage);
    }

    private static String generateMonetateIdForPredicate(String featureName, DoublePredicate hashPredicate) {
        int third = 1111;

        double computedHash;
        String monetateId;

        do {
            monetateId = generateMonetateId(third++);
            computedHash = hash(monetateId, featureName);
        } while (!hashPredicate.test(computedHash));

        return monetateId;
    }

    public static double hash(String monetateId, String featureName) {
        double featureId = internalHash(monetateId+ "|" + featureName);

        return featureId < 0 ? featureId + 4294967296L : featureId;
    }

    /*
     * This is meant to replicate the JS hash function provided by Monetate.
     * Javascript has a very niche way of handling bitwise operations on numbers, see: https://www.w3schools.com/js/js_bitwise.asp.
     * Because of this we need to store our number as a long, but convert it to an int when performing the bitwise operations.
     */
    private static double internalHash(String monetateFeatureHash) {
        Long randomInt = 2166136261L;

        for(int i = 0; i < monetateFeatureHash.length(); i++) {
            randomInt = (long) (randomInt.intValue() ^ Character.codePointAt(monetateFeatureHash, i));

            int as32Bit = randomInt.intValue();
            randomInt += (as32Bit << 1) + (as32Bit << 4) + (as32Bit << 7) + (as32Bit << 8) + (as32Bit << 24);
        }

        return randomInt & 4294967295L;
    }

    private static String generateMonetateId(int third) {
        return String.format("2.1111.%d", third);
    }

}
