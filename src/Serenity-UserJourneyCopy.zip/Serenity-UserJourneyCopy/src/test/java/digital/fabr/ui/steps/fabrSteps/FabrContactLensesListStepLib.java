package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrContactLensesListPage;
import net.thucydides.core.steps.ScenarioSteps;

public class FabrContactLensesListStepLib extends ScenarioSteps {
    FabrContactLensesListPage fabrContactLensesListPage;

    public void v3_selectFirstContactLensItem() {
        fabrContactLensesListPage.v3_selectFirstContactLensItem();
    }
}
