package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_AU;
import Framework.Annotations.FABR.FandB_R_REG;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Screenshots;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("fabr")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class Slice2EndToEndTestCases {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;

    @Disabled("out of scope")
    @Screenshots(forEachAction = true)
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(1)
    @SSTest(testCaseId = "39765347", projectId = "102929", testCaseName = "TC_02-Book-Standard booking journey via 'Book appointment' CTA", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_02_BookingJourneyWithBookAppointmentCTA() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyErrorMessageIsDisplayedForRequiredFields();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.validateBookingDataAndCheckMailosaurForEmail();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
    }

    // TODO: need to have a store where slots are not available
    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(2)
    @SSTest(testCaseId = "39767022", projectId = "102929", testCaseName = "TC_07-Book-Standard booking journey when no slots are available for a week", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_07_BookStandardBookingJourneyWhenNoSlotsAreAvailable() {
        fabr.openFabrHome();
        fabr.findStore5();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.verifyCalendarNoAvailabilityPeriodBannerTitleDisplayed();
        fabr.otherStoreLinkIsAvailable();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(3)
    @SSTest(testCaseId = "39798109", projectId = "102929", testCaseName = "TC_11-Booking journey via Book Appointment CTA", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_BookingJourneyOCTAppointment() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestATTAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(4)
    @SSTest(testCaseId = "39798111", projectId = "102929", testCaseName = "TC_12-Appointment booking journey- STAC appointments", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_12_AppointmentBookingJourneySTAC() {
        fabr.openFabrHome();
        //  TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestATTAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("au"), @Tag("no"),@Tag("ie")})
    @Order(5)
    @SSTest(testCaseId = "39798113", projectId = "102929", testCaseName = "TC_13-Appointment booking journey-Child eye test ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_13_BookingJourneyChildEyeTest() {
        fabr.openFabrHome();
        //  TODO: "Need to add click on Book Appointment button once it is available and cookie management"
        fabr.findStore1();
        fabr.selectStore();
        fabr.chooseChildEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsForChildEyeTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au")})
    @Order(6)
    @SSTest(testCaseId = "39798114", projectId = "102929", testCaseName = "TC_14-Book-Changing appointment type from recap page while performing a book journey ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_14_ChangeAppointmentTypeFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeAppointmentLink();
        fabr.verifyAppointmentPage();
        fabr.chooseContactLensAppointmentTypeWithATTAnswers();
        fabr.selectNewDateAndTime();
        fabr.verifyCustomerDetails();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("au"),@Tag("nl")})
    @Order(7)
    @SSTest(testCaseId = "39798115", projectId = "102929", testCaseName = "TC_15-Change appointment type from recap page but later cancel and go back", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_15_ChangeAppointmentFromRecapPageButLaterCancel() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeAppointmentLink();
        fabr.verifyAppointmentPage();
        fabr.clickOnCancelAndGoLink();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(8)
    @SSTest(testCaseId = "39798117", projectId = "102929", testCaseName = "TC_16-Changing appointment date/time from recap page while performing a book journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_16_ChangeAppointmentDateAndTimeFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changeDateAndTimeFromRecapPage();
        fabr.verifyDateAndTimePage();
        fabr.selectNewDateAndTime();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(9)
    @SSTest(testCaseId = "39798119", projectId = "102929", testCaseName = "TC_17-Changing appointment date/time from recap page but later cancels the action while performing a book journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_17_ChangeAppointmentDateAndTimeFromRecapPageAndLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changeDateAndTimeFromRecapPage();
        fabr.verifyDateAndTimePage();
        fabr.clickOnCancelAndGoLinkInDateAndTime();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(10)
    @SSTest(testCaseId = "39798120", projectId = "102929", testCaseName = "TC_18-Changing personal details from recap page while performing a book journey ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_18_ChangePersonalDetailsFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changePersonalDetailsFromRecapPage();
        fabr.verifyPersonalDetailsPage();
        fabr.reEnterPersonalDetailsInRecapPage();
        fabr.clickOnContinueInPersonalDetailPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(11)
    @SSTest(testCaseId = "39798123", projectId = "102929", testCaseName = "TC_19-Changing personal details from recap page but later cancels the action while performing a book journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_19_ChangePersonalDetailsFromRecapPageAndLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.changePersonalDetailsFromRecapPage();
        fabr.verifyPersonalDetailsPage();
        fabr.clickOnCancelAndGoBackLinkInPersonalDetails();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(12)
    @SSTest(testCaseId = "39799789", projectId = "102929", testCaseName = "TC_20-Changing location from recap page while performing a book journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_20_ChangeLocationFromRecapPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeLocationLink();
        fabr.verifyLocationPage();
        // TODO: need to change store
        fabr.findStore1WithoutCookies();
        fabr.selectStore();
        fabr.chooseAdultEyeTestATTAppointmentType();
        fabr.clickOnNoAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.confirmPersonalDetailsAndBooking();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(13)
    @SSTest(testCaseId = "39800024", projectId = "102929", testCaseName = "TC_21-Changing location from recap page but later cancels the action while performing a book journey", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_21_ChangeLocationFromRecapPageAndLaterCancelIt() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.clickOnChangeLocationLink();
        fabr.verifyLocationPage();
        fabr.clickCancelAndGoBackLink();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(14)
    @SSTest(testCaseId = "39800028", projectId = "102929", testCaseName = "TC_22-Book-Navigation to the various pages in book journey using breadcrumbs", testType = SSTestType.E2E, testCaseVersion = "3.0")
    public void TC_22_NavigationToVariousPagesUsingBreadcrumbs() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyPersonalDataInRecapPage();
        fabr.clickLocationBreadcrumb();
        fabr.verifyLocationPage();
        fabr.clickCancelAndGoBackLink();
        fabr.clickAppointmentTypeBreadcrumb();
        fabr.verifyAppointmentPage();
        fabr.clickCancelAndGoInAppointmentTypePage();
        fabr.clickDateAndTimeBreadcrumb();
        fabr.verifyDateAndTimePage();
        fabr.clickOnCancelAndGoLinkInDateAndTime();
        fabr.clickPersonalDetailsBreadcrumb();
        fabr.verifyPersonalDetailsPage();
        fabr.clickOnCancelAndGoBackLinkInPersonalDetails();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk")})
    @Order(15)
    @SSTest(testCaseId = "39800176", projectId = "102929", testCaseName = "TC_44-Ensure adult customer is unable to book a child eye test appointment for himself", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_44_EnsureAdultCustomerIsUnableToBookChildEyeTest() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseChildEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.verifyValidationMessageForWrongAppointmentSelection();
        fabr.verifyChangeAppointmentTypeLinkIsAvailable();
        fabr.clickAnotherAppointmentTypeLink();
        fabr.chooseChildEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsForChildEyeTest();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBooking();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(16)
    @SSTest(testCaseId = "39804306", projectId = "102929", testCaseName = "TC_51-Customer starts a new store search from DTP and completes the booking", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_51_CustomerStartsNewStoreSearchFromDTP() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.clickOtherStoreLinkInDTP();
        // TODO: need to change store
        fabr.findStore4WithoutCookies();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(17)
    @SSTest(testCaseId = "39765894", projectId = "102929", testCaseName = "TC_39-RAF journey for a store which a not enabled/de-whitelisted", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_39_RAFBookingJourneyForAStoreWhichIsNotEnabled() {
        fabr.openFabrHome();
        fabr.findStore9();
        fabr.selectStore();
        fabr.clickRequestAnAppointmentButton();
        fabr.acceptCookiesForRAFPage();
        fabr.clickRAFAdultEyeTest();
        fabr.inputRAFPersonalDetailsForBooking();
        fabr.clickRAFSubmitButton();
        fabr.verifyRAFBooking();
        fabr.verifyRAFAppointmentContainerInformation();
    }


    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nl")})
    @Order(18)
    @SSTest(testCaseId = "40928552", projectId = "102929", testCaseName = "TC_54- Appointment booking journey from the Store pages", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_54_AppointmentBookingJourneyFromStorePage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.clickStoreDetails();
        fabr.verifyStoreGeneralInformation();
        fabr.clickBookAppointmentInStorePage();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyRecapPage();
        fabr.confirmBookingAndValidateEmail();
    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au")})
    @Order(19)
    @SSTest(testCaseId = "39770765", projectId = "102929", testCaseName = "TC_27-Keep current appointment journey from when card on confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_27_KeepCurrentAppointmentJourneyFromWhenCardOnConfirmationPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.clickChangeAppointmentDateAndTimeInBookingConfirmationPage();
        fabr.keepCurrentAppointmentAndValidateEmailInMailosaur();
    }
    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au")})
    @Order(20)
    @SSTest(testCaseId = "39800097", projectId = "102929", testCaseName = "TC_29-Amend-Appointment amend journey using cancel booking link on confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_29_AmendAppointmentJourneyFromBookingConformationPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.clickCancelBookingInBookingConfirmationPage();
        fabr.amendConfirmedBookingDateAndTimeAndValidateEmailInMailosaur();

    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(21)
    @SSTest(testCaseId = "39800099", projectId = "102929", testCaseName = "TC_30-Keep current appointment journey using cancel booking link on confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_30_KeepCurrentAppointmentJourneyUsingCancelBookingLinkOnConfirmationPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.clickCancelBookingInBookingConfirmationPage();
        fabr.keepCurrentBookingJourneyUsingCancelBookingOnConfirmationPage();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nl")})
    @Order(22)
    @SSTest(testCaseId = "39814335", projectId = "102929", testCaseName = "TC_28-Cancel-Appointment cancellation journey from when card on confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_28_CancelCurrentAppointmentJourneyFromWhenCardOnConfirmationPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.selectAdultEyeTestATTWithAnswer();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.clickChangeAppointmentDateAndTimeInBookingConfirmationPage();
        fabr.cancelBookingFromAmendPage();

    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nl")})
    @Order(23)
    @SSTest(testCaseId = "39800102", projectId = "102929", testCaseName = "TC_32-Amend-Amending the amended appointment via confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_32_AmendAmendingAppointmentJourneyFromConformationPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.confirmBooking();
        fabr.clickChangeAppointmentDateAndTimeInBookingConfirmationPage();
        fabr.amendAmendedBookingDateAndTimeAndValidateEmailInMailosaur();

    }

    @FandB_R_REG
    @FandB_R_AU
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nl")})
    @Order(24)
    @SSTest(testCaseId = "39800169", projectId = "102929", testCaseName = "TC_38-Cancel-Cancelling an amended appointment via confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_38_CancelAmendedAppointmentJourneyFromConformationPage() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyDetailsAndContinueWithBooking();
        fabr.clickChangeAppointmentDateAndTimeInBookingConfirmationPage();
        fabr.cancelBookingFromAmendPage();
        fabr.checkEmailInMailosaur();
    }


    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(25)
    @SSTest(testCaseId = "39770764", projectId = "102929", testCaseName = "TC_24-Keep current appointment option journey via email using change date/time link", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_24_KeepCurrentAppointmentJourneyViaEmail() {
        fabr.keepCurrentAppointmentOptionJourneyViaEmailUsingChangeDateAndTimeLink();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(26)
    @SSTest(testCaseId = "39800104", projectId = "102929", testCaseName = "TC_33-Cancel-Appointment cancellation journey using cancel link in email", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_33_AppointmentCancellationJourneyUsingCancelLinkInEmail() {
        fabr.appointmentCancellationJourneyUsingCancelLinkInEmail();
    }


    @Disabled("out of scope")
    @FandB_R_REG
    @Tags(value = {@Tag("uk"), @Tag("au")})
    @Order(27)
    @SSTest(testCaseId = "39800166", projectId = "102929", testCaseName = "TC_33-Cancel-Appointment cancellation journey using cancel link in email", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_35_AppointmentAmendmentJourneyUsingCancelLinkInEmail() {
        fabr.appointmentAmendmentJourneyUsingCancelLinkInEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(28)
    @SSTest(testCaseId = "39800168", projectId = "102929", testCaseName = "TC_35-Amend-Appointment amendment journey using cancel link in email", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_37_CancellingAnAmendedAppointmentViaEmail() {
       fabr.cancellingAnAmendedAppointmentViaEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(29)
    @SSTest(testCaseId = "39800101", projectId = "102929", testCaseName = "TC_31-Amend-Amending the amended appointment via email", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_31_AmendingTheAmendedAppointmentViaEmail() {
        fabr.amendAmendedJourneyFromEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(30)
    @SSTest(testCaseId = "39800165", projectId = "102929", testCaseName = "TC_31-Amend-Amending the amended appointment via email", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_34_KeepCurrentAppointmentJourneyUsingCancelLinkInEmail() {
        fabr.keepCurrentAppointmentUsingCancelLinkInEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk"),@Tag("au")})
    @Order(30)
    @SSTest(testCaseId = "39767033", projectId = "102929", testCaseName = "TC_25-Cancel-Customer cancelling the appointment using the change date/time link in email", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_25_CustomerCancellingTheAppointmentUsingDateAndTimeLinkInEmail() {
        fabr.customerCancelTheAppointmentUsingAmendLinkInEmail();
    }

   @Disabled("out of scope")
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(30)
    @SSTest(testCaseId = "39800167", projectId = "102929", testCaseName = "TC_36-Cancel-Appointment cancellation journey using cancel booking link on confirmation page", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_36_AppointmentCancellingJourneyUsingCancelBookingLinkOnConfirmationPage() {
       fabr.appointmentCancellationJourneyUsingLinkInEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"),@Tag("nl")})
    @Order(30)
    @SSTest(testCaseId = "39800167", projectId = "102929", testCaseName = "TC_36-Cancel-Appointment cancellation journey using cancel booking link on confirmation page", testType = SSTestType.E2E, testCaseVersion = "2.0")
    public void TC_40_EditAppointmentUsingManageMyBooking(){
        fabr.openFabrHome();
        fabr.findStore1();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentTypeWithoutATT();
        fabr.selectTimeSlotForBooking();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.verifyErrorMessageIsDisplayedForRequiredFields();
        fabr.enterPersonalDetails();
        fabr.continueWithBookingInPersonalDetailsPage();
        fabr.editBookingDateUsingManageYourBookingSection();
    }

    @AfterEach
    public void tearDown() {
        fabr.closeSession();
    }

}
