package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import Framework.Staf;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FabrLocationPage extends BasePageObject {

    private final Logger logger = LoggerFactory.getLogger(FabrLocationPage.class);
    @FindBy(css = "input#specs-location-search-form_input")
    private WebElementFacade postcodeEntryField;

    @FindBy(css = "button#specs-location-search-form_button")
    private WebElementFacade getSearchStoreButton;

    @FindBy(css = "li.store-search-results__item:nth-child(1)>div>section>section.specs-store-result-card__store-details>div>button")
    private WebElementFacade bookOnlineButton;

    @FindBy(css = "p#cancel-and-go-back-banner_title")
    private WebElementFacade cancelAndGoBannerTitle;

    @FindBy(css = "a#cancel-and-go-back-link")
    private WebElementFacade cancelAndGoBackLink;

    @FindBy(css = "button[aria-label='Request an appointment at this store']")
    private WebElementFacade requestAppointment;

    @FindBy(xpath = "(//div[@class=\"specs-store-result-card__store-details-actions\"]/a)[1]")
    private WebElementFacade storeDetails;

    @FindBy(id = "change-location-link")
    private WebElementFacade changeLocationLink;

    @FindBy(css = "div#cookie-prompt button")
    private WebElementFacade acceptCookies;

    @FindBy(xpath = "(//h2[contains(@id,'store-search-results_specs-store-result-card_title')])[1]")
    private WebElementFacade searchedStoreText;

    @FindBy(css = "form.store-search-form.compact-form>div>input,#customer--location,input#search,input#specs-location-search-form_input,#specs-location-search-form_input")
    private WebElementFacade searchEntryField;  //supports v3 and v4

    @FindBy(css="button#edit-submit,div.ss-form-group.ng-dirty.ng-valid.ng-touched>span,button#specs-location-search-form_button,svg[class='form__icon js-search-submit'],button#specs-location-search-form_button")
    private WebElementFacade findButton;  //supports v3 and v4

    @FindBy(css="li[class*='views-row-first'] a[class='btn btn-primary'],#ss-button-select-store,div.store__actions>a,div[class='specs-store-result-card__store-details-actions'] button[id*='store-search-results_specs-store-result-card_book-button'],div:nth-child(1) > div.store__actions > button")
    private WebElementFacade v3_bookOnlineButton;

    @FindBy(css="ul.ss-top-bar__left-col-group a[trackaid=\"header-find-store-icon\"]")
    private WebElementFacade v3_findAStore;

    @FindBy(css="#header-topbar-location > div")
    private WebElementFacade v4_findAStore;

    @FindBy(css = "#googleplaceautocompletefield1, #specs-location-search-form_input")
    private WebElementFacade v3_postcodeEntryField;
    
    public void enterLocationTown(String location) {
            clickElement(this.postcodeEntryField);
            setText(this.postcodeEntryField, location);
    }

    public void clickSearch() {
                clickElement(this.getSearchStoreButton);
                waitForTimeoutInMilliseconds();
    }

    public void bookOnlineInSelectedLocation(String region) {
            Staf.wait.until(WebElementExpectations.elementIsDisplayed(bookOnlineButton));
            clickElement(bookOnlineButton);
           }

    public boolean verifyCancelAndGoBannerIsDisplayed() {
        return this.cancelAndGoBannerTitle.isDisplayed();
    }

    public void clickCancelAndGoLink() {
        clickElement(this.cancelAndGoBackLink);
    }

    public void clickRequestAppointment() {
        clickElement(this.requestAppointment);
    }

    public void clickStoreDetails() {
        clickElement(this.storeDetails);
    }

    public void acceptCookienOnLocationPage(){
        clickElement(this.acceptCookies);
    }

    public boolean verifyCookieDisplayed(){
        return this.acceptCookies.isDisplayed();
    }

    public void clickOnLocationSearchTextArea(){
        clickElement(this.postcodeEntryField);
    }

    public void inputNewStore(String location){
        this.postcodeEntryField.sendKeys(location);
    }

    public void clickChangeLocationLink(){
        evaluateScriptClick(changeLocationLink);
    }

    public WebElementFacade getSearchedStoreText(){
        return this.searchedStoreText;
    }

    public void waitForElementTextToAppear(WebElementFacade element, String text) {

        for (int i = 0; i <= 2; i++) {
            try {
                waitForCondition().until(
                        ExpectedConditions.textToBePresentInElement(element, text));
                break;
            } catch (NoSuchElementException | ElementNotInteractableException e) {
                logger.info(e.getMessage());
            }
        }
    }

    public void enterSearchLocation(String location) {
        setText(this.searchEntryField, location);
        this.searchEntryField.sendKeys(Keys.TAB);
        this.searchEntryField.click();
    }

    public void clickFindButton()
    {
        clickElement(findButton);
    }

    public void v3_bookOnlineInSelectedLocation() {
            Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_bookOnlineButton));
            clickElement(v3_bookOnlineButton);
    }

    public void v3_VerifyPostCodeSearchFieldIsDisplayed(){
        assertPageObjectIsDisplayed(this.v3_postcodeEntryField);
    }

    public void v3_VerifyFindAStoreLinkIsDisplayed(){
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_bookOnlineButton));
        assertPageObjectIsDisplayed(this.v3_findAStore);
    }

    public void v4_VerifyFindAStoreLinkIsDisplayed(){
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_bookOnlineButton));
        assertPageObjectIsDisplayed(this.v4_findAStore);
    }
}
