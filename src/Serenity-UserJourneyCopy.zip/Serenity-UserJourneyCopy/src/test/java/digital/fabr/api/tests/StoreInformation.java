package digital.fabr.api.tests;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_API;
import digital.fabr.api.steps.StoresSteps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class StoreInformation {

    @Steps
    StoresSteps getStores;

    @Disabled("out of scope")
    @FandB_R_API
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "39765894", projectId = "102929", testCaseName = "TC_39-RAF journey for a store which a not enabled/de-whitelisted", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void getStoreByURL(){
        getStores.getStoreByURLAndVerifyInformation();
    }

    @Disabled("out of scope")
    @FandB_R_API
    @Tags(value = {@Tag("no")})
    @SSTest(testCaseId = "39765894", projectId = "102929", testCaseName = "TC_39-RAF journey for a store which a not enabled/de-whitelisted", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void getAllStoresInformtion(){
      getStores.getStoresInformationBasesOnLocation();
    }

    @Disabled("out of scope")
    @FandB_R_API
    @Tags(value = {@Tag("no")})
    @SSTest(testCaseId = "39765894", projectId = "102929", testCaseName = "TC_39-RAF journey for a store which a not enabled/de-whitelisted", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void getSoreInformationBasedOnLocation(){
        getStores.getStoresInformationBasesOnLocation();
    }
}
