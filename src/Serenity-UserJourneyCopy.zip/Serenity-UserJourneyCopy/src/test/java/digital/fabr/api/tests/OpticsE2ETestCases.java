package digital.fabr.api.tests;

import Framework.Annotations.API;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_API;
import Framework.DataManager.TestDataManager;
import digital.fabr.api.steps.AppointmentSteps;
import net.serenitybdd.annotations.Screenshots;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class OpticsE2ETestCases {

    @Steps
    AppointmentSteps appointmentSteps;

    protected final TestDataManager testDataManager = new TestDataManager();

    @API
    @FandB_R_API
    @Screenshots(forEachAction = true)
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("ie"), @Tag("nl")})
    @Order(1)
    @SSTest(testCaseId = "42853420", projectId = "102929", testCaseName = "TC_02-Book-Standard booking journey via 'Book appointment' CTA", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_02_BookingJourneyWithBookAppointmentCTA() {
        appointmentSteps.getSlotsInformation(testDataManager.getTestInputRegionData("storeName.store1"));
        appointmentSteps.bookAppointmentForOpticalJourney();
        appointmentSteps.cancelAppointmentForOpticalJourney();
    }
    @FandB_R_API
    @Tags(value = {@Tag("uk")})
    @Order(3)
    @SSTest(testCaseId = "42853421", projectId = "102929", testCaseName = "TC_11-Booking journey via Book Appointment CTA", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_BookingJourneyOCTAppointment() {
        appointmentSteps.getSlotsInformationForOCTSCAN(testDataManager.getTestInputRegionData("storeName.store1"));
        appointmentSteps.bookAppointmentForOCTScanOpticalJourney();
        appointmentSteps.cancelAppointmentForOpticalJourney();
    }


    @API
    @FandB_R_API
    @Tags(value = {@Tag("uk"), @Tag("au"), @Tag("no"), @Tag("ie"), @Tag("nl")})
    @Order(5)
    @SSTest(testCaseId = "42853447", projectId = "102929", testCaseName = "TC_13-Appointment booking journey-Child eye test ", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_13_BookingJourneyChildEyeTest() {
        appointmentSteps.getSlotsInformationForChildEyeTest(testDataManager.getTestInputRegionData("storeName.store1"));
        appointmentSteps.bookAppointmentForChildOpticalJourney();
    }


    @API
    @FandB_R_API
    @Tags(value = {@Tag("uk"), @Tag("no"), @Tag("au"), @Tag("nl")})
    @Order(20)
    @SSTest(testCaseId = "42853448", projectId = "102929", testCaseName = "TC_29-Amend-Appointment amend journey using cancel booking link on confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_29_AmendAppointmentJourneyFromBookingConformationPage() {
        appointmentSteps.getSlotsInformation(testDataManager.getTestInputRegionData("storeName.store1"));
        appointmentSteps.amendBookedAppointmentDetails();
        appointmentSteps.cancelAppointmentForOpticalJourneyAfterAmendment();
    }


    @API
    @FandB_R_API
    @Tags(value = {@Tag("uk")})
    @SSTest(testCaseId = "42853450", projectId = "102929", testCaseName = "TC_44-Ensure adult customer is unable to book a child eye test appointment for himself", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_44_EnsureAdultCustomerIsUnableToBookChildEyeTest() {
        appointmentSteps.getSlotsInformation(testDataManager.getTestInputRegionData("storeName.store1"));
        appointmentSteps.validateChildEyeBookingFunctionality();
    }


    @API
    @FandB_R_API
    @Tags(value = {@Tag("uk"), @Tag("nl")})
    @SSTest(testCaseId = "42853451", projectId = "102929", testCaseName = "TC_38-Cancel-Cancelling an amended appointment via confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_38_CancelAmendedAppointmentJourneyFromConformationPage() {
        appointmentSteps.getSlotsInformation(testDataManager.getTestInputRegionData("storeName.store1"));
        appointmentSteps.bookAppointmentForOpticalJourney();
        appointmentSteps.cancelAppointmentForOpticalJourney();
    }

    @FandB_R_API
    @Tags(value = {@Tag("uk"),@Tag("au")})
    @SSTest(testCaseId = "42853451", projectId = "102929", testCaseName = "TC_38-Cancel-Cancelling an amended appointment via confirmation page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void opticalAppointmentForContactLensAssessmentAndTrial(){
        appointmentSteps.getSlotsInformationForContactLensAssessmentAndTrial(testDataManager.getTestInputRegionData("storeName.store2"));
        appointmentSteps.bookOpticalAppointmentForContactLensAssessmentAndTrial();
    }

}
