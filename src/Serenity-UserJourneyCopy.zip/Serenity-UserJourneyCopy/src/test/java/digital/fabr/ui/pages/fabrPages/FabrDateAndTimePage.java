package digital.fabr.ui.pages.fabrPages;

import Framework.Staf;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class FabrDateAndTimePage extends FabrBase {
    @FindBy(css = "h1#page-header_title")
    private WebElementFacade dateAndTimePageTitle;

    @FindBy(css = "fieldset#appointment-times")
    private WebElementFacade dateAndTimeComponent;

    @FindBy(xpath = "//*[@id=\"appointment-times\"]/div[1]/label")
    private WebElementFacade availableTimeSlots;

    @FindBy(xpath = "//*[@id=\"appointment-times\"]/div[2]/label")
    private WebElementFacade nextTimeSlot;

    @FindBy(css = "fieldset#calendar_day-select-ribbon_date-range>div>label")
    private List<WebElementFacade> partOfDay;

    @FindBy(css = "p#check-out-other-stores_main-text a")
    private WebElementFacade checkOutOtherStoreLink;

    @FindBy(css = "#journey-page-footer_button-list a")
    private WebElementFacade continueToPersonalDetailsPage;

    @FindBy(css = "a#journey-page-footer_cancel-and-go-back-link")
    private WebElementFacade cancelAndGoBackLink;

    @FindBy(id = "specs-chevron-icon-left")
    private WebElementFacade selectPreviousTimeSlot;

    @FindBy(css = "svg#specs-chevron-icon-right")
    private WebElementFacade selectLaterTimeSlot;

    @FindBy(css = "p#calendar_no-availability-banner_title")
    private WebElementFacade calendarNoAvailabilityPeriodBannerTitle;

    @FindBy(css = "#calendar_no-availability-banner_footer a")
    private WebElementFacade otherStoreLink;

    @FindBy(css = "p#calendar_no-availability-banner_title")
    private WebElementFacade appointmentTimesSection;

    @FindBy(css = "div.calendar__loading-wrapper")
    private WebElementFacade calendarLoadingWrapper;

    @FindBy(css = "button.calendar-ab--days__next,#calendar_day-select-ribbon_later,div[class='calendar__control js-calendar-control'][data-direction='next'],#specs-chevron-icon-right")
    private WebElementFacade v3_selectLaterTimeSlot;

    @FindBy(css = "button.calendar-ab--days__next,#calendar_day-select-ribbon_later,div[class='calendar__control js-calendar-control'][data-direction='next'],#specs-chevron-icon-right")
    private WebElementFacade v3_selectNextOnCalendar;

    @FindBy(css = "div.ss-calendar--loading,div.calendar__loading-wrapper")
    private WebElementFacade v3_calendarLoading;

    @FindBy(css = "ss-picker-slots>div>button:nth-child(1),#appointment-times > div:nth-child(2) > label > p,div[class='calendar__times js-times']>span:nth-child(2)")
    private WebElementFacade v3_firstTimeSlot;

    @FindBy(css = "button#calendar-book-btn>div,#journey-page-footer_continue-button,div.js-move-footer span.button.button--primary.js-action-submit,div#journey-page-footer_button-list")
    private WebElementFacade v3_continueButton;

    @FindBy(css = "ss-picker-slots>div>button:nth-child(2),div[class='calendar__times js-times']>span:nth-child(3),#appointment-times>div:nth-child(3)>label>p")
    private WebElementFacade v3_secondTimeSlot;

    @FindBy(css="button#amend-calendar-book-btn,div.js-move-footer span.button.button--primary.js-action-submit,#edit-submit,div.js-move-footer button.button.button--primary.js-action-submit,div#journey-page-footer_button-list>a")
    private WebElementFacade v3_changeAppointment;

    @FindBy(id="journey-page-footer_continue-button")
    private WebElementFacade v4_clickChangeAppointment;


    public boolean dateAndTimeIsDisplayed() {
          dateAndTimeComponent.waitUntilPresent();
         dateAndTimeComponent.waitUntilVisible();
        return dateAndTimeComponent.isDisplayed();
    }

    public boolean dateAndTimeTitleIsDisplayed() {
        return dateAndTimePageTitle.isDisplayed();
    }

    public void clickDateAndTime() {
        this.calendarLoadingWrapper.waitUntilNotVisible();
        waitForTimeoutInMilliseconds();
        clickElement(this.availableTimeSlots);
    }

    public void clickContinueButton() {
        clickElement(this.continueToPersonalDetailsPage);
    }

    public void selectNewDateAndTime() {
        clickElement(availableTimeSlots);

    }

    public void clickCancelAndGoLink() {
        clickElement(this.cancelAndGoBackLink);
    }

    public void clickCheckOutOtherStoreLink() {
       evaluateScriptClick(this.checkOutOtherStoreLink);
    }

    public void selectPreviousTimeSlots() {
        clickElement(this.selectPreviousTimeSlot);
    }

    public void clickLaterTimeSlotsIcon() {
        waitForTimeoutInMilliseconds();
        clickElement(this.selectLaterTimeSlot);
        this.calendarLoadingWrapper.waitUntilNotVisible();
    }

    public void calendarNoAvailabilityPeriodBannerTitleIsDisplayed() {
        this.calendarLoadingWrapper.waitUntilNotVisible();
        assertPageObjectIsDisplayed(this.calendarNoAvailabilityPeriodBannerTitle);
    }

    public void clickOtherStoreLink() {
        clickElement(this.otherStoreLink);
    }

    public void otherStoreLinkIsDisplayed() {
        assertPageObjectIsDisplayed(this.otherStoreLink);
    }

    public void waitForLoadingWrapperToDisappear(){
        this.calendarLoadingWrapper.waitUntilNotVisible();
    }

    public void v3_clickLaterTimeSlotsIcon() {
        clickElement(this.v3_selectLaterTimeSlot);
        this.calendarLoadingWrapper.waitUntilNotVisible();
        clickElement(this.v3_selectNextOnCalendar);
        this.v3_calendarLoading.waitUntilNotVisible();
    }

    public void v3_clickDateAndTime() {
        this.v3_calendarLoading.waitUntilNotVisible();
        clickElement(this.v3_firstTimeSlot);
    }

    public void v3_clickContinueButton() {
        clickElement(this.v3_continueButton);
    }

    public void v3_selectSecondTimeSlot(){
       if(Staf.getTargetRegion().equals("uk")||Staf.getTargetRegion().equals("no")||Staf.getTargetRegion().equals("ie")||Staf.getTargetRegion().equals("au")) {  //this condition is placed as this is requied for uk and no regions
           switchToChildWindow();
       }
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_secondTimeSlot));
        clickElement(this.v3_secondTimeSlot);
    }

    public void v3_clickOnChangeAppointmentButton(){
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(v3_changeAppointment));
        clickElement(this.v3_changeAppointment);
    }
}
