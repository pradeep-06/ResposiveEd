package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_REG;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("fabr")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class ROIAudiologyTestCases {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;

    @FandB_R_REG
    @Tags(value = {@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42581416", projectId = "102929", testCaseName = "Booking journey via Find a store CTA (Combined store) - (By providing Gmail id details on PD page)", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void bookingJourneyViaFindAStoreCTA(){
        fabr.bookROIAudiologyAppointmentViaBookAppointmentCTA();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42581417", projectId = "102929", testCaseName = "Booking journey via Book Appointment CTA (Combined store) - (By providing Yahoo mail id details on PD page)", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void bookAppointmentFromStorePage(){
        fabr.bookAppointmentFromStorePage();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42581418", projectId = "102929", testCaseName = "Book journey using \"Book a hearing test\" CTA on home page", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void bookAppointmentUsingBookAHearingTestFromHomePage(){
        fabr.bookAppointmentUsingBookAHearingTestFromHomePage();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42581419", projectId = "102929", testCaseName = "Booking journey via Find a store CTA (Audiology only store)", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void bookAppointmentUsingFindAStoreCTAForAudiologyOnlyStore(){
        fabr.bookAppointmentUsingFindAStoreCTAForAudiologyOnlyStore();
    }
}
