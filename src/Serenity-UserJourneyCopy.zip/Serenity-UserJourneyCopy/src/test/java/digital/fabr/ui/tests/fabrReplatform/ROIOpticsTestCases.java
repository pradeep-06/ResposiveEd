package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_REG;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("fabr")

@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class ROIOpticsTestCases {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;

    @FandB_R_REG
    @Tags(value = {@Tag("ie")})
    @Order(1)
    @SSTest(testCaseId = "42560686", projectId = "102929", testCaseName = "Verify user receives appointment booking confirmation email on Gmail", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void verifyUserReceivesBookingEmailConfirmation(){
       fabr.verifyUserReceivesBookingConfirmationMail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42560689", projectId = "102929", testCaseName = "Verify user receives appointment amendment email on Gmail", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void verifyUserReceivesBookingAmendEmail(){
        fabr.verifyUserReceivesAmendEmail();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("ie")})
    @Order(3)
    @SSTest(testCaseId = "42560692", projectId = "102929", testCaseName = "Verify user receives appointment cancellation email- Gmail", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void verifyUserReceivesBookingCancellationEmail(){
        fabr.verifyUserReceivesCancellationEmail();
    }


    @Disabled("out of scope")
    @Tags(value = {@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42560694", projectId = "102929", testCaseName = "Customer cancelling the appointment using the change date/time link in AMC email", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void customerCancellingTheAppointmentUsingChangeDateAndTimeLinkInEmail(){
        fabr.customerCancelBookingUsingChangeDateAndTimeLinkInEmail();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("ie")})
    @Order(1)
    @SSTest(testCaseId = "42560686", projectId = "102929", testCaseName = "Verify user receives appointment booking confirmation email on Gmail", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void verifyUserReceivesBookingEmailConfirmationForPRSITreatment(){
        fabr.verifyUserReceivesBookingConfirmationMailForPRSITreatment();
    }

}
