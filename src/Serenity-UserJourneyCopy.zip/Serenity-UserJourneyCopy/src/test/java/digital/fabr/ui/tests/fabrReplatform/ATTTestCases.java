package digital.fabr.ui.tests.fabrReplatform;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_REG;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("fabr")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class ATTTestCases{

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    FabrStepDefinitions fabr;


    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(1)
    @SSTest(testCaseId = "41394853", projectId = "102929", testCaseName = "[STAC+OCT] Adult eye test triage journey when a customer is recommended 'Adult eye test' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_01_AdultEyeTestRecommendationET1(){
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.chooseAdultEyeTestATTAppointmentType();
        fabr.clickOnNoAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();

    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(2)
    @SSTest(testCaseId = "41394854", projectId = "102929", testCaseName = "[STAC+OCT] Adult eye test triage journey when a customer is recommended 'Adult eye test and OCT' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_02_AdultEyeTestRecommendationET2(){
        fabr.openFabrHome();
        fabr.findStore2();
        fabr.selectStore();
        fabr.chooseAdultEyeTestATTAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(3)
    @SSTest(testCaseId = "41394856", projectId = "102929", testCaseName = "[STAC+OCT] Contact lens triage journey when a customer is recommended 'Contact lens consultation and trial' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_03_ConsultationAndTrialTriageCL2A(){
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseContactLensAppointmentType();
        fabr.clickOnNoAndProceed();
        fabr.clickOnYesAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(4)
    @SSTest(testCaseId = "41394858", projectId = "102929", testCaseName = "[STAC+OCT] Contact lens triage journey when a customer is recommended to call the store- CL4A", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_04_ContactLensTriageJourneyCL4A() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseContactLensAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickOnNoAndProceed();
        fabr.clickOnYesAndProceed();
        fabr.clickOnGotToHomePage();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(5)
    @SSTest(testCaseId = "41394859", projectId = "102929", testCaseName = "[STAC+OCT]Contact lens triage journey when a customer is recommended to call the store- CL4B", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_05_ContactLensTriageJourneyCL4B() {
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseContactLensAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickOnNoAndProceed();
        fabr.clickOnNoAndProceed();
        fabr.clickOnGotToHomePage();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(6)
    @SSTest(testCaseId = "41392706", projectId = "102929", testCaseName = "[NON OCT+NON STAC]Customer journey for 'Contact lens consultation and trial' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_06_CustomerJourneyCLConsultationAndTrial(){
        fabr.openFabrHome();
        fabr.findStore1();
        fabr.selectStore();
        fabr.chooseCLConsultationAndTrialType();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(7)
    @SSTest(testCaseId = "41392707", projectId = "102929", testCaseName = "[NON OCT+NON STAC]Customer journey for 'Contact lens health check' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_07_CustomerJourneyCLAndHealthCheck(){
        fabr.openFabrHome();
        fabr.findStore1();
        fabr.selectStore();
        fabr.chooseContactLensHealthCheck();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(8)
    @SSTest(testCaseId = "41394862", projectId = "102929", testCaseName = "[STAC+OCT]Customer tries to change appointment type from recap page\n" +
            "-switches from Adult eye test triage category to CL triage category", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_08_CustomerTriesToChangeAppointmentTypeFromRecapPage(){
        fabr.customerTriesToChangeAppointmentTypeFromAdultToCLTriageCategory();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(9)
    @SSTest(testCaseId = "41392709", projectId = "102929", testCaseName = "Customer tries to change location from recap page\n" +
            "-Changes from STAC to NON STAC store", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_09_CustomerTriesToChangeLocationFromSTACToNonSTACStore(){
        fabr.customerChangesLocationFromSTACToNonSTACStore();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(10)
    @SSTest(testCaseId = "41394860", projectId = "102929", testCaseName = "[STAC+OCT]Contact lens triage journey when a customer is recommended 'Contact lens health check' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_10_ContactLensTriageJourneyWhereRecommendedToHealthCheckCL5B(){
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseContactLensAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickOnYesAndProceed();
        fabr.clickOnYesAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(11)
    @SSTest(testCaseId = "41394861", projectId = "102929", testCaseName = "[STAC+OCT] Contact lens triage journey when a customer is recommended 'Eye test with contact lens health check' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_11_ContactLensTriageJourneyWhereRecommendedTEyeTestWithHealthCheck(){
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseContactLensAppointmentType();
        fabr.clickOnYesAndProceed();
        fabr.clickOnYesAndProceed();
        fabr.clickOnNoAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(12)
    @SSTest(testCaseId = "41394857", projectId = "102929", testCaseName = "[STAC+OCT] Contact lens triage journey when a customer is recommended 'Eye test with contact lens health check' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_12_ContactLensTriageJourneyCL2B(){
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseContactLensAppointmentType();
        fabr.clickOnNoAndProceed();
        fabr.clickOnNoAndProceed();
        fabr.clickChooseDateAndTime();
        fabr.selectTimeSlotForBooking();
        fabr.inputPersonalDetailsAndValidateBooking();
        fabr.checkEmailInMailosaur();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk")})
    @Order(13)
    @SSTest(testCaseId = "41394855", projectId = "102929", testCaseName = "[STAC+OCT]Customer journey for Child eye test", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_13_CustomerJourneyForChildEyeTest(){
        fabr.openFabrHome();
        fabr.findStore1();
        fabr.selectStore();
        fabr.chooseChildEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetailsForChildEyeTest();
        fabr.continueWithBookingAndConfirm();
    }

    @FandB_R_REG
    @Tags(value = {@Tag("uk"),@Tag("no")})
    @Order(14)
    @SSTest(testCaseId = "41392705", projectId = "102929", testCaseName = "[NON OCT+NON STAC]Customer journey for 'Adult eye test' appointment", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_14_CustomerJourneyForAdultEyeTest(){
        fabr.openFabrHome();
        fabr.findStore4();
        fabr.selectStore();
        fabr.chooseAdultEyeTestAppointmentType();
        fabr.selectTimeSlotForBooking();
        fabr.enterPersonalDetails();
        fabr.verifyDetailsAndContinueBooking();
    }

    @Disabled("out of scope")
    @Tags(value = {@Tag("uk")})
    @Order(15)
    @SSTest(testCaseId = "41392713", projectId = "102929", testCaseName = "Verify that customer is displayed right set of appointments based on the store type i.e. triage categories or various appointment types", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_15_CustomerIsDisplayedWithRightSetOfAppointment(){
        fabr.openFabrHome();
        fabr.findStore1();
        fabr.selectStore();
        fabr.verifyCorrectStoreAppointmentTypesDisplayed();
        fabr.clickLocationBreadcrumb();
        fabr.findBedworthStoreWithoutCookies();
        fabr.selectStore();
        fabr.verifyCorrectStoreAppointmentTypesDisplayed();
        fabr.verifyBreadCrumbFunctionality();
    }

    @AfterEach
    public void tearDown() {
        fabr.closeSession();
    }

}


