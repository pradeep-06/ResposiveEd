package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrPersonalDetailsPage;
import net.thucydides.core.steps.ScenarioSteps;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static org.assertj.core.api.Assertions.assertThat;

public class FabrPersonalDetailsStepLib extends ScenarioSteps {
    private FabrPersonalDetailsPage personalDetailsPage;
    private String dobDate;
    private String dobMonth;
    private String dobYear;

    public void dateOfBirth(int age) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -age);
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        String dobString = format1.format(cal.getTime());
        dobYear = dobString.substring(0, 4);
        dobMonth = dobString.substring(5, 7);
        dobDate = dobString.substring(8, 10);
    }

    public void assertPersonalDetailsPageIsDisplayed() {
        assertThat(personalDetailsPage.personalDetailsPageIsDisplayed()).isTrue();
    }

    public void completePersonalDetailsForm(String title, String firstName, String lastName, String postCode, int age, String emailAddress, String mobileno) {

        dateOfBirth(age);
        personalDetailsPage.selectTitle(title);
        personalDetailsPage.enterFirstName(firstName);
        personalDetailsPage.enterLastName(lastName);
        personalDetailsPage.enterPostCode(postCode);
        personalDetailsPage.enterDate(dobDate);
        personalDetailsPage.enterMonth(dobMonth);
        personalDetailsPage.enterYear(dobYear);
        personalDetailsPage.enterEmail(emailAddress);
        personalDetailsPage.enterMobileNumber(mobileno);
    }

    public void clickContinueBookingButton() {
       personalDetailsPage.clickContinueBookingButton();
    }

    public void assertPersonalDetailsEmail(String email) {
        assertThat(personalDetailsPage.personalDetailsEmailIsDisplayed(email)).isTrue();
    }

    public void assertPersonalDetailsMobileNo(String mobileno) {
        assertThat(personalDetailsPage.personalDetailsMobileNoIsDisplayed(mobileno)).isTrue();
    }

    public void assertPersonalDetailsFirstName(String firstName) {
        assertThat(personalDetailsPage.personalDetailsFirstNameIsDisplayed(firstName)).isTrue();
    }

    public void assertPersonalDetailsLastName(String lastName) {
        assertThat(personalDetailsPage.personalDetailsFirstNameIsDisplayed(lastName)).isTrue();
    }

    public void assertCancelAndGoBannerTitle() {
       personalDetailsPage.cancelAndGoBannerTitleIsDisplayed();

    }

    public void clickCancelAndGoBackLink() {
        personalDetailsPage.clickCancelAndGoBackLink();
    }

    public void assertPersonalDetailsDOBErrorTitle() {
        assertThat(personalDetailsPage.personalDetailsDOBErrorTitleIsDisplayed()).isTrue();
    }

    public void assertChangeAppointmentTypeLink() {
        assertThat(personalDetailsPage.changeAppointmentTypeLinkIsDisplayed()).isTrue();
    }

    public void clickOnChangeAppointmentTypeLink() {
        personalDetailsPage.clickOnChangeAppointmentTypeLink();
    }

    public void assertErrorBannerListItems() {
        personalDetailsPage.errorBannerListItemsIsDisplayed();
    }

    public void completePersonalDetailsFormForAudiology(String title, String firstname, String lastName, int age, String emailAddress, String mobileno) {
        dateOfBirth(age);
        personalDetailsPage.selectTitle(title);
        personalDetailsPage.enterFirstName(firstname);
        personalDetailsPage.enterLastName(lastName);
        personalDetailsPage.enterDate(dobDate);
        personalDetailsPage.enterMonth(dobMonth);
        personalDetailsPage.enterYear(dobYear);
        personalDetailsPage.enterEmail(emailAddress);
        personalDetailsPage.enterMobileNumber(mobileno);
    }

    public void completePersonalDetailsForm(String firstName, String lastName, int age, String emailAddress, String mobileno) {

        dateOfBirth(age);
        personalDetailsPage.enterFirstName(firstName);
        personalDetailsPage.enterLastName(lastName);
        personalDetailsPage.enterDate(dobDate);
        personalDetailsPage.enterMonth(dobMonth);
        personalDetailsPage.enterYear(dobYear);
        personalDetailsPage.enterEmail(emailAddress);
        personalDetailsPage.enterMobileNumber(mobileno);
    }

    public void completePersonalDetailsForm(String title, String firstName, String lastName,int age, String emailAddress, String mobileno) {

        dateOfBirth(age);
        personalDetailsPage.selectTitle(title);
        personalDetailsPage.enterFirstName(firstName);
        personalDetailsPage.enterLastName(lastName);
        personalDetailsPage.enterDate(dobDate);
        personalDetailsPage.enterMonth(dobMonth);
        personalDetailsPage.enterYear(dobYear);
        personalDetailsPage.enterEmail(emailAddress);
        personalDetailsPage.enterMobileNumber(mobileno);
    }

    public void completePersonalDetailsFormForNO(String firstName, String lastName, String postCode, int age, String emailAddress, String mobileno) {

        dateOfBirth(age);
        personalDetailsPage.enterFirstName(firstName);
        personalDetailsPage.enterLastName(lastName);
        personalDetailsPage.enterPostCode(postCode);
        personalDetailsPage.enterDate(dobDate);
        personalDetailsPage.enterMonth(dobMonth);
        personalDetailsPage.enterYear(dobYear);
        personalDetailsPage.enterEmail(emailAddress);
        personalDetailsPage.enterMobileNumber(mobileno);
    }

    public void v3_completePersonalDetailsForm(String title, String firstName, String lastName, int age, String emailAddress, String mobileno) {
        dateOfBirth(age);
        personalDetailsPage.v3_selectTitle(title);
        personalDetailsPage.v3_enterFirstName(firstName);
        personalDetailsPage.v3_enterLastName(lastName);
        personalDetailsPage.v3_enterDate(dobDate);
        personalDetailsPage.v3_enterMonth(dobMonth);
        personalDetailsPage.v3_enterYear(dobYear);
        personalDetailsPage.v3_enterEmail(emailAddress);
        personalDetailsPage.v3_enterMobileNumber(mobileno);
    }

    public void v3_clickContinueBookingButton() {
        personalDetailsPage.v3_clickContinueBookingButton();
    }

    public void v3_completePersonalDetailsForm(String firstName, String lastName, int age, String emailAddress, String mobileno) {
        dateOfBirth(age);
        personalDetailsPage.v3_enterFirstName(firstName);
        personalDetailsPage.v3_enterLastName(lastName);
        personalDetailsPage.v3_enterDate(dobDate);
        personalDetailsPage.v3_enterMonth(dobMonth);
        personalDetailsPage.v3_enterYear(dobYear);
        personalDetailsPage.v3_enterEmail(emailAddress);
        personalDetailsPage.v3_enterMobileNumber(mobileno);
    }

    public void v3_completePersonalDetailsForm(String firstName, String lastName, int age, String emailAddress, String mobileno,String postCode) {
        dateOfBirth(age);
        personalDetailsPage.v3_enterFirstName(firstName);
        personalDetailsPage.v3_enterLastName(lastName);
        personalDetailsPage.v3_enterPostCode(postCode);
        personalDetailsPage.v3_enterDate(dobDate);
        personalDetailsPage.v3_enterMonth(dobMonth);
        personalDetailsPage.v3_enterYear(dobYear);
        personalDetailsPage.v3_enterEmail(emailAddress);
        personalDetailsPage.v3_enterMobileNumber(mobileno);
    }

    public void v3_completePersonalDetailsForm(String title,String firstName, String lastName,int age, String postCode, String emailAddress, String mobileno) {
        dateOfBirth(age);
        personalDetailsPage.v3_selectTitle(title);
        personalDetailsPage.v3_enterFirstName(firstName);
        personalDetailsPage.v3_enterLastName(lastName);
        personalDetailsPage.v3_enterPostCode(postCode);
        personalDetailsPage.v3_enterDate(dobDate);
        personalDetailsPage.v3_enterMonth(dobMonth);
        personalDetailsPage.v3_enterYear(dobYear);
        personalDetailsPage.v3_enterEmail(emailAddress);
        personalDetailsPage.v3_enterMobileNumber(mobileno);
    }

    public void completePersonalDetailsFormForPRSITreatment(String title, String firstName, String lastName,int age, String emailAddress, String mobileno,String ppsNumber) {

        dateOfBirth(age);
        personalDetailsPage.selectTitle(title);
        personalDetailsPage.enterFirstName(firstName);
        personalDetailsPage.enterLastName(lastName);
        personalDetailsPage.enterDate(dobDate);
        personalDetailsPage.enterMonth(dobMonth);
        personalDetailsPage.enterYear(dobYear);
        personalDetailsPage.enterEmail(emailAddress);
        personalDetailsPage.enterMobileNumber(mobileno);
        personalDetailsPage.inputPPSNumber(ppsNumber);
    }
}
