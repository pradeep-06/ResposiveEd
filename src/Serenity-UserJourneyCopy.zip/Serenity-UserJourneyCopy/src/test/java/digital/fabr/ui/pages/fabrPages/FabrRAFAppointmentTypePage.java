package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class FabrRAFAppointmentTypePage extends BasePageObject {

    @FindBy(css = "label.appointment-type-label >span.checkmark")
    private List<WebElementFacade> appointmentType;

    @FindBy(css = "input#date-time")
    private WebElementFacade appointmentDateAndTime;

    @FindBy(css = "select#customer-title")
    private WebElementFacade customerTitle;

    @FindBy(css = "input#first-name")
    private WebElementFacade customerFirstName;

    @FindBy(css = "input#last-name")
    private WebElementFacade customerLastName;

    @FindBy(css = "input#customer-mobile")
    private WebElementFacade customerMobile;

    @FindBy(css = "input#customer-email")
    private WebElementFacade customerEmail;

    @FindBy(css = "button#edit-your-details-wrapper-submit")
    private WebElementFacade submitButton;

    @FindBy(xpath = "//*[@id=\"raf\"]/div[1]//label")
    private List<WebElementFacade> appointmentTypeList;

    @FindBy(css = "textarea#customer-notes")
    private WebElementFacade customerAnythingElseWeShouldKnow;

    @FindBy(css="button.green.book-appointment")
    private WebElementFacade requestAnAppointment;

    @FindBy(css="iframe[name*='healow-oa-ifrm']")
    private WebElementFacade frameinNzRegion;

    @FindBy(id = "appointment-type_request-appointment-button")
    private WebElementFacade clickRequestAppointmentForRaf;

    @FindBy(css = "#appointment-type_footer-text2 > a:nth-child(2)")
    private WebElementFacade RequestFormLink;

    public void clickRequestFormLink() { clickElement(this.RequestFormLink);}

    public void clickAdultSightTest() {
        clickElement(this.appointmentType.get(0));
    }

    public void clickAdultSightTestAndOCTScan() {
        clickElement(this.appointmentType.get(1));
    }

    public void clickChildEyeTest() {
        clickElement(this.appointmentType.get(2));
    }

    public void clickContactLensConsultationAndTrial() {
        clickElement(this.appointmentType.get(3));
    }

    public void clickContactLensHealthCheck() {
        clickElement(this.appointmentType.get(4));
    }

    public void clickHearingTest() {
        clickElement(this.appointmentType.get(0));
    }

    public void clickHearingTestAndHearingAidConsultation() {
        clickElement(this.appointmentType.get(1));
    }

    public void clickCheckUpForExistingHearingAidWearers() {
        clickElement(this.appointmentType.get(2));
    }

    public void clickHearingAidMaintenanceOrRepair() {
        clickElement(this.appointmentType.get(3));
    }

    public void clickHearingProtectionConsultation() {
        clickElement(this.appointmentType.get(4));
    }

    public void inputAppointmentDateAndTime(String dateAndTime) {
        setText(this.appointmentDateAndTime, dateAndTime);
    }

    public void selectCustomerTitle(String title) {
        this.customerTitle.selectByVisibleText(title);
    }

    public void inputCustomerFirstName(String firstName) {
        setText(this.customerFirstName, firstName);
    }

    public void inputCustomerLastName(String lastName) {
        setText(this.customerLastName, lastName);
    }

    public void inputCustomerMobile(String mobile) {
        setText(this.customerMobile, mobile);
    }

    public void inputCustomerEmail(String email) {
        setText(this.customerEmail, email);
    }

    public void focusOnAnythingElseWeShouldKnow() {
        clickElement(this.customerAnythingElseWeShouldKnow);
    }

    public void clickSubmitButton() {
        clickElement(this.submitButton);
    }

    public void SelectAppointmentTestAs(String appointmentTypeName) {
        clickElement(this.appointmentTypeList.stream().filter(x->
        {
            String name = x.getText().toLowerCase();
            return name.contains(appointmentTypeName.toLowerCase());
        }).findFirst().get());
    }

    public void verifyRequestAnAppointmentButtonIsDisplayed(){
        assertPageObjectIsDisplayed(requestAnAppointment);
    }

    public void switchToFrameForAppointments(){
        getDriver().switchTo().frame(frameinNzRegion);
    }

    public void requestAnAppointmentRafBtn() {
        clickElement(clickRequestAppointmentForRaf);
    }
}

