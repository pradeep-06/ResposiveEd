package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import Framework.Staf;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class FabrAmendConfirmationPage extends BasePageObject {

    @FindBy(id="confirmation-page-template_specs-success-banner_title")
    private WebElementFacade confirmationHeaderTitle;

    @FindBy(id = "confirmation-page-template_specs-success-banner_subtitle")
    private WebElementFacade confirmationheaderSubTitle;

    @FindBy(id = "confirmation-card-when_amend-appointment-link")
    private WebElementFacade changeAppointmentDateAndTime;

    @FindBy(id = "confirmation-card-when")
    private WebElementFacade whenSubtitle;

    @FindBy(css = "#date-and-time_cancel-link > a")
    private WebElementFacade cancelBooking;

    @FindBy(css="[id='confirmation-page-template_specs-success-banner_title'],[class='confirmation-header__title ss-sas--heading'],div[class='book-confirmation-page']>div>div>h2,div[class='oas-receipt js-receipt']>div>h1")
    private WebElementFacade v3_confirmationHeaderTitle;

    public void verifyConfirmationHeaderTitleIsDisplayed() {
        waitForTimeoutInMilliseconds();
       assertTrue(this.confirmationHeaderTitle.isDisplayed());
    }

    public void verifyConfirmationHeaderSubTitleIsDisplayed() {
        this.confirmationheaderSubTitle.isDisplayed();
    }

    public void amendAppointmentAgain() {
        scrollToView(this.changeAppointmentDateAndTime);
        clickElement(this.changeAppointmentDateAndTime);
    }

    public boolean verifyWhenSubtitleIsDisplayed() {
        this.whenSubtitle.waitUntilVisible();
        return this.whenSubtitle.isDisplayed();
    }

    public void cancelBooking() {
        waitForTimeoutInMilliseconds();
        waitFor(this.cancelBooking);
        clickElement(this.cancelBooking);
    }

    public void v3_verifyConfirmationHeaderTitleIsDisplayed(){
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(this.v3_confirmationHeaderTitle));
        assertPageObjectIsDisplayed(this.v3_confirmationHeaderTitle);
    }
}
