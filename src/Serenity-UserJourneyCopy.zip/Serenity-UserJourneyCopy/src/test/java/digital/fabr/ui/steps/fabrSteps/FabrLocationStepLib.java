package digital.fabr.ui.steps.fabrSteps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.steps.AddGlassesToBasket;
import digital.fabr.ui.pages.fabrPages.FabrLocationPage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FabrLocationStepLib {
    final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(AddGlassesToBasket.class);
    FabrLocationPage fabrLocationPage;

    public void assertCancelAndGoBanner() {
        assertThat(fabrLocationPage.verifyCancelAndGoBannerIsDisplayed());
    }

    public void clickCancelAndGoLink() {
        fabrLocationPage.clickCancelAndGoLink();
    }

    public void clickRequestAppointment() {
        fabrLocationPage.clickRequestAppointment();
    }

    public void bookOnlineInSelectedLocation(String region) {
        fabrLocationPage.bookOnlineInSelectedLocation(region);
    }

    public void clickStoreDetails() {
        fabrLocationPage.clickStoreDetails();
    }

    public void enterLocationTown() {
        String searchString = testDataManager.getTestInputRegionData("storeName.coventry");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore1() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store1");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore5() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store5");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore2() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store2");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputLeedsCrownPointStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.leeds");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputWarwickStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.warwick");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore4() {
        final String searchString = testDataManager.getTestInputRegionData("storeName.store4");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore6() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store6");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputKirkstallStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.kirkstall");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputLeedsAlbionStreet() {
        String store = testDataManager.getTestInputRegionData("storeName.leedsAlbionStreet");
        fabrLocationPage.enterLocationTown(store);
    }

    public void inputStore9() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store9");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void clickSearch() {
        fabrLocationPage.clickSearch();

    }

    public void accptCookiesOnLocationPage() {
        fabrLocationPage.acceptCookienOnLocationPage();
    }

    public boolean assertCookieSection() {
        return fabrLocationPage.verifyCookieDisplayed();
    }

    public void clickOnLocationSearchTextArea() {
        fabrLocationPage.clickOnLocationSearchTextArea();
    }

    public void inputNewStore(String storeName) {
        fabrLocationPage.inputNewStore(storeName);
    }

    public void inputFordeStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.forde");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore10() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store10");
        fabrLocationPage.enterLocationTown(searchString);
    }
    public void inputStore3() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store3");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore12() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store12");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputStore13() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store13");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void inputRAFStore(String searchString) {
        fabrLocationPage.enterSearchLocation(searchString);
    }

    public void clickFind() {
        fabrLocationPage.clickFindButton();
    }

    public void v3_bookOnlineInSelectedLocation() {
        fabrLocationPage.v3_bookOnlineInSelectedLocation();
    }

    public void enterRAFStoreNameAndClickOnSearchButton(){
        inputRAFStore(testDataManager.getTestInputRegionData("storeName.rAFStore1"));
        clickFind();
    }

    public void inputSASStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.sASStore1");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void v3_inputSASStore() {
        String searchString = testDataManager.getTestInputRegionData("storeName.sASStore1");
        logger.info("Searching for SAS Store : "+searchString);
        fabrLocationPage.enterSearchLocation(searchString);
    }

    public void v3_clickFind() {
        logger.info("Click On find/search button");
        fabrLocationPage.clickFindButton();
    }

    public void inputStore11() {
        String searchString = testDataManager.getTestInputRegionData("storeName.store11");
        fabrLocationPage.enterLocationTown(searchString);
    }

    public void v3_VerifyPostCodeSearchFieldIsDisplayed()
    {
        fabrLocationPage.v3_VerifyPostCodeSearchFieldIsDisplayed();
    }

    public void v3_VerifyFindAStoreLinkIsdisplayed(){
        fabrLocationPage.v3_VerifyFindAStoreLinkIsDisplayed();
    }

    public void v4_VerifyFindAStoreLinkIsdisplayed() {
        fabrLocationPage.v4_VerifyFindAStoreLinkIsDisplayed();
    }

    public void v3_inputSASStoreForHearing() {
        String searchString = testDataManager.getTestInputRegionData("storeName.sASStore2");
        logger.info("Searching for SAS Store : "+searchString);
        fabrLocationPage.enterSearchLocation(searchString);
    }
}
