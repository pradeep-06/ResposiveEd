package digital.fabr.api.steps;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import sce.api.queryResponse.CommonAPI;
import Framework.api.graphql.GraphQL;
import digital.fabr.api.query.GraphQLQuery;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.model.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.model.util.EnvironmentVariables;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static io.restassured.RestAssured.given;

public class StoresSteps extends CommonAPI {

    @Steps
    GraphQL graphQL;

    private static Response response;
    private EnvironmentVariables env;
    protected final TestDataManager testDataManager = new TestDataManager();
    private static final Logger logger = LoggerFactory.getLogger(StoresSteps.class);

    @Step("Get store information using store name")
    public void getStoreByURLAndVerifyInformation(){
        RestAssured.baseURI =  EnvironmentSpecificConfiguration.from(env).getProperty("fabr.base.url");
        final String storeByURLQuery=testDataManager.getTestInputCommonData("storeByURL.query");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(storeByURLQuery);
        JSONObject variables = new JSONObject();
        variables.put("url", testDataManager.getTestInputRegionData("storeName.store1"));
        query.setVariables(variables.toString());
        response = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post(testDataManager.getTestInputCommonData("pathVariable.pathVariableValue"));

        response.then().log().all()
                .assertThat().statusCode(200);

    }

    @Step("get all stores information based on location")
    public void getStoresInformationBasesOnLocation(){
        String region=Staf.getTargetRegion().toUpperCase();
        if(region.equals("UK")){
            region="GB";
        }
        else{
            region=Staf.getTargetRegion().toUpperCase();
        }
        RestAssured.baseURI =  "https://qa-gb-luc-main.az.ssdgws.co.uk/graphql";
        final String allStoresQuery=testDataManager.getTestInputCommonData("allStoresInformation.query");
        GraphQLQuery query = new GraphQLQuery();
        query.setQuery(allStoresQuery);
        JSONObject variables = new JSONObject();
        variables.put("countryCode", region);
        query.setVariables(variables.toString());
        response = given().log().all()
                .contentType(ContentType.JSON)
                .body(query)
                .when().log().all()
                .post();

        response.then().log().all()
                .assertThat().statusCode(200);
    }
}
