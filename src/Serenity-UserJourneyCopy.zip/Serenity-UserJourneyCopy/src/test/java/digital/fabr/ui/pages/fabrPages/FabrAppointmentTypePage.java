package digital.fabr.ui.pages.fabrPages;

import Framework.Staf;
import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.pages.WebElementExpectations;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class FabrAppointmentTypePage extends FabrBase {

    private final Logger logger = LoggerFactory.getLogger(FabrAppointmentTypePage.class);

    @FindBy(css = "h1#page-header_title")
    private WebElementFacade appointmentTypePageTitle;

    @FindAll({@FindBy(id="specs-appointment-type-2000_title"),@FindBy(id="specs-appointment-type-adult_eye_test_triage_title")})
    private WebElementFacade adultEyeTest;

    @FindBy(css = "h2#specs-appointment-type-2040_title")
    private WebElementFacade adultEyeTestWithOCTScan;

    @FindBy(css = "h2#specs-appointment-type-2001_title")
    private WebElementFacade childEyeTest;

    @FindBy(css = "div#specs-appointment-type-2100")
    private WebElementFacade eyeTestWithContactLensConsultationAndTrial;

    @FindBy(css = "div#specs-appointment-type-2101")
    private WebElementFacade eyeTestWithContactLensHealthCheck;

    @FindAll({@FindBy(css = "div#specs-appointment-type-2003"),@FindBy(css="h2#specs-appointment-type-2003_title")})
    private WebElementFacade contactLensConsultationAndTrial;

    @FindBy(xpath = "//*[contains(text(),'Contact lens health check')]")
    private WebElementFacade contactlensHealthCheck;

    @FindBy(id = "journey-page-footer_continue-button")
    private WebElementFacade appointmentBookASlotButton;

    @FindBy(css = "p#cancel-and-go-back-banner_title")
    private WebElementFacade cancelAndGoBannerTitle;

    @FindBy(css = "a#journey-page-footer_cancel-and-go-back-link")
    private WebElementFacade cancelAndGoLink;

    @FindBy(css = "p#appointment-type_tab-button-1_body")
    private WebElementFacade hearingServicesButton;

    @FindBy(css = "div#audiology-nhs-information-banner")
    private WebElementFacade nhsInformationBanner;

    @FindBy(css = "p#audiology-nhs-information-banner_content_text")
    private WebElementFacade nhsInformationBannerText;

    @FindBy(css = "a#audiology-nhs-information-banner_content_link")
    private WebElementFacade nhsInformationBannerContentLink;

    @FindBy(css = "h2#specs-appointment-type-10011_title")
    private WebElementFacade hearingTest;

    @FindBy(css = "h2#specs-appointment-type-10010_title")
    private WebElementFacade hearingTestAndHearingAidConsultation;

    @FindBy(css = "h2#specs-appointment-type-10021_title")
    private WebElementFacade checkUpForExistingHearingAidWearers;

    @FindBy(css = "h2#specs-appointment-type-10022_title")
    private WebElementFacade hearingAidMaintenanceOrRepair;

    @FindBy(css = "h2#specs-appointment-type-10030_title")
    private WebElementFacade hearingProtectionConsultation;

    @FindBy(css = "h2#specs-appointment-type-10040_title")
    private WebElementFacade earwaxRemoval;

    @FindBy(css = "p#online-booking-unavailable-banner_title")
    private WebElementFacade bookingUnavailabilityBannerTitle;

    @FindBy(css = "a#appointment-type_request-appointment-button")
    private WebElementFacade requestAnAppointmentButton;

    @FindBy(css = "#popup-buttons button,#onetrust-accept-btn-handler")
    private WebElementFacade cookieButton;

    @FindBy(id = "appointment-type-triage-container_question_headline")
    private WebElementFacade appointmentTypeTriageContainer;

    @FindBy(css = "div.att-question__cta-container>button:nth-child(1)")
    private WebElementFacade appointmentTypeTriageYesButton;

    @FindBy(css = "div.att-question__cta-container>button:nth-child(2)")
    private WebElementFacade appointmentTypeTriageNoButton;

    @FindBy(id = "appointment-type-triage-container_previous-button")
    private WebElementFacade appointmentTypeTriagePreviousButton;

    @FindBy(css = "header#appointment-type-triage-container_page-header h1")
    private WebElementFacade appointmentTypeTriageContainerHeader;

    @FindBy(css ="#appointment-type-triage-container_appointment-card >a")
    private WebElementFacade appointmentTypeTriageChooseDateAndTime;

    @FindAll({@FindBy(css = "div#specs-appointment-type-contact_lens_triage"),@FindBy(css="div#specs-appointment-type-2002"),@FindBy(css="div#specs-appointment-type-2003")})
    private WebElementFacade contactLensAppointment;

    @FindBy(css= "#main>div>div>a")
    private WebElementFacade goBackToHomepage;

    @FindBy(css = "h2#specs-appointment-type-hearing_test_triage_title")
    private WebElementFacade hearingAppointment;

    @FindBy(css = "button#appointment-type-triage-container_question_cta-1")
    private WebElementFacade audiologyATTQuestionYesOption;

    @FindBy(css = "button#appointment-type-triage-container_question_cta-2")
    private WebElementFacade audiologyATTQuestionNoOption;

    @FindBy(css = "p#specs-appointment-type-ear_wax_removal_triage_summary")
    private WebElementFacade earwaxRemovalAudiologyATT;

    @FindBy(css = "button#specs-confirmation-modal_cta-1")
    private WebElementFacade iUnderstandForEarwaxRemoval;

    @FindBy(css="h2#appointment-type-triage-container_nhs-info-card_title")
    private WebElementFacade nHSFundingHeading;

    @FindBy(css = "div#appointment-type-triage-container_nhs-info-card_info a")
    private WebElementFacade nHSFundingCheckYourEligibility;

    @FindBy(css = "button#specs-confirmation-modal_cta-2")
    private WebElementFacade goBackForEarwaxRemoval;

    @FindBy(css = "h1#appointment-type-triage-container_question_headline")
    private  WebElementFacade aTTContainerQuestionHeadline;

    @FindBy(css = "button#appointment-type-triage-container_previous-button")
    private WebElementFacade previousButton;

    @FindAll({@FindBy(css = "h2#specs-appointment-type-adult_eye_test_triage_title"),@FindBy(id="specs-appointment-type-2000_title")})
    private WebElementFacade adultEyeTestATT;

    @FindBy(css = "button#specs-confirmation-modal_header_close-button")
    private WebElementFacade closeButton;

    @FindBy(css = "h2#appointment-type-title,div[id='edit-ap-type'] label[class='control-label'],label.appointment-type-label,div.choose-panel.clearfix.SelectorBtn div:nth-child(2),[class*='specs-appointment-type__title'],div.booking-type__content span.booking-type__title,h2[id*='specs-appointment-type']")
    private List<WebElementFacade> v3_appointmentTypeList;

    @FindBy(css="#appointments-book-button,button[class*='book-appointment'],[id='journey-page-footer_continue-button'],div.oas-application__footer > div > button,#journey-page-footer_continue-button")
    private WebElementFacade v3_bookAppointmentButton;

    @FindBy(css="div#edit-medical-card label[class*='control-label']")
    private List<WebElementFacade> v3_DoYouHaveMedicalCardButtonList;

    @FindBy(css="div#edit-appointment-type label[class*='control-label']")
    private List<WebElementFacade> v3_AppointmentTypeButtonList;

    @FindBy(css="div#calendar--section div[class='header--date next']")
    private WebElementFacade v3_nextDate;

    @FindBy(css="div[class='period morning']")
    private WebElementFacade v3_before12Noon;

    @FindBy(css="div[class='slots morning']>div:nth-child(1)")
    private WebElementFacade v3_timeSlot;

    @FindBy(css="a#choose-slot")
    private WebElementFacade v3_selectThisDateAndTime;

    @FindBy(css="div#edit-title div label")
    private List<WebElementFacade> v3_title;

    @FindBy(css="input[name='fname'],input[name='req_user_fname'],input[name='name']")
    private WebElementFacade v3_firstName;

    @FindBy(css="input[name='lname'],input[name='req_user_lname']")
    private WebElementFacade v3_lastName;

    @FindBy(css="input[name='dob-dd']")
    private WebElementFacade v3_date;

    @FindBy(css="input[name='dob-mm']")
    private WebElementFacade v3_month;

    @FindBy(css="input[name='dob-yy']")
    private WebElementFacade v3_year;

    @FindBy(css="input[name='email'],input[name='contact_email']")
    private WebElementFacade v3_email;

    @FindBy(css="input[name='mobile_number'],input[name='contact_phone'],input[name='phone']")
    private WebElementFacade v3_mobileNumber;

    @FindBy(css="button#edit-submit,input[name='confirmOAApptBtn'],button[class='button button--primary js-action-recap']")
    private WebElementFacade v3_bookNow;

    @FindBy(css="#journey-page-footer_continue-button")
    private WebElementFacade v4_bookNow;

    @FindBy(css="iframe[name*='healow-oa-ifrm']")
    private WebElementFacade frameinNzRegion;

    @FindBy(css="td.undefined a.ui-state-default")
    private List<WebElementFacade> v3_DatesList;

    @FindBy(css="div.TimeBox.TimeLabel")
    private List<WebElementFacade> v3_TimeSlotList;

    @FindBy(css="input[name='req_user_dob']")
    private WebElementFacade v3_dob;

    @FindBy(css="div[class='slots morning']>div:nth-child(2)")
    private WebElementFacade v3_secondTimeSlot;

    @FindBy(css="[class*='specs-appointment-type__title']")
    private List<WebElementFacade> appointmentTypeList;

    @FindBy(css="div.oas-application__content.oas-application__content--appointment-type>div:nth-child(3)>div.booking-type__content span.booking-type__title")
    private WebElementFacade eyeTestAppointment;

    @FindBy(id="journey-page-footer_continue-button")
    private WebElementFacade v4_bookAppointmentButton;

    @FindBy(id="appointment-type-triage-container_question_cta-2")
    private WebElementFacade medicalCardNo;

    @FindBy(id="appointment-type-triage-container_question_cta-2")
    private WebElementFacade noPRSIBtn;

    @FindBy(css="#appointment-type-triage-container_appointment-card > a")
    private WebElementFacade chooseYourAppointmentButton;

    public boolean appointmentSearchPageIsDisplayed() {
        Staf.wait.until(WebElementExpectations.elementIsDisplayed(appointmentTypePageTitle));
        return appointmentTypePageTitle.isDisplayed();
    }

    public void clickAdultEyeTest() {

        clickElement(this.adultEyeTest);
    }

    public void clickAdultEyeTestWithOCTScan() {
        clickElement(this.adultEyeTestWithOCTScan);
    }

    public void clickChildEyeTest() {
        clickElement(this.childEyeTest);
    }

    public void clickEyeTestWithContactLensConsultationAndTrial() {
        clickElement(this.eyeTestWithContactLensConsultationAndTrial);
    }

    public void clickEyeTestWithContactLensHealthCheck() {
        clickElement(this.eyeTestWithContactLensHealthCheck);
    }

    public void clickContactLensConsultationAndTrial() {
        scrollDown();
        clickElement(this.contactLensConsultationAndTrial);
    }

    public void clickContactlensHealthCheck() {
        evaluateScriptClick(this.contactlensHealthCheck);
    }

    public void clickBookASlotButton() {
        clickElement(this.appointmentBookASlotButton);
    }

    public boolean cancelAndGoBannerTitleIsDisplayed() {
        return cancelAndGoBannerTitle.isDisplayed();
    }

    public void clickCancelAndGoBackButton() {
        clickElement(this.cancelAndGoLink);

    }

    public void clickHearingServices() {
        clickElement(this.hearingServicesButton);
    }

    public boolean nhsInformationBannerIsDisplayed() {
        return nhsInformationBanner.isDisplayed();
    }

    public boolean nhsInformationBannerTextIsDisplayed() {
        return nhsInformationBannerText.isDisplayed();
    }

    public void clickNHSInformationBannerContentLink() {
        clickElement(this.nhsInformationBannerContentLink);
    }

    public void clickHearingTest() {
        clickElement(this.hearingTest);
    }

    public void clickHearingTestAndHearingAidConsultation() {
        clickElement(this.hearingTestAndHearingAidConsultation);
    }

    public void clickCheckUpForExistingHearingAidWearers() {
        clickElement(this.checkUpForExistingHearingAidWearers);
    }

    public void clickHearingAidMaintenanceOrRepair() {
        clickElement(this.hearingAidMaintenanceOrRepair);
    }

    public void clickHearingProtectionConsultation() {
        clickElement(this.hearingProtectionConsultation);
    }

    public void clickEarwaxRemoval() {
        clickElement(this.earwaxRemoval);
    }

    public boolean bookingUnavailabilityBannerTitleIsDisplayed() {
        return this.bookingUnavailabilityBannerTitle.isDisplayed();
    }

    public void clickRequestAnAppointmentButton() {
        clickElement(this.requestAnAppointmentButton);
    }

    public boolean requestAnAppointmentButtonIsDisplayed() {
        return this.requestAnAppointmentButton.isPresent();
    }

    public void acceptCookies() {
        clickElement(this.cookieButton);
    }

    public void clickATTNoButton(){
        clickElement(this.appointmentTypeTriageNoButton);
    }

    public void clickATTChooseDateAndTimeButton(){
        clickElement(this.appointmentTypeTriageChooseDateAndTime);
        //Need to check without wait
    }

    public void clickATTYesButton(){
        clickElement(this.appointmentTypeTriageYesButton);
    }

    public void clickContactLenseAppointment() {
        clickElement(this.contactLensAppointment);
    }

    public void clickOnGoBackToHomePage(){
        clickElement(this.goBackToHomepage);
    }

    public void verifySTAACANDOCTAppointmentTypes(){
        assertPageObjectIsDisplayed(this.adultEyeTest);
        assertPageObjectIsDisplayed(this.childEyeTest);
       // assertPageObjectIsDisplayed(this.contactLensAppointment);
    }

    public void verifyNonSTACAnsNonOCTAppointmentTypes(){
        assertPageObjectIsDisplayed(this.adultEyeTest);
        assertPageObjectIsDisplayed(this.childEyeTest);
        //assertPageObjectIsDisplayed(this.contactLensConsultationAndTrial);
        //assertPageObjectIsDisplayed(this.contactlensHealthCheck);
    }

    public void clickHearingAppointment(){
        clickElement(this.hearingAppointment);
    }
    public void clickAudiologyATTYesOption(){
        clickElement(this.audiologyATTQuestionYesOption);
    }
    public void clickAudiologyATTNoOption(){
        waitOnPage();
        this.waitFor(audiologyATTQuestionNoOption);
        clickElement(this.audiologyATTQuestionNoOption);
    }

    public boolean getHearingAppointmentElementInformation(){
        return this.hearingAppointment.isDisplayed();
    }

    public void clickEarwaxRemovalAudiologyATT() {
        clickElement(this.earwaxRemovalAudiologyATT);
    }

    public void clickIUnderstandForEarwaxRemoval(){
        clickElement(this.iUnderstandForEarwaxRemoval);
    }

    public void validateNHSFundingHeadingIsDisplayed(){
        assertPageObjectIsDisplayed(this.nHSFundingHeading);
    }

    public void clickCheckYourEligibility(){
        clickElement(this.nHSFundingCheckYourEligibility);
    }

    public void clickGoBackForEarwaxRemoval(){
        clickElement(this.goBackForEarwaxRemoval);
    }

    public void validateATTContainerQuestionHeadline(){
        assertPageObjectIsDisplayed(this.aTTContainerQuestionHeadline);
    }

    public void validatePreviousButton(){
        assertPageObjectIsDisplayed(this.previousButton);
    }

    public void clickPreviousLink(){
        clickElement(previousButton);
    }

    public void clickOnCloseButton(){
        clickElement(closeButton);
    }

    public void assertEarwaxRemovalAudiologyATTIsSelected(){
        boolean result=earwaxRemovalAudiologyATT.isSelected();
        assertThat(result).isTrue();
    }

    public void clickAdultEyeTestATT(){
        waitForElement();
        clickElement(this.adultEyeTestATT);
    }

    //works for both v3 and v4 versions
    public void v3_selectAppointmentTestAs(String appointmentTypeName) {
            clickElement(this.v3_appointmentTypeList.stream().filter(x ->
            {
                String name = x.getText().toLowerCase();
                return name.contains(appointmentTypeName.toLowerCase());
            }).findFirst().get());
    }

    public void v3_ClickBookAppointmentButton(){
        clickElement(this.v3_bookAppointmentButton);
    }

    public void v4_ClickBookAppointmentButton(){
        clickElement(this.v4_bookAppointmentButton);
    }

    public void v4_ClickNoMedicalCardButton(){
        clickElement(this.medicalCardNo);
    }

    public void v4_ClickNoPRSIButton(){
        clickElement(this.noPRSIBtn);
    }

    public void v4_ChooseYourAppointmentBtn(){
        clickElement(this.chooseYourAppointmentButton);
    }

    public void v3_selectMedicalCardAvailabilityAs(String value){
        clickElement(this.v3_DoYouHaveMedicalCardButtonList.stream().filter(x->
        {
            String name = x.getText().toLowerCase();
            return name.contains(value.toLowerCase());
        }).findFirst().get());
    }

    public void v3_selectAppointmentCategoryAs(String value){
        clickElement(this.v3_AppointmentTypeButtonList.stream().filter(x->
        {
            String name = x.getText().toLowerCase();
            return name.contains(value.toLowerCase());
        }).findFirst().get());
    }

    public void v3_SelectDateAndTime() {
        if(Staf.getTargetRegion().equals("ie")) {
            clickElement(v3_nextDate);
            getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
            clickElement(v3_before12Noon);
            clickElement(v3_timeSlot);
            clickElement(v3_selectThisDateAndTime);
        }
        else if(Staf.getTargetRegion().equals("nz"))
        {
            clickElement(v3_DatesList.get(0));
            getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            clickElement(v3_TimeSlotList.get(0));
            clickElement(v3_bookAppointmentButton);
        }

    }

    public void enterTitleAs(String value){
        clickElement(this.v3_title.stream().filter(x->{
            String title=x.getText().toLowerCase()  ;
            return title.contains(value.toLowerCase());
        }).findFirst().get());
    }

    public void enterFirstName(String value){
        setText(v3_firstName,value);
    }

    public void enterLastName(String value){
        setText(v3_lastName,value);
    }

    public void enterDate(String value){
        setText(v3_date,value);
    }

    public void enterMonth(String value){
        setText(v3_month,value);
    }

    public void enterYear(String value){
        setText(v3_year,value);
        clickElement(v3_month);
    }

    public void enterEmail(String value){
        setText(v3_email,value);
    }

    public void enterMobileNumber(String value){
        setText(v3_mobileNumber,value);
    }

    public void clickOnBookNowButton(){
        clickOn(v3_bookNow);
    }

    public void clickOnBookNowButtonV4() {
        clickOn(v4_bookNow);
    }
    public void switchToFrameForAppointments(){
        getDriver().switchTo().frame(frameinNzRegion);
    }

    public void enterDOB(String value){
        setText(v3_dob,value);
    }

    public void v3_selectLaterDateAndTime() {
        clickElement(v3_nextDate);
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        clickElement(v3_before12Noon);
        clickElement(v3_secondTimeSlot);
        clickElement(v3_selectThisDateAndTime);
    }

    public void SelectAppointmentTestAs(String appointmentTypeName) {
        clickElement(this.appointmentTypeList.stream().filter(x->
        {
            String name = x.getText().toLowerCase();
            return name.contains(appointmentTypeName.toLowerCase());
        }).findFirst().get());
    }

    public void v3_selectEyeTestInAppointmentTypePage(){
        clickElement(this.eyeTestAppointment);
    }
}