package digital.fabr.ui.pages.findStore;

import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class NonSASYourAppointmentPage extends FabrBase {

    @FindBy(xpath = "//h2[contains(@class, 'section__name') and contains(., 'Where')]")
    private WebElementFacade whereSection;

    @FindBy(xpath = "//h2[contains(@class, 'section__name') and contains(., 'When')]")
    private WebElementFacade whenSection;

    @FindBy(xpath = "//h2[contains(@class, 'section__name') and contains(., 'What')]")
    private WebElementFacade whatSection;

    @FindBy(xpath = "//h2[contains(@class, 'section__name') and contains(., 'Who')]")
    private WebElementFacade whoSection;

    public WebElementFacade getWhereSection() {

        return whereSection;
    }
    public WebElementFacade getWhenSection() {
        return whenSection;
    }

    public WebElementFacade getWhatSection() {
        return whatSection;
    }

    public WebElementFacade getWhoSection() {
        return whoSection;
    }
}
