package digital.fabr.ui.pages.findStore;

import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class eCommFindStorePage extends FabrBase {

    @FindBy(css = "a[trackaid='header-find-store-icon']")
    public WebElementFacade findAStore;

    @FindBy(id = "onetrust-accept-btn-handler")
    public WebElementFacade acceptButton;

    @FindBy(id = "googleplaceautocompletefield1")
    public WebElementFacade storeLocations;

    @FindBy(id = "edit-submit")
    public WebElementFacade findAStoreButton;

    @FindBy(className = "store-header--title")
    public WebElementFacade storeAddress;

    @FindBy(css = "#results > div > ul > li.views-row.views-row-1.views-row-odd.views-row-first > div.store-name > a")
    public WebElementFacade storeName;

    @FindBy(id = "store-search-page")
    public WebElementFacade enterAddressManuallyLink;

    @FindBy(css = "#block-defaultcontent-blocks-no-stores-found-content-block > div > div > p > a")
    public WebElementFacade findStoreList;

    public void clickFindStore() {
        evaluateScriptClick(this.findAStore); //Used java script : Dipak
    }

    public void enterStoreLocation(String storeLocation) {
        clickElement(this.storeLocations);
        setText(this.storeLocations, storeLocation);
    }

    public void clickFindButton() {
        findAStoreButton.waitUntilPresent().click();
    }

    public void clickOnStoreName() {
        clickElement(this.storeName);
    }

    public String storeAddress() {
        return (storeAddress.getText());
    }

    public void clickFindStoreList() {
        clickElement(this.findStoreList);
    }


}

