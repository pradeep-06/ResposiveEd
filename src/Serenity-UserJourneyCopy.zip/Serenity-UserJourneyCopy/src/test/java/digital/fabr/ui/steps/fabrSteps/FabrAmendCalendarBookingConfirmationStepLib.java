package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrAmendCalendarBookingConfirmationPage;
import net.thucydides.core.steps.ScenarioSteps;

public class FabrAmendCalendarBookingConfirmationStepLib extends ScenarioSteps {
    FabrAmendCalendarBookingConfirmationPage fabrAmendCalendarBookingConfirmationPage;

    public void clickOnKeepCurrentAppointment() {
        fabrAmendCalendarBookingConfirmationPage.clickKeepCurrentAppointment();
    }

    public void clickCancelBooking() {
        fabrAmendCalendarBookingConfirmationPage.clickCancelBooking();
    }
}
