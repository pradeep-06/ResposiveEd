package digital.fabr.ui.pages.fabrPages;

import digital.fabr.ui.extensions.FabrBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;

public class FabrContactLensesListPage extends FabrBase {

    @FindBy(css = ".product-details")
    private List<WebElementFacade> v3_contactLensItems ;

    public void v3_selectFirstContactLensItem() {
        clickOn(this.v3_contactLensItems.get(0));
    }
}
