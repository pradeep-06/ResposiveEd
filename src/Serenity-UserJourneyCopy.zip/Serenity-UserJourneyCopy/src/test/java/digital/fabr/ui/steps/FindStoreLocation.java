package digital.fabr.ui.steps;

import Framework.DataManager.TestDataManager;
import digital.eComm.ui.pages.eCommHomePage;
import digital.fabr.ui.pages.findStore.eCommFindStorePage;
import net.thucydides.core.steps.ScenarioSteps;
import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FindStoreLocation extends ScenarioSteps {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(FindStoreLocation.class);
    eCommFindStorePage findStorePage;
    eCommHomePage homePage;

    public void theUserAcceptCookies() {

        if (testDataManager.getFeatureData("models.cookieModel", Boolean.class)) {
            homePage.clickAcceptOnCookies();
        }
    }


    public void clickfindstore() {
        findStorePage.clickFindStore();
    }


    public void enterFindLocationDetails() {

        final String storeLocation = testDataManager.getTestInputRegionData("appointmentData.storeLocation.storeName");

        findStorePage.enterStoreLocation(storeLocation);

        findStorePage.clickFindButton();
        findStorePage.clickOnStoreName();

        Assertions.assertThat(findStorePage.storeAddress()).isEqualTo(storeLocation);

    }

}

