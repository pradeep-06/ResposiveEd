package digital.fabr.ui.steps.fabrSteps;

import Framework.Staf;
import digital.fabr.ui.pages.fabrPages.FabrRAFAppointmentTypePage;
import digital.fabr.ui.stepdefinitions.FabrStepDefinitions;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FabrRAFAppointmentTypeStepLib extends ScenarioSteps {
    FabrRAFAppointmentTypePage fabrRAFAppointmentTypePage;
    private final Logger logger = LoggerFactory.getLogger(FabrStepDefinitions.class);

    public void clickAdultSightTest() {
        fabrRAFAppointmentTypePage.clickAdultSightTest();
    }

    public void clickAdultSightTestAndOCTScan() {
        fabrRAFAppointmentTypePage.clickAdultSightTestAndOCTScan();
    }

    public void clickChildEyeTest() {
        fabrRAFAppointmentTypePage.clickChildEyeTest();
    }

    public void clickContactLensConsultationAndTrial() {
        fabrRAFAppointmentTypePage.clickContactLensConsultationAndTrial();
    }

    public void clickContactLensHealthCheck() {
        fabrRAFAppointmentTypePage.clickContactLensHealthCheck();
    }

    public void clickHearingTest() {
        fabrRAFAppointmentTypePage.clickHearingTest();
    }

    public void clickHearingTestAndHearingAidConsultation() {
        fabrRAFAppointmentTypePage.clickHearingTestAndHearingAidConsultation();
    }

    public void clickCheckUpForExistingHearingAidWearers() {
        fabrRAFAppointmentTypePage.clickCheckUpForExistingHearingAidWearers();
    }

    public void clickHearingAidMaintenanceOrRepair() {
        fabrRAFAppointmentTypePage.clickHearingAidMaintenanceOrRepair();
    }

    public void clickHearingProtectionConsultation() {
        fabrRAFAppointmentTypePage.clickHearingProtectionConsultation();
    }

    public void inputRAFPersonalDetailsForBooking(String dateAndTime, String title, String firstName, String lastName, String phoneNumber, String email) {
        fabrRAFAppointmentTypePage.inputAppointmentDateAndTime(dateAndTime);
        fabrRAFAppointmentTypePage.selectCustomerTitle(title);
        fabrRAFAppointmentTypePage.inputCustomerFirstName(firstName);
        fabrRAFAppointmentTypePage.inputCustomerLastName(lastName);
        fabrRAFAppointmentTypePage.inputCustomerMobile(phoneNumber);
        fabrRAFAppointmentTypePage.inputCustomerEmail(email);
        if(Staf.getTargetRegion().equals("eses"))
            fabrRAFAppointmentTypePage.focusOnAnythingElseWeShouldKnow();
    }

    public void clickOnSubmitButtonForRAFBooking() {
        fabrRAFAppointmentTypePage.clickSubmitButton();
    }

    public void clickOnAppointment(String appointmentName){
        logger.info("Select appointment type as "+appointmentName);
        if(Staf.getTargetRegion().equals(("nz"))){
            fabrRAFAppointmentTypePage.switchToFrameForAppointments();
        }
        if(Staf.getTargetRegion().equals(("au"))){
            fabrRAFAppointmentTypePage.clickRequestFormLink();
        }

        fabrRAFAppointmentTypePage.SelectAppointmentTestAs(appointmentName);
    }

    public void inputRAFPersonalDetailsForBooking(String dateAndTime, String firstName, String lastName, String phoneNumber, String email) {
        fabrRAFAppointmentTypePage.inputAppointmentDateAndTime(dateAndTime);
        fabrRAFAppointmentTypePage.inputCustomerFirstName(firstName);
        fabrRAFAppointmentTypePage.inputCustomerLastName(lastName);
        fabrRAFAppointmentTypePage.inputCustomerMobile(phoneNumber);
        fabrRAFAppointmentTypePage.inputCustomerEmail(email);
        if(Staf.getTargetRegion().equals("au"))
            fabrRAFAppointmentTypePage.focusOnAnythingElseWeShouldKnow();
    }

    public void verifyRequestAnAppointmentButtonIsDisplayed(){
        fabrRAFAppointmentTypePage.verifyRequestAnAppointmentButtonIsDisplayed();
    }

    public void clickRafRequestAnAppointmentBtn(){
        fabrRAFAppointmentTypePage.requestAnAppointmentRafBtn();
    }
}
