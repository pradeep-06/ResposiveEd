package digital.fabr.api.tests;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.FABR.FandB_R_API;
import Framework.DataManager.TestDataManager;
import digital.fabr.api.steps.AppointmentSteps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(SerenityJUnit5Extension.class)
public class AudiologyE2ETestCases {

    @Steps
    AppointmentSteps appointmentSteps;

    protected final TestDataManager testDataManager = new TestDataManager();

    @Disabled("out of scope")
    @FandB_R_API
    @Tags(value = {@Tag("ie"),@Tag("uk")})
    @Order(2)
    @SSTest(testCaseId = "42858356", projectId = "102929", testCaseName = "Booking journey via Find a store CTA (Combined store) - (By providing Gmail id details on PD page)", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void bookingJourneyViaFindAStoreCTA(){
        appointmentSteps.getSlotsInformationForAudiology(testDataManager.getTestInputRegionData("storeName.store4"));
        appointmentSteps.bookAppointmentForAudiologyJourney();
    }

    @Disabled("out of scope")
    @FandB_R_API
    @Tags(value = {@Tag("uk"),@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42858369", projectId = "102929", testCaseName = "TC_15-Audiology-Appointment book journey-Ear wax removal", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void TC_15_AudiologyBookingJourneyEarWaxRemoval(){
        appointmentSteps.getSlotsInformationForAudiology(testDataManager.getTestInputRegionData("storeName.store3"));
        appointmentSteps.bookAppointmentForAudiologyJourney();
    }

    @FandB_R_API
    @Tags(value = {@Tag("uk"),@Tag("ie")})
    @Order(2)
    @SSTest(testCaseId = "42858369", projectId = "102929", testCaseName = "Booking journey for hearing protection consultation", testType = SSTestType.E2E, testCaseVersion = "1.0")
    public void bookingJourneyForHearingProtectionConsultation(){
        appointmentSteps.getSlotsInformationForAudiology(testDataManager.getTestInputRegionData("storeName.store2"));
        appointmentSteps.bookAppointmentForHearingProtectionConsultation();
    }
}
