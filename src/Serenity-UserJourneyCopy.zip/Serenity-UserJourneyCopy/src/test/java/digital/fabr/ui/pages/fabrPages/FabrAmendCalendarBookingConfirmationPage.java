package digital.fabr.ui.pages.fabrPages;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;

public class FabrAmendCalendarBookingConfirmationPage extends BasePageObject {

    @FindBy(css = "h1#amend-calendar-title")
    private WebElementFacade amendCalendarTitle;

    @FindBy(css = "div.calendar-ab--slots button")
    private List<WebElementFacade> calendarSlots;

    @FindBy(id = "date-and-time_keep-appointment-button")
    private WebElementFacade keepCurrentAppointment;

    @FindBy(css = "a#amend-calendar-footer-cancel")
    private WebElementFacade cancelBooking;

    public boolean verifyAmendCalendarTitleIsDisplayed() {
        return this.amendCalendarTitle.isDisplayed();
    }

    public void clickKeepCurrentAppointment() {
        clickElement(this.keepCurrentAppointment);
    }

    public void clickCancelBooking(){
        clickElement(this.cancelBooking);
    }
}
