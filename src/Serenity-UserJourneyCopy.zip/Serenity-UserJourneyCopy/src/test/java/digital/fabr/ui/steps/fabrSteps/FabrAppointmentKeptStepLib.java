package digital.fabr.ui.steps.fabrSteps;

import digital.fabr.ui.pages.fabrPages.FabrAppointmentKeptPage;
import net.thucydides.core.steps.ScenarioSteps;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FabrAppointmentKeptStepLib extends ScenarioSteps {
    FabrAppointmentKeptPage fabrAppointmentKeptPage;
    public void assertHeaderConfirmationTitle() {
        assertThat(fabrAppointmentKeptPage.headerConfirmationTitleIsDisplayed());
    }
}
