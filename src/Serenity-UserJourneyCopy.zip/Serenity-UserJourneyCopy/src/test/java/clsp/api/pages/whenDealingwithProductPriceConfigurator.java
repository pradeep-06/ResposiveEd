package clsp.api.pages;

import Framework.api.request.APIRequests;
import clsp.api.extentions.clspApiBase;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class whenDealingwithProductPriceConfigurator extends clspApiBase {
    private final Logger logger = LoggerFactory.getLogger(whenDealingwithProductPriceConfigurator.class);
    public clspApiBase clspApiRequest = new clspApiBase();
    public APIRequests apiRequests = new APIRequests();
    public String xApiKey=testDataManager.getTestInputCommonData("url.apiKeyCDG");
    private Response response;
    public void userRequestForPriceOptions(int status,String left_style_no, String right_style_no, String country_code, String tax_code) {

        final String endPoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.ProductURICDG")+testDataManager.getTestInputCommonData("url.priceOptionEndPoint")+testDataManager.getTestInputCommonData("url.countryCodeEndPoint")+country_code+testDataManager.getTestInputCommonData("url.taxCodeEndPoint")+tax_code+testDataManager.getTestInputCommonData("url.leftEyeStyleIdEndPoint")+left_style_no+testDataManager.getTestInputCommonData("url.rightEyeStyleIdEndPoint")+right_style_no;
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        assertEquals(status, apiRequests.verifyResponseStatusCode());

    }
    public void validatePriceOptionsBody() {
        //response = apiRequests.response;
        try {
            ResponseBody<?> body = response.getBody();
            String bodyStringValue = body.asString();
            JSONObject jsonOb = new JSONObject(bodyStringValue);
            JSONArray prodId = jsonOb.getJSONArray("product_id");
            logger.info("Product Id:"+prodId);
            for (int index=0; index<prodId.length(); index++) {
                JSONObject currentObj = prodId.getJSONObject(index);
                Assertions.assertNotNull(prodId);
                //prodDesc = currentObj.getString("product_description");
                //Assert.assertTrue(!(prodDesc.equals(null)));
                logger.info("Product ["+(index+1)+"]: "+prodId);
            }
        }
        catch(Exception e) {
        }
    }
    public void theResponseStatusCodeIs(int statusCode) {
        assertThat(apiRequests.verifyResponseStatusCode()).isEqualTo(statusCode);
    }
}
