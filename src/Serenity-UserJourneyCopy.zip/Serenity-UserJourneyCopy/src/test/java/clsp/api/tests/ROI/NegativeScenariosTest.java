package clsp.api.tests.ROI;

import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.api.stepDefinitions.carts;
import clsp.api.stepDefinitions.customerSignupSteps;
import clsp.api.stepDefinitions.socrates;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class NegativeScenariosTest {
    @Steps
    carts cartsSteps;

    @Steps
    socrates socratesSteps;

    @Steps
    customerSignupSteps subscriptionSteps;

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,0010AACPL35N96OIH,228791,204,404"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Customer,Find customer for given criteria,Search for customers matching given criteria, Retrieve a customer (Negative)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUserAbleToFindMatchingCriteriaWithInvalidCustomerId(int status, String accountReference,String customerId,int removedStatus, int newStatus ) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToFindCustomerWithInvalidCustomerId(customerId,status);
        subscriptionSteps.userAbleToSearchMatchingCriteriaWithInvalidCustomerId(customerId,status);
        subscriptionSteps.userRetrieveCustomerDataWithInvalidAccountReference(accountReference,newStatus);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,ABNANL,NL12ABNA064070,204,0010AACPL35N96OIH,firstName"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create_Customer_Update_Payment_Details_Negative", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUserUpdatePaymentDetailsForInvalidBICAndIBAN(int status, String bic,String iban,int removedStatus, String acc_reference,String firstName) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userRequestsToUpdatePaymentDetailsForInvalidBIC(bic,status,acc_reference,firstName);
        subscriptionSteps.userRequestsToUpdatePaymentDetailsForInvalidIBAN(iban,status,acc_reference,firstName);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "404,8175,UK,8029,207943,1271565,1"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Get_Customer_With_CLFIT_one_Negative", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUserGetCustomerForInvalidStore(int status, int invalidStoreId,String countryCode,String storeId,String accountId,String tdr,String clfit) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userRequestToGetCustomerWithCLFITData(countryCode,storeId,accountId,tdr,clfit);
        subscriptionSteps.validateResponseAndStatusCodeForInvalidStore(status,invalidStoreId);
        subscriptionSteps.userRequestToGetCustomerWithCLFITData(countryCode,storeId,accountId,tdr,clfit);
        subscriptionSteps.userValidateResponseAndStatusCodeForCLFIT(status);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,GMPMJPAG,7ud921,8029,404,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Apply_Invalid_Promotion_Validate_Invalid_Promotion", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyInvalidPromotionOnCart(int status, String voucher,String authCode,String storeId,int newStatus, int removedStatus)  {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        cartsSteps.userTriesToAddACart(status);
        cartsSteps.userRequestsToApplyInvalidPromotionOnTheCart(newStatus,storeId,voucher,authCode);
        cartsSteps.userRequestToValidateThatInvalidPromotionOnCart(newStatus,storeId,voucher,authCode);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,123456,404"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Store_Transfer_Negative", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyStoreTransferNegative(int status, String dailyType,int quantity, int removedStatus,String customerID,int newStatus)  {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesDailyCustomer(dailyType, status, quantity);
        subscriptionSteps.userRequestsToTransferTheInvalidStore(newStatus,customerID);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "404,8175,7ud921,8029"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Authentication_Store_Negative", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyAuthenticateInvalidStore(int status, String invalidStoreId,String authCode, String storeId) throws Exception {
        cartsSteps.cleanSession();
        socratesSteps.userRequestToAuthenticateStore(invalidStoreId,authCode);
        socratesSteps.userValidatesTheResponseBodyForThatInvalidStore(status,invalidStoreId);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,PRE,404"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Replace_Pack_Negative_Trying_to_replace_Pending_Pack", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyReplaceInvalidPack(int status, int removedStatus,String payerType,int newStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesSubscription(status,payerType);
        subscriptionSteps.userMustBeAbleToGetSubscriptionDetails(status);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userRequestsToReplaceInvalidPack(newStatus);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,PRE"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Expedite_Pack_Negative", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyExpeditePackWithPastDeliveryDate(int status, int removedStatus,String payerType)  {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesSubscription(status,payerType);
        subscriptionSteps.userMustBeAbleToGetSubscriptionDetails(status);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userRequestsToExpeditePackWithPastDeliveryDate(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,NONE,400"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create_Subscription_Negative_Past_First_Payment_Date", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toCreateSubscriptionNegativeWithPaymentDate(int status, int removedStatus,String firstPack,int newStatus) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToAddAddressForTheCustomer(status);
        cartsSteps.userTriesToAddACart(status);
        subscriptionSteps.userMakesPayment();
        subscriptionSteps.userMustNotBeAbleToCreateSubscriptionWithPaymentDate(newStatus,firstPack);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,NONE"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create_Subscription_Negative_Past_First_Dispatch_Date", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toCreateSubscriptionNegativeWithDispatchDate(int status, int removedStatus,String firstPack) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToAddAddressForTheCustomer(status);
        cartsSteps.userTriesToAddACart(status);
        subscriptionSteps.userMakesPayment();
        subscriptionSteps.userMustNotBeAbleToCreateSubscriptionWithDispatchDate(status,firstPack);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

}
