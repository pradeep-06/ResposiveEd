package clsp.api.pages;

import Framework.api.request.APIRequests;
import Framework.api.request.Headers;
import Framework.extensions.StafUtils;
import clsp.api.extentions.clspApiBase;
import clsp.ui.pages.PaymentPage;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class whenDealingwithSubscription extends clspApiBase {

    private final Logger logger = LoggerFactory.getLogger(whenDealingwithSubscription.class);
    public clspApiBase clspApiRequest = new clspApiBase();
    public APIRequests apiRequests = new APIRequests();
    private static final Headers header = new Headers();

    public static String account_id;
    public static String acc_reference;
    public static String subscription_id;
    public static String tdr_no;
    public String add_id;
    public static String cart_id;
    public static String store_id;
    public static String custType="Test";
    public static String total_cost;
    public static String packRef;
    public static String packRef_2;
    public static String packRef_3;
    public static String paymentStatus;
    public static String paymentDateAPI;
    public static String paymentRef1;
    public static String paymentRef2;
    public static String paymentRef3;

    public static String grossAmount;
    public static String changeUsageAmount;
    public static String changeAmount;
    public static String payerTypeAPI;
    public static String paymentAmount;
    public static String sub_description;
    public static String getFirstPaymentDateAPI;
    public static String nextPaymentAmt="";
    public static String nextPaymentDate;
    public static String nextDeliveryDate;
    public static String nonLensMailOrderValue;
    public static String firstPackStatus;

    private Response response;
    public static String subRef;
    public static String subExpDate;
    public static String deliveryDateAPI;
    public static String client_user_id = "4"+getNewUserID();
    public static String lastName = "AutoTest";
    public static String firstName = StafUtils.getFirstName(6);
    public static String emailID = StafUtils.generateNewCustomerEmail("");
    public String xApiKey=testDataManager.getTestInputCommonData("url.apiKeyCDG");
    public String xClientId=testDataManager.getTestInputCommonData("mppHeaders.clientId");
    public String xClientPassword=testDataManager.getTestInputCommonData("mppHeaders.clientPassword");
    public String xVersion=testDataManager.getTestInputCommonData("mppHeaders.versionNumber");

    public static String customerID;

    public static String balanceAmount;

    public static ArrayList<String> bankHoliday = new ArrayList<String>();


    public static String getNewUserID() {

        final long varTime = System.currentTimeMillis();
        final double randomMath = Math.random() * 1000;
        final long multi = (long) (varTime * randomMath);
        final String s = multi + "";
        final String subStr = s.substring(0, 6);
        return subStr;
    }



    public void userRequestForNewCustomerOnCDG(int status){

        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG");
        final String response = apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCustomerJsonBodyCDG(client_user_id,firstName,lastName,emailID));
        customerID= client_user_id;
        if(response.contains("Account with that ClientUserId already exists") || response.contains("The email is already in use"))
        {
            userReattemptsAccountCreation(endpoint);
        }else{
            captureCustomerAccountDetails();
        }

    }

    public void userReattemptsAccountCreation(String endpoint) {
        client_user_id = "5"+getNewUserID();
        emailID = "auto"+emailID;
        logger.info("customers id with 5 is:" +client_user_id);
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCustomerJsonBodyCDG(client_user_id,firstName,lastName,emailID));
        captureCustomerAccountDetails();

    }
    public void userMakesPayment() {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.paymentEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getpaymentBody("payment", firstName));
        if(testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod").equalsIgnoreCase("SEPA"))
            PaymentPage.mandateReference =  apiRequests.getValueFormJsonResponseKey("sepa[0].reference"); //According to 46 change
        else
            PaymentPage.mandateReference =  apiRequests.getValueFormJsonResponseKey("bacs[0].reference");
        logger.info("The customer ID:"+client_user_id+"has Mandate reference:"+PaymentPage.mandateReference);

    }
    public void userCreatesSubscriptionUsingCDG(String payerType,String cart_id) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions";
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getSubscriptionRequestCDGBody(payerType,acc_reference,cart_id,add_id));
    }

    public void captureCustomerAccountDetails(){
        account_id = apiRequests.getValueFormJsonResponseKey("account.account_id");
        client_user_id = apiRequests.getValueFormJsonResponseKey("client_user_id");
        acc_reference =  apiRequests.getValueFormJsonResponseKey("account.resource_reference");
        store_id = apiRequests.getValueFormJsonResponseKey("mpp_store_id");
        emailID = apiRequests.getValueFormJsonResponseKey("customer_contact_details.email");
        add_id = apiRequests.getValueFormJsonResponseKey("address_book[0].id");

        logger.info("The account ID is:" +account_id);
        logger.info("The client user ID is:" +client_user_id);
        logger.info("The account reference is:" +acc_reference);
        logger.info("Store Id : "+store_id);
        logger.info("Email Id : "+emailID);
        assertTrue(account_id.length()>4);

    }
    public void userSearchesSubscription(int status) {
        final String endPoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions";
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        subscription_id = apiRequests.getValueFormJsonResponseKey("subscriptions[0].id");
        tdr_no = apiRequests.getValueFormJsonResponseKey("subscriptions[0].tdr");
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
    }

    public void deleteCustomer(String customerID, int status) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonMPPURI")+"/rest/api/accounts";
        apiRequests.GETMethodWithQueryParam(endPoint,"clientUserId",customerID,"surname","Auto",clspApiRequest.getMPPHeaders());
        logger.info("accreference is" + acc_reference);
        acc_reference = apiRequests.getValueFormJsonResponseKey("[0].accountReference");
        deleteCustomer(status);
    }
    public void deleteCustomer(int status){
        final String endpoint = testDataManager.getTestInputCommonData("url.commonMPPURI")+"/rest/api/accounts/"+acc_reference;
        logger.info("The Delete endpoint is:"+endpoint);
        apiRequests.DELETEMethodWithSpecificHeaders(endpoint,clspApiRequest.getHeadersForRemoveCust());
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }
    public void createDailyCustomer(String dailyType,int quantity,int status, String payerType){
        userRequestForNewCustomerOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType,quantity);
        userMakesPayment();
        userCreatesSubscriptionUsingCDG(payerType,cart_id);
        userGetsTheSubscriptionDetails(0);
    }
    public void userTriesToAddACartForDailyCustomer(String dailyType,int quantity) {

        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.cartEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCartJsonBodyCDGDaily(dailyType,quantity));
        custType = dailyType;
        cart_id = apiRequests.getValueFormJsonResponseKey("id");
        total_cost =  apiRequests.getValueFormJsonResponseKey("total_cost");
    }

    public void userGetsTheSubscriptionDetails(int subId)  {
        //Passing subId 0 for first subscription and 1 for second subscription
        final String endPointURI = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions";
        apiRequests.GETMethodWithXApiHeaders(endPointURI,xApiKey);
        subRef= apiRequests.getValueFormJsonResponseKey("subscriptions["+subId+"].id");
        assertTrue(subRef.length()>4);
        subExpDate= apiRequests.getValueFormJsonResponseKey("subscriptions[0].expiry_date");
        nextPaymentAmt = apiRequests.getValueFormJsonResponseKey("subscriptions[0].next_payment_amount");
        logger.info("nextPaymentAmt:"+nextPaymentAmt);
        nextPaymentDate = apiRequests.getValueFormJsonResponseKey("subscriptions[0].next_payment");
        nextDeliveryDate = apiRequests.getValueFormJsonResponseKey("subscriptions[0].next_delivery");

        final String endpointSubRef = endPointURI+"/"+subRef;
        apiRequests.GETMethodWithXApiHeaders(endpointSubRef,testDataManager.getTestInputCommonData("url.apiKeyCDG"));
        packRef = apiRequests.getValueFormJsonResponseKey("packs[0].id");
        packRef_2 = apiRequests.getValueFormJsonResponseKey("packs[1].id");
        packRef_3 = apiRequests.getValueFormJsonResponseKey("packs[2].id");
        paymentRef1 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].id");
        paymentRef2 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[1].id");
        paymentRef3 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].id");
        grossAmount = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].gross_amount");
        changeUsageAmount=apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].gross_amount");
        changeAmount=apiRequests.getValueFormJsonResponseKey("packs[1].payments[0].gross_amount");
        getFirstPaymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");

        paymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");
        deliveryDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].delivery_date");

        firstPackStatus = apiRequests.getValueFormJsonResponseKey("packs[0].status");
        payerTypeAPI = apiRequests.getValueFormJsonResponseKey("type");

        nonLensMailOrderValue = apiRequests.getValueFormJsonResponseKey("packs[0].non_lens_mail_order");
        paymentStatus = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].status");
        sub_description = apiRequests.getValueFormJsonResponseKey("description");
        paymentAmount = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].gross_amount");
    }
    public void createDailyCustomerPaymentCompleted(String dailyType,int quantity,int status){
        userRequestForNewCustomerOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType,quantity);
        userMakesPayment();
        userCreatesSameDayPaymentSubcriptionUsingMPP(status, "PRE","");
        waitABit(150000);
        userGetsTheSubscriptionDetails(0);
    }
    public void userCreatesSameDayPaymentSubcriptionUsingMPP(int status, String payerType, String discountType ) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonESBURI")+"/api/accounts/"+acc_reference+"/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestFirstPaymentInFlightOrCompleted(payerType, discountType, "No",0,cart_id,add_id,custType));
    }
    public void userCancelsSubscription(int status) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + testDataManager.getTestInputCommonData("url.accountEndPointCDG") + "/" + acc_reference + "/subscriptions" + "/" + subscription_id;
        apiRequests.DELETEMethodWithSpecificHeadersAndJSONBody(endPoint, xApiKey, clspApiRequest.getDeleteSubscriptionBody());
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        waitABit(90000);
    }

    public String userMustBeAbleToGetLifecycleState(String state, String orderType) {
        String actualSubscriptionID="";
        logger.info(testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+testDataManager.getTestInputCommonData("url.lifeCycleState")+"ACTIVE");
        final String endPoint= testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+testDataManager.getTestInputCommonData("url.lifeCycleState")+"ACTIVE";
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        String activeState = apiRequests.getValueFormJsonResponseKey("subscriptions");
        String activeOrderType = apiRequests.getValueFormJsonResponseKey("subscriptions[0].order_type");
        String activeSubscriptionId = apiRequests.getValueFormJsonResponseKey("subscriptions[0].id");
        String activeStatus = apiRequests.getValueFormJsonResponseKey("subscriptions[0].status");

        logger.info(testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+testDataManager.getTestInputCommonData("url.lifeCycleState")+"ONE_OFF");
        final String endPointOneOff= testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+testDataManager.getTestInputCommonData("url.lifeCycleState")+"ONE_OFF";
        apiRequests.GETMethodWithXApiHeaders(endPointOneOff,xApiKey);
        String oneOffState = apiRequests.getValueFormJsonResponseKey("subscriptions");
        String oneOffOrderType = apiRequests.getValueFormJsonResponseKey("subscriptions[0].order_type");
        String oneOffSubscriptionId = apiRequests.getValueFormJsonResponseKey("subscriptions[0].id");
        String oneOffStatus = apiRequests.getValueFormJsonResponseKey("subscriptions[0].status");

        logger.info(testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+testDataManager.getTestInputCommonData("url.lifeCycleState")+"HISTORY");
        final String endPointHistory= testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+testDataManager.getTestInputCommonData("url.lifeCycleState")+"HISTORY";
        apiRequests.GETMethodWithXApiHeaders(endPointHistory,xApiKey);
        String historyState = apiRequests.getValueFormJsonResponseKey("subscriptions");
        String historyOrderType = apiRequests.getValueFormJsonResponseKey("subscriptions[0].order_type");
        String historySubscriptionId = apiRequests.getValueFormJsonResponseKey("subscriptions[0].id");
        String historyStatus = apiRequests.getValueFormJsonResponseKey("subscriptions[0].status");

        if(state.equals("ACTIVE"))
        {
            logger.info("active state");
            assertEquals(activeSubscriptionId, subscription_id);
            assertTrue(activeOrderType.equals(orderType) && activeStatus.equalsIgnoreCase("Pending") || activeStatus.equalsIgnoreCase("Active") );
            assertEquals("[]", oneOffState);
            assertEquals("[]", historyState);
            actualSubscriptionID=activeSubscriptionId;
        }
        else if(state.equals("ONE_OFF"))
        {
            logger.info("One_off state");
            assertEquals(activeSubscriptionId, subscription_id);
            assertNotEquals(oneOffState, subscription_id);
            assertTrue(oneOffOrderType.equals(orderType) && oneOffStatus.equalsIgnoreCase("Active"));
            assertEquals("[]", historyState);
            actualSubscriptionID=oneOffSubscriptionId;
        }
        else if(state.equals("HISTORY"))
        {
            logger.info("History state");
            assertTrue(historySubscriptionId.contains(subscription_id));
            assertTrue(historyOrderType.equals(orderType) && historyStatus.equalsIgnoreCase("Cancelled"));
            assertEquals("[]", activeState);
            assertEquals("[]", oneOffState);
            actualSubscriptionID=historySubscriptionId;
        }
        return actualSubscriptionID;
    }
    public void userAuthenticatesStore(int status, String authCode, String responseString) {
        final String endPoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.authenticate")+"/"+store_id;
        String Key1 = "auth_code";
        apiRequests.GETMethodWithSingleQueryParam(endPoint,xApiKey,Key1,authCode);
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
    public void userPerformsWriteOn (int status, String writeOffType, String authCode){
        waitABit(60000);  // Adding wait as the Housekeeper requires 30-40 sec to change payment status
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subRef+"/packs/"+packRef+"/payments/"+paymentRef2+"/actions?"+"write_off_type="+writeOffType+"&"+"addNote=true";
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getWriteOffBody(writeOffType,authCode));
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
    public void userUpdatesPackStatus(String packStatus, int status) {
        logger.info(testDataManager.getTestInputCommonData("url.commonCDGURI") + "accounts/" + acc_reference + "/subscriptions/" + subRef + "/packs/");
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + "accounts/" + acc_reference + "/subscriptions/" + subRef + "/packs/" + packRef;
        apiRequests.PUTMethodWithXApiHeaders(endpoint, xApiKey, updatePackStatusToGiven(packStatus));
        final String expStatus = Integer.toString(status);
        logger.info(expStatus);
    }
    private Map<String, ?> updatePackStatusToGiven(String packStatus) {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("status", packStatus);
        requestSubscriptionBody.put("collected_in_store", false);
        return requestSubscriptionBody.toMap();
    }
    public void userGetsTheBalanceAmountForSubscription() {

        final String endPoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+ testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+"/balance";
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        balanceAmount = apiRequests.getValueFormJsonResponseKey("balance");
        logger.info("balanceAmount:"+balanceAmount);

    }
    public void performHolidayPackWhenPaymentCompleted(int status, String serviceCredit) {
        userGetsTheSubscriptionDetails(0);
         packRef = apiRequests.getValueFormJsonResponseKey("packs[0].id");
        packRef_2 = apiRequests.getValueFormJsonResponseKey("packs[1].id");
        paymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");
        paymentRef1 = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].id");
        final String holidayEndPoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + testDataManager.getTestInputCommonData("url.accountEndPointCDG") + "/" + acc_reference + "/subscriptions" + "/" + subscription_id + "/packs/" + packRef + "/holiday";
        apiRequests.PUTMethodWithXApiHeaders(holidayEndPoint, xApiKey, clspApiRequest.jsonDataForHolidayPack(serviceCredit));
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        String pack_id = apiRequests.getValueFormJsonResponseKey("[0].id");
        logger.info("Pack id is : " + pack_id);
        assertEquals(packRef, pack_id);

    }
    public void requestsToRefundPayment(int status, Boolean serviceCredit, String refundReason) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + testDataManager.getTestInputCommonData("url.accountEndPointCDG") + "/" + acc_reference + "/subscriptions" + "/" + subscription_id + "/packs/" + packRef + testDataManager.getTestInputCommonData("url.payments") + paymentRef1 + testDataManager.getTestInputCommonData("url.refundEndPoint");
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.jsonDataForRefundPayment(serviceCredit,grossAmount,refundReason));
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        String statusRefund = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].status");
        logger.info("Status :"+statusRefund);
        assertEquals("MaxRefunded", statusRefund);
    }
    public void unableToReinstatePack(int status, String packStatus, String paymentStatus) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+"/packs/"+packRef;
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.jsonDataForReinstatePack(packStatus));
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        assertEquals("409", apiRequests.getValueFormJsonResponseKey("code"));

        userGetsTheSubscriptionDetails(0);
        String pack_status = apiRequests.getValueFormJsonResponseKey("packs[0].status");
        logger.info("Pack status is : "+pack_status);
        assertEquals(paymentStatus, pack_status);
        logger.info("Payment status for 3rd payment : "+apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].status"));
        logger.info("Payment status for 4th payment : "+apiRequests.getValueFormJsonResponseKey("packs[0].payments[3].status"));
        assertEquals(apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].status"), paymentStatus);
        assertEquals(apiRequests.getValueFormJsonResponseKey("packs[0].payments[3].status"), paymentStatus);

    }
    public void userVerifiesPaymentStatusAfterGoodwillIsPerformed(String writeOffType) {

        final String PaymentStatus = apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].payment_method");
        logger.info("PaymentStatusFlag:"+PaymentStatus);
        assertTrue(PaymentStatus.equalsIgnoreCase(writeOffType));

    }
    public void userRequestsToTransferTheStore(int status,String customerID) {
        final String endPointHealth = testDataManager.getTestInputCommonData("url.commonCDGURI")+"/stores"+testDataManager.getTestInputRegionData("storeToStoreTransfer.number")+"/health";
        apiRequests.GETMethodWithXApiHeaders(endPointHealth,xApiKey);

        final String endPoint1= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.updateClientID");
        apiRequests.POSTMethodWithXApiHeaders(endPoint1,xApiKey,clspApiRequest.jsonDataForStoreTransfer(customerID));
        assertEquals(status, apiRequests.verifyResponseStatusCode());
        assertEquals((testDataManager.getTestInputRegionData("storeToStoreTransfer.number") + "-" +customerID), apiRequests.getValueFormJsonResponseKey("client_user_id"));

        performS2STAtSubscriptionLevel(status);
        userVerifiesStoreIDAtPackLevel(status);
    }

    public void performS2STAtSubscriptionLevel(int status){
        for (int i=0; i>=0;i++)
        {
            final String endPoint = testDataManager.getTestInputRegionData("url.commonCDGURI")+ testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions";
            apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
            Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
            try{
                if(apiRequests.getValueFormJsonResponseKey("subscriptions["+i+"].id").contains("null"))
                    break;
                else
                {
                    subscription_id=apiRequests.getValueFormJsonResponseKey("subscriptions["+i+"].id");
                    final String endPointTransfer= testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+testDataManager.getTestInputCommonData("url.storeTransfer");
                    apiRequests.PUTMethodWithXApiHeaders(endPointTransfer,xApiKey,clspApiRequest.jsonDataForStoreTransfer(customerID));
                    logger.info(subscription_id);
                }
            }catch(Exception e){
                logger.info("Maximum value reached");
                break;
            }
        }
    }

    public void userVerifiesStoreIDAtPackLevel(int status)
    {
        userGetsTheSubscriptionDetails(0);
        ResponseBody<?> body = response.getBody();
        String bodyStringValue = body.asString();
        JSONObject jsonOb = new JSONObject(bodyStringValue);
        JSONArray packs = jsonOb.getJSONArray("packs");
        for (int i=0; i<packs.length(); i++)
        {
            String packstatus = apiRequests.getValueFormJsonResponseKey("packs["+i+"].status");
            JSONObject object = packs.getJSONObject(i);
            JSONArray payments = object.getJSONArray("payments");
            for (int j=0; j<payments.length(); j++)
            {
                final String paymentStatusJson = apiRequests.getValueFormJsonResponseKey("packs["+i+"].payments["+j+"].status");
                if(paymentStatusJson.equalsIgnoreCase("Completed") || packstatus.equalsIgnoreCase("Dispatched") || packstatus.equalsIgnoreCase("Processing") || packstatus.equalsIgnoreCase("Cancelled"))
                    assertEquals(testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"), apiRequests.getValueFormJsonResponseKey("packs[" + i + "].store_id"));
                else
                    assertEquals(testDataManager.getTestInputRegionData("storeToStoreTransfer.mpp_store_id"), apiRequests.getValueFormJsonResponseKey("packs[" + i + "].payments[" + j + "].store_id"));
            }
        }
    }
    public void userRequestsToTransferTheInvalidStore() {

        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Subscription account not found";
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }
    public void requestsToReplacePack(int status) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+testDataManager.getTestInputCommonData("url.PacksEndPoint")+packRef+testDataManager.getTestInputCommonData("url.replace");
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.jsonDataForReplacePack(add_id));
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        logger.info(apiRequests.getValueFormJsonResponseKey("[0].id"));
        assertTrue(apiRequests.getValueFormJsonResponseKey("[0].id").equalsIgnoreCase(userMustBeAbleToGetLifecycleState("ONE_OFF","Replacement")));
    }
    public void userRequestsToAssertErrorMessage() {

        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Pack for subscription and account is not eligible for given order type";
        System.out.println("Expected error message is : "+expectedErrorMessage);
        System.out.println("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
        String actualCode = apiRequests.getValueFormJsonResponseKey("code");
        String expectedCode = "500";
        assertEquals(actualCode, expectedCode);
    }
    public void requestsToExpeditePackWithPastDeliveryDate(int status) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+"/packs/"+packRef+"/expedite";
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.jsonDataForExpeditePackWithPastDeliveryDate());
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Pack Id for subscription and account is not eligible to be expedited";
        System.out.println("Expected error message is : "+expectedErrorMessage);
        System.out.println("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
        String actualErrorCode = apiRequests.getValueFormJsonResponseKey("code");
        assertEquals("500", actualErrorCode);

    }
    public void userCreatesSubscriptionOnCDGWithPastFirstPaymentDate(int status, String firstPack) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+ testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions";
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getSubscriptionBodyWithPastFirstPaymentDate(firstPack,add_id,acc_reference,cart_id));
        assertEquals(status, apiRequests.verifyResponseStatusCode());
        final String actualCode = apiRequests.getValueFormJsonResponseKey("code");
        final String expectedCode = "404";
        assertEquals(actualCode,expectedCode);
    }
    public void userCreatesSubscriptionOnCDGWithPastFirstDispatchDate(int status, String firstPack) {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+ testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions";
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getSubscriptionBodyWithPastFirstDispatchDate(firstPack,add_id,acc_reference,cart_id));
        assertEquals(status, apiRequests.verifyResponseStatusCode());
        final String actualCode = apiRequests.getValueFormJsonResponseKey("code");
        final String expectedCode = "404";
        assertEquals(actualCode,expectedCode);
    }

    public void userAddAddressWithInvalidAccReference(String accReference, int expectedStatus){

        apiRequests.POSTMethodWithXApiHeaders(testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts"+"/"+accReference+"/addresses",xApiKey,clspApiRequest.getCustomerJsonBodyForAddAddressToCustomer());
        assertEquals(apiRequests.verifyResponseStatusCode(), expectedStatus);
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedErrorMessage = "404";
        assertEquals(actualErrorMessage,expectedErrorMessage);

    }
    public void userRequestsToUpdatePaymentwithPastDeliveryDate(int status){
        System.out.println(testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+testDataManager.getTestInputRegionData("url.PacksEndPoint")+packRef);
        String endpoint=testDataManager.getTestInputRegionData("url.commonCDGURI")+testDataManager.getTestInputRegionData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+"/"+subscription_id+testDataManager.getTestInputRegionData("url.PacksEndPoint")+packRef;
        apiRequests.PUTMethodWithXApiHeaders(endpoint, xApiKey, jsonDataForUpdatingPayentwithPastDeliveryDate());

        //assertEquals(status, customApiRequests.verifyResponseStatusCode());
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Bad Request";
        System.out.println("Expected error message is : "+expectedErrorMessage);
        System.out.println("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage,expectedErrorMessage);

    }

    private Map<String, ?> jsonDataForUpdatingPayentwithPastDeliveryDate() {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("payment_date",testDataManager.getTestInputRegionData("pastDeliveryDate.payment_date"));
        jsonBody.put("apply_all_future_payments",testDataManager.getTestInputRegionData("pastDeliveryDate.apply_all_future_payments"));
        return jsonBody.toMap();
    }
}
