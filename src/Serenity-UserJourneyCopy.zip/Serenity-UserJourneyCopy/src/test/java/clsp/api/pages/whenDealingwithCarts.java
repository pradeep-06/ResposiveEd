package clsp.api.pages;

import Framework.api.request.APIRequests;
import Framework.api.request.Headers;
import clsp.api.extentions.clspApiBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class whenDealingwithCarts extends clspApiBase {

    private final Logger logger = LoggerFactory.getLogger(whenDealingwithCarts.class);
    public clspApiBase clspApiRequest = new clspApiBase();
    public APIRequests apiRequests = new APIRequests();
    private static final Headers header = new Headers();
    public static String cart_id;

    public static String custType="Test";
    public String xApiKey=testDataManager.getTestInputCommonData("url.apiKeyCDG");
    public String xClientId=testDataManager.getTestInputCommonData("mppHeaders.clientId");
    public String xClientPassword=testDataManager.getTestInputCommonData("mppHeaders.clientPassword");
    public String xVersion=testDataManager.getTestInputCommonData("mppHeaders.versionNumber");

    public void userCreatesCart(String solutionType, int status) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+whenDealingwithSubscription.acc_reference+"/"+testDataManager.getTestInputCommonData("url.cartEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getMonthlyCartJsonBodyCDG(solutionType,custType));
        cart_id = apiRequests.getValueFormJsonResponseKey("id");
    }
    public void userPerformsGetCart(int status){
        final String endpoint=testDataManager.getTestInputCommonData("url.commonCDGURI")+ testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+ whenDealingwithSubscription.acc_reference+"/"+cart_id;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);

        assertTrue(apiRequests.getValueFormJsonResponseKey("id").equalsIgnoreCase(cart_id));
        assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
    public void userRequestsForGetCart(int status){
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"carts/"+cart_id;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertTrue(apiRequests.getValueFormJsonResponseKey("id").equalsIgnoreCase(cart_id));
        assertEquals(status, apiRequests.verifyResponseStatusCode());
        }
    public void requestsToChangeTheCartOfAnAccount(int status, String acc_reference, String subscription_id) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions/"+subscription_id+"/change";
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.jsonDataForCartToChange(cart_id));
        assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
    public void verifyChangeUsageWhenOnePaymentCompleted(String changeUsageAmount,String changeAmount)
    {
        /*final String cartId = apiRequests.getValueFormJsonResponseKey("packs[0].cart_id");
        logger.info("Cart id is : "+cartId);
        logger.info("New Cart id is : "+cart_id);
        assertTrue(!cart_id.equals(cartId));*/
        logger.info("beforeChangeUsageAmt : "+changeUsageAmount);
        logger.info("afterChangeUsageAmt : "+changeAmount);
        assertNotEquals(changeUsageAmount, changeAmount);
    }
    //user requests to apply invalid promotion on the cart
    public void requestsToApplyInvalidPromotionOnTheCart(int status, String storeId,String voucher,String authCode) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.cartEndPoint")+"/"+cart_id+testDataManager.getTestInputCommonData("url.voucherEndPoint")+"/"+voucher+"?"+testDataManager.getTestInputCommonData("url.StoreIdEndpoint")+storeId+"&"+testDataManager.getTestInputCommonData("url.authCodeEndPoint")+authCode;
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey);
        assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
    public void requestToValidateThatInvalidPromotionOnCart(int status,String storeId,String voucher,String authCode) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.cartEndPoint")+"/"+cart_id+testDataManager.getTestInputCommonData("url.voucherEndPoint")+"/"+voucher+"?"+testDataManager.getTestInputCommonData("url.StoreIdEndpoint")+storeId+"&"+testDataManager.getTestInputCommonData("url.authCodeEndPoint")+authCode;
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
}
