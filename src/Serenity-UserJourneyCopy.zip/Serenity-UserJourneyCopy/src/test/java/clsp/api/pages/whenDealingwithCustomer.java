package clsp.api.pages;

import Framework.api.request.APIRequests;
import Framework.extensions.StafUtils;
import clsp.api.extentions.clspApiBase;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class whenDealingwithCustomer extends clspApiBase {

    private final Logger logger = LoggerFactory.getLogger(whenDealingwithCustomer.class);
    public clspApiBase clspApiRequest = new clspApiBase();
    public APIRequests apiRequests = new APIRequests();
    public whenDealingwithCarts whenDealingwithCarts = new whenDealingwithCarts();

    public String xApiKey=testDataManager.getTestInputCommonData("url.apiKeyCDG");

    public String xClientId=testDataManager.getTestInputCommonData("mppHeaders.clientId");
    public String xClientPassword=testDataManager.getTestInputCommonData("mppHeaders.clientPassword");
    public String xVersion=testDataManager.getTestInputCommonData("mppHeaders.versionNumber");


    public static String client_user_id = "4"+getNewUserID();
    public static String accountReference;
    private Response response;
    public static String add_id;
    public static String  left_style_no;
    public static String right_style_no;
    public static String firstName = StafUtils.getFirstName(6);
    public String emailID = StafUtils.generateNewCustomerEmail("");
    public static String lastName = "AutoTest";


    public Map<String, ?> getAPIMocKHeaders () {
        Map<String, String> headers = new HashMap<>();

        headers.put("x-api-key", testDataManager.getTestInputCommonData("mppHeaders.xApiKey"));
        return headers;
    }
    public Map<String, ?> getHeadersForRemoveCust () {
        Map<String, String> headers = new HashMap<>();

        headers.put("X-ClientId", testDataManager.getTestInputCommonData("mppHeaders.clientId"));
        headers.put("X-ClientPassword", testDataManager.getTestInputCommonData("mppHeaders.clientPassword"));
        headers.put("x-version", testDataManager.getTestInputCommonData("mppHeaders.versionNumber"));

        headers.put("Origin", testDataManager.getTestInputCommonData("mppHeaders.Origin"));
        headers.put("x-tokenId", testDataManager.getTestInputCommonData("mppHeaders.x-tokenId"));

        //    headers.put("x-api-key", getapiKeyCDG());
        return headers;
    }
    // Generate User ID
    public String getUserID() {

        long varTime = System.nanoTime();

        double randomMath = Math.random() * 1000;

        long multi = (long) (varTime * randomMath);

        String s = multi + "";
        String subStr = s.substring(0, 5);

        int finalNum = Integer.parseInt(subStr);

        return subStr;
    }



    // Example - On demand GET request

    public void requestCustomerWithCustomerId(String accountReference) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+"/"+accountReference;
        apiRequests.GETMethodWithSpecificHeaders(endpoint,getMPPHeaders());
    }

    // On demand GET request for Notes
    public void requestForTheNotesThatHasBeenCreated()
    {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+accountReference+testDataManager.getTestInputRegionData("url.LogNotesfinal String endpoint")+"?"+testDataManager.getTestInputRegionData("url.Notesfinal String endpoint");
        apiRequests.GETMethodWithSpecificHeaders(endpoint,getMPPHeaders());
    }

    public void verifyNotesStatus(String status) {
        String notesStatus = apiRequests.getValueFormJsonResponseKey("logStatus");
        assertNotEquals(notesStatus, status);
    }

    private Map<String, ?> getRequestLogNotesBody(String logType, String logStatus, String logTitle, String logDetails)
    {
        JSONObject requestNotesBody = new JSONObject();
        requestNotesBody.put("logType", logType);
        requestNotesBody.put("logStatus", logStatus );
        requestNotesBody.put("logTitle", logTitle );
        requestNotesBody.put("logDetails", logDetails );
        logger.info("Request Jason"+requestNotesBody);
        return requestNotesBody.toMap();
    }

    private Map<String, ?> getRequestPaymentBody(String accountHolderName, String iban, String bic) {
        JSONObject requestPaymentBody = new JSONObject();
        requestPaymentBody.put("accountHolderName", accountHolderName);
        requestPaymentBody.put("iban", iban);
        requestPaymentBody.put("bic", bic);
       logger.info("Request Jason"+requestPaymentBody);
        return requestPaymentBody.toMap();
    }

    public void getNewlyCreatedCustomer(int status) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+"/" + accountReference;
        apiRequests.GETMethodWithSpecificHeaders(endpoint,getMPPHeaders());
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }
    public void userRetrievesCustomerData(int status){
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+whenDealingwithSubscription.acc_reference;
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        assertEquals(status, apiRequests.verifyResponseStatusCode());
        add_id = apiRequests.getValueFormJsonResponseKey("customer_contact_details.default_address.id");

    }




    // Example - On demand POST request to find customer using Account number
    public void userSearchesForCustomerUsingAccountID(int status,String customerID){
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+testDataManager.getTestInputCommonData("url.searchCustomer")+"/"+testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }

    // Search customer using Matching Criteria
    public void userSearchesCustomerMatchingCriteria(int status,String customerID){
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+testDataManager.getTestInputCommonData("url.searchCustomer")+"/"+testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID+testDataManager.getTestInputCommonData("url.searchAccount");
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);

    }

    public void userAddsAddress(int status,String acc_reference){
        apiRequests.POSTMethodWithXApiHeaders(testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts"+"/"+acc_reference+"/addresses",xApiKey,clspApiRequest.getCustomerJsonBodyForAddAddressToCustomer());
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        add_id =  apiRequests.getValueFormJsonResponseKey("address.id");
       logger.info("The address ID is:"+add_id);
    }

    // GET METHOD - Verify Payment Method for user
    public void userVerifiesPaymentDetails(int status, String acc_reference){
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.paymentEndPoint");
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);

    }

    //user retrieves customer CLFIT data
    public void retrievesCustomerCLFITData(String countryCode,String storeId,String accountId,String tdr,String clfit) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.storeEndpoint")+"/"+storeId+testDataManager.getTestInputCommonData("url.SocratesCustomerEndpoint")+"/customers/"+accountId+testDataManager.getTestInputCommonData("url.clfit")+testDataManager.getTestInputCommonData("url.TdrEndpoint")+tdr+testDataManager.getTestInputCommonData("url.clFitNumberEndpoint")+clfit;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);

        final String store_id = apiRequests.getValueFormJsonResponseKey("clfit.store_id");
        final String tdrNo = apiRequests.getValueFormJsonResponseKey("clfit.tdr_no");
        final String custId = apiRequests.getValueFormJsonResponseKey("clfit.customer_id");
        final String leftLens = apiRequests.getValueFormJsonResponseKey("clfit.left_lens_name");
        final String rightLens = apiRequests.getValueFormJsonResponseKey("clfit.right_lens_name");
        final String leftLensSupplier = apiRequests.getValueFormJsonResponseKey("clfit.left_lens_supplier");
        final String rightLensSupplier = apiRequests.getValueFormJsonResponseKey("clfit.right_lens_supplier");
        left_style_no = apiRequests.getValueFormJsonResponseKey("clfit.left_style_no");
        right_style_no = apiRequests.getValueFormJsonResponseKey("clfit.right_style_no");

        logger.info("Store id is "+store_id);
        logger.info("tdr number is "+tdrNo);
        logger.info("Customer id is "+custId);
        logger.info("Left lens is "+leftLens);
        logger.info("Right lens is "+rightLens);
        logger.info("Left lens supplier is "+leftLensSupplier);
        logger.info("Right lens supplier is "+rightLensSupplier);
        assertEquals(store_id, testDataManager.getTestInputRegionData("CLFITData.store_id"));
        assertEquals(tdrNo, testDataManager.getTestInputRegionData("CLFITData.tdrNo"));
        assertEquals(custId, testDataManager.getTestInputRegionData("CLFITData.custId"));
        assertEquals(leftLens, testDataManager.getTestInputRegionData("CLFITData.leftLens"));
        assertEquals(rightLens, testDataManager.getTestInputRegionData("CLFITData.rightLens"));
        assertEquals(leftLensSupplier, testDataManager.getTestInputRegionData("CLFITData.leftLensSupplier"));
        assertEquals(rightLensSupplier, testDataManager.getTestInputRegionData("CLFITData.rightLensSupplier"));
    }

    //user request to validate that promotion on cart of account
    public void requestToValidateThatPromotionOnCartOfAccount(int status,String storeId) {
        String authCode = testDataManager.getTestInputRegionData("promotion.authCode");
        String voucher = testDataManager.getTestInputRegionData("promotion.voucher");
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+"/"+accountReference+testDataManager.getTestInputRegionData("url.Cartfinal String endpoint")+"/"+whenDealingwithCarts.cart_id+testDataManager.getTestInputRegionData("url.Voucherfinal String endpoint")+"/"+voucher+"?"+testDataManager.getTestInputRegionData("url.StoreIdfinal String endpoint")+storeId+testDataManager.getTestInputRegionData("url.Authcodefinal String endpoint")+authCode;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String cartId = apiRequests.getValueFormJsonResponseKey("id");
      logger.info("cart id is : "+cartId);
        assertEquals(whenDealingwithCarts.cart_id, cartId);
    }

    public void requestToUpdateCustomer(int status,String accountReference, String customerID, String email, String account_id, String paymentType) {
        apiRequests.PUTMethodWithXApiHeaders(testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+accountReference+testDataManager.getTestInputCommonData("url.socrates_sync_flag")+"true",xApiKey,clspApiRequest.getUpdateCustomerJsonBodyCDG(accountReference,add_id,firstName,lastName,customerID,email,account_id,paymentType));
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        final String customerId = apiRequests.getValueFormJsonResponseKey("customer_id");
        assertEquals(customerId, accountReference);
    }



    public void userRequestForNewCustomerOnCDGUsingExistingClientUserId(String clientUserId,int status) {
        apiRequests.POSTMethodWithXApiHeaders(testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG"),xApiKey,getCustomerJsonBodyCDGNegativeClientUserId(client_user_id));
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Account with that ClientUserId already exists";
       logger.info("Expected error message is : "+expectedErrorMessage);
      logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }

    public Map<String, ?> getCustomerJsonBodyCDGNegativeClientUserId(String clientUserId){


        JSONObject jsonBody = new JSONObject();

        JSONObject custJsonObj = new JSONObject();
        //custJsonObj.put("client_user_id",testObj.getTestData("createCustomer").get("store_id")+"-"+clientUserId);
        custJsonObj.put("client_user_id",client_user_id);
        custJsonObj.put("title",testDataManager.getTestInputCommonData("login.salutation"));
        custJsonObj.put("first_name",firstName);
        custJsonObj.put("last_name",lastName);
        custJsonObj.put("error",testDataManager.getTestInputRegionData("createCustomer.error"));
        custJsonObj.put("gender",testDataManager.getTestInputRegionData("createCustomer.gender"));
        custJsonObj.put("mpp_store_id",testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));


        JSONObject accJsonObj = new JSONObject();
        JSONObject accValueJsonObj = new JSONObject();
        accJsonObj.put("value", accValueJsonObj);
        custJsonObj.put("account",accJsonObj);

        JSONArray addArrayElement = new JSONArray();
        custJsonObj.put("address_book",addArrayElement);

        JSONObject contactJsonObj = new JSONObject();
        contactJsonObj.put("email", emailID);
        JSONObject defAddJsonObj = new JSONObject();
        defAddJsonObj.put("street", testDataManager.getTestInputRegionData("createCustomer.street"));
        defAddJsonObj.put("is_default", testDataManager.getTestInputRegionData("createCustomer.is_default"));
        defAddJsonObj.put("address_type", testDataManager.getTestInputRegionData("createCustomer.address_type"));
        contactJsonObj.put("default_address", defAddJsonObj);
        custJsonObj.put("customer_contact_details",contactJsonObj);

        custJsonObj.put("date_of_birth", testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONArray entitleArrayElement = new JSONArray();
        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierFree"));
        freeglasJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
        freeglasJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateFree"));
        freeglasJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusFree"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierSpare"));
        spareLenseJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameSpare"));
        spareLenseJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateSpare"));
        spareLenseJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusSpare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierAftercare"));
        afterCareJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameAftercare"));
        afterCareJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateAftercare"));
        afterCareJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusAftercare"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierSun"));
        subglassJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameSun"));
        subglassJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateSun"));
        subglassJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusSun"));
        entitleArrayElement.put(subglassJsonObj);

        custJsonObj.put("entitlements",entitleArrayElement);

        JSONArray notesArrayElement = new JSONArray();
        custJsonObj.put("notes",notesArrayElement);

        // 	    	JSONArray paymentArrayElement = new JSONArray();
        // 	    	custJsonObj.put("payment_methods",paymentArrayElement);

        custJsonObj.put("payment_method_type", testDataManager.getTestInputRegionData("createCustomer.payment_method_type"));

        jsonBody.put("customer",custJsonObj);
        jsonBody.put("store_id", testDataManager.getTestInputRegionData("createCustomer.store_id"));
        return jsonBody.toMap();

    }

    public Map<String, ?> getCustomerJsonBodyCDGNegativeMail(String mailId){
        client_user_id = getUserID();
        JSONObject jsonBody = new JSONObject();

        JSONObject custJsonObj = new JSONObject();
        //custJsonObj.put("client_user_id",testObj.getTestData("createCustomer").get("store_id")+"-"+client_user_id);
        custJsonObj.put("client_user_id",client_user_id);
        custJsonObj.put("title",testDataManager.getTestInputCommonData("login.salutation"));
        custJsonObj.put("first_name",firstName);
        custJsonObj.put("last_name",lastName);
        custJsonObj.put("error","");
        custJsonObj.put("gender","Male");
        custJsonObj.put("mpp_store_id",testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));


        JSONObject accJsonObj = new JSONObject();
        JSONObject accValueJsonObj = new JSONObject();
        accJsonObj.put("value", accValueJsonObj);
        custJsonObj.put("account",accJsonObj);

        JSONArray addArrayElement = new JSONArray();
        custJsonObj.put("address_book",addArrayElement);

        JSONObject contactJsonObj = new JSONObject();
        contactJsonObj.put("email", emailID);
        JSONObject defAddJsonObj = new JSONObject();
        defAddJsonObj.put("street", testDataManager.getTestInputRegionData("createCustomer.street"));
        defAddJsonObj.put("is_default", testDataManager.getTestInputRegionData("createCustomer.is_default"));
        defAddJsonObj.put("address_type", testDataManager.getTestInputRegionData("createCustomer.address_type"));
        contactJsonObj.put("default_address", defAddJsonObj);
        custJsonObj.put("customer_contact_details",contactJsonObj);

        custJsonObj.put("date_of_birth", testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONArray entitleArrayElement = new JSONArray();
        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierFree"));
        freeglasJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
        freeglasJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateFree"));
        freeglasJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusFree"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierSpare"));
        spareLenseJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameSpare"));
        spareLenseJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateSpare"));
        spareLenseJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusSpare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierAftercare"));
        afterCareJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameAftercare"));
        afterCareJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateAftercare"));
        afterCareJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusAftercare"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierSun"));
        subglassJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameSun"));
        subglassJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateSun"));
        subglassJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusSun"));
        entitleArrayElement.put(subglassJsonObj);

        custJsonObj.put("entitlements",entitleArrayElement);

        JSONArray notesArrayElement = new JSONArray();
        custJsonObj.put("notes",notesArrayElement);

        //	    	JSONArray paymentArrayElement = new JSONArray();
        //	    	custJsonObj.put("payment_methods",paymentArrayElement);

        custJsonObj.put("payment_method_type", testDataManager.getTestInputRegionData("createCustomer.payment_method_type"));

        jsonBody.put("customer",custJsonObj);
        jsonBody.put("store_id", testDataManager.getTestInputRegionData("createCustomer.store_id"));
        return jsonBody.toMap();

    }

    public void userSearchesCustomerWithInvalidCustomerId(String customerId,int status) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+testDataManager.getTestInputCommonData("url.searchCustomer")+customerId;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String totalResults = apiRequests.getValueFormJsonResponseKey("total_results");
      logger.info("Count for total result is : "+totalResults);
        assertEquals("0", totalResults);
    }

    public void userSearchesMatchingCriteriaWithInvalidCustomerId(String customerId,int status){
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+testDataManager.getTestInputCommonData("url.searchCustomer")+customerId+testDataManager.getTestInputCommonData("url.searchAcount");
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String totalResults = apiRequests.getValueFormJsonResponseKey("total_results");
        logger.info("Count for total result is : "+totalResults);
        assertEquals("0", totalResults);
    }

    public void userRetrievesCustomerDataWithInvalidAccountReference(String accountReference,int newStatus){
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+accountReference;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), newStatus);
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedErrorMessage = "404";
      logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }

    private Map<String, ?> getpaymentBodyWithInvalidIBAN(String iban){
        JSONObject paymentJSONBody = new JSONObject();
        JSONObject sepaJSONBody = new JSONObject();
        sepaJSONBody.put("account_holder_name",firstName);
        sepaJSONBody.put("bic",testDataManager.getTestInputRegionData("sepa.bic"));
        sepaJSONBody.put("iban",iban );
        paymentJSONBody.put("sepa", sepaJSONBody);
        return paymentJSONBody.toMap();
    }

    public void requestsCustomerCLFITData(String countryCode,String storeId,String accountId,String tdr,String clfit) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.product")+testDataManager.getTestInputCommonData("url.clfitfinal String endpoint")+testDataManager.getTestInputCommonData("url.storefinal String endpoint")+storeId+testDataManager.getTestInputCommonData("url.customerfinal String endpoint")+accountId+"&"+testDataManager.getTestInputCommonData("url.tdrfinal String endpoint")+tdr+testDataManager.getTestInputCommonData("url.clfitNumberfinal String endpoint")+clfit+"&"+testDataManager.getTestInputCommonData("url.countryCodefinal String endpoint")+countryCode;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
    }

    public void validateResponseAndStatusCodeIs(int status) {
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String actualCodeMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedCodeMessage = "504";
        assertEquals(actualCodeMessage, expectedCodeMessage);
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Gateway Timeout"; //need to update message
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }

    public void validateResponseAndStatusCodeForInvalidStore(int status, int invalidStoreId) {
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Store not found: "+invalidStoreId;
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
        String actualCodeMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedCodeMessage = "404";
        assertEquals(actualCodeMessage, expectedCodeMessage);

    }

    public void requestingToGetCustomerWithCLFITData(String countryCode,String storeId,String accountId,String tdr,String clfit) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.storefinal String endpoint")+"/"+storeId+testDataManager.getTestInputCommonData("url.socratesCustomerfinal String endpoint")+accountId+testDataManager.getTestInputCommonData("url.clfit")+testDataManager.getTestInputCommonData("url.tdrfinal String endpoint")+tdr+testDataManager.getTestInputCommonData("url.clfitNumberfinal String endpoint")+clfit;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
    }

    public void validateResponseAndStatusCodeForCLFIT(int status) {
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Customer not found";
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }

    public void requestToValidateThatInvalidPromotionOnCartOfAccount(int status,String authCode,String voucher,String storeId) {
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+"/"+accountReference+testDataManager.getTestInputCommonData("url.cartfinal String endpoint")+"/"+whenDealingwithCarts.cart_id+testDataManager.getTestInputCommonData("url.voucherfinal String endpoint")+"/"+voucher+"?"+testDataManager.getTestInputCommonData("url.storeIdfinal String endpoint")+storeId+testDataManager.getTestInputCommonData("url.authcodefinal String endpoint")+authCode;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }


    private Map<String, ?> updateAddressBody(){
        JSONObject updateAddress = new JSONObject();
        JSONObject addressBookJson = new JSONObject();
        addressBookJson.put("id",add_id);
        addressBookJson.put("country",testDataManager.getTestInputRegionData("updateAddress.country"));
        addressBookJson.put("county",testDataManager.getTestInputRegionData("updateAddress.county") );
        addressBookJson.put("town_city", testDataManager.getTestInputRegionData("updateAddress.town_city"));
        addressBookJson.put("district",testDataManager.getTestInputRegionData("updateAddress.district"));
        addressBookJson.put("state",testDataManager.getTestInputRegionData("updateAddress.state"));
        addressBookJson.put("house_flat_number",testDataManager.getTestInputRegionData("updateAddress.house_flat_number"));
        addressBookJson.put("house_name",testDataManager.getTestInputRegionData("updateAddress.house_name"));
        addressBookJson.put("street",testDataManager.getTestInputRegionData("updateAddress.street"));
        addressBookJson.put("postcode",testDataManager.getTestInputRegionData("updateAddress.postcode"));
        addressBookJson.put("is_default",testDataManager.getTestInputRegionData("updateAddress.is_default"));
        JSONArray addressBookElement = new JSONArray();
        addressBookElement.put(addressBookJson);
        JSONObject customerJson = new JSONObject();
        customerJson.put("client_user_id",client_user_id);
        customerJson.put("address_book",addressBookElement);
        updateAddress.put("customer", customerJson);
        return updateAddress.toMap();
    }

    public Map<String, ?> getUpdateCustomerJsonBodyCDGUsingExistingClientUserId(String clientUserId) {
        JSONObject jsonBody = new JSONObject();

        JSONObject custJsonObj = new JSONObject();

        custJsonObj.put("mpp_store_id",testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));
        custJsonObj.put("client_user_id",clientUserId);
        custJsonObj.put("care_alert",testDataManager.getTestInputRegionData("updateCustomer.care_alert"));
        custJsonObj.put("debt_alert",testDataManager.getTestInputRegionData("updateCustomer.debt_alert"));
        custJsonObj.put("note_alert",testDataManager.getTestInputRegionData("updateCustomer.note_alert"));
        custJsonObj.put("gender",testDataManager.getTestInputRegionData("createCustomer.gender"));
        custJsonObj.put("payment_method_type",testDataManager.getTestInputRegionData("createCustomer.payment_method_type"));
        custJsonObj.put("customer_id",accountReference);
        custJsonObj.put("title",testDataManager.getTestInputRegionData("createCustomer.title"));
        custJsonObj.put("first_name",firstName);
        custJsonObj.put("last_name",lastName);
        custJsonObj.put("date_of_birth",testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONObject accJsonObj = new JSONObject();
        //     accJsonObj.put("account_id",account_id);
        accJsonObj.put("resource_reference",accountReference);
        accJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.custStatus"));

        JSONObject accValueJsonObj = new JSONObject();

        JSONArray customerValueArrayElement = new JSONArray();
        JSONObject customerValue = new JSONObject();
        customerValue.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        customerValue.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        customerValueArrayElement.put(customerValue);
        accValueJsonObj.put("total_customer_value", customerValueArrayElement);

        JSONArray totalPaymentToDateArrayElement = new JSONArray();
        JSONObject totalPaymentToDate = new JSONObject();
        totalPaymentToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        totalPaymentToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        totalPaymentToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        totalPaymentToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        totalPaymentToDateArrayElement.put(totalPaymentToDate);
        accValueJsonObj.put("total_payments_to_date", totalPaymentToDateArrayElement);

        JSONArray totalRefundToDateArrayElement = new JSONArray();
        JSONObject totalRefundToDate = new JSONObject();
        totalRefundToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        totalRefundToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        totalRefundToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        totalRefundToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        totalRefundToDateArrayElement.put(totalRefundToDate);
        accValueJsonObj.put("total_refunds_to_date", totalRefundToDateArrayElement);

        JSONArray outstandingPaymentsToDateArrayElement = new JSONArray();
        JSONObject outstandingPaymentsToDate = new JSONObject();
        outstandingPaymentsToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        outstandingPaymentsToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        outstandingPaymentsToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        outstandingPaymentsToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        outstandingPaymentsToDateArrayElement.put(outstandingPaymentsToDate);
        accValueJsonObj.put("outstanding_payments_to_date", outstandingPaymentsToDateArrayElement);

        JSONArray outstandingCreditBalanceArrayElement = new JSONArray();
        JSONObject outstandingCreditBalance = new JSONObject();
        outstandingCreditBalance.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        outstandingCreditBalance.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        outstandingCreditBalanceArrayElement.put(outstandingCreditBalance);
        accValueJsonObj.put("outstanding_credit_balance", outstandingCreditBalanceArrayElement);

        JSONObject customerContactDeatils = new JSONObject();
        customerContactDeatils.put("email",emailID);

        JSONObject defaultAddress = new JSONObject();
        defaultAddress.put("id",add_id);
        defaultAddress.put("country",testDataManager.getTestInputRegionData("updateCustomer.country"));
        defaultAddress.put("county",testDataManager.getTestInputRegionData("updateCustomer.county"));
        defaultAddress.put("town_city",testDataManager.getTestInputRegionData("updateCustomer.town_city"));
        defaultAddress.put("district",testDataManager.getTestInputRegionData("updateCustomer.district"));
        defaultAddress.put("state",testDataManager.getTestInputRegionData("updateCustomer.state"));
        defaultAddress.put("house_flat_number",testDataManager.getTestInputRegionData("updateCustomer.house_flat_number"));
        defaultAddress.put("house_name",testDataManager.getTestInputRegionData("updateCustomer.house_name"));
        defaultAddress.put("street",testDataManager.getTestInputRegionData("updateCustomer.street"));
        defaultAddress.put("postcode",testDataManager.getTestInputRegionData("updateCustomer.postcode"));
        defaultAddress.put("is_default",testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        customerContactDeatils.put("default_address",defaultAddress);

        JSONArray addressBookArrayElement = new JSONArray();
        JSONObject addressBook = new JSONObject();
        addressBook.put("id",add_id);
        addressBook.put("country",testDataManager.getTestInputRegionData("updateCustomer.country"));
        addressBook.put("county",testDataManager.getTestInputRegionData("updateCustomer.county"));
        addressBook.put("town_city",testDataManager.getTestInputRegionData("updateCustomer.town_city"));
        addressBook.put("district",testDataManager.getTestInputRegionData("updateCustomer.district"));
        addressBook.put("state",testDataManager.getTestInputRegionData("updateCustomer.state"));
        addressBook.put("house_flat_number",testDataManager.getTestInputRegionData("updateCustomer.house_flat_number"));
        addressBook.put("house_name",testDataManager.getTestInputRegionData("updateCustomer.house_name"));
        addressBook.put("street",testDataManager.getTestInputRegionData("updateCustomer.street"));
        addressBook.put("postcode",testDataManager.getTestInputRegionData("updateCustomer.postcode"));
        addressBook.put("is_default",testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        addressBookArrayElement.put(addressBook);

        JSONArray entitleArrayElement = new JSONArray();

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Sun"));
        subglassJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Sun"));
        subglassJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Sun"));
        subglassJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Sun"));
        subglassJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Sun"));
        entitleArrayElement.put(subglassJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Spare"));
        spareLenseJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Spare"));
        spareLenseJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Spare"));
        spareLenseJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Spare"));
        spareLenseJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Spare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_After"));
        afterCareJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_After"));
        afterCareJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_After"));
        afterCareJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_After"));
        afterCareJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_After"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Free"));
        freeglasJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Free"));
        freeglasJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Free"));
        freeglasJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Free"));
        freeglasJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Free"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONObject value = new JSONObject();

        custJsonObj.put("entitlements",entitleArrayElement);
        custJsonObj.put("address_book",addressBookArrayElement);
        custJsonObj.put("customer_contact_details",customerContactDeatils);
        accJsonObj.put("value", accValueJsonObj);
        custJsonObj.put("account", accJsonObj);
        jsonBody.put("customer", custJsonObj);

        return jsonBody.toMap();

    }

    public Map<String, ?> getUpdateCustomerJsonBodyCDGUsingExistingEmail(String email) {
        JSONObject jsonBody = new JSONObject();

        JSONObject custJsonObj = new JSONObject();

        custJsonObj.put("mpp_store_id",testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));
        custJsonObj.put("client_user_id",client_user_id);
        custJsonObj.put("care_alert",testDataManager.getTestInputRegionData("updateCustomer.care_alert"));
        custJsonObj.put("debt_alert",testDataManager.getTestInputRegionData("updateCustomer.debt_alert"));
        custJsonObj.put("note_alert",testDataManager.getTestInputRegionData("updateCustomer.note_alert"));
        custJsonObj.put("gender",testDataManager.getTestInputRegionData("createCustomer.gender"));
        custJsonObj.put("payment_method_type",testDataManager.getTestInputRegionData("createCustomer.payment_method_type"));
        custJsonObj.put("customer_id",accountReference);
        custJsonObj.put("title",testDataManager.getTestInputRegionData("createCustomer.title"));
        custJsonObj.put("first_name",firstName);
        custJsonObj.put("last_name",lastName);
        custJsonObj.put("date_of_birth",testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONObject accJsonObj = new JSONObject();
        accJsonObj.put("resource_reference",accountReference);
        accJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.custStatus"));

        JSONObject accValueJsonObj = new JSONObject();

        JSONArray customerValueArrayElement = new JSONArray();
        JSONObject customerValue = new JSONObject();
        customerValue.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        customerValue.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        customerValueArrayElement.put(customerValue);
        accValueJsonObj.put("total_customer_value", customerValueArrayElement);

        JSONArray totalPaymentToDateArrayElement = new JSONArray();
        JSONObject totalPaymentToDate = new JSONObject();
        totalPaymentToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        totalPaymentToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        totalPaymentToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        totalPaymentToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        totalPaymentToDateArrayElement.put(totalPaymentToDate);
        accValueJsonObj.put("total_payments_to_date", totalPaymentToDateArrayElement);

        JSONArray totalRefundToDateArrayElement = new JSONArray();
        JSONObject totalRefundToDate = new JSONObject();
        totalRefundToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        totalRefundToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        totalRefundToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        totalRefundToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        totalRefundToDateArrayElement.put(totalRefundToDate);
        accValueJsonObj.put("total_refunds_to_date", totalRefundToDateArrayElement);

        JSONArray outstandingPaymentsToDateArrayElement = new JSONArray();
        JSONObject outstandingPaymentsToDate = new JSONObject();
        outstandingPaymentsToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        outstandingPaymentsToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        outstandingPaymentsToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        outstandingPaymentsToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        outstandingPaymentsToDateArrayElement.put(outstandingPaymentsToDate);
        accValueJsonObj.put("outstanding_payments_to_date", outstandingPaymentsToDateArrayElement);

        JSONArray outstandingCreditBalanceArrayElement = new JSONArray();
        JSONObject outstandingCreditBalance = new JSONObject();
        outstandingCreditBalance.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        outstandingCreditBalance.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        outstandingCreditBalanceArrayElement.put(outstandingCreditBalance);
        accValueJsonObj.put("outstanding_credit_balance", outstandingCreditBalanceArrayElement);

        JSONObject customerContactDeatils = new JSONObject();
        customerContactDeatils.put("email",email);

        JSONObject defaultAddress = new JSONObject();
        defaultAddress.put("id",add_id);
        defaultAddress.put("country",testDataManager.getTestInputRegionData("updateCustomer.country"));
        defaultAddress.put("county",testDataManager.getTestInputRegionData("updateCustomer.county"));
        defaultAddress.put("town_city",testDataManager.getTestInputRegionData("updateCustomer.town_city"));
        defaultAddress.put("district",testDataManager.getTestInputRegionData("updateCustomer.district"));
        defaultAddress.put("state",testDataManager.getTestInputRegionData("updateCustomer.state"));
        defaultAddress.put("house_flat_number",testDataManager.getTestInputRegionData("updateCustomer.house_flat_number"));
        defaultAddress.put("house_name",testDataManager.getTestInputRegionData("updateCustomer.house_name"));
        defaultAddress.put("street",testDataManager.getTestInputRegionData("updateCustomer.street"));
        defaultAddress.put("postcode",testDataManager.getTestInputRegionData("updateCustomer.postcode"));
        defaultAddress.put("is_default",testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        customerContactDeatils.put("default_address",defaultAddress);

        JSONArray addressBookArrayElement = new JSONArray();
        JSONObject addressBook = new JSONObject();
        addressBook.put("id",add_id);
        addressBook.put("country",testDataManager.getTestInputRegionData("updateCustomer.country"));
        addressBook.put("county",testDataManager.getTestInputRegionData("updateCustomer.county"));
        addressBook.put("town_city",testDataManager.getTestInputRegionData("updateCustomer.town_city"));
        addressBook.put("district",testDataManager.getTestInputRegionData("updateCustomer.district"));
        addressBook.put("state",testDataManager.getTestInputRegionData("updateCustomer.state"));
        addressBook.put("house_flat_number",testDataManager.getTestInputRegionData("updateCustomer.house_flat_number"));
        addressBook.put("house_name",testDataManager.getTestInputRegionData("updateCustomer.house_name"));
        addressBook.put("street",testDataManager.getTestInputRegionData("updateCustomer.street"));
        addressBook.put("postcode",testDataManager.getTestInputRegionData("updateCustomer.postcode"));
        addressBook.put("is_default",testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        addressBookArrayElement.put(addressBook);

        JSONArray entitleArrayElement = new JSONArray();

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Sun"));
        subglassJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Sun"));
        subglassJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Sun"));
        subglassJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Sun"));
        subglassJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Sun"));
        entitleArrayElement.put(subglassJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Spare"));
        spareLenseJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Spare"));
        spareLenseJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Spare"));
        spareLenseJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Spare"));
        spareLenseJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Spare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_After"));
        afterCareJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_After"));
        afterCareJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_After"));
        afterCareJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_After"));
        afterCareJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_After"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Free"));
        freeglasJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Free"));
        freeglasJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Free"));
        freeglasJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Free"));
        freeglasJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Free"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONObject value = new JSONObject();

        custJsonObj.put("entitlements",entitleArrayElement);
        custJsonObj.put("address_book",addressBookArrayElement);
        custJsonObj.put("customer_contact_details",customerContactDeatils);
        accJsonObj.put("value", accValueJsonObj);
        custJsonObj.put("account", accJsonObj);
        jsonBody.put("customer", custJsonObj);

        return jsonBody.toMap();

    }


    //user request to validate that promotion on invalid cart of account
    public void requestToValidateThatPromotionOnInvalidCartOfAccount(String cartReff,String storeId,int status) {
        String authCode = testDataManager.getTestInputRegionData("promotion.authCode");
        String voucher = testDataManager.getTestInputRegionData("promotion.voucher");
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+"/"+accountReference+testDataManager.getTestInputRegionData("url.Cartfinal String endpoint")+"/"+cartReff+testDataManager.getTestInputRegionData("url.Voucherfinal String endpoint")+"/"+voucher+"?"+testDataManager.getTestInputRegionData("url.StoreIdfinal String endpoint")+storeId+testDataManager.getTestInputRegionData("url.Authcodefinal String endpoint")+authCode;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }

    // GET METHOD - Verify PAyment Method for Invalid Account
    public void userVerifiesPaymentDetailsForInvalidAccount(String accReff,int status){
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+"/"+accReff+testDataManager.getTestInputRegionData("url.Paymentfinal String endpoint");
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }


    public void userSearchesForCustomerUsingClientUserIdInput(int status, String clientUserIdInput){
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+testDataManager.getTestInputCommonData("url.searchCustomer")+clientUserIdInput;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        accountReference = apiRequests.getValueFormJsonResponseKey("customers[0].customer_id");
        logger.info("Account Reference for this customer is "+accountReference);
    }

    public void userSearchesForCustomerUsingClientId(int status,String clientId){
        final String endpoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountfinal String endpointCDG")+testDataManager.getTestInputCommonData("url.searchCustomer")+clientId;
        apiRequests.GETMethodWithXApiHeaders(endpoint,xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
        accountReference = apiRequests.getValueFormJsonResponseKey("customers[0].customer_id");
        logger.info("Account Reference for this customer is "+accountReference);
    }
    public void userUpdateAddress(int status,String accountReference, String customerID){
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+accountReference;
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.updateAddressBody(add_id,customerID));
        final String resourceRef = apiRequests.getValueFormJsonResponseKey("account.resource_reference");
        logger.info("Resource reference is "+resourceRef);
        assertEquals(accountReference, resourceRef);
        assertEquals(status, apiRequests.verifyResponseStatusCode());
         }
    public void userSearchesForCustomerUsingLastname(int status) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + testDataManager.getTestInputCommonData("url.accountEndPointCDG") + testDataManager.getTestInputCommonData("url.searchLastName") + "Automation" + testDataManager.getTestInputCommonData("url.searchAccount");
        apiRequests.GETMethodWithXApiHeaders(endPoint, xApiKey);
        assertEquals(status, apiRequests.verifyResponseStatusCode());
    }
    public void userAddsAddressWithInvalidAccountReference(String accountReference,int status) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + testDataManager.getTestInputCommonData("url.accountEndPointCDG") + "/" + accountReference +"/addresses";
        apiRequests.POSTMethodWithXApiHeaders(endPoint, xApiKey, clspApiRequest.getAddressJsonBodyCDG());
        assertEquals(status, apiRequests.verifyResponseStatusCode());
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedErrorMessage = "404";
        logger.info("Expected error message is : " + expectedErrorMessage);
        logger.info("Actual error message is : " + actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }
    public void requestsToUpdatePaymentDetailsForInvalidBIC(String bic,int status, String acc_reference,String firstName){
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.paymentEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getPaymentBodyWithInvalidBIC(bic,firstName));
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedErrorMessage = "500";
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }
    public void requestsToUpdatePaymentDetailsForInvalidIBAN(String iban,int status, String acc_reference,String firstName){
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.paymentEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getPaymentBodyWithInvalidIBAN(iban,firstName));
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("code");
        String expectedErrorMessage = "500";
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        assertEquals(actualErrorMessage, expectedErrorMessage);
    }
    public void userCreatesSameDayPaymentSubscriptionUsingMPP(int status, String payerType, String discountType, String acc_reference, String cart_id, String custType ) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonESBURI")+"/api/accounts/"+acc_reference+"/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestFirstPaymentInFlightOrCompleted(payerType, discountType, "No",0,cart_id,add_id,custType));

    }





}
