
package clsp.api.extentions;

import Framework.BaseObject.BasePageObject;
import Framework.DataManager.TestDataManager;
import clsp.ui.pages.SearchPage;
import clsp.ui.pages.SubscriptionPage;
import clsp.ui.pages.SummaryPage;
import io.restassured.RestAssured;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class clspApiBase extends BasePageObject {

    protected static final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(SearchPage.class);


    SummaryPage summaryPage = new SummaryPage();
    SubscriptionPage subscriptionPage;
    public static String futureDate;
    public static String dispatchedDateBankHoliday;


    public void setUpCleanSession() {
        try {
            RestAssured.reset();
            //SerenityRest.proxy("proxy.uk.specsavers.com",8080);
        }catch (RuntimeException e) {
            logger.error(e.getMessage());
        }
    }

    public Map<String, ?> getMPPHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("X-ClientId", testDataManager.getTestInputCommonData("mppHeaders.clientId"));
        headers.put("X-ClientPassword",testDataManager.getTestInputCommonData("mppHeaders.clientPassword"));
        headers.put("x-version", testDataManager.getTestInputCommonData("mppHeaders.versionNumber"));
        headers.put("Content-Type","application/json");
        return headers;
    }
    public Map<String, ?>  getHeaders() {

        Map<String, String> headers = new HashMap<>();
        headers.put("x-api-key", testDataManager.getTestInputCommonData("url.apiKeyCDG"));
        return headers;
    }


    //Generate client user id method. To be invoked if cust creation files due to existing cust ID

    public String getFutureDaysDate(long days) {

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now().plusDays(days);
        return dtf.format(localDate);

    }

    //Generate client user id method. To be invoked if cust creation files due to existing cust ID
    public static String getNewUserID() {

        final long varTime = System.currentTimeMillis();
        final double randomMath = Math.random() * 1000;
        final long multi = (long) (varTime * randomMath);
        final String s = multi + "";
        final String subStr = s.substring(0, 6);
        return subStr;
    }
    public String getFutureDaysDateAndTime(long days) {

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime localDate = LocalDateTime.now().plusDays(days);
        localDate = localDate.plusMinutes(10);
        final String futureDate = dtf.format(localDate);
        logger.info(futureDate);
        return futureDate;

    }

    public Map<String, ?> getHeadersForRemoveCust() {
        Map<String, String> headers = new HashMap<>();
        headers.put("X-ClientId", testDataManager.getTestInputCommonData("mppHeaders.clientId"));
        headers.put("X-ClientPassword",testDataManager.getTestInputCommonData("mppHeaders.clientPassword"));
        headers.put("x-version", testDataManager.getTestInputCommonData("mppHeaders.versionNumber"));
        headers.put("Origin", testDataManager.getTestInputCommonData("mppHeaders.Origin"));
        headers.put("x-tokenId", testDataManager.getTestInputCommonData("mppHeaders.x-tokenId"));
        return headers;
    }
    public Map<String, ?> getMonthlyCartNonQuarterlyJsonBodyCDG(String solutionType, String custType){
        JSONObject jsonBody = new JSONObject();

        JSONObject cartLeftJsonObj = new JSONObject();
        cartLeftJsonObj.put("quantity",testDataManager.getTestInputRegionData("nonQuarterly.quantity"));

        JSONObject leftPricingJsonObj = new JSONObject();
        leftPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData("nonQuarterly.gross_amount"));
        leftPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData("nonQuarterly.tax_amount"));
        leftPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData("nonQuarterly.net_amount"));
        leftPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("nonQuarterly.currency"));
        cartLeftJsonObj.put("pricing",leftPricingJsonObj);

        cartLeftJsonObj.put("product_description",testDataManager.getTestInputRegionData("nonQuarterly.product_description"));
        cartLeftJsonObj.put("product_id",testDataManager.getTestInputRegionData("nonQuarterly.product_id"));
        cartLeftJsonObj.put("usage",testDataManager.getTestInputRegionData("nonQuarterly.usage"));
        cartLeftJsonObj.put("payments",12);




        JSONObject lensDetailPricingJsonObj = new JSONObject();
        lensDetailPricingJsonObj.put("eye", testDataManager.getTestInputRegionData("nonQuarterly.eyeL"));

        JSONObject leftCLFitJsonObj = new JSONObject();
        leftCLFitJsonObj.put("add", testDataManager.getTestInputRegionData("nonQuarterly.Add"));
        leftCLFitJsonObj.put("add_type", testDataManager.getTestInputRegionData("nonQuarterly.add_type"));
        leftCLFitJsonObj.put("axis", testDataManager.getTestInputRegionData("nonQuarterly.Axis"));
        leftCLFitJsonObj.put("base_curve", testDataManager.getTestInputRegionData("nonQuarterly.base_curve"));
        leftCLFitJsonObj.put("cyl", testDataManager.getTestInputRegionData("nonQuarterly.Cyl"));
        leftCLFitJsonObj.put("diameter", testDataManager.getTestInputRegionData("nonQuarterly.Diameter"));
        leftCLFitJsonObj.put("lens_name", testDataManager.getTestInputRegionData("nonQuarterly.lens_name"));
        leftCLFitJsonObj.put("lens_supplier", testDataManager.getTestInputRegionData("nonQuarterly.lens_supplier"));
        leftCLFitJsonObj.put("power", testDataManager.getTestInputRegionData("nonQuarterly.Power"));
        leftCLFitJsonObj.put("sku", testDataManager.getTestInputRegionData("nonQuarterly.SKU"));
        leftCLFitJsonObj.put("style_number", testDataManager.getTestInputRegionData("nonQuarterly.style_number"));
        leftCLFitJsonObj.put("tint_desc", testDataManager.getTestInputRegionData("nonQuarterly.tint_desc"));
        lensDetailPricingJsonObj.put("clfit", leftCLFitJsonObj);
        cartLeftJsonObj.put("lens_detail", lensDetailPricingJsonObj);
        cartLeftJsonObj.put("box_size", testDataManager.getTestInputRegionData("montlySolutionCustomer.quantity"));

        JSONObject leftSolutionDetailsJsonObj = new JSONObject();
        leftSolutionDetailsJsonObj.put("solution_supplier_name", testDataManager.getTestInputRegionData("nonQuarterly.solution_supplier_name"));
        leftSolutionDetailsJsonObj.put("solution_sku", testDataManager.getTestInputRegionData("nonQuarterly.solution_sku"));
        cartLeftJsonObj.put("solution_detail", leftSolutionDetailsJsonObj);

        jsonBody.put("left", cartLeftJsonObj);


        JSONObject cartRightJsonObj = new JSONObject();
        cartRightJsonObj.put("quantity",testDataManager.getTestInputRegionData("nonQuarterly.quantity"));

        JSONObject rightPricingJsonObj = new JSONObject();
        rightPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData("nonQuarterly.gross_amount"));
        rightPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData("nonQuarterly.tax_amount"));
        rightPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData("nonQuarterly.net_amount"));
        rightPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("nonQuarterly.currency"));
        cartRightJsonObj.put("pricing",rightPricingJsonObj);

        cartRightJsonObj.put("product_description",testDataManager.getTestInputRegionData("nonQuarterly.product_description"));
        cartRightJsonObj.put("product_id",testDataManager.getTestInputRegionData("nonQuarterly.product_id"));
        cartRightJsonObj.put("usage",testDataManager.getTestInputRegionData("nonQuarterly.usage"));
        cartRightJsonObj.put("payments",12);

        if(solutionType.equalsIgnoreCase("solution")){
            custType = "Monthly Solution";     // varibale value declared for Replacement Method
            JSONObject cartExtrasJsonObj = new JSONObject();

            JSONObject solutionJsonObj = new JSONObject();
            JSONObject solutionDetailsJsonObj = new JSONObject();
            solutionDetailsJsonObj.put("solution_supplier_name", testDataManager.getTestInputRegionData("nonQuarterly.solution_supplier_name"));
            solutionDetailsJsonObj.put("solution_sku", testDataManager.getTestInputRegionData("nonQuarterly.solution_sku"));
            solutionJsonObj.put("solution_detail", solutionDetailsJsonObj);

            solutionJsonObj.put("product_description", testDataManager.getTestInputRegionData("nonQuarterly.product_description2"));
            solutionJsonObj.put("product_id", testDataManager.getTestInputRegionData("nonQuarterly.product_id2"));
            solutionJsonObj.put("quantity", testDataManager.getTestInputRegionData("nonQuarterly.quantity_sol"));

            JSONObject extrasPricingJsonObj = new JSONObject();
            extrasPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData("nonQuarterly.gross_amount_sol"));
            extrasPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData("nonQuarterly.tax_amount_sol"));
            extrasPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData("nonQuarterly.net_amount_sol"));
            extrasPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("nonQuarterly.currency"));
            solutionJsonObj.put("pricing",extrasPricingJsonObj);

            cartExtrasJsonObj.put("solution", solutionJsonObj);

            jsonBody.put("extras", cartExtrasJsonObj);
            jsonBody.put("total_cost", testDataManager.getTestInputRegionData("nonQuarterly.total_costSoln"));
        }
        jsonBody.put("total_cost", testDataManager.getTestInputRegionData("nonQuarterly.total_cost"));


        return jsonBody.toMap();
    }

    public Map<String, ?> getCustAltPayerJsonBodyCDG(String client_user_id,String firstName,String lastName,String emailID){
        JSONObject jsonBody = new JSONObject();

        // JSONArray custArrayElement = new JSONArray();
        JSONObject custJsonObj = new JSONObject();
        custJsonObj.put("client_user_id", testDataManager.getTestInputRegionData("createCustomer.store_id") + "-" + client_user_id);
        custJsonObj.put("title", testDataManager.getTestInputCommonData("login.salutation"));
        custJsonObj.put("first_name", firstName);
        custJsonObj.put("last_name",lastName);

        custJsonObj.put("error", testDataManager.getTestInputRegionData("createCustomer.error"));
        custJsonObj.put("gender", testDataManager.getTestInputRegionData("createCustomer.gender"));
        custJsonObj.put("mpp_store_id", testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));

        JSONObject accJsonObj = new JSONObject();
        JSONObject accValueJsonObj = new JSONObject();
        accJsonObj.put("value", accValueJsonObj);
        custJsonObj.put("account", accJsonObj);

        JSONArray addArrayElement = new JSONArray();
        custJsonObj.put("address_book", addArrayElement);

        JSONObject contactJsonObj = new JSONObject();
        contactJsonObj.put("email", emailID);
        JSONObject defAddJsonObj = new JSONObject();
        defAddJsonObj.put("street", testDataManager.getTestInputRegionData("createCustomer.street"));
        defAddJsonObj.put("is_default", testDataManager.getTestInputRegionData("createCustomer.is_default"));
        defAddJsonObj.put("address_type", testDataManager.getTestInputRegionData("createCustomer.address_type"));
        defAddJsonObj.put("house_name", testDataManager.getTestInputRegionData("createCustomer.house_name"));
        defAddJsonObj.put("town_city", testDataManager.getTestInputRegionData("createCustomer.town_city"));
        defAddJsonObj.put("district", testDataManager.getTestInputRegionData("createCustomer.district"));
        defAddJsonObj.put("county", testDataManager.getTestInputRegionData("createCustomer.county"));
        defAddJsonObj.put("postcode", testDataManager.getTestInputRegionData("createCustomer.postcode"));
        defAddJsonObj.put("country", testDataManager.getTestInputRegionData("createCustomer.country"));
        contactJsonObj.put("default_address", defAddJsonObj);
        custJsonObj.put("customer_contact_details", contactJsonObj);

        custJsonObj.put("date_of_birth", testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONArray entitleArrayElement = new JSONArray();
        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier", testDataManager.getTestInputRegionData("createCustomer.identifierFree"));
        freeglasJsonObj.put("friendly_name", testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
        freeglasJsonObj.put("claim_date", testDataManager.getTestInputRegionData("createCustomer.claim_dateFree"));
        freeglasJsonObj.put("status", testDataManager.getTestInputRegionData("createCustomer.statusFree"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier", testDataManager.getTestInputRegionData("createCustomer.identifierSpare"));
        spareLenseJsonObj.put("friendly_name", testDataManager.getTestInputRegionData("createCustomer.friendly_nameSpare"));
        spareLenseJsonObj.put("claim_date", testDataManager.getTestInputRegionData("createCustomer.claim_dateSpare"));
        spareLenseJsonObj.put("status", testDataManager.getTestInputRegionData("createCustomer.statusSpare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier", testDataManager.getTestInputRegionData("createCustomer.identifierAftercare"));
        afterCareJsonObj.put("friendly_name", testDataManager.getTestInputRegionData("createCustomer.friendly_nameAftercare"));
        afterCareJsonObj.put("claim_date", testDataManager.getTestInputRegionData("createCustomer.claim_dateAftercare"));
        afterCareJsonObj.put("status", testDataManager.getTestInputRegionData("createCustomer.statusAftercare"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier", testDataManager.getTestInputRegionData("createCustomer.identifierSun"));
        subglassJsonObj.put("friendly_name", testDataManager.getTestInputRegionData("createCustomer.friendly_nameSun"));
        subglassJsonObj.put("claim_date", testDataManager.getTestInputRegionData("createCustomer.claim_dateSun"));
        subglassJsonObj.put("status", testDataManager.getTestInputRegionData("createCustomer.statusSun"));
        entitleArrayElement.put(subglassJsonObj);

        custJsonObj.put("entitlements", entitleArrayElement);

        JSONArray notesArrayElement = new JSONArray();
        custJsonObj.put("notes", notesArrayElement);

        custJsonObj.put("payment_method_type", testDataManager.getTestInputRegionData("createCustomer.payment_method_type"));

        JSONObject AltalternatePayerJsonObj = new JSONObject();
        AltalternatePayerJsonObj.put("title", testDataManager.getTestInputRegionData("alternatePayer.alternateTitle"));
        AltalternatePayerJsonObj.put("first_name", testDataManager.getTestInputRegionData("alternatePayer.alternateFirstName"));
        AltalternatePayerJsonObj.put("last_name", testDataManager.getTestInputRegionData("alternatePayer.alternateLastName"));
        //AltalternatePayerJsonObj.put("email_address", emailID);
        JSONObject AltAdd = new JSONObject();
        AltAdd.put("street", testDataManager.getTestInputRegionData("alternatePayer.alternateAddrOne"));
        AltAdd.put("house_name", testDataManager.getTestInputRegionData("alternatePayer.houseName"));
        AltAdd.put("country", testDataManager.getTestInputRegionData("alternatePayer.countrySelected"));
        AltAdd.put("county", testDataManager.getTestInputRegionData("alternatePayer.alternateCounty"));
        AltAdd.put("district", testDataManager.getTestInputRegionData("alternatePayer.district"));
        AltAdd.put("house_flat_number", testDataManager.getTestInputRegionData("alternatePayer.houseNo"));
        AltAdd.put("postcode", testDataManager.getTestInputRegionData("alternatePayer.postcode"));
        AltAdd.put("town_city", testDataManager.getTestInputRegionData("alternatePayer.alternateTown"));

        AltalternatePayerJsonObj.put("billing_address", AltAdd);
        custJsonObj.put("alternate_payer", AltalternatePayerJsonObj);

        jsonBody.put("customer", custJsonObj);
        jsonBody.put("store_id", testDataManager.getTestInputRegionData("createCustomer.store_id"));
        return jsonBody.toMap();

    }

    public Map<String, ?> getCustomerJsonBodyCDG(String client_user_id,String firstName,String lastName, String emailID){

        JSONObject jsonBody = new JSONObject();

        JSONObject custJsonObj = new JSONObject();
        custJsonObj.put("client_user_id",testDataManager.getTestInputRegionData("createCustomer.store_id")+"-"+client_user_id);
        custJsonObj.put("title",testDataManager.getTestInputRegionData("createCustomer.title"));
        custJsonObj.put("first_name",firstName);
        custJsonObj.put("last_name",lastName);
        custJsonObj.put("error",testDataManager.getTestInputRegionData("createCustomer.error"));
        custJsonObj.put("gender",testDataManager.getTestInputRegionData("createCustomer.gender"));
        custJsonObj.put("mpp_store_id",testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));
        custJsonObj.put("mpp_store_name",testDataManager.getTestInputRegionData("createCustomer.mpp_store_name"));

        JSONObject accJsonObj = new JSONObject();
        JSONObject accValueJsonObj = new JSONObject();
        accJsonObj.put("value", accValueJsonObj);
        accJsonObj.put("lens_mail_start_date", getFutureDaysDate(12));
        custJsonObj.put("account",accJsonObj);

        JSONArray addArrayElement = new JSONArray();
        custJsonObj.put("address_book",addArrayElement);

        JSONObject contactJsonObj = new JSONObject();
        contactJsonObj.put("email", emailID);
        contactJsonObj.put("home_number", testDataManager.getTestInputRegionData("createCustomer.home_number"));
        contactJsonObj.put("mobile_number", testDataManager.getTestInputRegionData("createCustomer.mobile_number"));

        JSONObject defAddJsonObj = new JSONObject();
        defAddJsonObj.put("street", testDataManager.getTestInputRegionData("createCustomer.addressLine"));
        defAddJsonObj.put("is_default", testDataManager.getTestInputRegionData("createCustomer.is_default"));
        defAddJsonObj.put("address_type", testDataManager.getTestInputRegionData("createCustomer.address_type"));
        defAddJsonObj.put("house_name",testDataManager.getTestInputRegionData("createCustomer.name"));
        defAddJsonObj.put("town_city", testDataManager.getTestInputRegionData("createCustomer.town"));
        defAddJsonObj.put("district", testDataManager.getTestInputRegionData("createCustomer.number"));
        defAddJsonObj.put("county", testDataManager.getTestInputRegionData("createCustomer.county"));
        defAddJsonObj.put("postcode", testDataManager.getTestInputRegionData("createCustomer.postcode"));
        defAddJsonObj.put("country", testDataManager.getTestInputRegionData("createCustomer.countryName"));
        contactJsonObj.put("default_address", defAddJsonObj);
        custJsonObj.put("customer_contact_details",contactJsonObj);

        custJsonObj.put("date_of_birth",testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONArray entitleArrayElement = new JSONArray();
        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierFree"));
        freeglasJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
        freeglasJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateFree"));
        freeglasJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusFree"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierSpare"));
        spareLenseJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameSpare"));
        spareLenseJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateSpare"));
        spareLenseJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusSpare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierAftercare"));
        afterCareJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameAftercare"));
        afterCareJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateAftercare"));
        afterCareJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusAftercare"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier",testDataManager.getTestInputRegionData("createCustomer.identifierSun"));
        subglassJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("createCustomer.friendly_nameSun"));
        subglassJsonObj.put("claim_date",testDataManager.getTestInputRegionData("createCustomer.claim_dateSun"));
        subglassJsonObj.put("status",testDataManager.getTestInputRegionData("createCustomer.statusSun"));
        entitleArrayElement.put(subglassJsonObj);

        custJsonObj.put("entitlements",entitleArrayElement);

        JSONArray notesArrayElement = new JSONArray();
        custJsonObj.put("notes",notesArrayElement);

        jsonBody.put("customer",custJsonObj);
        jsonBody.put("store_id",Integer.parseInt(testDataManager.getTestInputRegionData("createCustomer.store_id")));
        return jsonBody.toMap();

    }

    public Map<String, ?> getCartJsonBodyCDGDaily(String DailyType, int quantity){

        JSONObject jsonBody = new JSONObject();
        JSONObject cartLeftJsonObj = new JSONObject();
        cartLeftJsonObj.put("quantity",quantity);
        JSONObject leftPricingJsonObj = new JSONObject();
        leftPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData(DailyType+".gross_amount"));
        leftPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData(DailyType+".tax_amount"));
        leftPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData(DailyType+".net_amount"));
        leftPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("cartJsonBody.currency"));
        cartLeftJsonObj.put("pricing",leftPricingJsonObj);
        cartLeftJsonObj.put("product_description",testDataManager.getTestInputRegionData(DailyType+".product_description"));
        cartLeftJsonObj.put("product_id",testDataManager.getTestInputRegionData(DailyType+".product_id"));
        cartLeftJsonObj.put("usage",DailyType);

        JSONObject lensDetailPricingJsonObj = new JSONObject();
        lensDetailPricingJsonObj.put("eye", testDataManager.getTestInputRegionData(DailyType+".eyeL"));

        JSONObject leftCLFitJsonObj = new JSONObject();
        leftCLFitJsonObj.put("add", testDataManager.getTestInputRegionData(DailyType+".Add"));
        leftCLFitJsonObj.put("add_type", testDataManager.getTestInputRegionData(DailyType+".add_type"));
        leftCLFitJsonObj.put("axis", testDataManager.getTestInputRegionData(DailyType+".Axis"));
        leftCLFitJsonObj.put("base_curve", testDataManager.getTestInputRegionData(DailyType+".base_curve"));
        leftCLFitJsonObj.put("cyl", testDataManager.getTestInputRegionData(DailyType+".Cyl"));
        leftCLFitJsonObj.put("diameter", testDataManager.getTestInputRegionData(DailyType+".Diameter"));
        leftCLFitJsonObj.put("lens_name", testDataManager.getTestInputRegionData(DailyType+".lens_name"));
        leftCLFitJsonObj.put("lens_supplier", testDataManager.getTestInputRegionData(DailyType+".lens_supplier"));
        leftCLFitJsonObj.put("power", testDataManager.getTestInputRegionData(DailyType+".Power"));
        leftCLFitJsonObj.put("sku", testDataManager.getTestInputRegionData(DailyType+".SKU"));
        leftCLFitJsonObj.put("style_number", testDataManager.getTestInputRegionData(DailyType+".style_number"));
        leftCLFitJsonObj.put("tint_desc", testDataManager.getTestInputRegionData(DailyType+".tint_desc"));
        lensDetailPricingJsonObj.put("clfit", leftCLFitJsonObj);
        cartLeftJsonObj.put("lens_detail", lensDetailPricingJsonObj);
        cartLeftJsonObj.put("box_size", testDataManager.getTestInputRegionData("Occasional.quantity"));

        jsonBody.put("left", cartLeftJsonObj);


        JSONObject cartRightJsonObj = new JSONObject();
        cartRightJsonObj.put("quantity",quantity);

        JSONObject rightPricingJsonObj = new JSONObject();
        rightPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData(DailyType+".gross_amount"));
        rightPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData(DailyType+".tax_amount"));
        rightPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData(DailyType+".net_amount"));
        rightPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("cartJsonBody.currency"));
        cartRightJsonObj.put("pricing",rightPricingJsonObj);

        cartRightJsonObj.put("product_description",testDataManager.getTestInputRegionData(DailyType+".product_description"));
        cartRightJsonObj.put("product_id",testDataManager.getTestInputRegionData(DailyType+".product_id"));
        cartRightJsonObj.put("usage",DailyType);

        JSONObject rightlensDetailPricingJsonObj = new JSONObject();
        rightlensDetailPricingJsonObj.put("eye", testDataManager.getTestInputRegionData(DailyType+".eyeR"));

        JSONObject rightCLFitJsonObj = new JSONObject();
        rightCLFitJsonObj.put("add", testDataManager.getTestInputRegionData(DailyType+".Add"));
        rightCLFitJsonObj.put("add_type", testDataManager.getTestInputRegionData(DailyType+".add_type"));
        rightCLFitJsonObj.put("axis", testDataManager.getTestInputRegionData(DailyType+".Axis"));
        rightCLFitJsonObj.put("base_curve", testDataManager.getTestInputRegionData(DailyType+".base_curve"));
        rightCLFitJsonObj.put("cyl", testDataManager.getTestInputRegionData(DailyType+".Cyl"));
        rightCLFitJsonObj.put("diameter", testDataManager.getTestInputRegionData(DailyType+".Diameter"));
        rightCLFitJsonObj.put("lens_name", testDataManager.getTestInputRegionData(DailyType+".lens_name"));
        rightCLFitJsonObj.put("lens_supplier", testDataManager.getTestInputRegionData(DailyType+".lens_supplier"));
        rightCLFitJsonObj.put("power", testDataManager.getTestInputRegionData(DailyType+".Power"));
        rightCLFitJsonObj.put("sku", testDataManager.getTestInputRegionData(DailyType+".SKU"));
        rightCLFitJsonObj.put("style_number", testDataManager.getTestInputRegionData(DailyType+".style_number"));
        rightCLFitJsonObj.put("tint_desc", testDataManager.getTestInputRegionData(DailyType+".tint_desc"));
        rightlensDetailPricingJsonObj.put("clfit", rightCLFitJsonObj);
        cartRightJsonObj.put("lens_detail", rightlensDetailPricingJsonObj);
        cartRightJsonObj.put("box_size", testDataManager.getTestInputRegionData("Occasional.quantity"));

        jsonBody.put("right", cartRightJsonObj);

        jsonBody.put("total_cost", testDataManager.getTestInputRegionData(DailyType+".total_cost"));


        return jsonBody.toMap();

    }


    public Map<String, ?> getpaymentBody(String paymentType, String firstName) {

        JSONObject paymentJSONBody = new JSONObject();
        if(testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod").equalsIgnoreCase("SEPA")) {
            JSONObject sepaJSONBody = new JSONObject();
            sepaJSONBody.put("account_holder_name", firstName);
            sepaJSONBody.put("bic", testDataManager.getTestInputRegionData(paymentType+".accNumbIc"));
            sepaJSONBody.put("iban", testDataManager.getTestInputRegionData(paymentType+".accSortiBan"));
            paymentJSONBody.put("sepa", sepaJSONBody);
            //paymentJSONBody.put("bacs", String.valueOf(null));      // commenting as the JSON that generated doesn't pass using null value
        }
        else {
            JSONObject bacsJSONBody = new JSONObject();
            bacsJSONBody.put("account_holder_name", firstName);
            bacsJSONBody.put("account_number",testDataManager.getTestInputRegionData(paymentType+".accNumbIc"));
            bacsJSONBody.put("sort_code", testDataManager.getTestInputRegionData(paymentType+".accSortiBan"));
            bacsJSONBody.put("payment_method_type", "BACS");
            paymentJSONBody.put("bacs", bacsJSONBody);
        }
        return paymentJSONBody.toMap();
    }

    public Map<String, ?> getSubscriptionRequestFirstPaymentInFlightOrCompleted(String payerType , String discountType, String nonLensMailOrderValue, int days, String cart_id, String add_id, String custType) {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("CartReference", cart_id);
        requestSubscriptionBody.put("AddressReference", add_id);
        requestSubscriptionBody.put("PaymentMethod", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("FirstPaymentDate", getFutureDaysDateAndTime(days));
        requestSubscriptionBody.put("FirstDispatchDate", getFutureDaysDate(60)+"T00:00:00.000Z");
        requestSubscriptionBody.put("LeadTime", Integer.parseInt(testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime")));
        requestSubscriptionBody.put("Description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));

        if (discountType.equalsIgnoreCase(testDataManager.getTestInputRegionData("subscriptionRequest.discountType1"))){
            //requestSubscriptionBody.put("VoucherCode", "JA9AG5P3A3");
            requestSubscriptionBody.put("VoucherCode", "AG674G5M35");

        }

        JSONObject jsonCustomParam = new JSONObject();
        jsonCustomParam.put("StoreNumber", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        jsonCustomParam.put("NonLensMailOrder", nonLensMailOrderValue);
        jsonCustomParam.put("StoreName", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        jsonCustomParam.put("MailerQuantity", testDataManager.getTestInputRegionData("subscriptionRequest.MailerQuantity"));
        if(custType.equalsIgnoreCase("Monthly No Solution"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("montlyNoSolutionCustomer.MailerSKU"));
        }
        else if(custType.equalsIgnoreCase("Monthly Solution"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("montlySolutionCustomer.MailerSKU"));
        }
        else if(custType.equalsIgnoreCase("Occasional"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("dailyOccasionalCustomer.MailerSKU"));
        }
        else if(custType.equalsIgnoreCase("Part Time"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("dailyPartTimeCustomer.MailerSKU"));
        }
        else
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("dailyFullTimeCustomer.MailerSKU"));
        }
        jsonCustomParam.put("LetterTextCode", testDataManager.getTestInputRegionData("subscriptionRequest.LetterTextCode"));
        jsonCustomParam.put("LeadTime", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        jsonCustomParam.put("OrderLineType", testDataManager.getTestInputRegionData("subscriptionRequest.OrderLineType"));
        jsonCustomParam.put("CollectedInStore", testDataManager.getTestInputRegionData("subscriptionRequest.CollectedInStore"));
        jsonCustomParam.put("BoxSize", testDataManager.getTestInputRegionData("Occasional.quantity"));
        jsonCustomParam.put("Payments", "3");
        requestSubscriptionBody.put("CustomFulfilmentParameters", jsonCustomParam);

        requestSubscriptionBody.put("FirstPack", "NONE");

        JSONObject jsonCustomInstructionParam = new JSONObject();
        jsonCustomInstructionParam.put("PayerType", payerType);
        jsonCustomInstructionParam.put("CLensFitNo", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        jsonCustomInstructionParam.put("TDRNo", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        jsonCustomInstructionParam.put("ExpiryDate", getFutureDaysDate(90));
        jsonCustomInstructionParam.put("AftercareStore", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        jsonCustomInstructionParam.put("MigratedSubscription", "No"); //commenting this parameter as records to be appear in standard order report
        jsonCustomInstructionParam.put("SubscriptionType", "Normal");
        requestSubscriptionBody.put("CustomPaymentInstructionParameters", jsonCustomInstructionParam);

        JSONObject jsonCustomPaymentParam = new JSONObject();
        jsonCustomPaymentParam.put("StoreNumber", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));

        requestSubscriptionBody.put("CustomPaymentParameters", jsonCustomPaymentParam);

        requestSubscriptionBody.put("NumberOfMonthsToCompletion", 27);
        return requestSubscriptionBody.toMap();
    }
    public Map<String, ?> getSubscriptionRequestMigratedCustomer(String payerType , String discountType, String nonLensMailOrderValue, int days, String cart_id, String add_id, String custType) {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("CartReference", cart_id);
        requestSubscriptionBody.put("AddressReference", add_id);
        requestSubscriptionBody.put("PaymentMethod", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("FirstPaymentDate", getFutureDaysDateAndTime(20));
        requestSubscriptionBody.put("FirstDispatchDate", getFutureDaysDate(1)+"T00:00:00.000Z");
        requestSubscriptionBody.put("LeadTime", Integer.parseInt(testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime")));
        requestSubscriptionBody.put("Description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));

        if (discountType.equalsIgnoreCase(testDataManager.getTestInputRegionData("subscriptionRequest.discountType1"))){
            //requestSubscriptionBody.put("VoucherCode", "JA9AG5P3A3");
            requestSubscriptionBody.put("VoucherCode", testDataManager.getTestInputRegionData("subscriptionRequest.VoucherCode"));

        }

        JSONObject jsonCustomParam = new JSONObject();
        jsonCustomParam.put("StoreNumber", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        jsonCustomParam.put("NonLensMailOrder", nonLensMailOrderValue);
        jsonCustomParam.put("StoreName", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        jsonCustomParam.put("MailerQuantity", testDataManager.getTestInputRegionData("subscriptionRequest.MailerQuantity"));
        if(custType.equalsIgnoreCase("Monthly No Solution"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("montlyNoSolutionCustomer.MailerSKU"));
        }
        else if(custType.equalsIgnoreCase("Monthly Solution"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("montlySolutionCustomer.MailerSKU"));
        }
        else if(custType.equalsIgnoreCase("Occasional"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("dailyOccasionalCustomer.MailerSKU"));
        }
        else if(custType.equalsIgnoreCase("Part Time"))
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("dailyPartTimeCustomer.MailerSKU"));
        }
        else
        {
            jsonCustomParam.put("MailerSKU", testDataManager.getTestInputRegionData("dailyFullTimeCustomer.MailerSKU"));
        }
        jsonCustomParam.put("LetterTextCode", testDataManager.getTestInputRegionData("subscriptionRequest.LetterTextCode"));
        jsonCustomParam.put("LeadTime", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        jsonCustomParam.put("OrderLineType", testDataManager.getTestInputRegionData("subscriptionRequest.OrderLineType"));
        jsonCustomParam.put("CollectedInStore", testDataManager.getTestInputRegionData("subscriptionRequest.CollectedInStore"));
        jsonCustomParam.put("BoxSize", testDataManager.getTestInputRegionData("Occasional.quantity"));
        jsonCustomParam.put("Payments", "3");
        requestSubscriptionBody.put("CustomFulfilmentParameters", jsonCustomParam);

        requestSubscriptionBody.put("FirstPack", "NONE");

        JSONObject jsonCustomInstructionParam = new JSONObject();
        jsonCustomInstructionParam.put("PayerType", payerType);
        jsonCustomInstructionParam.put("CLensFitNo", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        jsonCustomInstructionParam.put("TDRNo", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        jsonCustomInstructionParam.put("ExpiryDate", getFutureDaysDate(90));
        jsonCustomInstructionParam.put("AftercareStore", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        jsonCustomInstructionParam.put("MigratedSubscription", "Yes"); //commenting this parameter as records to be appear in standard order report
        jsonCustomInstructionParam.put("SubscriptionType", "Normal");
        requestSubscriptionBody.put("CustomPaymentInstructionParameters", jsonCustomInstructionParam);

        JSONObject jsonCustomPaymentParam = new JSONObject();
        jsonCustomPaymentParam.put("StoreNumber", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));

        requestSubscriptionBody.put("CustomPaymentParameters", jsonCustomPaymentParam);

        requestSubscriptionBody.put("NumberOfMonthsToCompletion", 27);
        return requestSubscriptionBody.toMap();
    }
    public String getMigratedSubscription(){
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("op", "replace");
        jsonBody.put("path", "/customPaymentInstructionParameters/MigratedSubscription");
        jsonBody.put("value","Yes");
        jsonArray.put(jsonBody);

        return jsonArray.toString();
    }

    public Map<String, ?> getSubscriptionRequestCDGBody(String payerType, String acc_reference,String cart_id, String add_id) {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));
        requestSubscriptionBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        requestSubscriptionBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        requestSubscriptionBody.put("account_id", acc_reference);
        requestSubscriptionBody.put("cart_id", cart_id);
        requestSubscriptionBody.put("address_id", add_id);
        requestSubscriptionBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("first_payment_date",getFutureDaysDate(12));
        requestSubscriptionBody.put("first_dispatch_date",getFutureDaysDate(72));
        requestSubscriptionBody.put("lead_time", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        requestSubscriptionBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        requestSubscriptionBody.put("subscription_length_months", testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));
        requestSubscriptionBody.put("account_type", payerType);
        requestSubscriptionBody.put("non_lens_mail_order", Boolean.valueOf(testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder")));
        requestSubscriptionBody.put("expiry_date", getFutureDaysDate(742));
        requestSubscriptionBody.put("first_pack", testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));
        requestSubscriptionBody.put("country_code", testDataManager.getTestInputRegionData("subscriptionRequest.country_code"));
        requestSubscriptionBody.put("required_payments", testDataManager.getTestInputRegionData("subscriptionRequest.required_payments"));
        requestSubscriptionBody.put("box_size", testDataManager.getTestInputRegionData("subscriptionRequest.box_size"));
        requestSubscriptionBody.put("MigratedSubscription", "No");

        return requestSubscriptionBody.toMap();
    }
    public String getBankHolidayDate() throws ParseException {
        Date holidayDate;
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat tfs = new SimpleDateFormat("dd/MM/yyyy");
        String todayDate = dateFormat.format(cal.getTime());
        Date currentDate = dateFormat.parse(todayDate);
        summaryPage.wantsToAddHolidayList(64);

        for(int i =1;i<summaryPage.bankHoliday.size();i++)
        {
            String holiday = summaryPage.bankHoliday.get(i);
            Date newFormat = tfs.parse(holiday);
            String nextBankHoliday = dateFormat.format(newFormat);
            holidayDate = dateFormat.parse(nextBankHoliday);
            if(holidayDate.after(currentDate))

            {
                summaryPage.getValidPaymentDate(holidayDate);
                cal.setTime(holidayDate);
                futureDate = dateFormat.format(cal.getTime());
                logger.info("Future date is "+futureDate);
                subscriptionPage.selectedPaymentDate = String.valueOf(tfs.format(cal.getTime()));
                cal.add(Calendar.MONTH, 2);
                dispatchedDateBankHoliday = dateFormat.format(cal.getTime());
                logger.info("Future dispatch date is "+dispatchedDateBankHoliday);
                break;
            }
        }

        return futureDate;

    }
    public Map<String, ?> getSubscriptionRequestWithPaymentOnBankHoliday( String cart_id, String add_id, String acc_reference) throws Exception {

        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("cart_id", cart_id);
        requestSubscriptionBody.put("address_id", add_id);
        requestSubscriptionBody.put("account_id", acc_reference);
        requestSubscriptionBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("first_payment_date", getBankHolidayDate());
        requestSubscriptionBody.put("first_dispatch_date", dispatchedDateBankHoliday);
        requestSubscriptionBody.put("lead_time", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));

        requestSubscriptionBody.put("non_lens_mail_order", Boolean.valueOf(testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder")));
        requestSubscriptionBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        requestSubscriptionBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));

        requestSubscriptionBody.put("first_pack",testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));

        requestSubscriptionBody.put("account_type", testDataManager.getTestInputRegionData("subscriptionRequest.PayerType"));
        requestSubscriptionBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        requestSubscriptionBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        requestSubscriptionBody.put("expiry_date", getFutureDaysDate(742));

        requestSubscriptionBody.put("subscription_length_months", testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));

        return requestSubscriptionBody.toMap();

    }
    public Map<String, ?> getSubscriptionRequestCDGBodyWithPaymentOnBankHolidayPostPay( String cart_id, String add_id, String acc_reference) throws ParseException {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("cart_id", cart_id);
        requestSubscriptionBody.put("address_id", add_id);
        requestSubscriptionBody.put("account_id", acc_reference);
        requestSubscriptionBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("first_payment_date", getBankHolidayDate());
        requestSubscriptionBody.put("first_dispatch_date", dispatchedDateBankHoliday);
        requestSubscriptionBody.put("lead_time", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));

        requestSubscriptionBody.put("non_lens_mail_order", Boolean.valueOf(testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder")));
        requestSubscriptionBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        requestSubscriptionBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));

        requestSubscriptionBody.put("first_pack",testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));

        requestSubscriptionBody.put("account_type", "POST");
        requestSubscriptionBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        requestSubscriptionBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        requestSubscriptionBody.put("expiry_date", getFutureDaysDate(742));

        requestSubscriptionBody.put("subscription_length_months", testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));

        return requestSubscriptionBody.toMap();
    }



    public Map<String, ?> getMonthlyCartJsonBodyCDG(String solutionType, String custType){
        JSONObject jsonBody = new JSONObject();

        JSONObject cartLeftJsonObj = new JSONObject();
        cartLeftJsonObj.put("quantity",testDataManager.getTestInputRegionData("cartJsonBody.quantity"));

        JSONObject leftPricingJsonObj = new JSONObject();
        leftPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData("cartJsonBody.gross_amount"));
        leftPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData("cartJsonBody.tax_amount"));
        leftPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData("cartJsonBody.net_amount"));
        leftPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("cartJsonBody.currency"));
        cartLeftJsonObj.put("pricing",leftPricingJsonObj);

        cartLeftJsonObj.put("product_description",testDataManager.getTestInputRegionData("cartJsonBody.product_description"));
        cartLeftJsonObj.put("product_id",testDataManager.getTestInputRegionData("cartJsonBody.product_id"));
        cartLeftJsonObj.put("usage",testDataManager.getTestInputRegionData("cartJsonBody.usage"));

        JSONObject lensDetailPricingJsonObj = new JSONObject();
        lensDetailPricingJsonObj.put("eye", testDataManager.getTestInputRegionData("cartJsonBody.eyeL"));

        JSONObject leftCLFitJsonObj = new JSONObject();
        leftCLFitJsonObj.put("add", testDataManager.getTestInputRegionData("cartJsonBody.Add"));
        leftCLFitJsonObj.put("add_type", testDataManager.getTestInputRegionData("cartJsonBody.add_type"));
        leftCLFitJsonObj.put("axis", testDataManager.getTestInputRegionData("cartJsonBody.Axis"));
        leftCLFitJsonObj.put("base_curve", testDataManager.getTestInputRegionData("cartJsonBody.base_curve"));
        leftCLFitJsonObj.put("cyl", testDataManager.getTestInputRegionData("cartJsonBody.Cyl"));
        leftCLFitJsonObj.put("diameter", testDataManager.getTestInputRegionData("cartJsonBody.Diameter"));
        leftCLFitJsonObj.put("lens_name", testDataManager.getTestInputRegionData("cartJsonBody.lens_name"));
        leftCLFitJsonObj.put("lens_supplier", testDataManager.getTestInputRegionData("cartJsonBody.lens_supplier"));
        leftCLFitJsonObj.put("power", testDataManager.getTestInputRegionData("cartJsonBody.Power"));
        leftCLFitJsonObj.put("sku", testDataManager.getTestInputRegionData("cartJsonBody.SKU"));
        leftCLFitJsonObj.put("style_number", testDataManager.getTestInputRegionData("cartJsonBody.style_number"));
        leftCLFitJsonObj.put("tint_desc", testDataManager.getTestInputRegionData("cartJsonBody.tint_desc"));
        lensDetailPricingJsonObj.put("clfit", leftCLFitJsonObj);
        cartLeftJsonObj.put("lens_detail", lensDetailPricingJsonObj);
        cartLeftJsonObj.put("box_size", testDataManager.getTestInputRegionData("montlySolutionCustomer.quantity"));

        JSONObject leftsolutionDetailsJsonObj = new JSONObject();
        leftsolutionDetailsJsonObj.put("solution_supplier_name", testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));
        leftsolutionDetailsJsonObj.put("solution_sku", testDataManager.getTestInputRegionData("cartJsonBody.solution_sku"));
        cartLeftJsonObj.put("solution_detail", leftsolutionDetailsJsonObj);

        jsonBody.put("left", cartLeftJsonObj);


        JSONObject cartRightJsonObj = new JSONObject();
        cartRightJsonObj.put("quantity",testDataManager.getTestInputRegionData("cartJsonBody.quantity"));

        JSONObject rightPricingJsonObj = new JSONObject();
        rightPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData("cartJsonBody.gross_amount"));
        rightPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData("cartJsonBody.tax_amount"));
        rightPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData("cartJsonBody.net_amount"));
        rightPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("cartJsonBody.currency"));
        cartRightJsonObj.put("pricing",rightPricingJsonObj);

        cartRightJsonObj.put("product_description",testDataManager.getTestInputRegionData("cartJsonBody.product_description"));
        cartRightJsonObj.put("product_id",testDataManager.getTestInputRegionData("cartJsonBody.product_id"));
        cartRightJsonObj.put("usage",testDataManager.getTestInputRegionData("cartJsonBody.usage"));

        JSONObject rightlensDetailPricingJsonObj = new JSONObject();
        rightlensDetailPricingJsonObj.put("eye", testDataManager.getTestInputRegionData("cartJsonBody.eyeR"));

        JSONObject rightCLFitJsonObj = new JSONObject();
        rightCLFitJsonObj.put("add", testDataManager.getTestInputRegionData("cartJsonBody.Add") );
        rightCLFitJsonObj.put("add_type", testDataManager.getTestInputRegionData("cartJsonBody.add_type"));
        rightCLFitJsonObj.put("axis", testDataManager.getTestInputRegionData("cartJsonBody.Axis"));
        rightCLFitJsonObj.put("base_curve", testDataManager.getTestInputRegionData("cartJsonBody.base_curve"));
        rightCLFitJsonObj.put("cyl", testDataManager.getTestInputRegionData("cartJsonBody.Cyl"));
        rightCLFitJsonObj.put("diameter", testDataManager.getTestInputRegionData("cartJsonBody.Diameter"));
        rightCLFitJsonObj.put("lens_name", testDataManager.getTestInputRegionData("cartJsonBody.lens_name"));
        rightCLFitJsonObj.put("lens_supplier", testDataManager.getTestInputRegionData("cartJsonBody.lens_supplier"));
        rightCLFitJsonObj.put("power", testDataManager.getTestInputRegionData("cartJsonBody.Power"));
        rightCLFitJsonObj.put("sku", testDataManager.getTestInputRegionData("cartJsonBody.SKU"));
        rightCLFitJsonObj.put("style_number", testDataManager.getTestInputRegionData("cartJsonBody.style_number"));
        rightCLFitJsonObj.put("tint_desc", testDataManager.getTestInputRegionData("cartJsonBody.tint_desc"));
        rightlensDetailPricingJsonObj.put("clfit", rightCLFitJsonObj);
        cartRightJsonObj.put("lens_detail", rightlensDetailPricingJsonObj);
        cartRightJsonObj.put("box_size", testDataManager.getTestInputRegionData("montlySolutionCustomer.quantity"));

        JSONObject rightsolutionDetailsJsonObj = new JSONObject();
        rightsolutionDetailsJsonObj.put("solution_supplier_name", testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));
        rightsolutionDetailsJsonObj.put("solution_sku", testDataManager.getTestInputRegionData("cartJsonBody.solution_sku"));
        cartLeftJsonObj.put("solution_detail", rightsolutionDetailsJsonObj);

        jsonBody.put("right", cartRightJsonObj);

        if(solutionType.equalsIgnoreCase("solution")){
            custType = "Monthly Solution";     // varibale value declared for Replacement Method
            JSONObject cartExtrasJsonObj = new JSONObject();

            JSONObject solutionJsonObj = new JSONObject();
            JSONObject solutionDetailsJsonObj = new JSONObject();
            solutionDetailsJsonObj.put("solution_supplier_name", testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));
            solutionDetailsJsonObj.put("solution_sku", testDataManager.getTestInputRegionData("cartJsonBody.solution_sku"));
            solutionJsonObj.put("solution_detail", solutionDetailsJsonObj);

            solutionJsonObj.put("product_description", testDataManager.getTestInputRegionData("cartJsonBody.product_description2"));
            solutionJsonObj.put("product_id", testDataManager.getTestInputRegionData("cartJsonBody.product_id2"));
            solutionJsonObj.put("quantity", testDataManager.getTestInputRegionData("cartJsonBody.quantity_sol"));

            JSONObject extrasPricingJsonObj = new JSONObject();
            extrasPricingJsonObj.put("gross_amount", testDataManager.getTestInputRegionData("cartJsonBody.gross_amount_sol"));
            extrasPricingJsonObj.put("tax_amount", testDataManager.getTestInputRegionData("cartJsonBody.tax_amount_sol"));
            extrasPricingJsonObj.put("net_amount", testDataManager.getTestInputRegionData("cartJsonBody.net_amount_sol"));
            extrasPricingJsonObj.put("currency", testDataManager.getTestInputRegionData("cartJsonBody.currency"));
            solutionJsonObj.put("pricing",extrasPricingJsonObj);

            cartExtrasJsonObj.put("solution", solutionJsonObj);

            jsonBody.put("extras", cartExtrasJsonObj);
        }
        jsonBody.put("total_cost", testDataManager.getTestInputRegionData("cartJsonBody.total_costSoln"));


        return jsonBody.toMap();
    }


    public Map<String, ?> getSubscriptionRequestWithRequiredPackUsingCDGBody( int packSize, String payerType, String acc_reference,String cart_id, String add_id) {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));
        requestSubscriptionBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        requestSubscriptionBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        requestSubscriptionBody.put("account_id", acc_reference);
        requestSubscriptionBody.put("cart_id", cart_id);
        requestSubscriptionBody.put("address_id", add_id);
        requestSubscriptionBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("first_payment_date",getFutureDaysDate(12));
        requestSubscriptionBody.put("first_dispatch_date",getFutureDaysDate(42));
        requestSubscriptionBody.put("lead_time", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        requestSubscriptionBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        requestSubscriptionBody.put("subscription_length_months", packSize);
        requestSubscriptionBody.put("account_type", payerType);
        requestSubscriptionBody.put("non_lens_mail_order", Boolean.valueOf(testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder")));
        requestSubscriptionBody.put("expiry_date", getFutureDaysDate(90));
        requestSubscriptionBody.put("first_pack", testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));
        requestSubscriptionBody.put("country_code", testDataManager.getTestInputRegionData("subscriptionRequest.country_code"));
        requestSubscriptionBody.put("required_payments", testDataManager.getTestInputRegionData("subscriptionRequest.required_payments"));
        requestSubscriptionBody.put("box_size", testDataManager.getTestInputRegionData("subscriptionRequest.box_size"));
        requestSubscriptionBody.put("MigratedSubscription", "No");

        return requestSubscriptionBody.toMap();
    }
    public Map<String, ?> getNonlensMailerSubscriptionRequestCDGBody( String payerType, String acc_reference,String cart_id, String add_id) {
        JSONObject requestSubscriptionBody = new JSONObject();

        requestSubscriptionBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));
        requestSubscriptionBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        requestSubscriptionBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        requestSubscriptionBody.put("account_id", acc_reference);
        requestSubscriptionBody.put("cart_id", cart_id);
        requestSubscriptionBody.put("address_id", add_id);
        requestSubscriptionBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("first_payment_date", getFutureDaysDate(12));
        requestSubscriptionBody.put("first_dispatch_date", getFutureDaysDate(42));
        requestSubscriptionBody.put("lead_time", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        requestSubscriptionBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        requestSubscriptionBody.put("account_type", payerType);
        requestSubscriptionBody.put("non_lens_mail_order", Boolean.valueOf(testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder")));
        requestSubscriptionBody.put("expiry_date", getFutureDaysDate(90));
        requestSubscriptionBody.put("first_pack", testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));


        return requestSubscriptionBody.toMap();


    }
    public Map<String, ?> jsonDataForChanegPackDeliveryDate(){
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("delivery_date", getFutureDaysDate(0));
        jsonBody.put("apply_all", false);
        return jsonBody.toMap();
    }
    public Map<String, ?> getSubscriptionRequestMPPBodyWithFirstPack( String cart_id, String add_id) {

        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("CartReference", cart_id);
        requestSubscriptionBody.put("AddressReference", add_id);
        requestSubscriptionBody.put("PaymentMethod", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("FirstPaymentDate", getFutureDaysDate(12)+"T00:00:00.000Z");
        requestSubscriptionBody.put("FirstDispatchDate", getFutureDaysDate(72)+"T00:00:00.000Z");
        requestSubscriptionBody.put("LeadTime", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("Description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));

        JSONObject jsonCustomParam = new JSONObject();
        jsonCustomParam.put("NonLensMailOrder", testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder"));
        jsonCustomParam.put("StoreName", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        jsonCustomParam.put("MailerQuantity", testDataManager.getTestInputRegionData("subscriptionRequest.MailerQuantity"));
        jsonCustomParam.put("StoreNumber", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        requestSubscriptionBody.put("CustomFulfilmentParameters", jsonCustomParam);

        requestSubscriptionBody.put("firstPack", testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));

        JSONObject jsonCustomInstructionParam = new JSONObject();
        jsonCustomInstructionParam.put("PayerType", testDataManager.getTestInputRegionData("subscriptionRequest.PayerType"));
        jsonCustomInstructionParam.put("CLensFitNo", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        jsonCustomInstructionParam.put("TDRNo", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        jsonCustomInstructionParam.put("ExpiryDate", getFutureDaysDate(742));
        requestSubscriptionBody.put("CustomPaymentInstructionParameters", jsonCustomInstructionParam);
        requestSubscriptionBody.put("NumberOfMonthsToCompletion", testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));
        jsonCustomParam.put("OrderLineType", testDataManager.getTestInputRegionData("subscriptionRequest.OrderLineType"));

        return requestSubscriptionBody.toMap();


    }
    public Map<String, ?> jsonDataForCartToChange(String cart_id) {
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("cart_id",cart_id);
        jsonBody.put("type",testDataManager.getTestInputRegionData("jsonDataForCartToChange.type"));
        return jsonBody.toMap();
    }
    public Map<String, ?> getCustomerJsonBodyForAddAddressToCustomer() {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("street", testDataManager.getTestInputRegionData("createCustomer.addressLine"));
        jsonBody.put("is_default", testDataManager.getTestInputRegionData("createCustomer.is_default"));
        jsonBody.put("address_type", testDataManager.getTestInputRegionData("createCustomer.address_type"));
        jsonBody.put("house_name",testDataManager.getTestInputRegionData("createCustomer.name"));
        jsonBody.put("town_city", testDataManager.getTestInputRegionData("createCustomer.town"));
        jsonBody.put("district", testDataManager.getTestInputRegionData("createCustomer.number"));
        jsonBody.put("county", testDataManager.getTestInputRegionData("createCustomer.county"));
        jsonBody.put("postcode", testDataManager.getTestInputRegionData("createCustomer.postcode"));
        jsonBody.put("country", testDataManager.getTestInputRegionData("createCustomer.countryName"));

        return jsonBody.toMap();
    }
    public Map<String, ?> getUpdateCustomerJsonBodyCDG(String accountReference,String add_id,String firstName,String lastName,String customerID,String emailID,String account_id, String paymentType) {
        JSONObject jsonBody = new JSONObject();

        JSONObject custJsonObj = new JSONObject();

        custJsonObj.put("mpp_store_id",testDataManager.getTestInputRegionData("createCustomer.mpp_store_id"));
        custJsonObj.put("mpp_store_name",testDataManager.getTestInputRegionData("createCustomer.mpp_store_name"));
        custJsonObj.put("client_user_id",testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID);
        custJsonObj.put("care_alert",testDataManager.getTestInputRegionData("updateCustomer.care_alert"));
        custJsonObj.put("debt_alert",testDataManager.getTestInputRegionData("updateCustomer.debt_alert"));
        custJsonObj.put("note_alert",testDataManager.getTestInputRegionData("updateCustomer.note_alert"));
        custJsonObj.put("gender",testDataManager.getTestInputRegionData("createCustomer.gender"));
        custJsonObj.put("payment_method_type",testDataManager.getTestInputRegionData("createCustomer.payment_method_type"));
        custJsonObj.put("customer_id",accountReference);
        custJsonObj.put("clss_registration",testDataManager.getTestInputCommonData("url.clss_registration"));
        custJsonObj.put("title",testDataManager.getTestInputRegionData("createCustomer.title"));
        custJsonObj.put("first_name",firstName);
        custJsonObj.put("last_name",lastName);
        custJsonObj.put("date_of_birth",testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));

        JSONObject accJsonObj = new JSONObject();
        accJsonObj.put("account_id",account_id);
        accJsonObj.put("resource_reference",accountReference);
        accJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.custStatus"));
        accJsonObj.put("lens_mail_start_date", getFutureDaysDate(12));

        JSONObject accValueJsonObj = new JSONObject();

        JSONArray customerValueArrayElement = new JSONArray();
        JSONObject customerValue = new JSONObject();
        customerValue.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        customerValue.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        customerValueArrayElement.put(customerValue);
        accValueJsonObj.put("total_customer_value", customerValueArrayElement);

        JSONArray totalPaymentToDateArrayElement = new JSONArray();
        JSONObject totalPaymentToDate = new JSONObject();
        totalPaymentToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        totalPaymentToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        totalPaymentToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        totalPaymentToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        totalPaymentToDateArrayElement.put(totalPaymentToDate);
        accValueJsonObj.put("total_payments_to_date", totalPaymentToDateArrayElement);

        JSONArray totalRefundToDateArrayElement = new JSONArray();
        JSONObject totalRefundToDate = new JSONObject();
        totalRefundToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        totalRefundToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        totalRefundToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        totalRefundToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        totalRefundToDateArrayElement.put(totalRefundToDate);
        accValueJsonObj.put("total_refunds_to_date", totalRefundToDateArrayElement);

        JSONArray outstandingPaymentsToDateArrayElement = new JSONArray();
        JSONObject outstandingPaymentsToDate = new JSONObject();
        outstandingPaymentsToDate.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        outstandingPaymentsToDate.put("quantity",testDataManager.getTestInputRegionData("updateCustomer.quantity"));
        outstandingPaymentsToDate.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        outstandingPaymentsToDate.put("average_value",testDataManager.getTestInputRegionData("updateCustomer.average_value"));
        outstandingPaymentsToDateArrayElement.put(outstandingPaymentsToDate);
        accValueJsonObj.put("outstanding_payments_to_date", outstandingPaymentsToDateArrayElement);

        JSONArray outstandingCreditBalanceArrayElement = new JSONArray();
        JSONObject outstandingCreditBalance = new JSONObject();
        outstandingCreditBalance.put("currency",testDataManager.getTestInputRegionData("updateCustomer.currency"));
        outstandingCreditBalance.put("total_value",testDataManager.getTestInputRegionData("updateCustomer.total_value"));
        outstandingCreditBalanceArrayElement.put(outstandingCreditBalance);
        accValueJsonObj.put("outstanding_credit_balance", outstandingCreditBalanceArrayElement);

        JSONObject customerContactDetails = new JSONObject();
        customerContactDetails.put("email",emailID);
        customerContactDetails.put("home_number", "776548765");
        customerContactDetails.put("mobile_number", "776543456");
        customerContactDetails.put("preferred_contact","NONE");


        JSONObject defaultAddress = new JSONObject();
        defaultAddress.put("id",add_id);
        defaultAddress.put("country",testDataManager.getTestInputRegionData("updateCustomer.country"));
        defaultAddress.put("county",testDataManager.getTestInputRegionData("updateCustomer.county"));
        defaultAddress.put("town_city",testDataManager.getTestInputRegionData("updateCustomer.town_city"));
        defaultAddress.put("district",testDataManager.getTestInputRegionData("updateCustomer.district"));
        defaultAddress.put("state",testDataManager.getTestInputRegionData("updateCustomer.state"));
        defaultAddress.put("house_flat_number",testDataManager.getTestInputRegionData("updateCustomer.house_flat_number"));
        defaultAddress.put("house_name",testDataManager.getTestInputRegionData("updateCustomer.house_name"));
        defaultAddress.put("street",testDataManager.getTestInputRegionData("updateCustomer.street"));
        defaultAddress.put("postcode",testDataManager.getTestInputRegionData("updateCustomer.postcode"));
        defaultAddress.put("is_default",testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        customerContactDetails.put("default_address",defaultAddress);

        JSONArray addressBookArrayElement = new JSONArray();
        JSONObject addressBook = new JSONObject();
        addressBook.put("id",add_id);
        addressBook.put("country",testDataManager.getTestInputRegionData("updateCustomer.country"));
        addressBook.put("county",testDataManager.getTestInputRegionData("updateCustomer.county"));
        addressBook.put("town_city",testDataManager.getTestInputRegionData("updateCustomer.town_city"));
        addressBook.put("district",testDataManager.getTestInputRegionData("updateCustomer.district"));
        addressBook.put("state",testDataManager.getTestInputRegionData("updateCustomer.state"));
        addressBook.put("house_flat_number",testDataManager.getTestInputRegionData("updateCustomer.house_flat_number"));
        addressBook.put("house_name",testDataManager.getTestInputRegionData("updateCustomer.house_name"));
        addressBook.put("street",testDataManager.getTestInputRegionData("updateCustomer.street"));
        addressBook.put("postcode",testDataManager.getTestInputRegionData("updateCustomer.postcode"));
        addressBook.put("is_default",testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        addressBookArrayElement.put(addressBook);

        JSONArray entitleArrayElement = new JSONArray();

        JSONObject subglassJsonObj = new JSONObject();
        subglassJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Sun"));
        subglassJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Sun"));
        subglassJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Sun"));
        subglassJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Sun"));
        subglassJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Sun"));
        entitleArrayElement.put(subglassJsonObj);

        JSONObject spareLenseJsonObj = new JSONObject();
        spareLenseJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Spare"));
        spareLenseJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Spare"));
        spareLenseJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Spare"));
        spareLenseJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Spare"));
        spareLenseJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Spare"));
        entitleArrayElement.put(spareLenseJsonObj);

        JSONObject afterCareJsonObj = new JSONObject();
        afterCareJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_After"));
        afterCareJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_After"));
        afterCareJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_After"));
        afterCareJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_After"));
        afterCareJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_After"));
        entitleArrayElement.put(afterCareJsonObj);

        JSONObject freeglasJsonObj = new JSONObject();
        freeglasJsonObj.put("identifier",testDataManager.getTestInputRegionData("updateCustomer.identifier_Free"));
        freeglasJsonObj.put("friendly_name",testDataManager.getTestInputRegionData("updateCustomer.friendly_name_Free"));
        freeglasJsonObj.put("claim_date",testDataManager.getTestInputRegionData("updateCustomer.claim_date_Free"));
        freeglasJsonObj.put("next_date",testDataManager.getTestInputRegionData("updateCustomer.next_date_Free"));
        freeglasJsonObj.put("status",testDataManager.getTestInputRegionData("updateCustomer.status_Free"));
        entitleArrayElement.put(freeglasJsonObj);

        JSONArray paymentMethod = new JSONArray();
        JSONObject paymentJSONBody = new JSONObject();
        if(testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod").equalsIgnoreCase("SEPA")) {
            JSONObject sepaJSONBody = new JSONObject();
            sepaJSONBody.put("account_holder_name", firstName);
            sepaJSONBody.put("bic", testDataManager.getTestInputRegionData(paymentType+".accNumbIc"));
            sepaJSONBody.put("iban", testDataManager.getTestInputRegionData(paymentType+".accSortiBan"));
            paymentJSONBody.put("sepa", sepaJSONBody);
            //paymentJSONBody.put("bacs", String.valueOf(null));      // commenting as the JSON that generated doesn't pass using null value
        }
        else {
            JSONObject bacsJSONBody = new JSONObject();
            bacsJSONBody.put("account_holder_name", firstName);
            bacsJSONBody.put("account_number",testDataManager.getTestInputRegionData(paymentType+".accNumbIc"));
            bacsJSONBody.put("sort_code", testDataManager.getTestInputRegionData(paymentType+".accSortiBan"));
            bacsJSONBody.put("payment_method_type", "BACS");
            paymentJSONBody.put("bacs", bacsJSONBody);
        }
        paymentMethod.put(paymentJSONBody);

        custJsonObj.put("entitlements",entitleArrayElement);
        custJsonObj.put("address_book",addressBookArrayElement);
        custJsonObj.put("customer_contact_details",customerContactDetails);
        accJsonObj.put("value", accValueJsonObj);
        custJsonObj.put("account", accJsonObj);
        jsonBody.put("customer", custJsonObj);
        jsonBody.put("payment_methods",paymentMethod);


        return jsonBody.toMap();

    }
    public Map<String, ?> updateAddressBody(String add_id, String clientUser_id){
        JSONObject updateAddress = new JSONObject();
        JSONObject addressBookJson = new JSONObject();
        addressBookJson.put("id",add_id);
        addressBookJson.put("country",testDataManager.getTestInputRegionData("updateAddress.country"));
        addressBookJson.put("county",testDataManager.getTestInputRegionData("updateAddress.county") );
        addressBookJson.put("town_city", testDataManager.getTestInputRegionData("updateAddress.town_city"));
        addressBookJson.put("district",testDataManager.getTestInputRegionData("updateAddress.district"));
        addressBookJson.put("state",testDataManager.getTestInputRegionData("updateAddress.state"));
        addressBookJson.put("house_flat_number",testDataManager.getTestInputRegionData("updateAddress.house_flat_number"));
        addressBookJson.put("house_name",testDataManager.getTestInputRegionData("updateAddress.house_name"));
        addressBookJson.put("street",testDataManager.getTestInputRegionData("updateAddress.street"));
        addressBookJson.put("postcode",testDataManager.getTestInputRegionData("updateAddress.postcode"));
        addressBookJson.put("is_default",testDataManager.getTestInputRegionData("updateAddress.is_default"));
        JSONArray addressBookElement = new JSONArray();
        addressBookElement.put(addressBookJson);
        JSONObject customerJson = new JSONObject();
        customerJson.put("client_user_id",testDataManager.getTestInputRegionData("address.storeNo")+"-"+clientUser_id);
        customerJson.put("address_book",addressBookElement);
        updateAddress.put("customer", customerJson);
        return updateAddress.toMap();
    }

    public Map<String, ?> getAddressJsonBodyCDG() {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("country", "Ireland");
        jsonBody.put("county","Test");
        jsonBody.put("town_city","Tes");
        jsonBody.put("district", "Test");
        jsonBody.put("house_flat_number", "1");
        jsonBody.put("house_name", "Test");
        jsonBody.put("street", "Test");
        jsonBody.put("postcode", "TE12 4ST");
        jsonBody.put("is_default", "false");
        jsonBody.put("address_type", "Home");

        return jsonBody.toMap();

    }
    public Map<String, ?> getPaymentBodyWithInvalidBIC(String bic,String firstName){
        JSONObject paymentJSONBody = new JSONObject();
        JSONObject jSONBody = new JSONObject();
        jSONBody.put("account_holder_name",firstName);
        jSONBody.put("accNumbIc",bic);
        jSONBody.put("accSortiBan", testDataManager.getTestInputRegionData("payment.accSortiBan"));
        paymentJSONBody.put("BACS", jSONBody);
        return paymentJSONBody.toMap();
    }
    public Map<String, ?> getPaymentBodyWithInvalidIBAN(String iban,String firstName){
        JSONObject paymentJSONBody = new JSONObject();
        JSONObject jSONBody = new JSONObject();
        jSONBody.put("account_holder_name",firstName);
        jSONBody.put("accNumbIc",testDataManager.getTestInputRegionData("payment.accNumbIc"));
        jSONBody.put("accSortiBan",iban);
        paymentJSONBody.put("BACS", jSONBody);
        return paymentJSONBody.toMap();
    }
    public Map<String, ?> getDeleteSubscriptionBody() {

        JSONObject jSONBody = new JSONObject();

        jSONBody.put("reason",testDataManager.getTestInputRegionData("subscription.reason"));

        return jSONBody.toMap();
    }
    public Map<String, ?> getWriteOffBody(String writeOffType,String authCode){
        JSONObject writeOffJSONBody = new JSONObject();
        writeOffJSONBody.put("write_off_type", writeOffType);
        writeOffJSONBody.put("auth_code", authCode);
        return writeOffJSONBody.toMap();
    }
    public Map<String, ?> migrateCustomerBody(){
        JSONObject JSONBody = new JSONObject();
        JSONBody.put("op", "replace");
        JSONBody.put("path","/customPaymentInstructionParameters/MigratedSubscription");
        JSONBody.put("value","true");
        return JSONBody.toMap();

    }
    public Map<String, ?> jsonDataForHolidayPack(String serviceCredit) {
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("service_credit",serviceCredit);
        return jsonBody.toMap();
    }
    public Map<String, ?> jsonDataForRefundPayment(Boolean serviceCredit,String grossAmount,String refundReason) {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("amount",grossAmount);
        jsonBody.put("refund_reason",refundReason);
        //jsonBody.put("payment_date",payment_date);
        jsonBody.put("service_credit",serviceCredit);
        return jsonBody.toMap();
    }
    public Map<String, ?> jsonDataForReinstatePack(String packStatus) {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("status", packStatus);
        return jsonBody.toMap();
    }
    public Map<String, ?> jsonDataForStoreTransfer(String client_user_id) {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("store_id",testDataManager.getTestInputRegionData("storeToStoreTransfer.number"));
        jsonBody.put("socrates_customer_id",client_user_id);
        jsonBody.put("store_name",testDataManager.getTestInputRegionData("storeToStoreTransfer.name"));
        return jsonBody.toMap();
    }
    public Map<String, ?> getNonLensMailerSubscriptionRequestMPPBody(String cart_id,String add_id) {

        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("CartReference", cart_id);
        requestSubscriptionBody.put("AddressReference", add_id);
        System.out.println();
        requestSubscriptionBody.put("PaymentMethod", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        requestSubscriptionBody.put("FirstPaymentDate", getFutureDaysDate(12)+"T00:00:00.000Z");
        requestSubscriptionBody.put("FirstDispatchDate", getFutureDaysDate(72)+"T00:00:00.000Z");
        requestSubscriptionBody.put("LeadTime", testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        requestSubscriptionBody.put("Description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));

        JSONObject jsonCustomParam = new JSONObject();
        jsonCustomParam.put("NonLensMailOrder", testDataManager.getTestInputRegionData("updateCustomer.is_default"));
        jsonCustomParam.put("StoreName", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        jsonCustomParam.put("MailerQuantity", testDataManager.getTestInputRegionData("subscriptionRequest.MailerQuantity"));
        jsonCustomParam.put("StoreNumber", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        jsonCustomParam.put("LetterTextCode", testDataManager.getTestInputRegionData("subscriptionRequest.LetterTextCode"));
//      jsonCustomParam.put("MailerSKU", testObj.getTestData(dailytype).get("MailerSKU"));
        jsonCustomParam.put("MailerSKU", "8088");
        jsonCustomParam.put("OrderLineType", testDataManager.getTestInputRegionData("subscriptionRequest.OrderLineType"));
        jsonCustomParam.put("DeliveryInstructions", testDataManager.getTestInputRegionData("subscriptionRequest.DeliveryInstructions"));
        jsonCustomParam.put("OrderDetails", testDataManager.getTestInputRegionData("subscriptionRequest.OrderDetails"));
        jsonCustomParam.put("CollectedInStore", testDataManager.getTestInputRegionData("subscriptionRequest.CollectedInStore"));
        requestSubscriptionBody.put("CustomFulfilmentParameters", jsonCustomParam);

        requestSubscriptionBody.put("firstPack", testDataManager.getTestInputRegionData("subscriptionRequest.firstPack"));

        JSONObject jsonCustomInstructionParam = new JSONObject();
        jsonCustomInstructionParam.put("PayerType", testDataManager.getTestInputRegionData("subscriptionRequest.PayerType"));
        jsonCustomInstructionParam.put("CLensFitNo", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        jsonCustomInstructionParam.put("TDRNo", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        jsonCustomInstructionParam.put("ExpiryDate", getFutureDaysDate(742));
        requestSubscriptionBody.put("CustomPaymentInstructionParameters", jsonCustomInstructionParam);

        requestSubscriptionBody.put("NumberOfMonthsToCompletion", testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));
        jsonCustomParam.put("OrderLineType", testDataManager.getTestInputRegionData("subscriptionRequest.OrderLineType"));
        return requestSubscriptionBody.toMap();

    }
    public Map<String, ?> jsonDataForReplacePack(String add_id) {

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("right_quantity",testDataManager.getTestInputRegionData("replacePack.right_quantity"));
        jsonBody.put("left_quantity",testDataManager.getTestInputRegionData("replacePack.left_quantity"));
        jsonBody.put("replenishment_quantity",testDataManager.getTestInputRegionData("replacePack.replenishment_quantity"));
        jsonBody.put("solution_quantity",testDataManager.getTestInputRegionData("replacePack.solution_quantity"));
        jsonBody.put("order_reason",testDataManager.getTestInputRegionData("replacePack.order_reason"));
        jsonBody.put("address_id",add_id);
        jsonBody.put("payment_method",testDataManager.getTestInputRegionData("replacePack.payment_method"));
        return jsonBody.toMap();
    }
    public Map<String, ?> jsonDataForExpeditePackWithPastDeliveryDate() {
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("delivery_date",testDataManager.getTestInputRegionData("pastDeliveryDate.payment_date"));
        return jsonBody.toMap();
    }

    public Map<String, ?> getSubscriptionBodyWithPastFirstPaymentDate(String firstPack,String add_id,String acc_reference,String cart_id) {
        JSONObject subscriptionJSONBody = new JSONObject();
        subscriptionJSONBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));
        subscriptionJSONBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        subscriptionJSONBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        subscriptionJSONBody.put("account_id",acc_reference);
        subscriptionJSONBody.put("cart_id",cart_id);
        subscriptionJSONBody.put("address_id",add_id);
        subscriptionJSONBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        subscriptionJSONBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        subscriptionJSONBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        subscriptionJSONBody.put("first_dispatch_date", getFutureDaysDate(3));
        subscriptionJSONBody.put("first_payment_date", testDataManager.getTestInputRegionData("subscriptionRequest.FirstPaymentDate"));
        subscriptionJSONBody.put("subscription_length_months",testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));
        subscriptionJSONBody.put("account_type", testDataManager.getTestInputRegionData("subscriptionRequest.PayerType"));
        subscriptionJSONBody.put("non_lens_mail_order", testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder"));
        subscriptionJSONBody.put("expiry_date", getFutureDaysDate(1));
        subscriptionJSONBody.put("first_pack", firstPack);
        subscriptionJSONBody.put("lead_time",testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        return subscriptionJSONBody.toMap();
    }
    public Map<String, ?> getSubscriptionBodyWithPastFirstDispatchDate(String firstPack,String add_id,String acc_reference,String cart_id) {
        JSONObject subscriptionJSONBody = new JSONObject();
        subscriptionJSONBody.put("description", testDataManager.getTestInputRegionData("subscriptionRequest.Description"));
        subscriptionJSONBody.put("store_id", testDataManager.getTestInputRegionData("subscriptionRequest.StoreNumber"));
        subscriptionJSONBody.put("store_name", testDataManager.getTestInputRegionData("subscriptionRequest.StoreName"));
        subscriptionJSONBody.put("account_id",acc_reference);
        subscriptionJSONBody.put("cart_id",cart_id);
        subscriptionJSONBody.put("address_id",add_id);
        subscriptionJSONBody.put("payment_method", testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod"));
        subscriptionJSONBody.put("clfit_number", testDataManager.getTestInputRegionData("subscriptionRequest.CLensFitNo"));
        subscriptionJSONBody.put("tdr_number", testDataManager.getTestInputRegionData("subscriptionRequest.TDRNo"));
        subscriptionJSONBody.put("first_dispatch_date",  testDataManager.getTestInputRegionData("subscriptionRequest.FirstDispatchDate"));
        subscriptionJSONBody.put("first_payment_date",getFutureDaysDate(10));
        subscriptionJSONBody.put("subscription_length_months",testDataManager.getTestInputRegionData("subscriptionRequest.NumberOfMonthsToCompletion"));
        subscriptionJSONBody.put("account_type", testDataManager.getTestInputRegionData("subscriptionRequest.PayerType"));
        subscriptionJSONBody.put("non_lens_mail_order", testDataManager.getTestInputRegionData("subscriptionRequest.NonLensMailOrder"));
        subscriptionJSONBody.put("expiry_date", getFutureDaysDate(1));
        subscriptionJSONBody.put("first_pack", firstPack);
        subscriptionJSONBody.put("lead_time",testDataManager.getTestInputRegionData("subscriptionRequest.LeadTime"));
        return subscriptionJSONBody.toMap();
    }



}
