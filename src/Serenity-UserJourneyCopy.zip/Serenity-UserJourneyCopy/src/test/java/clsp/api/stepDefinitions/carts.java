package clsp.api.stepDefinitions;

import clsp.api.steps.navigateToAPI;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class carts extends ScenarioSteps  {

    @Steps
    navigateToAPI navigateToAPI = new navigateToAPI();

    @Step("setup clean session")
    public void cleanSession() {
        navigateToAPI.cleanSession();
    }
    @Step("user creates cart")
    public void userTriesToAddACart(int status) {
        navigateToAPI.userCreatesCart(status);
    }
    @Step("user performs get cart")
    public void userMustBeAbleToValidateTheNewlyCreatedCart(int status) {
        navigateToAPI.userMustBeAbleToValidateTheNewlyCreatedCart(status);
    }
    @Step("user requests for get cart")
    public void userMustBeAbleToGetCart(int status) {
        navigateToAPI.userMustBeAbleToGetCart(status);
    }
    @Step("user requests to change the cart of account")
    public void userRequestsToChangeTheCartOfAnAccount(int status){
        navigateToAPI.requestsToChangeTheCartOfAnAccount(status);
    }
    @Step("")
    public void userRequestToChangeTheCartAfterPaymentCompleted(int status){
        navigateToAPI.userRequestToChangeTheCartAfterPaymentCompleted(status);
    }
    @Step("user get subscription details")
    public void userGetsTheSubscriptionDetails(int status){
        navigateToAPI.userGetsTheSubscriptionDetails(status);
    }
    @Step("user requests to apply invalid promotion on cart")
    public void userRequestsToApplyInvalidPromotionOnTheCart(int status,String storeId,String voucher,String authCode){
        navigateToAPI.userRequestsToApplyInvalidPromotionOnTheCart(status,storeId,voucher,authCode);
    }
    @Step("user request to validate invalid promotion on cart")
    public void userRequestToValidateThatInvalidPromotionOnCart(int status, String storeId,String voucher,String authCode){
        navigateToAPI.userRequestToValidateThatInvalidPromotionOnCart(status,storeId,voucher,authCode);
    }


}
