package clsp.api.tests.Core;

import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.api.stepDefinitions.carts;
import clsp.api.stepDefinitions.customerSignupSteps;
import clsp.api.stepDefinitions.productPriceConfigurator;
import clsp.api.stepDefinitions.socrates;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class CustomerTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    carts cartsSteps;

    @Steps
    socrates socratesSteps;

    @Steps
    customerSignupSteps subscriptionSteps;
    @Steps
    productPriceConfigurator productPriceConfigurator;

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Customer,Find customer for given criteria,Search for customers matching given criteria, Retrieve a customer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void verifyFindCustomerAndMatchingCriteria(int status, int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToFindCustomerWithAccountId(status);
        subscriptionSteps.userMustBeAbleToSearchCustomerMatchingCriteria(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Customer,Add address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyCreateAndAddAddress(int status, int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToAddAddressForTheCustomer(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,UK,8173,100080,1000079,77"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Retrieve a customer's CLFIT data", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyRetrieveClFitDetails(int status,String countryCode,String storeId,String accountId, String tdr, String clfit) {
        cartsSteps.cleanSession();
        subscriptionSteps.userRequestToGetCustomerWithCLFITData(countryCode,storeId,accountId,tdr,clfit);
        socratesSteps.userRequestToRetrieveAnyParticularStore(storeId);
        productPriceConfigurator.userRequestForPriceOptions(status);
        productPriceConfigurator.userValidatesTheResponseBodyForPriceOptions();
        subscriptionSteps.userRetrievesCustomerCLFITData(countryCode,storeId,accountId,tdr,clfit);

    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,UK,8173,100080,1000079,77,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Get Customer With CLFIT", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyCustomerClFit(int status,String countryCode,String storeId,String accountId, String tdr, String clfit, int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userRequestToGetCustomerWithCLFITData(countryCode,storeId,accountId,tdr,clfit);
        productPriceConfigurator.theResponseStatusCodeIs(status);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Update_Customer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUpdateCustomer(int status,int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToAddAddressForTheCustomer(status);
        subscriptionSteps.userUpdatesTheDetailsOfCustomer(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Customer,Update address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyAddAndUpdateAddress(int status,int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToAddAddressForTheCustomer(status);
        subscriptionSteps.userTriesToUpdateAddressForTheCustomer(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Customer,Search Account Using Last Name", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUserFindCustomerUsingLastName(int status,int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        subscriptionSteps.userTriesToFindCustomerWithLastname(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
}
