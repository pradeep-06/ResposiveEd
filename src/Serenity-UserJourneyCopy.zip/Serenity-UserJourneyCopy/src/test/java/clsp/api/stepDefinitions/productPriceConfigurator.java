package clsp.api.stepDefinitions;


import clsp.api.steps.navigateToAPI;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class productPriceConfigurator extends ScenarioSteps {

    @Steps
    navigateToAPI navigateToAPI = new navigateToAPI();

    @Step("user request for price options")
    public void userRequestForPriceOptions(int status){
        navigateToAPI.userRequestForPriceOptions(status);
    }
    @Step("user validates the response body for price options")
    public void userValidatesTheResponseBodyForPriceOptions(){
        navigateToAPI.userValidatesTheResponseBodyForPriceOptions();
    }
    @Step("user verify status code")
    public void theResponseStatusCodeIs(int statusCode){
        navigateToAPI.theResponseStatusCodeIs(statusCode);
    }
}
