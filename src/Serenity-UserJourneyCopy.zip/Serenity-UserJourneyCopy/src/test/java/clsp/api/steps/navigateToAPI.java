package clsp.api.steps;

import clsp.api.pages.whenDealingwithCarts;
import clsp.api.pages.whenDealingwithCustomer;
import clsp.api.pages.whenDealingwithProductPriceConfigurator;
import clsp.api.pages.whenDealingwithSocrates;
import clsp.api.pages.whenDealingwithSubscription;
import net.thucydides.core.steps.ScenarioSteps;

public class navigateToAPI extends ScenarioSteps {


    whenDealingwithSubscription whenDealingwithSubscription = new whenDealingwithSubscription();
    whenDealingwithCarts whenDealingWithCarts = new whenDealingwithCarts();
    whenDealingwithCustomer whenDealingwithCustomer = new whenDealingwithCustomer();
    whenDealingwithSocrates whenDealingwithSocrates = new whenDealingwithSocrates();
    whenDealingwithProductPriceConfigurator whenDealingwithProductPriceConfigurator = new whenDealingwithProductPriceConfigurator();

    public void cleanSession() {
        whenDealingwithSubscription.setUpCleanSession();
    }

    public void userRequestForNewCustomerOnCDG(int status) {
    whenDealingwithSubscription.userRequestForNewCustomerOnCDG(status);

    }

    public void userCreatesCart(int status) {
        whenDealingWithCarts.userCreatesCart("No solution",status);
    }
    public void userMustBeAbleToValidateTheNewlyCreatedCart(int status) {
        whenDealingWithCarts.userPerformsGetCart(status);
    }
    public void userMustBeAbleToGetCart(int status) {
        whenDealingWithCarts.userRequestsForGetCart(status);
    }
    public void deleteCustomer(int status) {
        whenDealingwithSubscription.deleteCustomer(status);
    }
    public void userMakesPayment() {
        whenDealingwithSubscription.userMakesPayment();
    }
    public void userCreatesSameDayPaymentSubscriptionUsingMPP(int status, String payerType, String discountType) {
        whenDealingwithCustomer.userCreatesSameDayPaymentSubscriptionUsingMPP(status,payerType,discountType,whenDealingwithSubscription.acc_reference,whenDealingWithCarts.cart_id,whenDealingwithSubscription.custType);
    }
    public void userSearchesSubscription(int status) {
        whenDealingwithSubscription.userSearchesSubscription(status);
    }
    public void userRetrivesSubscriptionDetails(int status) {

    }
    public void userRetrievesCustomerData(int status){
        whenDealingwithCustomer.userRetrievesCustomerData(status);
    }
    public void userShouldBeAbleToCreateSubscription(String payerType){
        whenDealingwithSubscription.userCreatesSubscriptionUsingCDG(payerType,whenDealingWithCarts.cart_id);
    }
    public void requestsToChangeTheCartOfAnAccount(int status){
        whenDealingWithCarts.requestsToChangeTheCartOfAnAccount(status,whenDealingwithSubscription.acc_reference,whenDealingwithSubscription.subscription_id);
    }
    public void createDailyCustomer(String dailyType,int quantity,int status){
        whenDealingwithSubscription.createDailyCustomer(dailyType,quantity,status,"PRE");
    }
    public void userAddsAdditionalCart(String dailyType, int quantity){
        whenDealingwithSubscription.userTriesToAddACartForDailyCustomer(dailyType,quantity);
    }
    public void createDailyCustomerPaymentCompleted(String dailyType,int quantity,int status){
        whenDealingwithSubscription.createDailyCustomerPaymentCompleted(dailyType,quantity,status);
    }
    public void userRequestToChangeTheCartAfterPaymentCompleted(int status) {
        whenDealingwithSubscription.userGetsTheSubscriptionDetails(0);
        ///whenDealingWithCarts.requestsToChangeTheCartOfAnAccount(status);
        whenDealingWithCarts.verifyChangeUsageWhenOnePaymentCompleted(whenDealingwithSubscription.changeUsageAmount,whenDealingwithSubscription.changeAmount);
    }
    public void userTriesToFindCustomerWithAccountId(int status) {
        whenDealingwithCustomer.userSearchesForCustomerUsingAccountID(status,whenDealingwithSubscription.customerID);
    }
    public void userMustBeAbleToSearchCustomerMatchingCriteria(int status) {
        whenDealingwithCustomer.userSearchesCustomerMatchingCriteria(status,whenDealingwithSubscription.customerID);
    }
    public void userGetsTheSubscriptionDetails(int status) {
        whenDealingwithSubscription.userGetsTheSubscriptionDetails(0);
    }
    public void userTriesToAddAddressForTheCustomer(int status) {
        whenDealingwithCustomer.userAddsAddress(status,whenDealingwithSubscription.acc_reference);
    }
    public void userMustBeAbleToVerifyThePaymentDetails(int status) {
        whenDealingWithCarts.userCreatesCart("No solution",status);
        whenDealingwithSubscription.userMakesPayment();
        whenDealingwithCustomer.userVerifiesPaymentDetails(status,whenDealingwithSubscription.acc_reference);
    }
    public void userRequestToGetCustomerWithCLFITData(String countryCode, String storeId, String accountId, String tdr, String clfit) {
        whenDealingwithCustomer.retrievesCustomerCLFITData(countryCode,storeId,accountId,tdr,clfit);
    }
    public void userRequestToRetrieveAnyParticularStore(String storeId) {
        whenDealingwithSocrates.requestToRetrieveAnyParticularStore(storeId);
    }
    public void userRequestForPriceOptions(int status) {
        whenDealingwithProductPriceConfigurator.userRequestForPriceOptions(status,whenDealingwithCustomer.left_style_no,whenDealingwithCustomer.right_style_no,whenDealingwithSocrates.country_code,whenDealingwithSocrates.tax_code);
    }
    public void userValidatesTheResponseBodyForPriceOptions() {
        whenDealingwithProductPriceConfigurator.validatePriceOptionsBody();
    }
    public void userRetrievesCustomerCLFITData(String countryCode, String storeId, String accountId, String tdr, String clfit ) {
        whenDealingwithCustomer.retrievesCustomerCLFITData(countryCode,storeId,accountId,tdr,clfit);
    }
    public void theResponseStatusCodeIs(int statusCode){
        whenDealingwithProductPriceConfigurator.theResponseStatusCodeIs(statusCode);
    }
    public void userUpdatesTheDetailsOfCustomer(int status) {
        whenDealingwithCustomer.requestToUpdateCustomer(status,whenDealingwithSubscription.acc_reference,whenDealingwithSubscription.customerID, whenDealingwithSubscription.emailID, whenDealingwithSubscription.account_id,"payment");
    }
    public void userTriesToUpdateAddressForTheCustomer(int status) {
        whenDealingwithCustomer.userUpdateAddress(status,whenDealingwithSubscription.acc_reference,whenDealingwithSubscription.customerID);
    }
    public void userTriesToFindCustomerWithLastname(int status) {
        whenDealingwithCustomer.userSearchesForCustomerUsingLastname(status);
    }
    public void userTriesToAddAddressWithInvalidAccountReference(String accountReference,int status) {
        whenDealingwithCustomer.userAddsAddressWithInvalidAccountReference(accountReference,status);
    }
    public void userRequestsToUpdatePaymentDetailsForInvalidBIC(String bic,int status) {
        whenDealingwithCustomer.requestsToUpdatePaymentDetailsForInvalidBIC(bic,status,whenDealingwithSubscription.acc_reference,whenDealingwithSubscription.firstName);
    }
    public void requestsToUpdatePaymentDetailsForInvalidIBAN(String iban,int status) {
        whenDealingwithCustomer.requestsToUpdatePaymentDetailsForInvalidIBAN(iban,status,whenDealingwithSubscription.acc_reference,whenDealingwithSubscription.firstName);
    }
    public void userMustBeAbleToCancelTheSubscription(int status) {
        whenDealingwithSubscription.userCancelsSubscription(status);
    }
    public void userTriesToAuthenticateStore(int status, String authCode, String responseString) {
        whenDealingwithSubscription.userAuthenticatesStore(status, authCode,responseString);

    }
    public void userTriesToPerformWriteOn(int status, String writeOffType, String authCode) {
        whenDealingwithSubscription.userPerformsWriteOn(status,writeOffType,authCode);
    }
    public void userGetsTheBalanceAmountForSubscription() {
        whenDealingwithSubscription.userGetsTheBalanceAmountForSubscription();
    }
    public void userRequestsToUpdatePack(String packStatus, int status) {
        whenDealingwithSubscription.userUpdatesPackStatus(packStatus,status);
    }
    public void userPerformHolidayPackWhenPaymentCompleted(int status, String serviceCredit ) {
        whenDealingwithSubscription.performHolidayPackWhenPaymentCompleted(status,serviceCredit);
    }
    public void userRequestsToRefundPayment(int status, Boolean serviceCredit, String refundReason) {
        whenDealingwithSubscription.requestsToRefundPayment(status, serviceCredit,refundReason);
    }
    public void userShouldNotBeAbleToPerformReinstatePack(int status, String packStatus, String paymentStatus) {
        whenDealingwithSubscription.unableToReinstatePack(status, packStatus, paymentStatus);
    }
    public void userMustBeAbleToVerifyThePaymentStatus(String WriteOffType) {
        whenDealingwithSubscription.userVerifiesPaymentStatusAfterGoodwillIsPerformed(WriteOffType);
    }
    public void userTriesToFindCustomerWithInvalidCustomerId(String customerId,int status) {
        whenDealingwithCustomer.userSearchesCustomerWithInvalidCustomerId(customerId,status);
    }
    public void userAbleToSearchMatchingCriteriaWithInvalidCustomerId(String customerId,int status) {
        whenDealingwithCustomer.userSearchesMatchingCriteriaWithInvalidCustomerId(customerId,status);
    }
    public void userRetrieveCustomerDataWithInvalidAccountReference(String accountReference,int newStatus) {
        whenDealingwithCustomer.userRetrievesCustomerDataWithInvalidAccountReference(accountReference,newStatus);
    }
    public void userRequestsToUpdatePaymentDetailsForInvalidBIC(String bic,int status, String acc_reference,String firstName) {
        whenDealingwithCustomer.requestsToUpdatePaymentDetailsForInvalidBIC(bic,status,acc_reference,firstName);
    }
    public void userRequestsToUpdatePaymentDetailsForInvalidIBAN(String iban,int status, String acc_reference,String firstName) {
        whenDealingwithCustomer.requestsToUpdatePaymentDetailsForInvalidIBAN(iban,status,acc_reference,firstName);
    }
    public void validateResponseAndStatusCodeForInvalidStore(int status,int invalidStoreId) {
        whenDealingwithCustomer.validateResponseAndStatusCodeForInvalidStore(status,invalidStoreId);
    }
    public void userValidateResponseAndStatusCodeForCLFIT(int status) {
        whenDealingwithCustomer.validateResponseAndStatusCodeForCLFIT(status);
    }
    public void userRequestsToApplyInvalidPromotionOnTheCart(int status,String storeId,String voucher,String authCode) {
        whenDealingWithCarts.requestsToApplyInvalidPromotionOnTheCart(status,storeId,voucher,authCode);
    }
    public void userRequestToValidateThatInvalidPromotionOnCart(int status, String storeId,String voucher,String authCode) {
        whenDealingWithCarts.requestToValidateThatInvalidPromotionOnCart(status,storeId,voucher,authCode);
    }
    public void userRequestsToTransferTheInvalidStore(int status,String customerID) {
        whenDealingwithSubscription.userRequestsToTransferTheStore(status,customerID);
        whenDealingwithSubscription.userRequestsToTransferTheInvalidStore();
    }
    public void userRequestToAuthenticateStore(String invalidStoreId,String authCode) {
        whenDealingwithSocrates.userRequestToAuthenticateStore(invalidStoreId,authCode);
    }
    public void userValidatesTheResponseBodyForThatInvalidStore(int status,String invalidStoreId) {
        whenDealingwithSocrates.validatesTheResponseBodyForThatInvalidStore(status,invalidStoreId);
    }
    public void userRequestsToReplaceInvalidPack(int status) {
        whenDealingwithSubscription.requestsToReplacePack(status);
        whenDealingwithSubscription.userRequestsToAssertErrorMessage();
    }
    public void userRequestsToExpeditePackWithPastDeliveryDate(int status) {
        whenDealingwithSubscription.requestsToExpeditePackWithPastDeliveryDate(status);
    }
    public void userMustNotBeAbleToCreateSubscriptionWithPaymentDate(int status, String firstPack) {
        whenDealingwithSubscription.userCreatesSubscriptionOnCDGWithPastFirstPaymentDate(status,firstPack);
    }
    public void userMustNotBeAbleToCreateSubscriptionWithDispatchDate(int status, String firstPack) {
        whenDealingwithSubscription.userCreatesSubscriptionOnCDGWithPastFirstDispatchDate(status,firstPack);
    }

    public void userAddAddressWithInvalidAccReference(String accountReference, int status){
        whenDealingwithSubscription.userAddAddressWithInvalidAccReference(accountReference, status);
    }

    public void userRequestsToUpdatePaymentwithPastDeliveryDate(int status){
        whenDealingwithSubscription.userRequestsToUpdatePaymentwithPastDeliveryDate(status);
    }




}
