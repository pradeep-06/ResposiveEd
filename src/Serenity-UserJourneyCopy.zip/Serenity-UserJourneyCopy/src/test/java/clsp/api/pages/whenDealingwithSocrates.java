package clsp.api.pages;

import Framework.api.request.APIRequests;
import Framework.api.request.Headers;
import clsp.api.extentions.clspApiBase;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class whenDealingwithSocrates extends clspApiBase {
    private final Logger logger = LoggerFactory.getLogger(whenDealingwithSocrates.class);
    public clspApiBase clspApiRequest = new clspApiBase();
    public APIRequests apiRequests = new APIRequests();
    private static final Headers header = new Headers();
    public static String country_code;
    public static String tax_code;
    public String xApiKey=testDataManager.getTestInputCommonData("url.apiKeyCDG");
    public void requestToRetrieveAnyParticularStore(String storeId) {
        final String endPoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.storeEndpoint")+"/"+storeId;
        apiRequests.GETMethodWithXApiHeaders(endPoint,xApiKey);
        country_code = apiRequests.getValueFormJsonResponseKey("address.country");
        tax_code = apiRequests.getValueFormJsonResponseKey("tax_code");
    }
    public void userRequestToAuthenticateStore(String invalidStoreId,String authCode) {
        final String endPoint= testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.authenticate")+"/"+invalidStoreId;
        String Key1 = "auth_code";
        apiRequests.GETMethodWithSingleQueryParam(endPoint,xApiKey,Key1,authCode);
    }
    public void validatesTheResponseBodyForThatInvalidStore(int status,String invalidStoreId) {
        Assertions.assertEquals(status, apiRequests.verifyResponseStatusCode());
        String actualErrorMessage = apiRequests.getValueFormJsonResponseKey("error");
        String expectedErrorMessage = "Auth for store not found. Store ID: "+invalidStoreId;
        logger.info("Expected error message is : "+expectedErrorMessage);
        logger.info("Actual error message is : "+actualErrorMessage);
        Assertions.assertEquals(actualErrorMessage, expectedErrorMessage);
    }
}
