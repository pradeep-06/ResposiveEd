package clsp.api.tests.ROI;


import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.api.stepDefinitions.carts;
import clsp.api.stepDefinitions.customerSignupSteps;
import clsp.api.stepDefinitions.socrates;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class PositiveScenariosTest {

    @Steps
    carts cartsSteps;

    @Steps
    socrates socratesSteps;

    @Steps
    customerSignupSteps subscriptionSteps;

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,NONE,204,WRITE_ON,7ud921,true,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Perform WriteOff 1st Payment completed", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformWriteOn(int status,String pack, int removedStatus,String writeOffType, String authCode, String responseString,   int newSubscriptionstatus) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(status, pack, newSubscriptionstatus);
        subscriptionSteps.userMustBeAbleToCancelTheSubscription(status);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userTriesToAuthenticateStore(status, authCode, responseString);
        subscriptionSteps.userTriesToPerformWriteOn(status, writeOffType, authCode);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,NONE,204,WRITE_OFF,7ud921,Dispatched,true,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "API_First_payment_completed_and_try_to_perform_Writeoff", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userPerformWriteOff(int status,String pack,int removedStatus, String writeOffType,  String authCode, String packStatus,String responseString,   int newSubscriptionstatus) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(status, pack, newSubscriptionstatus);
        subscriptionSteps.userMustBeAbleToCancelTheSubscription(status);
        subscriptionSteps.userUpdatePackStatusToGivenStatus(packStatus,status);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userTriesToAuthenticateStore(status, authCode, responseString);
        subscriptionSteps.userTriesToPerformWriteOn(status, writeOffType, authCode);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,NONE,204,7ud921,null,true,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Holidaying_a_Pack_with_Refund_via_Service_Credit", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUserPerformsHolidayPack(int status,String pack,int removedStatus,String authCode, String serviceCredit,  String responseString,   int newSubScriptionStatus) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(status, pack, newSubScriptionStatus);
        subscriptionSteps.userTriesToAuthenticateStore(status, authCode, responseString);
        subscriptionSteps.userPerformHolidayPackWhenPaymentCompleted(status, serviceCredit);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,NONE,204,7ud921,true,false,201,goods not received"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Refund_via_Original_Payment_Method_SEPA_and_perform_Holiday_a_Pack", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyUserPerformingRefundAndHolidayPack(int status,String pack,int removedStatus,String authCode, String refundMethod,Boolean serviceCredit,int newSubscriptionstatus, String refundReason) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(status, pack, newSubscriptionstatus);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userRequestsToRefundPayment(status, serviceCredit,refundReason);
        subscriptionSteps.userPerformHolidayPackWhenPaymentCompleted(status,refundMethod);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,NONE,204,7ud921,Cancelled,Pending,true,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Preform_Holiday_having_pack_payments_completed_and_Reinstate_Pack", testType = SSTestType.SMOKE, testCaseVersion = "5.0",parameterized = "true")
    void toVerifyUserPerformHolidayAndReinstatePack(int status, String pack,int removedStatus,String authCode, String paymentStatus, String refundMethod,String packStatus,  String responseString,  int newSubscriptionstatus) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(status, pack, newSubscriptionstatus);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userTriesToAuthenticateStore(status,authCode,responseString);
        subscriptionSteps.userPerformHolidayPackWhenPaymentCompleted(status,refundMethod);
        subscriptionSteps.userShouldNotBeAbleToPerformReinstatePack(status,packStatus,paymentStatus);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,NONE,204,GOODWILL,7ud921,true,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "API_Perform_WriteOff_1st_Payment_completed_Goodwill_Payment_and_verify_the_balance_amount", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyPaymentStatusAfterGoodWill(int status, String pack, int removedStatus,String writeOffType, String authCode, String responseString,   int newSubscriptionstatus) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(status, pack, newSubscriptionstatus);
        subscriptionSteps.userTriesToAuthenticateStore(status,authCode,responseString);
        subscriptionSteps.userTriesToPerformWriteOn(status,writeOffType,authCode);
        subscriptionSteps.userGetsTheSubscriptionDetails(status);
        subscriptionSteps.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

}
