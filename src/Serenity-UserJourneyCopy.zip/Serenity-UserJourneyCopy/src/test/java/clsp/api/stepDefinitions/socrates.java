package clsp.api.stepDefinitions;

import clsp.api.steps.navigateToAPI;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class socrates extends ScenarioSteps {

    @Steps
    navigateToAPI navigateToAPI = new navigateToAPI();

    @Step("user retrieve store id")
    public void userRequestToRetrieveAnyParticularStore(String storeId){
        navigateToAPI.userRequestToRetrieveAnyParticularStore(storeId);
    }
    @Step("user request to authenticate store")
    public void userRequestToAuthenticateStore(String invalidStoreId,String authCode){
        navigateToAPI.userRequestToAuthenticateStore(invalidStoreId,authCode);
    }
    @Step("user validates the response for that invalid Store")
    public void userValidatesTheResponseBodyForThatInvalidStore(int status,String invalidStoreId){
        navigateToAPI.userValidatesTheResponseBodyForThatInvalidStore(status,invalidStoreId);
    }
}
