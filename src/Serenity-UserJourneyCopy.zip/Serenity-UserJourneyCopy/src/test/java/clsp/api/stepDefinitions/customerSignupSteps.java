package clsp.api.stepDefinitions;

import clsp.api.steps.navigateToAPI;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class customerSignupSteps  extends ScenarioSteps {

    @Steps
    navigateToAPI navigateToAPI = new navigateToAPI();


    @Step("user creates Monthly PostPay Subscription with First Payment Completed")
    public void userCreatesMonthlyPostPaySubscriptionWithFirstPaymentCompleted(int status, String pack, int newSubscriptionstatus) {
        navigateToAPI.userRequestForNewCustomerOnCDG(status);
        navigateToAPI.userRetrievesCustomerData(status);
        navigateToAPI.userCreatesCart(status);
        navigateToAPI.userMakesPayment();
        navigateToAPI.userCreatesSameDayPaymentSubscriptionUsingMPP(newSubscriptionstatus, "POST","");
        waitABit(120000);
        navigateToAPI.userSearchesSubscription(status);
        navigateToAPI.userGetsTheSubscriptionDetails(status);
    }
    @Step("user gets the subscription details")
        public void userGetsTheSubscriptionDetails(int status){
        navigateToAPI.userGetsTheSubscriptionDetails(status);
    }
    @Step("user tries to cancel the subscription")
    public void userMustBeAbleToCancelTheSubscription(int status){
        navigateToAPI.userMustBeAbleToCancelTheSubscription(status);
    }

    @Step("user creates customer")
    public void userCreatesCustomer(int status) {
        navigateToAPI.userRequestForNewCustomerOnCDG(status);
    }

    @Step("user deletes the customer")
    public void userDeletesCustomer(int status) {
        navigateToAPI.deleteCustomer(status);
    }
    @Step("user creates subscription")
    public void userCreatesSubscription(int status, String payerType) {
        navigateToAPI.userRequestForNewCustomerOnCDG(status);
        navigateToAPI.userRetrievesCustomerData(status);
        navigateToAPI.userCreatesCart(status);
        navigateToAPI.userMakesPayment();
        navigateToAPI.userShouldBeAbleToCreateSubscription(payerType);

    }
    @Step("user makes payment")
    public void userMakesPayment(){
        navigateToAPI.userMakesPayment();
    }
    @Step("user get subscription details")
    public void userMustBeAbleToGetSubscriptionDetails(int status) {
        navigateToAPI.userSearchesSubscription(status);
    }
    @Step("user creates daily customer")
    public void userCreatesDailyCustomer(String dailyType, int quantity, int status){
        navigateToAPI.createDailyCustomer(dailyType,quantity,status);
    }
    @Step("user creates daily customer payment completed")
    public void createDailyCustomerPaymentCompleted(String dailyType, int quantity, int status){
        navigateToAPI.createDailyCustomerPaymentCompleted(dailyType,quantity,status);
    }
    @Step("user adds additional cart")
    public void userAddsAdditionalCart(String dailyType,int quantity){
        navigateToAPI.userAddsAdditionalCart(dailyType,quantity);
    }
    @Step("user tries to find customer with account id")
    public void userTriesToFindCustomerWithAccountId(int status){
        navigateToAPI.userTriesToFindCustomerWithAccountId(status);
    }
    @Step("user able to search customer matching criteria")
    public void userMustBeAbleToSearchCustomerMatchingCriteria(int status){
        navigateToAPI.userMustBeAbleToSearchCustomerMatchingCriteria(status);
    }
    @Step("user tries to add address")
    public void userTriesToAddAddressForTheCustomer(int status){
        navigateToAPI.userTriesToAddAddressForTheCustomer(status);
    }
    @Step("user tries to verify payment details")
    public void userMustBeAbleToVerifyThePaymentDetails(int status){
        navigateToAPI.userMustBeAbleToVerifyThePaymentDetails(status);
    }
    @Step("user tries to get customer fit details")
    public void userRequestToGetCustomerWithCLFITData(String countryCode, String storeId, String accountId, String tdr, String clfit){
        navigateToAPI.userRequestToGetCustomerWithCLFITData(countryCode,storeId,accountId,tdr,clfit);
    }
    @Step("user retrieves customer clfit data")
    public void userRetrievesCustomerCLFITData(String countryCode, String storeId, String accountId, String tdr, String clfit){
        navigateToAPI.userRetrievesCustomerCLFITData(countryCode,storeId,accountId,tdr,clfit);
    }
    @Step("user updates the details of customer")
    public void userUpdatesTheDetailsOfCustomer(int status){
        navigateToAPI.userUpdatesTheDetailsOfCustomer(status);
    }
    @Step("user tries to update customer address")
    public void userTriesToUpdateAddressForTheCustomer(int status){
        navigateToAPI.userTriesToUpdateAddressForTheCustomer(status);
    }
    @Step("user tries to find customer with last name")
    public void userTriesToFindCustomerWithLastname(int status){
        navigateToAPI.userTriesToFindCustomerWithLastname(status);
    }
    @Step("user tries to add address with invalid account reference")
    public void userTriesToAddAddressWithInvalidAccountReference(String accountReference,int status){
        navigateToAPI.userTriesToAddAddressWithInvalidAccountReference(accountReference,status);
    }
    @Step("user requests to update the payment details for invalid BIC")
    public void userRequestsToUpdatePaymentDetailsForInvalidBIC(String bic,int status){
        navigateToAPI.userRequestsToUpdatePaymentDetailsForInvalidBIC(bic,status);
    }
    @Step("user requests to update the payment details for invalid IBAN")
    public void requestsToUpdatePaymentDetailsForInvalidIBAN(String iban,int status){
        navigateToAPI.requestsToUpdatePaymentDetailsForInvalidIBAN(iban,status);
    }
    @Step("user tries to authenticate store")
    public void userTriesToAuthenticateStore(int status, String authCode, String responseString){
        navigateToAPI.userTriesToAuthenticateStore(status,authCode,responseString);
    }
    @Step("user tries to perform Write On")
    public void userTriesToPerformWriteOn(int status, String writeOffType, String authCode){
        navigateToAPI.userTriesToPerformWriteOn(status,writeOffType,authCode);
    }
    @Step("user gets the balance amount of subscription")
    public void userGetsTheBalanceAmountForSubscription(){
        navigateToAPI.userGetsTheBalanceAmountForSubscription();
    }
    @Step("user updates pack status to given status")
    public void userUpdatePackStatusToGivenStatus(String packStatus, int status) {

        navigateToAPI.userRequestsToUpdatePack(packStatus,status);
    }
    @Step("user performs holiday to pack")
    public void userPerformHolidayPackWhenPaymentCompleted(int status, String serviceCredit ){
        navigateToAPI.userPerformHolidayPackWhenPaymentCompleted(status,serviceCredit);
    }
    @Step("user perfoms refund to the payment")
    public void userRequestsToRefundPayment(int status, Boolean serviceCredit, String refundReason){
        navigateToAPI.userRequestsToRefundPayment(status,serviceCredit,refundReason);
    }
    @Step("user should not be able to perform reinstate pack")
    public void userShouldNotBeAbleToPerformReinstatePack(int status, String packStatus, String paymentStatus){
        navigateToAPI.userShouldNotBeAbleToPerformReinstatePack(status,packStatus,paymentStatus);
    }
    @Step("user is able to verify the payment status")
    public void userMustBeAbleToVerifyThePaymentStatus(String WriteOffType){
        navigateToAPI.userMustBeAbleToVerifyThePaymentStatus(WriteOffType);
    }
    @Step("user tries to find customer with invalid customerId")
    public void userTriesToFindCustomerWithInvalidCustomerId(String customerId,int status){
        navigateToAPI.userTriesToFindCustomerWithInvalidCustomerId(customerId,status);
    }
    @Step("user search for matching criteria with invalid customerId")
    public void userAbleToSearchMatchingCriteriaWithInvalidCustomerId(String customerId,int status){
        navigateToAPI.userAbleToSearchMatchingCriteriaWithInvalidCustomerId(customerId,status);
    }
    @Step("user retrieve customer data with invalid account reference")
    public void userRetrieveCustomerDataWithInvalidAccountReference(String accountReference,int newStatus){
        navigateToAPI.userRetrieveCustomerDataWithInvalidAccountReference(accountReference,newStatus);
    }
    @Step("user update payment details for invalid BIC")
    public void userRequestsToUpdatePaymentDetailsForInvalidBIC(String bic,int status, String acc_reference,String firstName){
        navigateToAPI.userRequestsToUpdatePaymentDetailsForInvalidBIC(bic,status,acc_reference,firstName);
    }
    @Step("user update payment details for invalid IBAN")
    public void userRequestsToUpdatePaymentDetailsForInvalidIBAN(String iban,int status, String acc_reference,String firstName){
        navigateToAPI.userRequestsToUpdatePaymentDetailsForInvalidIBAN(iban,status,acc_reference,firstName);
    }
    @Step("user validate status code for invalid store")
    public void validateResponseAndStatusCodeForInvalidStore(int status,int invalidStoreId){
        navigateToAPI.validateResponseAndStatusCodeForInvalidStore(status,invalidStoreId);
    }
    @Step("user validate the response and status for clFit")
    public void userValidateResponseAndStatusCodeForCLFIT(int status){
        navigateToAPI.userValidateResponseAndStatusCodeForCLFIT(status);
    }
    @Step("user requests to transfer the invalid store")
    public void userRequestsToTransferTheInvalidStore(int status, String customerID){
        navigateToAPI.userRequestsToTransferTheInvalidStore(status,customerID);
    }
    @Step("user requests to replace invalid pack")
    public void userRequestsToReplaceInvalidPack(int status){
        navigateToAPI.userRequestsToReplaceInvalidPack(status);
    }
    @Step("user requests to expedite pack with past delivery date")
    public void userRequestsToExpeditePackWithPastDeliveryDate(int status){
        navigateToAPI.userRequestsToExpeditePackWithPastDeliveryDate(status);
    }
    @Step("user must not be able to create subscription")
    public void userMustNotBeAbleToCreateSubscriptionWithPaymentDate(int status, String firstPack){
        navigateToAPI.userMustNotBeAbleToCreateSubscriptionWithPaymentDate(status,firstPack);
    }
    @Step("user must not be able to create subscription")
    public void userMustNotBeAbleToCreateSubscriptionWithDispatchDate(int status, String firstPack){
        navigateToAPI.userMustNotBeAbleToCreateSubscriptionWithDispatchDate(status,firstPack);
    }
    @Step("user add address with Invalid Account Reference")
    public void userAddAddressWithInvalidAccReference(String accountReference, int status){
        navigateToAPI.userAddAddressWithInvalidAccReference(accountReference,status);
    }
    @Step("user requests to update Payment with Past Delivery Date")
    public void userRequestsToUpdatePaymentwithPastDeliveryDate(int status){
        navigateToAPI.userRequestsToUpdatePaymentwithPastDeliveryDate(status);
    }


}

