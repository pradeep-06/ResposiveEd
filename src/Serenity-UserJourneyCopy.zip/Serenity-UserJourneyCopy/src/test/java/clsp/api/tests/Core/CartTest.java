package clsp.api.tests.Core;


import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.api.stepDefinitions.carts;
import clsp.api.stepDefinitions.customerSignupSteps;
import clsp.api.stepDefinitions.socrates;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class CartTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    carts cartsSteps;

    @Steps
    socrates socratesSteps;

    @Steps
    customerSignupSteps subscriptionSteps;

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Cart For Account, Get Cart for Account", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void verifyCreateAndGetCartForAccountTest(int status, int removedStatus) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        cartsSteps.userTriesToAddACart(status);
        cartsSteps.userMustBeAbleToGetCart(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Create Cart, Get Cart", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyCreateCart(int status) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesCustomer(status);
        cartsSteps.userTriesToAddACart(status);
        cartsSteps.userMustBeAbleToGetCart(status);
    }

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,PRE"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Change Usage", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyChangeUsage(int status, int removedStatus, String payerType) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesSubscription(status, payerType);
        subscriptionSteps.userMustBeAbleToGetSubscriptionDetails(status);
        cartsSteps.userTriesToAddACart(status);
        cartsSteps.userRequestsToChangeTheCartOfAnAccount(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,Occasional,1,PartTime,2"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Change Usage from Daily Occasional to Part Time", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void toVerifyChangeUsagePartTimeToFullTime(int status, int removedStatus, String dailyType, int quantity, String newDailyType, int newQuantity) {
        cartsSteps.cleanSession();
        subscriptionSteps.userCreatesDailyCustomer(dailyType, status, quantity);
        subscriptionSteps.userMustBeAbleToGetSubscriptionDetails(status);
        subscriptionSteps.userAddsAdditionalCart(newDailyType, newQuantity);
        cartsSteps.userRequestsToChangeTheCartOfAnAccount(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,204,FullTime,3,PartTime,2"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Complete First payment and perform Change Usage", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void ToVerifyPaymentCompleteAndChangeUsage(int status, int removedStatus, String dailyType, int quantity, String newDailyType, int newQuantity) throws Exception {
        cartsSteps.cleanSession();
        subscriptionSteps.createDailyCustomerPaymentCompleted(dailyType, quantity, status);
        subscriptionSteps.userAddsAdditionalCart(newDailyType, newQuantity);
        cartsSteps.userRequestToChangeTheCartAfterPaymentCompleted(status);
        subscriptionSteps.userDeletesCustomer(removedStatus);
    }

}
