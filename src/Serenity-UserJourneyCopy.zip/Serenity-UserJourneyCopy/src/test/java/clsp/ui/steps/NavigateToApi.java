package clsp.ui.steps;

import Framework.DataManager.TestDataManager;
import clsp.ui.pages.SearchPage;
import net.thucydides.core.steps.ScenarioSteps;
public class NavigateToApi extends ScenarioSteps {


    protected final TestDataManager testDataManager = new TestDataManager();

    SearchPage searchPage = new SearchPage();


    public void createDailyCust(String dailyType,int quantity,int status){
        searchPage.createDailyCust(dailyType,quantity,status,"POST");
    }
    public void createPostPayNoSolutionPaymentCompleted(int status){
        searchPage.userCreatesPostPayMonthlyNoSolutionSubscriptionPaymentCompleted(status);
    }
    public void createDailyCustPaymentCompleted(String dailyType,int quantity,int status){
        searchPage.createDailyCustPaymentCompleted(dailyType,quantity,status);
    }
    public void createPostpayDailyCust(String dailyType,int quantity,int status){
        searchPage.createDailyCust(dailyType,quantity,status,"POST");
    }
    public void userStoresDeliveryDates(){
        searchPage.userStoresDeliveryDates();
    }
    public void userStoresThePackStatus(){
        searchPage.userStoresThePackStatus();
    }
    public void retrievePaymentsForStoreBalanceReport(){
        searchPage.retrievePaymentsForStoreBalanceReport();
    }
    public void userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(String dailyType, int quantity, int status, int newSubscriptionStatus)
    {
        searchPage.userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(dailyType,quantity,status,newSubscriptionStatus);
    }

    public void userCreatesMonthlySolutionCust(int status){
        searchPage.createMonthlySolutionCust(status, "PRE");
    }
    public void userCreatesMonthlyNoSolutionCust(int status){
        searchPage.createMonthlyNoSolutionCust(status, "POST");
    }
    public void userCreatesMonthlyNoSolutionCustomerPostPay(int status){
        searchPage.createMonthlyNoSolutionCust(status,  "POST");
    }


    public void deleteCustomer(String customerID, int status) {
        searchPage.deleteCustomer(customerID, status);
    }
    public void userUpdatesPackStatusToGivenStatus(int status, String customerID, String packStatus){
        searchPage.UpdatesPackStatusToGivenStatus(status, customerID, packStatus);
    }
    public void userUpdatePackStatusToGivenStatus(int status, String packStatus){
        searchPage.userUpdatesPackStatus(packStatus,status);
    }
    public void userUpdateSecondPackStatusToGivenStatus(int status, String packStatus){
        searchPage.userUpdatesSecondPackStatus(packStatus,status);
    }

    public void userGetsSubscriptionDetailsForCustomer(String customerID) {
        searchPage.userGetsSubscriptionDetailsForCustomerID(customerID);
    }
    public void userCreatesNewCustomerWithMonthlySolutionSubscriptionAndCompletedPack(int status) {
        searchPage.userTriesToAddACart();
    //    searchPage.userRetrievesAddressForCustomerUsingAccountID(status);
        searchPage.userCreatesSameDayPaymentSubcriptionUsingMPP(status,"PRE","");

    }
    public void userCreatesCustomerWithPaymentCompleted(int status,String customerID){
        searchPage.userGetsSubscriptionDetailsForCustomerID(customerID);
        searchPage.userCreatesSameDayPaymentSubscription(status,"PRE","");
    }
    public void userCreatesDailyCustomerSubscriptionWithCompletedPacks(String dailyType, int quantity, int status, String payerType) {
        searchPage.userCreatesDailyCustomerSubscriptionWithCompletedPacks(dailyType,quantity,status,payerType);
    }
    public  void createMultipleSubscriptionForDailyCustomer(String dailyType, int quantity, int status, String payerType){
        searchPage.createMultipleSubscriptionForDailyCustomer(dailyType,quantity,status,payerType);
    }
    public void userCreateMonthlyNoSolutionBankHoliday(int status) throws Exception {
        searchPage.userCreatesNewCustomerWithMonthlyNoSolutionSubscriptionOnBankHoliday(status);
    }
    public void userUpdatesTheSecondPackStatus(String packStatus, int status) {
        searchPage.userUpdatesTheSecondPackStatus(packStatus,status);
    }
    public void userCreatesMonthlyNoSolutionBankHolidayPostPay(int status) throws Exception {
        searchPage.userCreatesMonthlyNoSolutionBankHolidayPostPay(status);
    }
    public void userCreatePostPayMonthlySolutionAndFirstPaymentInFlight(int status) {
        searchPage.userCreatePostPayMonthlySolutionAndFirstPaymentInFlight(status);
    }
    public void userCreatesDailyNonLensMailerCustomerSubscriptionPostPay(String dailyType, int quantity, int status,int newSubscriptionStatus) {
        searchPage.userCreatesDailyNonLensMailerCustomerSubscriptionPostPay(dailyType,quantity,status,newSubscriptionStatus);
    }
    public void userGetsSubscriptionDetailsAndUpdatesPackStatusToDispatch(String packStatus,int status) {
        searchPage.userGetsSubscriptionDetailsAndUpdatesPackStatusToDispatch(packStatus,status);
    }
    public void userUpdatesFirstPackDueDateToTodayDate(int status, String pack) {
        searchPage.userUpdatesFirstPackDueDateToTodayDate(status,pack);
    }
    public void userCreatesPostPayMonthlySolutionAndCompletedPack(int status) {
        searchPage.userCreatesPostPayMonthlySolutionAndCompletedPack(status);
    }
    public void userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(String dailyType, String discountType, int quantity, int status,int newSubscriptionStatus) {
        searchPage.userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(dailyType,discountType,quantity,status,newSubscriptionStatus);
    }

    public void userDeletsTheCustomerFromEnv(String status){
        searchPage.userDeletsTheCustomerFromEnv(status);
    }
    public void userChecksMail(String customerType,int quantity,String packUsage){
        searchPage.checkEmail(customerType,quantity,packUsage,0,0);
    }

    public void userUpdatesPackDueDate(String custID, String FullID, String date){
            searchPage.userCreatesAPICAllToUpdatePack( custID, FullID, date);
    }
    public void userPerformsGoodwill(String paymentNum, int status){
        searchPage.userPerformsGoodwill(paymentNum,status);
    }


}