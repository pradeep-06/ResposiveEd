package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Response;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;


public class SubscriptionPage extends clspBase {

    protected static final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(SubscriptionPage.class);


    CustomerDashboard customerDashboard;
    SearchPage searchPage;
    public static String secondPaymentDateInSchedule;
    public static String selectedPaymentDate;
    static String firstPaymentDateInSchedule;
    public static String validFirstPayment;
    public static String updatedFirstDeliveryDate;
    String existingUsage = "//table[@class='usage-tbl table table-sm selected']//../th[contains(., '%1$s')]";
    String newUsage = "//div[@class='col-md-4 usage-options']//th[contains(., '%1$s')]";
    ArrayList <String> expectedPayments = new ArrayList<String>();
    public static ArrayList<String> bankHoliday = new ArrayList<String>();
    public static ArrayList<String> PaymentSchedule = new ArrayList<String>();
    public static boolean flag;
    public static Date firstpaymentDateSum;


    @FindBy(xpath = "//div[@class='dropdown-menu dropdown-menu-right show']")
    public WebElementFacade actionDropdownBox;

    @FindBy(xpath = "//button[text()='Change Pack Delivery Date']")
    private WebElementFacade changePackDeliveryDateButton;

    @FindBy(xpath = "//input[contains(@class,'form-control')]")
    private WebElementFacade calenderDate;

    @FindBy(xpath = "//button[contains(.,'Confirm')]")
    public WebElementFacade futureConfirmButton;

    @FindBy(xpath = "//button[contains(@class,'close pull-right')]")
    private WebElementFacade closeButton;

    @FindBy(xpath = "//div[@class='modal-footer modal-footer-display']//button[contains(., 'Confirm')]")
    public WebElementFacade solutionConfirmButton;


    @FindBy(xpath = "//span[contains(.,'Customer Dashboard')]//..//span[@class='fake-link back-button']")
    public WebElementFacade custDashboardBackButton;


    @FindBy(xpath = "//div[@class='col-md-12 mt-3 text-green']//span")
    private WebElementFacade deliveryMessage;

    @FindBy(xpath = "//input[contains(@id,'first-pack-fulfilment')]")
    private WebElementFacade firstPackFulfilment;

    @FindBy(xpath = "//button[@class='dropdown-item'][text()='Early Pack Request']")
    List<WebElementFacade> expediteButton;

    @FindBy(xpath = "//div[@class='modal-header']")
    private WebElementFacade earlyPackRequestHeader;

    @FindBy(xpath = "//div[@class='col-md-4 usage-options']//th[contains(., 'Full Time')]")
    private WebElementFacade fullTime;

    @FindBy(xpath = "//select[@id='regular-delivery-fulfilment']")
    private WebElementFacade fulfilmentType;

    @FindBy(xpath = "//ngbd-datepicker-popup[@id='paymentDay']//input[@name='dp']")
    private WebElementFacade firstPaymentDate;

    @FindBy(xpath = "//span[contains(.,'First Delivery Date')]//..//following-sibling::span")
    private WebElementFacade firstDelivDate;

    @FindBy(xpath = "//input[@class='form-control ng-untouched ng-pristine ng-valid']")
    private WebElementFacade firstDeliveryDate;

    @FindBy(xpath = "//span[contains(.,'First Delivery Date')]//..//following-sibling::span")
    private WebElementFacade firstRegularDeliveryDate;

    @FindBy(xpath = "//div[@id='customer-contact-details']//li[2]")
    private WebElementFacade genderDetails;

    @FindBy(xpath="//ngb-alert[@class='alert alert-danger']")
    private WebElementFacade invalidAuthorizationAlert;

    @FindBy(xpath = "//span[text()='Lens Subscription']")
    private WebElementFacade lensSubstnHeader;

    @FindBy(xpath = "//div[@class='row lens-name bg-white']")
    private WebElementFacade lensValueLeftRightEye;

    @FindBy(xpath ="//button[@type='submit']")
    private WebElementFacade promotionProceedBtn;

    @FindBy(xpath = "//div[@id='cart-usage-tbls']//th[text()='Monthly']")
    private WebElementFacade monthlyUsagePeriod;

    @FindBy(xpath = "//div[@class='col-md-4 usage-options']//th[contains(., 'Occasional')]")
    private WebElementFacade occasional;

    @FindBy(xpath = "//a[text()='Package']")
    public WebElementFacade packageTab;

    @FindBy(xpath = "//div[@class='col-md-4 usage-options']//th[contains(., 'Part Time')]")
    public WebElementFacade partTime;

    @FindBy(xpath = "//div[@class='pipe-separate-children']/div[contains(text(),'pay')]")
    public WebElementFacade payerType;

    @FindBy(xpath = "//label[contains(.,'Payment Basis')]//..//following-sibling::select")
    public WebElementFacade paymentBasis;

    @FindBy(xpath ="//td[text()='Total (per month)']/following-sibling::td")
    private WebElementFacade totalPermonth;

    @FindBy(xpath = "//label[contains(.,'Payment Basis')]//..//following-sibling::select")
    private WebElementFacade paymentBasisDropdownPrepay;

    @FindBy(xpath = "//button[@title='Previous month']")
    private WebElementFacade previousMonthArrow;

    @FindBy(xpath = "//a[text()='Schedule']")
    private WebElementFacade scheduleTab;

    @FindBy(xpath = "//select[@id='subscriptionTerm']")
    private WebElementFacade subscriptionTerm;

    @FindBy(xpath = "//select[@id='cart-solution']")
    private WebElementFacade solutionDropdown;

    @FindBy(xpath = "//input[@id='should-not-send-email']")
    private WebElementFacade emailNotSendButton;

    @FindBy(xpath = "//input[@id='should-send-email']")
    private WebElementFacade emailSendButton;

    @FindBy(xpath = "//button[text()=' Update Package ']")
    private WebElementFacade updatePackageButton;

    @FindBy(xpath = "//button[@class='btn-secondary pull-right']")
    private WebElementFacade solutionUpdateButton;

    @FindBy(xpath ="//*[@id='cart-solution-price']")
    public WebElementFacade solutionPrice;

    @FindBy(xpath ="//button[@class='btn-secondary']")
    private WebElementFacade updatePackage;

    @FindBy(xpath="//ngb-alert[@class='alert change-plan-alert alert-info']")
    public WebElementFacade packChangeAlertMessage;

    @FindBy(xpath = "//table[@class='usage-tbl table total-per-month-tbl table-sm selected']//td[contains(.,'per Month')]")
    private WebElementFacade usagePerMonth;

    @FindBy(xpath = "//span[contains(@class,'pack-status')]//..//following-sibling::div[contains(.,'Date')]")
    List<WebElementFacade> packDueDate;

    @FindBy(xpath ="//div[@class='row pack-subscription-header']/div/span[1]")
    List <WebElementFacade> printSchedulePackDelDates;

    @FindBy(xpath ="//div[@class='row pack-subscription-header']/div/span[2]")
    List <WebElementFacade> printSchedulePackStatus;

    @FindBy(xpath ="//div[@class='col-sm-6 pack-address']/p")
    List <WebElementFacade> printScheduleOrderID;

    @FindBy(xpath =  "//button[@class='close pull-right']")
    private WebElementFacade closePrintSchedule;

    @FindBy(xpath = "//div[contains(@class,'alert-warning')]")
    private WebElementFacade alertReleaseToSupplyChain;

    @FindBy(xpath = "//span[contains(.,'First Delivery Date')]//..//following-sibling::span")
    private WebElementFacade  PackDeliveryDate;

    @FindBy(xpath = "//div[contains(@class,'pack-dropdown')]//button[contains(@class,'pack-dropdown')]")
    List<WebElementFacade> actionDropdown;

    @FindBy(xpath = "//button[@class='dropdown-item'][text()='Reinstate Pack']")
    List <WebElementFacade>  reinstateButton;

    @FindBy(xpath = "//h4[text()='Reinstate pack']")
    public WebElementFacade reinstateHeader;

    @FindBy(xpath = "//button[text()='Collected']")
    private WebElementFacade collectedButton;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header clearfix pending')]//span[contains(@class,'pack-status pending')]")
    List<WebElementFacade> packStatusList;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header clearfix pending')]//span[contains(@title,'Dispatched')]")
    private WebElementFacade statusList;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header clearfix cancelled')]//span[contains(@class,'pack-status cancelled')]")
    List<WebElementFacade> cancelStatusList;

    @FindBy(xpath ="//button[contains(.,'Edit Subscription')]")
    public  List<WebElementFacade> editSubscriptnBtn;

    @FindBy(xpath = "//div[@class='status']//span[@class='pack-status complete pending']")
    List <WebElementFacade> compPaymentStatus;

    @FindBy(xpath = "//div[@class='order-details-content']")
    List <WebElement> orderDetails;

    @FindBy(xpath = "//ul[@class='address-info']")
    List <WebElement> deliveryAddress;

    @FindBy(xpath =  "//span[@class='text-label print-schedule-link']")
    private WebElementFacade printScheduleLink;

    @FindBy(xpath="//div[contains(@class,'store-address')]/ul")
    private WebElementFacade storeAddressOnPrint;

    @FindBy(xpath="//div[@class='customer-address']/p")
    private WebElementFacade customerNameOnPrint;

    @FindBy(xpath="//div[@class='customer-info']")
    private WebElementFacade customerIDOnPrint;

    @FindBy(xpath="//div[@class='customer-address']/ul")
    private WebElementFacade customerAddressOnPrint;

    @FindBy(xpath ="//div[@class='pack-payments']/span[1]")
    List <WebElementFacade> printScheduleDates;

    @FindBy(xpath="//div[@class='col-sm-6 pack-address']/ul")
    List <WebElement> customerAddressOnPrintSchedule;

    @FindBy(xpath = "//div[@class='fulfilled-by']")
    List <WebElement> orderToBeFullFiledBySupplyChainOrStore;

    @FindBy(xpath ="//button[text()='Store Fulfilment']")
    public WebElementFacade storeFullFilment;

    @FindBy(xpath = "//button[contains(.,'Supply Chain Fulfilment')]")
    private WebElementFacade supplyChainFulfilment;

    @FindBy(xpath ="//span[@title='Pending']//..//..//..//..//span[text()='To be fulfilled by store']")
    private WebElementFacade toBeFullFiledByStoreLabel;

    @FindBy(xpath = "//div[contains(@class,'alert alert-warning no-margin mt-3')]")
    private WebElementFacade storeFulFilment;

    @FindBy(xpath = "//span[text()=' Delivery Info ']")
    List <WebElement>  deliveryTabInfo;

    @FindBy(xpath = "//td[@class='text-label'] [contains(.,'Carrier')]//..//following-sibling::td")
    List <WebElement> carrier;

    @FindBy(xpath = "//td[@class='text-label'] [contains(.,'File Number')]//..//following-sibling::td")
    List <WebElement> fileNumber;

    @FindBy(xpath = "//td[@class='text-label'] [contains(.,'Hub Service')]//..//following-sibling::td")
    List <WebElement> hubService;

    @FindBy(xpath = "//td[@class='text-label'] [contains(.,'Fulfilment House')]//..//following-sibling::td")
    List <WebElement> fulfilmentHouse;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header float-right')]//div[2]") //Xpath in 46
    public List<WebElement> packPaymentList;

    @FindBy(xpath = "//div[@class='status']//span[@class='pack-status holiday']")
    List <WebElement>  holidayPaymentStatus;

    @FindBy(xpath = "//div[@class='status']//span[@title='Pending']")
    List <WebElement>  paymentStatus;

    @FindBy(xpath = "//div[@class='status']//span[@title='Pending']/../preceding-sibling::div[2]")
    List <WebElement>  pendingDateDetails;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header float-right')]//div[@class='pipe-separate-children']//div[1]")
    List<WebElement> paymentDateList;

    @FindBy(xpath = "//button[@class='dropdown-toggle btn btn-outline-success payment-dropdown__dropdown-btn']")
    List<WebElementFacade> visibleDropdown;

    @FindBy(xpath = "//select[@class='form-control ng-valid ng-dirty ng-touched']")
    private WebElementFacade completedVisibleDropdown;

    @FindBy(xpath = "//button[@class='dropdown-item'][contains(.,'Goodwill Payment')]")
    private WebElementFacade goodWillPayment;

    @FindBy(xpath =  "//input[@id='refund-to-credit']")
    private WebElementFacade creditRadioButton;

    @FindBy(xpath =  "//h4[@class='modal-title']")
    private WebElementFacade refundPaymentHeader;

    @FindBy(xpath =  "//select[@id='reason-select']")
    private WebElementFacade refundReasonDropdown;

    @FindBy(xpath =  "//input[@id='refund-original-payment']")
    private WebElementFacade originalPaymentMethodSEPARadioButton;

    @FindBy(xpath =  "//ngb-alert[@role='alert']")
    private WebElementFacade refundPopup;

    @FindBy(xpath =  "//span[text()='Top Up']")
    private WebElementFacade topUp;

    @FindBy(xpath =  "//div[@class='alert alert-warning no-margin']")
    private WebElementFacade topUpAlertWarning;

    @FindBy(xpath =  "//input[@id='authorisation-input-field']")
    private WebElementFacade authorization;

    @FindBy(xpath =  "//button[text()=' Proceed ']")
    private WebElementFacade proceedButton;

    @FindBy(xpath ="//button[@class='btn-secondary pull-right']")
    public WebElementFacade holidayConfirm;

    @FindBy(xpath = "(//span[contains(.,'Manage Payment')])[1]")
    private WebElementFacade managepayment;

    @FindBy(xpath = "//input[@class='form-control ng-untouched ng-pristine ng-valid']")
    private WebElementFacade editPaymentDate;

    @FindBy(xpath = "//span[@class='pack-status'][@title='Refunded']//..//..//..//..//button[contains(.,'Manage Payment')]")
    private WebElementFacade managePaymentRefunded;
    @FindBy(xpath = "//span[contains(.,'Manage Payment')]")
    List<WebElementFacade> selectActionBtnPendingPayment;



    @FindBy(xpath = "//button[@class='dropdown-item'][text()='Cancel Payment']")
    List <WebElementFacade> cancelPayment;

    @FindBy(xpath="//div[@class='alert alert-warning']")
    private WebElementFacade cancelPaymentAlertMessage;

    @FindBy(xpath="//h4[contains(.,'Cancel Payment')]")
    private WebElementFacade labelCancelPaymentHeader;

    @FindBy(xpath = "//div[@class='col-md-6'] //select")
    private WebElementFacade editPaymentDateVisibleButton;

    @FindBy(xpath = "//div[@class='alert alert-info']")
    private WebElementFacade warningInfo;

    @FindBy(xpath = "//i[@class='fa fa-calendar']")
    private WebElementFacade calendarBtn;

    @FindBy(xpath = "//button[@title='Next month']")
    private WebElementFacade nextMonthArrow;

    @FindBy(xpath = "//button[@class='btn-secondary pull-right']")
    public WebElementFacade confirmButton;

    @FindBy(xpath = "//a[contains(.,'Completed Packs')]")
    private WebElementFacade completedPacksTab;

    @FindBy(xpath = "//span[@title='Dispatched']//..//..//..//..//span[text()='Collected in Store']")
    private WebElementFacade collectedInStoreLabel;

    @FindBy(xpath ="//header[contains(@class,'content-panel-header float-right')]/div/div[1]/span")
    List <WebElementFacade> packCollectedDate;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header float-right')]/div/div[1]")
    public List<WebElementFacade> updatedPaymentDate;

    @FindBy(xpath = "//span[@class='fake-link'][text()='(Change?)']")
    public List <WebElementFacade> firstChangeLink;

    @FindBy(id = "first-pack-fulfilment")
    public WebElementFacade firstPack;

    @FindBy(xpath = "//span[contains(.,'Next Delivery')]//..//following-sibling::span")
    public WebElementFacade nextDeliverySubDetail;


    @FindBy(xpath = "//span[contains(.,'Final Delivery Date')]//..//following-sibling::span")
    public WebElementFacade finalDeliveryDate;

    @FindBy(xpath = "//select[@id='delivery-address']")
    public WebElementFacade newAddressDropDown;

    @FindBy(xpath = "//ul[@class='address-info']")
    private WebElementFacade deliveryAdd;

    @FindBy(xpath = "//ul[@class='address-info']")
    List<WebElementFacade> changedDeliveryAdd;

    @FindBy(xpath = "//a[contains(.,'Supplementary Orders')]")
    private WebElementFacade supplementaryOrderButton;

    @FindBy(xpath = "//span[@class='subscription_type']")
    private WebElementFacade subscriptionType;

    @FindBy(xpath = "//table[@class='cost-breakdown pull-left']//td[text()='L']//following-sibling::td")
    private WebElementFacade leftLensOnDashBoard;

    @FindBy(xpath = "//table[@class='cost-breakdown pull-left']//td[text()='R']//following-sibling::td")
    private WebElementFacade rightLensOnDashBoard;

    @FindBy(xpath = "//td[text()='Solution']//following-sibling::td")
    private WebElementFacade solutionOnDashBoard;


    @FindBy(xpath = "//span[contains(text(),'First Delivery Date')]//following-sibling::span")
    public WebElementFacade firstDeliveryDateInHeader;

    @FindBy(xpath = "//span[@class='fake-link back-button']")
    public WebElementFacade subscriptionBackButton;

    @FindBy(xpath = "//button[contains(@id,'socrates-btn')]")
    private WebElementFacade socratesSyncButton;

    @FindBy(xpath = "//input[contains(@id,'shouldUpdateAllPacks')]")
    private WebElementFacade updateFuturePacks;

    @FindBy(xpath = "//input[contains(@id,'delivery-future')]")
    private WebElementFacade updateFutureDeliveryPacks;

    @FindBy(xpath = "//td[contains(.,'Next Delivery')]//..//following-sibling::td")
    private WebElementFacade subscriptionNextDelivery;

    @FindBy(xpath = "//span[contains(.,' Completed Goodwill ')]")
    private WebElementFacade goodWillPaymentStatus;

    @FindBy(xpath = "//div[@class='icon-circle red']")
    private WebElementFacade customerDebtAlert;

    @FindBy(xpath="//span[@class='cancelled_status']")
    private WebElementFacade cancelledStatus;

    @FindBy(xpath ="//select[@id='delivery-address']")
    private WebElementFacade newAddressDropdown;

    @FindBy(xpath = "//select[@id='delivery-address']//option")
    List <WebElementFacade> options;

    @FindBy(xpath = "//input[@id='delivery-future']")
    private WebElementFacade applyAllFuturePacks;

    @FindBy(xpath = "//a[text()='Subscriptions']")
    public WebElementFacade subscriptionTab;

    @FindBy(xpath ="//a[text()='History']")
    public WebElementFacade historyTab;

    @FindBy(xpath = "//span[contains(.,'Pending') or contains(.,'Dispatched')]//..//..//..//preceding-sibling::button[@data-toggle='dropdown']")
    List<WebElement> selectActnDrpDownPendingDispatched;

    @FindBy(xpath = "//button[contains(.,'Replace') or contains(.,'Top Up')]")
    List<WebElementFacade> replaceBtn;

    @FindBy(xpath = "//div[@class='order-details-id']//div[1]")
    List<WebElement> orderIDList;


    @FindBy(xpath = "//h4[@class='modal-title']")
    public WebElementFacade replaceHeader;

    @FindBy(xpath = "//label[text()='Select Reason']")
    public WebElementFacade selectReasonlabel;

    @FindBy(xpath = "//tr//td[text()='L']//..//select[@class='form-control ng-untouched ng-pristine ng-valid']")
    private WebElementFacade leftQuantityBox;

    @FindBy(xpath = "//tr//td[text()='R']//..//select[@class='form-control ng-untouched ng-pristine ng-valid']")
    private WebElementFacade rightQuantityBox;

    @FindBy(xpath = "//div[@role='alert']")
    private WebElementFacade writeOffAlertMessage;

    @FindBy(xpath = "//input[@id='authorisation-input-field']")
    private WebElementFacade authorizationCodeFieldWriteOff;

    @FindBy(xpath =  "//ngb-alert[@class='alert alert-warning']")
    private WebElementFacade authorizationConfirmationAlert;

    @FindBy(xpath = "//input[contains(@id,'update-current')]")
    private WebElementFacade applyToCurrentCheckBox;

    @FindBy(xpath =  "//button[text()='Update']")
    private WebElementFacade updateButton;

    @FindBy(xpath = "//button[text()='Cancel']")
    private WebElementFacade cancelButton;

    @FindBy(xpath ="//header[@class='content-panel-header float-right cancelled pending']//..//button[contains(@class,'success payment-dropdown')]")
    List <WebElementFacade> cancelSubscriptionDropdown;

    @FindBy(xpath ="//button[@class='btn btn-outline-success']")
    List<WebElementFacade> selectActionBtnCompletedPayment;

    @FindBy(xpath = "//div[@class='status']//span[contains(@class,'pack-status')]")
    List <WebElementFacade>  packPaymentStatusList;

    @FindBy(xpath = "//span[@class='pack-status complete']")
    List<WebElementFacade>  writeOnPaymentStatus;

    @FindBy(xpath = "//button[@class='dropdown-item'][text()='Holiday']")
    List <WebElementFacade>  holidayButton;

    @FindBy(xpath = "//h4[text()='Holiday']")
    public WebElementFacade holidayHeader;

    @FindBy(xpath =  "//div[@class='alert alert-warning']")
    private WebElementFacade warningMessage;

    @FindBy(xpath = "//div[@class='pipe-separate-children']//span[@class='pack-status holiday']")
    List <WebElement>  holidayStatus;

    @FindBy(xpath = "//select[@id='replace-delivery']//option")
    List<WebElement> optionsReplaceTopUp;

    @FindBy(xpath = "//select[@id='select-replacement-reason']")
    private WebElementFacade replaceReasonButton;

    @FindBy(xpath = "//input[@id='replace-pack-store-address']")
    private WebElementFacade storeAddressCheckBox;

    @FindBy(xpath = "//select[@id='replace-delivery']")
    public WebElementFacade selectDeliveryAddress;

    @FindBy(xpath ="//select[@id='select-replacement-reason']")
    private WebElementFacade replaceReason;

    @FindBy(xpath ="//td[text()='Solutions']//..//select[contains(@class,'form-control')]")
    private WebElementFacade replaceSolution;

    @FindBy(xpath = "//button[@class='btn-secondary pull-right']")
    private WebElementFacade replaceConfirmBtn;

    @FindBy(xpath = "//a[text()='Supplementary Orders']")
    public WebElementFacade supplementaryOrders;

    @FindBy(xpath = "//button[contains(.,'Edit Subscription')]")
    public List<WebElementFacade> replacementTabEditSubscriptionButton;

    @FindBy(xpath = "//span[@class='subscription_type']")
    List<WebElement> replacementLensSubscptnHeader;

    @FindBy(xpath = "//tr//td[text()='Solution']//..//td[4]//span[1]")
    private WebElementFacade packContentSolutionQty;

    @FindBy(xpath = "//tr//td[text()='Solution']//..//td[2]")
    private WebElementFacade packContentSolution;

    @FindBy(xpath = "//tr//td[text()='L']//..//td[4]//span[1]")
    private WebElementFacade packContentsLeftBoxes;

    @FindBy(xpath = "//tr//td[text()='R']//..//td[4]//span[1]")
    private WebElementFacade packContentsRightBoxes;

    @FindBy(xpath = "//span[@class='capitalise']")
    public List<WebElementFacade> subscriptionHeading;

    @FindBy(xpath = "//div[@class='order-details-id']//div[1]")  //Xpath for Release #45
    private WebElementFacade replacementOrderID;

    @FindBy(xpath = "//span[contains(.,'Released to Supply Chain')]")
    List<WebElement> ReleasedToSupplyChainDate;

    @FindBy(xpath = "//ul[@class='replacement-delivery-address']")
    private WebElementFacade replacementDeliveryAddress;

    @FindBy(xpath = "//table[@class='usage-tbl table table-sm selected']//th")
    private WebElementFacade selectedPackage;

    @FindBy(xpath = "//a[text()='Fit']")
    private WebElementFacade fitButton;

    @FindBy(xpath = "//th[contains(.,'Lens Supplier')]//..//td")
    List<WebElementFacade> lensSupplier;

    @FindBy(xpath = "//td[contains(.,'CooperVision')]")
    private WebElementFacade lensSupplierCooper;

    @FindBy(xpath = "//th[contains(.,'Lens Name')]//..//td")
    List<WebElementFacade> lensName;

    @FindBy(xpath = "//td[contains(.,'vusion daily ev')]")
    private WebElementFacade vusionLensName;

    @FindBy(xpath = "//td[contains(.,'irisian sph mth')]")
    private WebElementFacade lensNameIrisian;

    @FindBy(xpath = "//th[contains(.,'Diameter')]//..//td")
    List<WebElementFacade> diameter;


    @FindBy(xpath = "//td[contains(.,'+1.00')]")
    private WebElementFacade sphere;

    @FindBy(xpath = "//td[contains(.,'8.70')]")
    private WebElementFacade baseCurveIrisian;

    @FindBy(xpath = "//th[contains(.,'Base Curve')]//..//td")
    List<WebElementFacade> baseCurve;

    @FindBy(xpath = "//td[contains(.,'14.00')]")
    private WebElementFacade diameterIrisian;

    @FindBy(xpath = "//td[contains(.,'14.20')]")
    private WebElementFacade diameterIrisianSph;

    @FindBy(xpath = "((//td[contains(.,'-1.00')])[1]")
    private WebElementFacade sphereIrisian;

    @FindBy(xpath = "//td[contains(.,'24876025')]")
    private WebElementFacade skuIrisian;

    @FindBy(xpath = "//th[contains(.,'SKU')]//..//td")
    List<WebElementFacade> sku;

    @FindBy(xpath = "//td[contains(.,'styleNumber')]")
    private WebElementFacade styleNumberIrisian;

    @FindBy(xpath = "//th[contains(.,'Style Number')]//..//td")
    List<WebElementFacade> styleNumber;

    @FindBy(xpath = "//th[text()='Left']//..//following-sibling::tr/td[2]")
    List<WebElement> clFitDataLeft;

    @FindBy(xpath = "//th[text()='Right']//..//following-sibling::tr/td[1]")
    List<WebElement> clFitDataRight;

    @FindBy(xpath = "//header[contains(.,' Promotions')]")
    private WebElementFacade labelPromotionsHeader;

    @FindBy(xpath = "//button[@class = 'btn btn-primary']/following-sibling::label")
    private WebElementFacade labelDiscountTermsAndConditions;

    @FindBy(xpath = "//h5[contains(.,'Available Promotions')]")
    private WebElementFacade labelAvailablePromotions;

    @FindBy(xpath = "//div[@class='alert alert-warning']")
    private WebElementFacade authorizationCodeAlertMessage;

    @FindBy(xpath = "//label[@for = 'authorisation-input-field']")
    private WebElementFacade labelAuthorisationInputField;

    @FindBy(xpath = "//input[@id='authorisation-input-field']")
    private WebElementFacade discountAuthorizationCodField;

    @FindBy(xpath = "//div[@class='promotions-message']")
    private WebElementFacade discountConfirmationMessage;

    @FindBy(xpath = "//button[@class='btn btn-primary'][contains(.,'3 month 50%')]")
    private WebElementFacade discountButton;

    @FindBy(xpath = "//div[@class='pack-payments']/span[2]")
    public List<WebElement> printSchedulePayments;

    @FindBy(xpath ="//div[@class='pack-payments']/span[3]")
    List <WebElement> printSchedulePaymentStatus;

    @FindBy(xpath = "//span[contains(.,'Right eye -') ]/following-sibling::span")
    private WebElementFacade lensValueRightEye;

    @FindBy(xpath = "//span[contains(.,'Left eye -') ]/following-sibling::span")
    private WebElementFacade lensValueLeftEye;

    @FindBy(xpath = "//th[text()='Occasional']//..//..//..//following-sibling::tr//td[contains(.,'Left Eye')]")
    private WebElementFacade priceOccasionLeftEyeLenses;

    @FindBy(xpath = "//th[text()='Part Time']//..//..//..//following-sibling::tr//td[contains(.,'Left Eye')]")
    private WebElementFacade pricePartTimeLeftEyeLenses;

    @FindBy(xpath = "//th[text()='Full Time']//..//..//..//following-sibling::tr//td[contains(.,'Left Eye')]")
    private WebElementFacade priceFullTimeLeftEyeLenses;

    @FindBy(xpath = "//th[text()='Occasional']//..//..//..//following-sibling::tr//td[contains(.,'Right Eye')]")
    private WebElementFacade priceOccasionalRightEyeLenses;

    @FindBy(xpath = "//th[text()='Part Time']//..//..//..//following-sibling::tr//td[contains(.,'Right Eye')]")
    private WebElementFacade pricePartTimeRightEyeLenses;

    @FindBy(xpath = "//th[text()='Full Time']//..//..//..//following-sibling::tr//td[contains(.,'Right Eye')]")
    private WebElementFacade priceFullTimeRightEyeLenses;

    @FindBy(xpath = "//strong[contains(.,'30 Lenses per Delivery')]")
    private WebElementFacade occasionalLens;

    @FindBy(xpath = "//strong[contains(.,'60 Lenses per Delivery')]")
    private WebElementFacade partTimeLens;

    @FindBy(xpath = "//strong[contains(.,'90 Lenses per Delivery')]")
    private WebElementFacade fullTimeLens;

    @FindBy(xpath = "//table[@class='usage-tbl table total-per-month-tbl table-sm selected']")
    private WebElementFacade occasionalMonthly;

    @FindBy(xpath = "//table[@class='usage-tbl table total-per-month-tbl table-sm']")
    List<WebElement> partTimeMonthly;

    @FindBy(xpath = "//td[contains(.,'€15.66 per Month')]")
    private WebElementFacade fullTimeMonthly;

    @FindBy(xpath = "//*[@id=\"cart-usage-tbls\"]/div[2]/table[1]/tbody/tr[2]/td")
    private WebElementFacade PriceEyeForLenses;

    @FindBy(xpath = "(//td[contains(.,'Right Eye €15.66 for 30 Lenses')])[2]")
    private WebElementFacade partTimePriceEye;

    @FindBy(xpath = "(//td[contains(.,'Right Eye €15.66 for 30 Lenses')])[3]")
    private WebElementFacade fullTimePriceEye;

    @FindBy(xpath ="//button[contains(.,'Cancel Subscription')]")
    public WebElementFacade cancelSubscriptionButton;

    @FindBy(xpath ="//select[@class='form-control form-control-danger']")
    public WebElementFacade cancelReasonDropDown;

    @FindBy(xpath ="//button[contains(.,'Edit Subscription')]")
    public  List<WebElementFacade> editSubscriptionButton;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header float-right')]/div/div[1]")
    List<WebElementFacade> paymentDate;

    @FindBy(xpath = "//span[@class='text-label'][text()='Next Payment']//..//following-sibling::span")
    public WebElementFacade nextPayment;

    @FindBy(xpath = "//td[@class='text-green']/following-sibling::td")
    private WebElementFacade totalPerMonth;

    @FindBy(xpath = "//input[contains(@id,'authorisation-input-field')]")
    private WebElementFacade authorizationCode;
    @FindBy(xpath = "//div[@class='modal-dialog']//select")
    public WebElementFacade managePaymentDropdown;

    final public String discountAuthCodeAlertMessage = "This action requires a manager authorisation code.";
    public static int completedPaymentStatusCount = 0;
    public static String currencySign = "";
    public static String selectedPaymntDate;
    //public String totalPerMonth = "//tr[@class='heavy-border-vertical']//td[contains(., '%1$s')]";
    float extraPriceSolution;
    float existingPriceLens;
    public String extrasPrice;
    public String existingPrice;
    public String firstPackDeliveryDate;
    public String newPrice;
    public String AfterAddingPrice;
    public String AfterRemovingPrice;
    public static String disabledbutton1 = "//div[@aria-label='%1$s' and @class='ngb-dp-day disabled']";
    //public String discountButton = "//button[contains(., '%1$s')]//parent::div[contains(@class,'text-center inline col-md-6 col-sm-6')]";
    // public String lensesPerDelivery = "//th[text()='%1$s']//..//..//..//td[contains(.,'Lenses per Delivery')]";
    public String priceRightEyeLenses = "//th[text()='%1$s']//..//..//..//td[contains(.,'Right Eye')]";
    public String priceLeftEyeLenses = "//th[text()='%1$s']//..//..//..//td[contains(.,'Left Eye')]";
    public String usagePerMonthSingleEye = "//th[text()='%1$s']//..//..//..//..//td[contains(.,'per Month')]";
    public static String enabledButton = "//div[@aria-label='%1$s']";
    public static String orderID;
    public static String date;
    public static String firstPaymentStatus = "";
    public String status;
    public String refundDate;
    public String refundPayment;
    public String paymentPrice;


    public static String selectedDispatchDate;
    public static String accountType;
    public static String fulfilmentAddressType;
    public static String updatedfirstPaymentDate;
    public static String fitExpiry;
    public Response response;
    public static String mppDate;
    public static String customerID;
    public static String mppEndDate;
    public static ArrayList<String> paymentDateArray = new ArrayList<String>();
    public static ArrayList<String> paymentDateArrayUI = new ArrayList<String>();
    public static ArrayList<String> contactCentreAuthCode = new ArrayList<String>();
    public static ArrayList<String> storeAuthCode = new ArrayList<String>();
    public static String paymentDatePendingOrder;
    public static String paymentDateUI;
    public static Date paymentDateUIFormat;
    public static String leftBoxValue;
    public static String rightBoxValue;
    public static String solutionValue;
    public static String replaceOrderID;
    public int replacementtabEditSubscriptionBtnCount = 0;
    public String replaceWithStoreAddress = "";
    public static String currentAmount;
    public static double paymentToBeAdded;
    public static double balanceBeforeRefund;
    public static String refundAmt;
    public static String totalPaidValue;
    public static String nextPaymentDate = "N/A";
    public static String totalGoodwillValue;
    double completedCount = 0;
    double goodwillCount = 0;
    double ToatalCalculatedValue = 0.00;
    double TotalGoodwillPayment = 0.00;
    public boolean alert = false;
   // public static String selectDeliveryType = "";
    public static String cancellationReason;
    public static Date selectedCalenderDate;

    public static String subscriptionStatus;
    public static String storeNamedeatils;
    public String storeFullfilmentWarningMessage = "Are you sure you want the Store to fulfil this delivery? Once changed you will be required to ensure the customer receives their lenses. Delivery method will change for this pack only.";
    public String supplyChainFulfillmentMessage = "Are you sure you want the Supply Chain to fulfil this delivery? Delivery method will change for this pack only.";
    public String customerCollectiontWarningMessage = "Are you sure you wish to confirm the collection of goods by the customer? Once confirmed you will be unable to undo this action.";
    public String editPaymentDateWarningInfo = "Please Note: Where the selected date falls on a weekend or bank holiday the system will reschedule the payment for the next available working day.";
    public String holidayWarningMessage = "Are you sure you want to take a Subscription Holiday for this pack? Confirm to remove this pack from the schedule.";
    public String topupAlertMessage = " The payment amount shown will be debited in full within 5 days from the customer’s nominated payment method. ";
    public String PaymentCollectionInfoMessage = "Your regular deliveries will begin after your second payment has been taken.";
    public String postpayPaymentCollectionInfoMessage = "Your deliveries will begin after your first payment has been taken.";
    public String lensMailDeliveryServiceMessage = "Home delivery service will begin immediately.";
    public String writeOffAlert="This will write off this payment. Manager authorisation required.";
    public String writeOffMsg="Please provide Manager authorisation to process ";
    public String storeFulFillMentMessage = "As this customer is set up for store fulfilment please ensure that the pack is collected off on this screen once the pack has been sent.\n" +
            "N.B. Store will not be credited with sale of pack until it is marked as collected.";
    public List<String> packAddressList = new ArrayList<>();

    public static String todaysDateWithBackslashes(int days){
        final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        final LocalDate localDate = LocalDate.now().plusDays(days);
        date = dtf.format(localDate);
        final String todayDate = dtf.format(localDate);
        return todayDate;
    }

    public void createAndLaunchURL(String customerID, String customerType, String tdrNumber, String fit) {

        final String userName = testDataManager.getTestInputCommonData("login.usrName");
        final String userId = testDataManager.getTestInputCommonData("login.usrId");
        final String storeID = testDataManager.getTestInputRegionData("storeAddress.storeNo");
        final String customerNumber = customerID;
        final  String TDRNumber = tdrNumber;
        final String fitNumber = fit;
        final String baseURL = testDataManager.getTestInputCommonData("url.baseURL");
        logger.info(baseURL + ";usrName=" + userName + ";usrId=" + userId + ";store=" + storeID + ";custNbr=" + customerNumber + ";tdrNbr=" + TDRNumber + ";fitNbr=" + fitNumber + ";");
        final String url = baseURL + ";usrName=" + userName + ";usrId=" + userId + ";store=" + storeID + ";custNbr=" + customerNumber + ";tdrNbr=" + TDRNumber + ";fitNbr=" + fitNumber + ";";
        openUrl(url);
        waitABit(10000);
    }

    public void selectDailyPackage(String dailyType, String deliveryType, String payerType, String firstPackOption, String customerType){

        try{
            occasional.waitUntilClickable();
            String solutionSelected = "No Solution";
            assertTrue(occasional.isVisible() && partTime.isVisible() && fullTime.isVisible());
            if(dailyType.contains("Occasional")){
                clickElement(occasional);
            }
            else if(dailyType.contains("PartTime")){
                clickElement(partTime);
            }
             else{
                clickElement(fullTime);
            }

            //totalPerMonth = String.format(totalPerMonth, testDataManager.getTestInputRegionData("payer.currencySign"));
            //assertTrue(usagePerMonth.getText().substring(1, 6).contains(totalPerMonth.getText().substring(1, 5)));
            assertTrue(solutionSelected.equalsIgnoreCase(solutionDropdown.getText().trim()));
            assertEquals("", firstPaymentDate.getTextValue());
            assertTrue(paymentBasis.isVisible());
            assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));
            Select paymentTypeSelect = new Select(paymentBasis);
            if(payerType.equalsIgnoreCase("PRE")){
                paymentTypeSelect.selectByValue("0: Prepay");
                assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));
                assertEquals(deliveryMessage.getText(), PaymentCollectionInfoMessage);
            }
            else{
                paymentTypeSelect.selectByValue("1: Postpay");
                assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("1: Postpay"));
                assertElementText(deliveryMessage, postpayPaymentCollectionInfoMessage);
            }
            if(firstPackOption.equalsIgnoreCase("Yes")){
                clickElement(firstPackFulfilment);
            }else{
                logger.info("first pack fulFilment is not selected");
            }
            accountType = paymentBasisDropdownPrepay.getSelectedVisibleTextValue();
            selectPaymentDate(payerType,customerType);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void selectMonthlySolutionType(String solutionType, String deliveryType, String payerType, String firstPackOption, String customerType){
        String lensvalue = "";
        String singleEyeCustomer = "";
        assertPageObjectIsDisplayed(monthlyUsagePeriod);

        lensvalue = testDataManager.getTestInputRegionData(customerType+".lensCost");
        // assertTrue(usagePerMonth.getText().substring(1,6).contains(lensvalue));
        double monthlyLensSoltnPrice=Double.parseDouble(lensvalue);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().toLowerCase().trim().contains(solutionType.toLowerCase().trim()));
        }
        else
        {
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().toLowerCase().trim().equalsIgnoreCase("No solution"));
        }

        while(!solutionType.equalsIgnoreCase("No Solution")){
            solutionDropdown.waitUntilClickable();
            solutionDropdown.selectByVisibleText(solutionType.toLowerCase());
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().toLowerCase().trim().contains(solutionType.toLowerCase()));
            monthlyLensSoltnPrice = monthlyLensSoltnPrice + (Double.parseDouble(solutionPrice.getTextValue())/3);
            logger.info("lensvalue"+String.valueOf(monthlyLensSoltnPrice));
            break;
        }
        assertTrue(totalPermonth.getText().contains(String.valueOf(monthlyLensSoltnPrice)));
        assertPageObjectIsDisplayed(paymentBasis);
        assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));
        assertEquals("", firstPaymentDate.getTextValue());
        CustomerDetailsPage.completeAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        assertPageObjectIsDisplayed(paymentBasis);
        assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));

        Select paymentTypeSelect = new Select(paymentBasis);

        if(payerType.equalsIgnoreCase("PRE")){
            paymentTypeSelect.selectByValue("0: Prepay");
            assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));
            assertElementText(deliveryMessage, PaymentCollectionInfoMessage);
        }
        else{
            paymentTypeSelect.selectByValue("1: Postpay");
            assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("1: Postpay"));
            assertElementText(deliveryMessage,postpayPaymentCollectionInfoMessage);
        }
        if(firstPackOption.equalsIgnoreCase("Yes")){
            clickElement(firstPackFulfilment);
        }else{
            logger.info("first pack fulFilment is not selected");
        }
        accountType = paymentBasisDropdownPrepay.getSelectedVisibleTextValue();
        if(solutionType.equalsIgnoreCase("No Solution")) {

            waitForElement();
            selectPaymentDate(payerType,customerType);
        }else {
            waitForElement();
            selectPaymentDate(payerType,customerType);
            clickElement(solutionConfirmButton);
        }
    }

    public void selectPeroxideSolutionType(String solutionType, String deliveryType, String payerType, String firstPackOption, String authCode, String customerType){
        String lensvalue = "";
        String singleEyeCustomer = "";
        assertPageObjectIsDisplayed(monthlyUsagePeriod);

        lensvalue = testDataManager.getTestInputRegionData(customerType+".lensCost");
        if(lensValueLeftRightEye.containsText("None"))
        {
            float calcvalue  = Float.parseFloat(lensvalue)/2;
            lensvalue = Float.toString(calcvalue);
            singleEyeCustomer = "True";
        }
        logger.info("lensvalue:"+lensvalue);
        double monthlyLensSoltnPrice=Double.parseDouble(lensvalue);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().toLowerCase().trim().contains(solutionType.toLowerCase().trim()));
        }
        else
        {
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().toLowerCase().trim().equalsIgnoreCase("No solution"));
        }

        while(!solutionType.equalsIgnoreCase("No Solution")){
            solutionDropdown.waitUntilClickable();
            solutionDropdown.selectByVisibleText(solutionType.toLowerCase());
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().toLowerCase().trim().contains(solutionType.toLowerCase()));
            if(singleEyeCustomer.equalsIgnoreCase("Yes"))
            {
                logger.info("single eye solution");
                monthlyLensSoltnPrice = monthlyLensSoltnPrice + (Double.parseDouble(solutionPrice.getTextValue())/6);
                logger.info("lensvalue single sol:"+String.valueOf(monthlyLensSoltnPrice));
            }
            else
            {
                logger.info("both eye solution");
                monthlyLensSoltnPrice = monthlyLensSoltnPrice + (Double.parseDouble(solutionPrice.getTextValue())/3);
                logger.info("lensvalue both sol:"+String.valueOf(monthlyLensSoltnPrice));
            }
            break;
        }
        assertTrue(totalPermonth.getText().contains(String.valueOf(monthlyLensSoltnPrice)));
        assertPageObjectIsDisplayed(paymentBasis);
        assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase(testDataManager.getTestInputRegionData("CommonCustomerData.paymentBasis")));
        assertEquals("", firstPaymentDate.getTextValue());
        CustomerDetailsPage.completeAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        assertPageObjectIsDisplayed(paymentBasis);
        assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase(testDataManager.getTestInputRegionData("CommonCustomerData.paymentBasis")));

        Select paymentTypeSelect = new Select(paymentBasis);

        if(payerType.equalsIgnoreCase("PRE")){
            paymentTypeSelect.selectByValue(testDataManager.getTestInputRegionData("CommonCustomerData.paymentBasis"));
            assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase(testDataManager.getTestInputRegionData("CommonCustomerData.paymentBasis")));
            assertElementText(deliveryMessage, PaymentCollectionInfoMessage);
        }
        else{
            paymentTypeSelect.selectByValue(testDataManager.getTestInputRegionData("CommonCustomerData.postPaymentBasis"));
            assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase(testDataManager.getTestInputRegionData("CommonCustomerData.postPaymentBasis")));
            assertElementText(deliveryMessage,postpayPaymentCollectionInfoMessage);
        }
        if(firstPackOption.equalsIgnoreCase("Yes")){
            clickElement(firstPackFulfilment);
        }else{
            logger.info("first pack fulFilment is not selected");
        }
        accountType = paymentBasisDropdownPrepay.getSelectedVisibleTextValue();
        selectPaymentDate(payerType,customerType);
        setText(authorizationCode,authCode);
        clickElement(proceedButton);
        clickElement(solutionConfirmButton);

    }
    public void wantsToAddHolidayList(int noOfHolidays) {
        bankHoliday.clear();
        for(int i=1; i<=noOfHolidays;i++) {
            bankHoliday.add(testDataManager.getTestInputRegionData("BankHoliday.Date"+i));
        }

    }
    public boolean isHoliday(String str) {
        flag = false;
        for(int i =1; i<=bankHoliday.size(); i++) {
            if((testDataManager.getTestInputRegionData("BankHoliday.Date"+i)).contains(str)) {
                flag = true;
                break;
            }
            else {
                flag = false;
            }
        }
        return flag;

    }
    public String getValidPaymentDate(Date selecteddt) {
        wantsToAddHolidayList(65);
        PaymentSchedule.clear();
        Date firstpaymentDate = selecteddt;
        Calendar c = Calendar.getInstance();
        c.setTime(firstpaymentDate);
        c.getTime();
        SimpleDateFormat tcs = new SimpleDateFormat("dd/MM/yyyy");
        String output = tcs.format(c.getTime());
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        String paymentDay = sdf.format(c.getTime());

        do{
            if(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")||isHoliday(output)==true){
                c.setTime(c.getTime());
                c.add(Calendar.DATE, 1);
                c.getTime();
                paymentDay = sdf.format(c.getTime());
                output = tcs.format(c.getTime());
                logger.info(output);
            }

        }while(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")||isHoliday(output)==true);

        firstpaymentDateSum = c.getTime();
        logger.info("FirstPAy: "+firstpaymentDateSum);
        logger.info("firstPayment Date: "+output);
        PaymentSchedule.add(output);

        return output;

    }

    public void selectPaymentDate(String payerType,String customerType) {
        SimpleDateFormat tfs = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");
        Calendar a = Calendar.getInstance();
        Calendar b = Calendar.getInstance();
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 12);
        a.setTime(new Date());
        a.add(Calendar.DATE, 11);
        b.setTime(new Date());
        b.add(Calendar.DATE, 12);
        String output2 = tfs.format(a.getTime());
        String output3 = tfs.format(b.getTime());
        firstPaymentDate.waitUntilClickable();
        clickOn(firstPaymentDate);

        String disabledButton = String.format(disabledbutton1,output2);
        String enabledButton = String.format(SubscriptionPage.enabledButton,output3);
        assertTrue(getDriver().findElement(By.xpath(enabledButton)).isDisplayed());
        getDriver().findElement(By.xpath(enabledButton)).click();
        selectedPaymentDate = firstPaymentDate.getTextValue();
        assertPageObjectIsDisplayed(firstDeliveryDate);
        if(customerType.equalsIgnoreCase("non-Quarterly")){
            date = deliveryDateFormat(selectedPaymentDate,11);
        }
        else if(payerType.equalsIgnoreCase("PRE")) {
            date = deliveryDateFormat(selectedPaymentDate,2);
        }
        else {
            date = deliveryDateFormat(selectedPaymentDate,1);
        }
        logger.info(date);
        assertEquals(firstDeliveryDate.getTextValue(), date);
        accountType = paymentBasisDropdownPrepay.getSelectedVisibleTextValue();
        updatedFirstDeliveryDate = firstDeliveryDate.getText();
        clickElement(futureConfirmButton);

    }

    public void performExpeditePack() {
        waitABit(15000);
        try {
            for (int k = 0; k < packStatusList.size(); k++) {
                final String packstatus = packStatusList.get(k).getText();
                if (packstatus.equalsIgnoreCase("Pending")) {
                    final String packDate = packDueDate.get(0).getText().substring(13);
                    Date newDate = new SimpleDateFormat("dd/MM/yyyy").parse(packDate);
                    final String actPayerType = payerType.getText();
                    Date maxdate;
                    if (actPayerType.equalsIgnoreCase("Prepay")) {
                        maxdate = new SimpleDateFormat("dd/MM/yyyy").parse(paymentDateList.get(1).getText().substring(5));
                    } else {
                        maxdate = new SimpleDateFormat("dd/MM/yyyy").parse(paymentDateList.get(0).getText().substring(5));
                    }
                    logger.info("The Date selected is:" + newDate);
                    actionDropdown.get(0).click();
                    for (int j = 0; j < actionDropdown.size(); j++) {
                        waitABit(5000);
                        if (actionDropdown.get(0).getText().contains("Early Pack Request")) {
                            logger.info("get Text:" + actionDropdown.get(j).getText());
                            assertTrue(actionDropdown.get(0).getText().contains("Early Pack Request"));
                            assertTrue(expediteButton.get(0).isVisible());
                            clickElement(expediteButton.get(0));
                            assertTrue(earlyPackRequestHeader.isVisible());
                            clickElement(calenderDate);

                            SimpleDateFormat tfs = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");
                            SimpleDateFormat expFrmt = new SimpleDateFormat("dd/MM/yyyy");

                            Calendar a = Calendar.getInstance();
                            Calendar b = Calendar.getInstance();
                            a.setTime(newDate);
                            a.add(Calendar.DATE, -29);

                            b.setTime(newDate);
                            b.add(Calendar.DATE, -28);

                            String output = tfs.format(a.getTime());
                            String output2 = tfs.format(b.getTime());
                            String output3 = expFrmt.format(b.getTime());

                            Date actualExpDueDate = new SimpleDateFormat("dd/MM/yyyy").parse(output3);
                            if (maxdate.after(actualExpDueDate)) {
                                b.setTime(maxdate);
                                b.add(Calendar.DATE, -1);
                                output = tfs.format(b.getTime());
                                output2 = tfs.format(maxdate);
                            }

                            final String disabledbutton = String.format(disabledbutton1, output);
                            final String ebledbutton = String.format(enabledButton, output2);

                            if (isElementVisible(By.xpath(ebledbutton)) == true) {
                                if (isElementVisible(By.xpath(disabledbutton)) == false) {
                                    clickElement(previousMonthArrow);
                                    logger.info("Select previous Month");
                                }
                            } else {
                                clickElement(previousMonthArrow);
                                logger.info("Select previous Month");
                            }
                            String buttonClass = getDriver().findElement(By.xpath(disabledbutton)).getAttribute("class");
                            assertTrue(buttonClass.equalsIgnoreCase("ngb-dp-day disabled"));

                            assertTrue(getDriver().findElement(By.xpath(ebledbutton)).isDisplayed());
                            getDriver().findElement(By.xpath(ebledbutton)).click();

                            final String selectedCalenderDate = calenderDate.getTextValue();
                            logger.info("Calender Date " + selectedCalenderDate);
                            final Date earlypayDate = new SimpleDateFormat("dd/MM/yyyy").parse(selectedCalenderDate);
                            logger.info("selectedPaymentDate" + earlypayDate);

                            clickElement(futureConfirmButton);
                            waitABit(10000);
                            assertEquals(packDueDate.get(0).getText().substring(14), selectedCalenderDate);
                        }
                    }
                    break;
                } else {
                    logger.info("Pack can not be Expidite");
                }

            }
        } catch (Exception ex) {
            logger.info(ex.getMessage());
        }
    }


    public void updatingPaymentDate(String noOfDays, String payment) {


        switch (payment) {
            case "first":
                logger.info("First Action Dropdown");
                waitABit(5000);
                clickElement(selectActionBtnPendingPayment.get(0));
                break;

            case "second":
                logger.info(paymentDateList.get(0).getText().substring(5));
                firstPaymentDateInSchedule = paymentDateList.get(0).getText().substring(5);
                logger.info("The First payment Date to be expected is:" + firstPaymentDateInSchedule);
                selectActionBtnPendingPayment.get(1).click();
                break;
        }
        waitABit(5000);
        clickElement(editPaymentDateVisibleButton);
        editPaymentDateVisibleButton.selectByVisibleText("Edit Payment Date");
        String getCalenderDate = calenderDate.getTextValue();
        try {
            Date newCalenderDate = new SimpleDateFormat("dd/MM/yyyy").parse(getCalenderDate);
            logger.info("Current Selected Date:" + newCalenderDate);
            SimpleDateFormat tfs = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");

            assertEquals(warningInfo.getText(), editPaymentDateWarningInfo);

            calendarBtn.waitUntilVisible();
            clickElement(calendarBtn);

            Calendar a = Calendar.getInstance();
            a.setTime(newCalenderDate);
            a.add(Calendar.DATE, Integer.parseInt(noOfDays));

            final String selectCalenderDate = tfs.format(a.getTime());
            logger.info("Date to Select:" + selectCalenderDate);

            final String clickableDate = String.format(enabledButton, selectCalenderDate);
            logger.info("Calender-clickableDate:" + clickableDate);
            if (isElementVisible(By.xpath(clickableDate)) == true) {
                getDriver().findElement(org.openqa.selenium.By.xpath(clickableDate)).click();
            } else {

                while (previousMonthArrow.isEnabled()) {
                    previousMonthArrow.waitUntilClickable();
                    clickElement(previousMonthArrow);
                    if (isElementVisible(org.openqa.selenium.By.id(clickableDate))) {
                        getDriver().findElement(org.openqa.selenium.By.xpath(clickableDate)).click();
                        break;
                    }
                }
                if (nextMonthArrow.isVisible()) {
                    logger.info("entered to check next month");
                    while (nextMonthArrow.isEnabled()) {
                        clickElement(nextMonthArrow);
                        if (isElementVisible(org.openqa.selenium.By.id(clickableDate))) {
                            getDriver().findElement(org.openqa.selenium.By.xpath(clickableDate)).click();
                            break;
                        }
                    }
                }
            }

            SummaryPage.PaymentSchedule.clear();
            selectedPaymentDate = calenderDate.getTextValue();
            logger.info("The new Date selected for Edit:" + selectedPaymentDate);
            final Date payDate = new SimpleDateFormat("dd/MM/yyyy").parse(selectedPaymentDate);
            validFirstPayment = getValidPaymentDate(payDate);
            secondPaymentDateInSchedule = getValidPaymentDate(payDate);
            clickElement(confirmButton);
            waitABit(10000);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void verifyPaymentSchedule() throws Exception {
        int j = 0;
        do {
            String UIDate = updatedPaymentDate.get(j).getText().substring(5);
            String CalcDate = String.valueOf(SummaryPage.paymentDate.get(j).getText().substring(5));
            logger.info("UI DATE :" + UIDate);
            logger.info("CALC DATE :" + CalcDate);
            assertEquals(UIDate, CalcDate);
            j++;
        }
        while (j < updatedPaymentDate.size());
    }
    public void verifyPaymentScheduleAfterUpdatingUsage(String customerType) {

        clickElement(scheduleTab);
        ArrayList <String> pendingPackPayments = new ArrayList<String>();
        pendingPackPayments.clear();
        int p=0;
        for (int j=0;j<packPaymentList.size();j++) {

            final String UIUpdatedPacks = packPaymentList.get(j).getText().substring(9);
            final String UIPaymentStatus = packPaymentStatusList.get(j).getText();
            logger.info(UIPaymentStatus);
            if(UIPaymentStatus.equalsIgnoreCase("PENDING")) {
                pendingPackPayments.add(UIUpdatedPacks);
                System.out.println("UI DATE :"+pendingPackPayments.get(p));
                p++;

            }

        }
        System.out.println(pendingPackPayments.size());

        for(int k=0; k<3;k++) {
            int size = pendingPackPayments.size();
            if(size%3!=0) {
                pendingPackPayments.remove(0);
            }
        }
        for(int i=0; i<pendingPackPayments.size();i++) {

            final String updatedPayments = pendingPackPayments.get(i);
            assertEquals(updatedPayments, testDataManager.getTestInputRegionData(customerType + ".lensCost"));
        }

    }

    //verifying subsequent delivery date
    public void verifySubsequentDeliveryDate() throws Exception {

        try {
            String firstDelDate = firstDelivDate.getText();
            String nextDelDate = nextDeliverySubDetail.getText();
            Date firstDelivery = new SimpleDateFormat("dd/MM/yyyy").parse(firstDelDate);
            Date nextDeliveryDate;
            updatedFirstDeliveryDate = firstDeliveryDate.getText();
            assertEquals(firstDelDate, updatedFirstDeliveryDate);
            assertEquals(nextDelDate, updatedFirstDeliveryDate);


            List<WebElement> dueDateList = getDriver().findElements(org.openqa.selenium.By.xpath("//header[@ng-reflect-klass='content-panel-header clearfix']/div[@class='pipe-separate-children']/div[2]"));
            for (int i = 1; i <= dueDateList.size(); i++) {
                assertEquals(dueDateList.get(i - 1).getText().substring(14), nextDelDate);
                Calendar c = Calendar.getInstance();
                c.setTime(firstDelivery);
                c.add(Calendar.MONTH, 3 * i);
                nextDeliveryDate = c.getTime();
                nextDelDate = new SimpleDateFormat("dd/MM/yyyy").format(nextDeliveryDate);

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void getNextPaymentDateAfterSecondPaymentDateEdit(Date selecteddt) {

        logger.info("The Payment Date in array is:" +PaymentSchedule);

        for (int j=2;j<paymentDate.size();j++) {

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(selecteddt);
            final int dateOfMonth1 = calendar.get(Calendar.DAY_OF_MONTH);
            logger.info("day1 "+dateOfMonth1);
            calendar.add(Calendar.MONTH, j-1);
            int dateOfMonth2 = calendar.get(Calendar.DAY_OF_MONTH);
            logger.info("day2 "+dateOfMonth2);
            if(dateOfMonth1!=dateOfMonth2) {
                calendar.add(Calendar.DATE, 1);
                logger.info("the dates are not matching");
            }
            logger.info("The refernce holding date before adding a month" +calendar.getTime());
            calendar.getTime();

            SimpleDateFormat format = new SimpleDateFormat("EEEEE, MMMMM dd, yyyy");
            String paymentDt = format.format(calendar.getTime());
            SimpleDateFormat tcs = new SimpleDateFormat("dd/MM/yyyy");
            String output = tcs.format(calendar.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
            String paymentDay = sdf.format(calendar.getTime());

            do{
                if(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")|| isHoliday(output)){
                    //c.setTime(new Date());
                    calendar.setTime(calendar.getTime());
                    calendar.add(Calendar.DATE, 1);
                    calendar.getTime();
                    paymentDay = sdf.format(calendar.getTime());
                    paymentDt = format.format(calendar.getTime());
                    output = tcs.format(calendar.getTime());
                }

            }while(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")|| isHoliday(output));
            logger.info("Adding to payment schedule:"+output);
            PaymentSchedule.add(output);
        }

    }

    //verifying payment schedule after second payment date
    public void verifyPaymentScheduleAfterEditSecondPaymentDate() throws Exception {
        SummaryPage.PaymentSchedule.clear();
        Date payDate1 = new SimpleDateFormat("dd/MM/yyyy").parse(firstPaymentDateInSchedule);
        validFirstPayment = getValidPaymentDate(payDate1);

        SummaryPage.PaymentSchedule.add(secondPaymentDateInSchedule);

        logger.info("selectedPaymentDate:" + selectedPaymentDate);
        Date payDate = new SimpleDateFormat("dd/MM/yyyy").parse(selectedPaymentDate);
        logger.info("payDate:" + payDate);
        getNextPaymentDateAfterSecondPaymentDateEdit(payDate);
            final String UIDate = updatedPaymentDate.get(1).getText().substring(5);
            final String CalcDate = SummaryPage.PaymentSchedule.get(0);
            logger.info("UI DATE :" + updatedPaymentDate.get(1).getText().substring(5));
            logger.info("CALC DATE :" + SummaryPage.PaymentSchedule.get(0));
            assertEquals(UIDate, CalcDate);
    }

    public void editDeliveryAddressForSubscription() {
        clickElement(firstChangeLink.get(0));
        newAddressDropDown.selectByVisibleText(testDataManager.getTestInputRegionData("address.number") + " " + testDataManager.getTestInputRegionData("address.name") + " " + testDataManager.getTestInputRegionData("address.addressLine") + " " + testDataManager.getTestInputRegionData("address.postcode"));
        clickElement(confirmButton);
        waitABit(2000);

        final String newAddressSelected = testDataManager.getTestInputRegionData("address.number") + " " + testDataManager.getTestInputRegionData("address.name") + " " + testDataManager.getTestInputRegionData("address.addressLine") + " " + testDataManager.getTestInputRegionData("address.town")  + " " + testDataManager.getTestInputRegionData("address.county")  + " " + testDataManager.getTestInputRegionData("address.postcode");
        logger.info(newAddressSelected);
        final String expectedAddress = changedDeliveryAdd.get(0).getText().replaceAll("[\r\n]+", " ");
        logger.info(expectedAddress);

        assertTrue(expectedAddress.contains(newAddressSelected));
    }


    public void userPerformsChangeUsageAndVerifiesSchedule(String selectingUsage,String customerType) {
        waitForElement();
        assertPageObjectIsDisplayed(lensSubstnHeader);
        clickElement(packageTab);
        updatePackage.waitUntilVisible().waitUntilDisabled();
        assertTrue(!updatePackage.isClickable());
        newUsage = String.format(newUsage, selectingUsage);
        getDriver().findElement(By.xpath(newUsage)).click();
        clickElement(updatePackage);
        clickElement(emailSendButton);
        clickElement(solutionUpdateButton);
        clickElement(scheduleTab);
        final String expectedAmt = testDataManager.getTestInputRegionData(customerType+".lensCost");
        for (int k = 0; k < packStatusList.size(); k++) {
            if (packStatusList.get(k).getText().equalsIgnoreCase(testDataManager.getTestInputRegionData("CommonCustomerData.packStatus"))) {
                assertEquals(packPaymentList.get(k).getText().substring(9,13), expectedAmt.substring(0,4));

            }
        }
    }


    public void verifyLeadTime(String leadTime) throws Exception {

        String fistDeliveryDateHeader = firstDeliveryDateInHeader.getText();
        int lead = Integer.parseInt(leadTime);
        Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(fistDeliveryDateHeader);
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        c.add(Calendar.DATE, lead);
        SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy");
        String releasedDate = simple.format(c.getTime());
        String s = "//div[@class='order-details-content'] /span[contains(text(),'Released to Supply Chain')]";
        String s2 = String.format(s, releasedDate);
        assertTrue(getDriver().findElement(By.xpath(s2)).isDisplayed());

    }

    public void verifyPackStatus() {
        try {

            logger.info("Number of total packs - " + packStatusList.size());
            for (int k = 0; k < packStatusList.size(); k++) {
                status = packStatusList.get(k).getText();
                assertEquals("PENDING", status);

            }
        } catch (StaleElementReferenceException ex) {
            ex.printStackTrace();
        }
    }
    public void verifyReplaceisAvailable(){
        selectActnDrpDownPendingDispatched.get(0).click();
        waitForElement();
        if(replaceBtn.size()==0){
            getDriver().navigate().refresh();
            searchPage.findCustomerByID(SearchPage.customerID);
            customerDashboard.clickElement(customerDashboard.editSubscriptnBtn.get(0));
            selectActnDrpDownPendingDispatched.get(0).click();
            waitForPageLoader();
            replaceBtn.get(0).waitUntilVisible();
            selectActnDrpDownPendingDispatched.get(0).click();
        }
    }

    public void performPackReplace(String replaceReason, String leftboxQty, String rightboxQty, String custType) {

        for (int i = 0; i < selectActnDrpDownPendingDispatched.size(); i++) {
            orderID = orderIDList.get(i).getText();
            orderID = orderID.substring(9);
        }
        selectActnDrpDownPendingDispatched.get(0).click();
        waitForElement();
        replaceBtn.get(0).click();
        assertPageObjectIsDisplayed(replaceHeader);
        leftQuantityBox.selectByVisibleText(leftboxQty);
        rightQuantityBox.selectByVisibleText(rightboxQty);
        leftBoxValue = leftboxQty;
        rightBoxValue = rightboxQty;
        // Included the below condition to create Replacement with New address for Socrates customer
        logger.info("Dropdow Values:" + selectDeliveryAddress.getTextValue());
        final String addressToSelect = testDataManager.getTestInputRegionData("address.number") + " " + testDataManager.getTestInputRegionData("address.name") + " " + testDataManager.getTestInputRegionData("address.addressLine") + " " + testDataManager.getTestInputRegionData("address.town") + " " + testDataManager.getTestInputRegionData("address.postcode") + " " + testDataManager.getTestInputRegionData("address.countryName");
        logger.info("addressToSelect:" + addressToSelect);
        storeAddressCheckBox.waitUntilVisible();
        if (custType.contains("Monthly Solution")) {
            clickElement(storeAddressCheckBox);
            solutionValue = "Yes";
        } else {
            solutionValue = "No";
        }
        clickElement(replaceConfirmBtn);
    }

    public void verifyReplacePackStatusOnly(String addressType) {
        subscriptionBackButton.waitUntilClickable();
        clickElement(subscriptionBackButton);
        clickElement(supplementaryOrders);
        waitForPageLoader();
        for (int i = replacementtabEditSubscriptionBtnCount; i < replacementTabEditSubscriptionButton.size(); i++) {
            assertTrue((replacementLensSubscptnHeader.get(i).getText()).substring(0, 24).equalsIgnoreCase("Lens Subscription - Pack") && replacementLensSubscptnHeader.get(i).getText().contains("Replacement"));
            replacementTabEditSubscriptionButton.get(i).click();
            waitForPageLoader();
            replacementtabEditSubscriptionBtnCount++;
            assertTrue((subscriptionHeading.get(2).getText()).substring(0, 24).equalsIgnoreCase("Lens Subscription - Pack") && subscriptionHeading.get(2).getText().contains("Replacement"));
            assertTrue(!replacementOrderID.getText().contains(SubscriptionPage.orderID));
            String packsize = String.valueOf(packStatusList.size());
            assertEquals("1", packsize);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            final String todaysDate = sdf.format(c.getTime());
            if (packStatusList.get(i).getText().equalsIgnoreCase("Pending")) {
                assertTrue(!actionDropdown.get(i).isEnabled());

            } else if (packStatusList.get(i).getText().equalsIgnoreCase("Dispatched")) {
                actionDropdown.get(i).click();
                assertTrue(visibleDropdown.get(i).getText().equalsIgnoreCase("Print Receipt"));
            } else {
                fail("Pack Status is Incorrect");
            }

            for (int j = 0; j < packPaymentStatusList.size(); j++) {
                //using substring for assertion
                assertTrue(updatedPaymentDate.get(j).getText().substring(5).equalsIgnoreCase(todaysDate));
                assertTrue(packPaymentStatusList.get(j).getText().equalsIgnoreCase("COMPLETED OFFLINE"));
                assertTrue(packPaymentList.get(j).getText().substring(9).equalsIgnoreCase("0.00"));
            }
            //using substring for assertion
            assertEquals(ReleasedToSupplyChainDate.get(0).getText().substring(26), todaysDate);
            clickElement(packageTab);
            assertEquals(replacementDeliveryAddress.getText().replaceAll("[\r\n]+", " "), testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress"));
            clickElement(subscriptionBackButton);
            assertEquals(deliveryAdd.getText().replaceAll("[\r\n]+", " "), testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress"));
            clickElement(subscriptionBackButton);
            assertTrue(replacementLensSubscptnHeader.get(i).getText().contains("Replacement"));
        }
    }

    public void verifyCustomerPackageDetails(String solutionType) {

        packageTab.waitUntilVisible();
        clickElement(packageTab);
        selectedPackage.waitUntilVisible();
        //assertElementText(selectedPackage, "Monthly");
        solutionDropdown.waitUntilVisible();
        if (solutionType.equalsIgnoreCase("No Solution")) {
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().trim().equalsIgnoreCase(solutionType));
        } else {
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().trim().toLowerCase().contains(solutionType.toLowerCase().trim()));
        }
        clickElement(scheduleTab);
    }

    public void verifyCLFitDataForMonthlySubscribed(String customerType) {

        clickElement(fitButton);
        assertElementContainsText(lensSupplier.get(0),testDataManager.getTestInputRegionData(customerType + ".LensSupplier"));
        assertElementContainsText(lensName.get(0),testDataManager.getTestInputRegionData(customerType + ".LensName"));
        assertElementText(baseCurve.get(0),testDataManager.getTestInputRegionData(customerType + ".BaseCurve"));
        assertElementText(diameter.get(0),testDataManager.getTestInputRegionData(customerType + ".Diameter"));
        assertElementText(sku.get(0),testDataManager.getTestInputRegionData(customerType + ".SKU"));
        assertElementText(styleNumber.get(0),testDataManager.getTestInputRegionData(customerType + ".StyleNumber"));
        clickElement(subscriptionBackButton);
    }
    public void verifyCLFitDataForMonthlyNoSolution(String customerType) {

        clickElement(fitButton);
        assertElementContainsText(lensSupplier.get(0),testDataManager.getTestInputRegionData(customerType + ".LensSupplier"));
        assertElementContainsText(lensName.get(0),testDataManager.getTestInputRegionData(customerType + ".LensName"));
        assertElementText(baseCurve.get(0),testDataManager.getTestInputRegionData(customerType + ".BaseCurve"));
        assertElementText(sku.get(0),testDataManager.getTestInputRegionData(customerType + ".SKU"));
        assertElementText(styleNumber.get(0),testDataManager.getTestInputRegionData(customerType + ".StyleNumber"));
        clickElement(subscriptionBackButton);
    }


    public void selectDiscount(String discountType, String authCode) {
        evaluateJavascript("window.scrollBy(0,1000)");
        assertElementText(labelPromotionsHeader, "Promotions");
        assertElementText(labelAvailablePromotions, "Available Promotions");
        assertElementText(labelDiscountTermsAndConditions, "Terms & Conditions apply");
        waitForCondition().until(ExpectedConditions.elementToBeClickable(discountButton));
        clickElement(discountButton);
        discountAuthorizationCodField.waitUntilVisible();
        assertElementText(authorizationCodeAlertMessage, discountAuthCodeAlertMessage);
        assertElementText(labelAuthorisationInputField, "Enter Authorisation Code to proceed");
        setText(discountAuthorizationCodField, authCode);
        clickElement(promotionProceedBtn);
        promotionProceedBtn.waitUntilNotVisible();
        assertElementText(discountConfirmationMessage, "OFFER [ " + discountType + " ] WILL BE APPLIED AT SUBSCRIPTION CONFIRMATION");
        assertTrue(!confirmButton.isEnabled());
    }

    public void verifyDiscountPaymentPlan(String discountType, String customerType, List<WebElement> PaymentList, String firstPackStatus) {

        final String lensCost;
        if (customerType.equalsIgnoreCase("montlySolutionCustomer") || customerType.equalsIgnoreCase("montlySolutionCustomerSingleEye")) {
            lensCost = String.valueOf(Double.parseDouble(testDataManager.getTestInputRegionData(customerType+".lensCost")) + Double.parseDouble(testDataManager.getTestInputRegionData(customerType+".solutionCost")));
        } else {
            lensCost = testDataManager.getTestInputRegionData(customerType+".lensCost");
        }
        DecimalFormat f = new DecimalFormat("##.00");
        switch (discountType) {
            case "3 month 50%":
                for (int i = 0; i < PaymentList.size(); i++) {
                    if (i <= 2) {
                        if (firstPackStatus.equalsIgnoreCase("Dispatched") || firstPackStatus.equalsIgnoreCase("Processing")) {
                            if (customerType.equalsIgnoreCase("montlySolutionCustomer") || customerType.equalsIgnoreCase("montlySolutionCustomerSingleEye"))
                                assertTrue(PaymentList.get(i).getText().substring(9).contains(f.format(Double.parseDouble(String.valueOf(Double.parseDouble(testDataManager.getTestInputRegionData(customerType+".lensCost")) + Double.parseDouble(testDataManager.getTestInputRegionData("montlySolutionCustomerSingleEye.solutionCost")))))));
                            else
                                assertTrue(PaymentList.get(i).getText().substring(9).contains(f.format(Double.parseDouble(lensCost) / 2)));
                        } else {
                            assertTrue(PaymentList.get(i).getText().substring(9).contains(String.format("%.02f", Double.parseDouble(lensCost) / 2)));
                        }
                    } else {
                        assertTrue(PaymentList.get(i).getText().substring(9).contains(lensCost));
                    }
                }
                break;
            case "Fixed":
                // code block
                break;
            default:
                for (int i = 0; i < PaymentList.size(); i++) {
                    assertTrue(PaymentList.get(i).getText().substring(9).contains(lensCost));
                }
        }


    }

    public void verifySingleEyeDetailsOnNewSubscriptionPage(String eyeType, String customerType) {

        assertElementText(occasionalLens, "30 Lenses per Delivery");
        assertElementText(partTimeLens, "60 Lenses per Delivery");
        assertElementText(fullTimeLens, "90 Lenses per Delivery");

        waitForElement();
        clickElement(occasional);
        assertElementContainsText(occasionalMonthly, (Double.toString(Double.parseDouble(testDataManager.getTestInputRegionData("Occasional.gross_amount")) / 3).substring(1,3)));
        clickElement(partTime);
        assertElementContainsText(occasionalMonthly, (Double.toString(Double.parseDouble(testDataManager.getTestInputRegionData("PartTime.gross_amount")) * 2 / 3).substring(1,3)));
        clickElement(fullTime);
        assertElementContainsText(occasionalMonthly, testDataManager.getTestInputRegionData("FullTime.gross_amount"));
        if (eyeType.contains("Right")) { //has to use static

            assertElementText(lensValueRightEye, testDataManager.getTestInputRegionData(customerType + ".LensName"));
            assertElementText(lensValueLeftEye, "None");
            clickElement(occasional);
            logger.info("occasional:"+ PriceEyeForLenses.getText());
            logger.info("Right Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("Occasional.gross_amount") + " for 30 Lenses");
            assertTrue(PriceEyeForLenses.getText().contains("Right Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("Occasional.gross_amount") + " for 30 Lenses"));
            clickElement(partTime);
            assertTrue(PriceEyeForLenses.getText().contains("Right Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("PartTime.gross_amount") + " for 30 Lenses"));
            clickElement(fullTime);
            assertTrue(PriceEyeForLenses.getText().contains("Right Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("FullTime.gross_amount") + " for 30 Lenses"));
            assertTrue(!priceOccasionLeftEyeLenses.isVisible() && !pricePartTimeLeftEyeLenses.isVisible() && !priceFullTimeLeftEyeLenses.isVisible());

        } else {
            assertElementContainsText(lensValueLeftEye, testDataManager.getTestInputRegionData("dailyOccasionalCustomer.LensName"));
            assertElementContainsText(lensValueRightEye, "None");
            clickElement(occasional);
            assertTrue(PriceEyeForLenses.getText().contains("Left Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("Occasional.gross_amount") + " for 30 Lenses"));
            clickElement(partTime);
            assertTrue(PriceEyeForLenses.getText().contains("Left Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("PartTime.gross_amount") + " for 30 Lenses"));
            clickElement(fullTime);
            assertTrue(PriceEyeForLenses.getText().contains("Left Eye " + testDataManager.getTestInputRegionData("payer.currencySign") + testDataManager.getTestInputRegionData("FullTime.gross_amount") + " for 30 Lenses"));
            assertTrue(!priceOccasionalRightEyeLenses.isVisible() && !pricePartTimeRightEyeLenses.isVisible() && !priceFullTimeRightEyeLenses.isVisible());
        }

    }

    public void verifyCLFitDataForSingleEye(String customerType) {
        clickElement(fitButton);
        assertElementContainsText(lensSupplier.get(0),testDataManager.getTestInputRegionData(customerType + ".LensSupplier"));
        assertElementContainsText(lensName.get(0),testDataManager.getTestInputRegionData(customerType + ".LensName"));
        assertElementText(baseCurve.get(0),testDataManager.getTestInputRegionData(customerType + ".BaseCurve"));
        assertElementText(diameter.get(0),testDataManager.getTestInputRegionData(customerType + ".Diameter"));
        assertElementText(sku.get(0),testDataManager.getTestInputRegionData(customerType + ".SKU"));
        assertElementText(styleNumber.get(0),testDataManager.getTestInputRegionData(customerType + ".StyleNumber"));
        clickElement(subscriptionBackButton);


    }

    public void performWriteOff(String writeOffType, String authCode, String alertMsgPart){
        if(writeOffType.equalsIgnoreCase("Goodwill Payment")){
            selectActionBtnPendingPayment.get(0).click();
        }
        else if(writeOffType.equalsIgnoreCase("Write On Debt")) {
            selectActionBtnCompletedPayment.get(0).click();
        }
        else if(writeOffType.equalsIgnoreCase("Write Off Debt")) {
            cancelSubscriptionDropdown.get(0).click();
        }
        final String payToBeAdded = packPaymentList.get(0).getText().substring(9);
        paymentToBeAdded = Double.parseDouble(payToBeAdded);
        totalPaidValue = calculateCompletedPayments();

        for (int j=0;j<visibleDropdown.size();j++){

            logger.info("The elements in the Dropdown are:"+visibleDropdown.get(j).getText());
            if(visibleDropdown.get(j).getText().equals(writeOffType)){
                assert(visibleDropdown.get(j).getText().equals(writeOffType));
                visibleDropdown.get(j).click();
                logger.info(writeOffAlertMessage.getText());
                if(writeOffType.equalsIgnoreCase("Write Off Debt")){
                    logger.info(writeOffAlertMessage.getText().trim());
                    assertElementText(writeOffAlertMessage,writeOffAlert);
                }else
                {
                    logger.info("Please provide Manager authorisation to process "+alertMsgPart+".");
                    assertElementText(writeOffAlertMessage,writeOffMsg+alertMsgPart+".");
                }

                setText(authorizationCodeFieldWriteOff,authCode);
                clickElement(promotionProceedBtn);
                validateAuthorizationCode(authCode);
                if(alert==true)
                {
                    clickElement(confirmButton);
                }
                else
                {
                    assertObjectIsNotInteractable(confirmButton);
                    clickElement(cancelButton);
                }
                waitABit(15000);
                break;
            }
        }
    }
    public String calculateCompletedPayments() {
        ToatalCalculatedValue=0.00;
        completedCount = 0;
        String TotalCompletedPayment="0.00";
        for(int i=0; i< packPaymentStatusList.size();i++) {
            String packPaymentStatus = packPaymentStatusList.get(i).getText();
            if(packPaymentStatus.equals("COMPLETED")==true) {
                completedCount = completedCount+1;
                logger.info("The payment number" +completedCount+"is of value" +packPaymentList.get(i).getText().substring(9));
                logger.info(packPaymentList.get(i).getText().substring(9));
                ToatalCalculatedValue = ToatalCalculatedValue+Double.parseDouble(packPaymentList.get(i).getText().substring(9));
                TotalCompletedPayment = String.valueOf(ToatalCalculatedValue);
                TotalCompletedPayment = String.format("%.02f",ToatalCalculatedValue);
                logger.info("String value"+TotalCompletedPayment);
            }
        }
        return TotalCompletedPayment;
    }

    private void validateAuthorizationCode(String authorizationValue) {
        for (int i = 1; i < 6; i++) {
            contactCentreAuthCode.add(testDataManager.getTestInputRegionData("contactCenterPageAuthCode.ccAuthCode" + i));
        }
        for (int i = 1; i < 6; i++) {
            storeAuthCode.add(testDataManager.getTestInputRegionData("storeUserPageAuthCode.suAuthCode" + i));
        }
        for (int i = 0; i < contactCentreAuthCode.size(); i++) {
            if (contactCentreAuthCode.get(i).equals(authorizationValue)) {
                assertPageObjectIsDisplayed(authorizationConfirmationAlert);
                alert = true;
                break;
            } else {
                assertPageObjectIsDisplayed(authorizationConfirmationAlert);
                alert = true;
                break;
            }


        }
        while (!alert) {
            assertPageObjectIsDisplayed(invalidAuthorizationAlert);
        }
    }

    public void performCancelSubscription(int cancelDays, String reason) throws ParseException {
        clickEditSubscription();
        cancelSubscriptionButton.waitUntilVisible().waitUntilClickable();
        clickElement(cancelSubscriptionButton);
        cancelReasonDropDown.waitUntilPresent();
        cancelReasonDropDown.selectByVisibleText(reason);
        cancellationReason = reason;
        calendarBtn.waitUntilVisible();
        clickElement(calendarBtn);
        SimpleDateFormat tfs = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");
        Calendar a = Calendar.getInstance();
        a.setTime(new Date());
        a.add(Calendar.DATE, cancelDays);
        final String output2 = tfs.format(a.getTime());
        final String disabledButton = String.format(enabledButton,output2);
        logger.info("The Xpath built is:" +disabledButton);
        int i=0;
        do{
            if(isElementVisible(By.xpath(disabledButton))){
                getDriver().findElement(By.xpath(disabledButton)).click();
                break;
            }
            else{
                clickElement(nextMonthArrow);
                logger.info("Clicking next month");
            }

        }while(i>=0);
        final String cancelSubDate = calenderDate.getTextValue();
        selectedCalenderDate = new SimpleDateFormat("dd/MM/yyyy").parse(cancelSubDate);
        logger.info("cancel date:"+selectedCalenderDate);
        clickElement(futureConfirmButton);
        //Housekeeper job
        waitABit(150000);
    }
    public void updateMonthlyPackage(String updatedSolution) {
        waitForCondition().until(ExpectedConditions.elementToBeClickable(packageTab));
        clickElement(packageTab);
        solutionDropdown.waitUntilClickable();
        logger.info("The text is: "+solutionDropdown.getText());
        solutionDropdown.selectByVisibleText(updatedSolution);
        updatePackageButton.waitUntilVisible().waitUntilClickable();
        clickElement(updatePackageButton);
        clickElement(emailNotSendButton);
        clickElement(solutionUpdateButton);
        assertTrue(solutionDropdown.getSelectedVisibleTextValue().trim().equalsIgnoreCase(updatedSolution));
        currentAmount= testDataManager.getTestInputRegionData("monthlyOtherlens.updated_amount"); //This amount will be used in Price Update testcase only.
    }
    public void verifyAuthCodeToPerformRefundForFirstPayment(String refundReason,String refundMethod,String authorizationValue,String nextPaymentAmt) {
        balanceBeforeRefund = Double.parseDouble(nextPaymentAmt);
        //assertTrue(selectActionBtnCompletedPayment.size()>0);
        clickElement(managepayment);
        refundAmt=packPaymentList.get(0).getText().substring(9);
        waitFor(editPaymentDateVisibleButton);
        editPaymentDateVisibleButton.selectByVisibleText(" Refund Payment ");
        while(editPaymentDateVisibleButton.getFirstSelectedOptionVisibleText().equals("Refund Payment")){
            assertPageObjectIsDisplayed(refundPaymentHeader);
            clickElement(refundReasonDropdown);
            refundReasonDropdown.selectByVisibleText(refundReason);
            setText(authorization,authorizationValue);
            proceedButton.waitUntilClickable();
            clickElement(proceedButton);
            if(confirmButton.isEnabled())
            {
                clickElement(confirmButton);

            }
            else
            {
                assertPageObjectIsDisplayed(invalidAuthorizationAlert);
                assertObjectIsNotInteractable(confirmButton);
                clickElement(cancelButton);
            }
            break;
        }
    }


    public void multipleRefund(){

        if(alert==true)
        {
            clickElement(confirmButton);
        }
        else
        {
            assertObjectIsNotInteractable(confirmButton);
            clickElement(cancelButton);
        }
        totalPaidValue = calculateCompletedPayments();
    }
    public void userChangesCustomerPackage(String newPackage, String customerType) throws ParseException{

        assertPageObjectIsDisplayed(lensSubstnHeader);
        String packDeliveryDate="";

        Date packChangeDate = null;
        int count=0,inFlightPackCount=0;
        for(int i=0;i<packPaymentStatusList.size();i++)
        {
            if(packPaymentStatusList.get(i).getText().equalsIgnoreCase("Completed") || packPaymentStatusList.get(i).getText().equalsIgnoreCase("Authorised"))
            {
                count++;
            }
        }
        for(int i=0;i<packStatusList.size();i++)
        {
            if(!packStatusList.get(i).getText().equalsIgnoreCase("Pending"))
            {
                inFlightPackCount++;
            }
        }
        if(count == 0)
        {
            packDeliveryDate = nextDeliverySubDetail.getText();
                    //packDueDate.get(0).getText().substring(14);
            packChangeDate = new SimpleDateFormat("dd/MM/yyyy").parse(packDeliveryDate);

        }
        else if (count >= 1 && count < 4  && packStatusList.get(1).getText().equalsIgnoreCase("Pending"))
        {
            packDeliveryDate = packDueDate.get(1).getText().substring(14);
            packChangeDate = new SimpleDateFormat("dd/MM/yyyy").parse(packDeliveryDate);
        }
        else if (count >= 1 && count < 4 && inFlightPackCount >0)
        {
            packDeliveryDate = packDueDate.get(inFlightPackCount).getText().substring(14);
            packChangeDate = new SimpleDateFormat("dd/MM/yyyy").parse(packDeliveryDate);
        }
        clickElement(packageTab);
        if(newPackage.equals("Occasional")){
            clickElement(occasional);
            assertPageObjectIsDisplayed(updatePackage);
            clickElement(updatePackage);
            clickElement(emailNotSendButton);
            clickElement(solutionUpdateButton);
            verifyScheduleTabAfterChangeUsage(customerType, packChangeDate);

        }
        else if(newPackage.equals("PartTime")){
            clickElement(partTime);
            assertPageObjectIsDisplayed(updatePackage);
            clickElement(updatePackage);
            clickElement(emailNotSendButton);
            clickElement(solutionUpdateButton);
            verifyScheduleTabAfterChangeUsage(customerType, packChangeDate);
        }
        else if(newPackage.equals("FullTime")){
            waitForCondition().until(ExpectedConditions.elementToBeClickable(fullTime));
            clickElement(fullTime);
            assertPageObjectIsDisplayed(updatePackage);
            clickElement(updatePackage);
            clickElement(emailNotSendButton);
            clickElement(solutionUpdateButton);
            verifyScheduleTabAfterChangeUsage(customerType, packChangeDate);
        }
        else {
            waitForCondition().until(ExpectedConditions.elementToBeSelected(solutionDropdown));
            solutionDropdown.selectByVisibleText(newPackage);
            clickElement(updatePackageButton);
            assertTrue(solutionDropdown.getSelectedVisibleTextValue().trim().equalsIgnoreCase(newPackage));
            verifyScheduleTabAfterChangeUsage(customerType, packChangeDate);
        }
    }
    private void verifyScheduleTabAfterChangeUsage(String customerType, Date packChangeDate) throws ParseException {
        clickElement(scheduleTab);
        int j =0,a=0;
        for (int k =0;k<packStatusList.size();k++) {
            do {

                String packDate = packDueDate.get(k).getText().substring(14);


                StringBuilder str = new StringBuilder(packDate);
                final String packDueDateRev=str.reverse().substring(0,10);
                StringBuilder str1 = new StringBuilder(packDueDateRev);
                packDate= str1.reverse().toString();
                logger.info("The reverse is" +packDate);

                Date packDateVerify = new SimpleDateFormat("dd/MM/yyyy").parse(packDate);

                //if(packDateverify.after(packChangeDate) && packStatusList.get(k).getText().equalsIgnoreCase("PENDING") && packPaymentStatusList.get(j).getText().equalsIgnoreCase("PENDING") ) {
                if(packDateVerify.after(packChangeDate) || packDateVerify.equals(packChangeDate)){
                    logger.info("Successful");
                    j++;
                    a++;
                }else
                {
                    j++;
                    a++;
                }

            }while(a<3);
            a=0;
        }

    }
    public void verifyDailyCustomerPackageDetails(String DailyType) {

        clickElement(packageTab);
        selectedPackage.waitUntilVisible();
        assertElementText(selectedPackage,DailyType);
        solutionDropdown.waitUntilVisible();
        assertObjectIsNotInteractable(solutionDropdown);
        assertTrue(solutionDropdown.getText().trim().equalsIgnoreCase("No Solution"));
        clickElement(scheduleTab);
    }
    public void updatePackageUsage(String newPackage) {
        clickElement(packageTab);
        clickElement(fullTime);
        assertElementText(selectedPackage,newPackage);
        assertTrue(solutionDropdown.getText().trim().equalsIgnoreCase("No Solution"));
        updatePackageButton.waitUntilVisible();
        clickElement(updatePackageButton);
        clickElement(emailNotSendButton);
        clickElement(solutionUpdateButton);
        clickElement(scheduleTab);
    }
    public void updatingOnePackAsHoliday(String pack,String nextPaymentAmt,String authorizationCode) {
        //final String payer = payerType.getText();
        String refundRequired = "";
        assertTrue(packStatusList.get(0).getText().equalsIgnoreCase("PENDING"));
        //completedPaymentStatusCount = selectActionBtnCompletedPayment.size();
        waitFor(packPaymentStatusList.get(0));
        firstPaymentStatus = packPaymentStatusList.get(0).getText();
        for(int j=0;j<packPaymentStatusList.size();j++)
        {
            if(packPaymentStatusList.get(j).getText().equalsIgnoreCase("Completed"))
            {
                expectedPayments.add(nextPaymentAmt);
                expectedPayments.add("-"+nextPaymentAmt);
            }
            else if(packPaymentStatusList.get(j).getText().equalsIgnoreCase("Pending"))
            {
                expectedPayments.add(nextPaymentAmt);
            }
        }

        //assertTrue(expectedPayments.size()>3);
        int k = 0;
        switch(pack){
            case "First":
                k=0;
                refundRequired=	retrievePayments(0);
                break;
            case "Second":
                k=1;
                refundRequired= retrievePayments(3);
                break;
            case "Third":
                k=2;
                refundRequired = retrievePayments(6);
                break;
        }
        waitABit(5000);
        clickElement(actionDropdown.get(0));
        clickElement(holidayButton.get(k));
        assertPageObjectIsDisplayed(holidayHeader);
        assertPageObjectIsDisplayed(warningMessage);
        clickElement(emailSendButton);
        clickElement(holidayConfirm);
        waitABit(15000);
        assertTrue(packPaymentStatusList.get(k).getText().equalsIgnoreCase("HOLIDAY"));
    }
    public void updatingOnePackAsHolidayWithAuthorization(String pack,String nextPaymentAmt,String authorizationCode) {
        //final String payer = payerType.getText();
        String refundRequired = "";
        if(packStatusList.size()==0)
            clickElement(editSubscriptnBtn.get(0));
        assertTrue(packStatusList.get(0).getText().equalsIgnoreCase("PENDING"));
        //completedPaymentStatusCount = selectActionBtnCompletedPayment.size();
        waitFor(packPaymentStatusList.get(0));
        firstPaymentStatus = packPaymentStatusList.get(0).getText();
        for(int j=0;j<packPaymentStatusList.size();j++)
        {
            if(packPaymentStatusList.get(j).getText().equalsIgnoreCase("Completed"))
            {
                expectedPayments.add(nextPaymentAmt);
                expectedPayments.add("-"+nextPaymentAmt);
            }
            else if(packPaymentStatusList.get(j).getText().equalsIgnoreCase("Pending"))
            {
                expectedPayments.add(nextPaymentAmt);
            }
        }
        int k = 0;
        switch(pack){
            case "First":
                k=0;
                refundRequired=	retrievePayments(0);
                break;
            case "Second":
                k=1;
                refundRequired= retrievePayments(3);
                break;
            case "Third":
                k=2;
                refundRequired = retrievePayments(6);
                break;
        }
        waitABit(5000);
        clickElement(actionDropdown.get(0));
        clickElement(holidayButton.get(k));
        assertPageObjectIsDisplayed(holidayHeader);
        assertPageObjectIsDisplayed(warningMessage);
        setText(authorization,authorizationCode);
        clickElement(proceedButton);
        clickElement(emailSendButton);
        clickElement(holidayConfirm);
        waitABit(15000);
        assertTrue(packPaymentStatusList.get(k).getText().equalsIgnoreCase("HOLIDAY"));
    }
    public String retrievePayments(int k){
        String refundStatus="";
        for(int j=k;j<=k+2;j++)
        {
            if(packPaymentStatusList.get(j).getText().equalsIgnoreCase("Completed"))
            {
                refundStatus = "Yes";
                break;
            }
            else if(packPaymentStatusList.get(j).getText().equalsIgnoreCase("Pending"))
            {
                refundStatus = "No";
                break;
            }
        }
        return refundStatus;
    }

    public void verifyExpeditePack() {

        try {

            for (int k=0;k<packStatusList.size();k++)
            {
                String packstatus = packStatusList.get(k).getText();
                if (packstatus.equalsIgnoreCase("Cancelled")  || packstatus.equalsIgnoreCase("Processing"))
                {
                    assertTrue(!actionDropdown.get(k).isEnabled());
                    assertTrue(actionDropdown.get(k).getAttribute("disabled").equalsIgnoreCase("true"));
                }
                else if(packstatus.equalsIgnoreCase("Dispatched") || packstatus.equalsIgnoreCase("Completed") || packstatus.equalsIgnoreCase("Holiday"))
                {
                    actionDropdown.get(k).click();
                    assertTrue(!(actionDropdown.get(k).getText().contains("Early Pack Request")));
                    assertPageObjectIsNotDisplayed(expediteButton.get(0));
                }

            }
        }
        catch(StaleElementReferenceException  ex) {
            ex.printStackTrace();
        }
    }
    public void verifyStoreIDOnSubscriptionDetails() {

        List<WebElement> clFitDataLeft = getDriver().findElements(By.xpath("//div[@class='order-details-id']/div[2]"));
        String actualStoreID = testDataManager.getTestInputCommonData("login.store");
        for(int i=0;i<clFitDataLeft.size();i++){
            assertTrue(clFitDataLeft.get(i).getText().contains(actualStoreID));
        }

    }
    public void retrieveHubServiceAndCarrierAndFHDetails() {

        final String deliveryTabValue = "Not Yet Specified";
        for (int k=0;k<packStatusList.size();k++)
        {
            assertTrue(deliveryTabInfo.get(k).isDisplayed());
            deliveryTabInfo.get(k).click();
            assertTrue(carrier.get(k).getText().equalsIgnoreCase(deliveryTabValue));
            assertTrue(hubService.get(k).getText().equalsIgnoreCase(deliveryTabValue));
            assertTrue(fulfilmentHouse.get(k).getText().equalsIgnoreCase(deliveryTabValue));
            assertTrue(fileNumber.get(k).getText().equalsIgnoreCase(deliveryTabValue));
        }
    }
    public void verifiesThePackAndPaymentStatusForAllPacksInSchedule(String customerType) {
        try {

            logger.info("Number of total payments - "+paymentStatus.size());
            for (int k =0;k<paymentStatus.size();k++) {
                status = paymentStatus.get(k).getText();
                logger.info("Payment Status - "+status);
                assertEquals("PENDING", status);
                paymentPrice = packPaymentList.get(k).getText().substring(9);
                System.out.println("Payment price - "+paymentPrice);
                assertEquals(paymentPrice, testDataManager.getTestInputRegionData(customerType + ".lensCost"));

                final String paymentDate = pendingDateDetails.get(k).getText().substring(5);
                logger.info("Payment date - "+paymentDate);
            }
        }
        catch(StaleElementReferenceException  ex) {
            ex.printStackTrace();
        }

    }
    public void performStoreFullFilment() {

        for(int i=0;i<packStatusList.size();i++)
        {
            final String orderFullFilBy = orderToBeFullFiledBySupplyChainOrStore.get(i).getText().substring(25);
            assertEquals("Supply Chain", orderFullFilBy);
            actionDropdown.get(i).click();
            clickElement(storeFullFilment);
            assertElementText(warningMessage,storeFullfilmentWarningMessage);
            clickElement(confirmButton);
            lensSubstnHeader.waitUntilVisible();
            assertElementText(toBeFullFiledByStoreLabel,"To be fulfilled by store");
            assertElementContainsText(storeFulFilment,storeFulFillMentMessage);
            final String orderFullFillByValue = orderToBeFullFiledBySupplyChainOrStore.get(i).getText().substring(25);
            assertEquals("Store", orderFullFillByValue);
            break;
        }
    }
    public void performSupplyChainFulfillment(){
        for(int i=0;i<packStatusList.size();i++)
        {
            final String orderFullFilBy = orderToBeFullFiledBySupplyChainOrStore.get(i).getText().substring(25);
            assertEquals(orderFullFilBy,testDataManager.getTestInputRegionData("CommonCustomerData.Store"));
            clickElement(actionDropdown.get(i));
            clickElement(supplyChainFulfilment);
            assertElementText(warningMessage,supplyChainFulfillmentMessage);
            clickElement(confirmButton);
            waitFor(lensSubstnHeader);
            assertPageObjectIsDisplayed(lensSubstnHeader);
            logger.info(orderToBeFullFiledBySupplyChainOrStore.get(i).getText().substring(25));
            final String orderFullFillByValue = orderToBeFullFiledBySupplyChainOrStore.get(i).getText().substring(25);
            assertEquals(orderFullFillByValue,testDataManager.getTestInputRegionData("CommonCustomerData.Supply_Chain"));
            break;
        }
    }
    public void clickEditSubscription(){
        editSubscriptnBtn.get(0).click();

    }
    public void openCustomerCenterUrl ()
    {
        openUrl(testDataManager.getTestInputCommonData("url.customerCenterPageUrl"));
        final String flag = "contactCenterPageAuthCode";
        logger.info("The flag is" +flag);
    }

    public void performCancelSubscriptionAndVerifyPacksAndPayments(int cancelDays, String reason) throws ParseException {
        ArrayList<String> packStatusListArray = new ArrayList<String>();
        ArrayList<String> packPaymentStatusArray = new ArrayList<String>();

        clickEditSubscription();

        for(int i=0;i<packStatusList.size();i++)
        {
            packStatusListArray.add(packStatusList.get(i).getText());
        }

        for (int j=0;j<packPaymentStatusList.size();j++)
        {
            packPaymentStatusArray.add(packPaymentStatusList.get(j).getText());
        }
        clickElement(subscriptionBackButton);

        performCancelSubscription(cancelDays,reason);

        SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MM/yyyy");
        if(cancelDays==0)
        {
            openCustomerCenterUrl();
            //housekeeper issue
            waitABit(100000);
            searchPage.findCustomerByClientID();
            clickElement(historyTab);
            customerDashboard.toVerifySubscriptionStatus("CANCELLED");
            clickEditSubscription();
            //assertElementText(cancelledStatus,"CANCELLED - "+simpleDate.format(selectedCalenderDate)+" - "+cancellationReason);
        }

        int c,count = 0;
        for (int b=0;b<packStatusList.size();b++)
        {
            for(c=count;c-count<3;c++)
            {
                Date packPaymentDate = new SimpleDateFormat("dd/MM/yyyy").parse(paymentDateList.get(c).getText().substring(5));
                logger.info("packpaymentDate:"+packPaymentDate);

                if(packPaymentDate.before(selectedCalenderDate) || packPaymentDate.equals(selectedCalenderDate))
                {
                    //assertTrue(packPaymentStatusList.get(c).getText().equals(packPaymentStatusArray.get(c)));
                }
                else if(packPaymentDate.after(selectedCalenderDate) && packStatusList.get(b).getText().equalsIgnoreCase("Dispatched"))
                {
                    //assertTrue(packPaymentStatusList.get(c).getText().equals(packPaymentStatusArray.get(c)));
                }
                else
                {
                    assertTrue(packPaymentStatusList.get(c).getText().contains("CANCELLED"));
                }
            }
            count = c;
        }

        final String packStatus = cancelStatusList.get(0).getText();

        clickElement(subscriptionBackButton);

        if(cancelDays==0)
        {
            assertEquals("CANCELLED", customerDashboard.subscriptionStatus.get(0).getText());
            assertElementText(subscriptionNextDelivery,"N/A");
            if(packStatus.equalsIgnoreCase("DISPATCHED"))
            {
                assertElementText(customerDashboard.nextPaymentDate,simpleDate.format(new SimpleDateFormat("yyyy-MM-dd").parse(searchPage.nextPaymentDate)));
                assertElementText(customerDashboard.nextPaymentAmount,currencySign+searchPage.nextPaymentAmt);

            }
            else
            {
                assertElementText(customerDashboard.nextPaymentDate,"N/A");
                assertElementText(customerDashboard.nextPaymentAmount,"N/A");
            }
        }
        else
        {
            assertTrue(customerDashboard.subscriptionStatus.get(0).getText().equals("PENDING") || customerDashboard.subscriptionStatus.get(0).getText().equals("ACTIVE"));
        }
    }
    public void verifyUpdatePackageButtonIsDisabled() {
        waitForCondition().until(ExpectedConditions.elementToBeClickable(packageTab));
        clickElement(packageTab);
        final String selectAnotherPackage = "//table[@class ='usage-tbl table table-sm']//th[text()='%1$s']";
        final String selectPackage = String.format(selectAnotherPackage,"Full Time");
        getDriver().findElement(By.xpath(selectPackage)).click();
        assertElementText(selectedPackage,"Full Time");
        assertTrue(solutionDropdown.getText().trim().equalsIgnoreCase("No Solution"));
        boolean flag;
        try {
            updatePackageButton.waitUntilClickable();
            flag = true;
        }
        catch(Exception e) {
            flag = false;
        }
    }

    public void verifiesSelectActionDropdownIsDisabled() {

        for (int k=0;k<packStatusList.size();k++)
        {
            final String packStatus = packStatusList.get(k).getText();
            if (packStatus.equalsIgnoreCase("Processing")  || packStatus.equalsIgnoreCase("Cancelled"))
            {
                assertTrue(!actionDropdown.get(k).isEnabled());
                assertTrue(actionDropdown.get(k).getAttribute("disabled").equalsIgnoreCase("true"));
                logger.info("Action Dropdown is Disabled");
            }
        }
    }
    public void selectPaymentDateToPerformChangePackDeliveryDate(String paymentNumber, String applyToAllPack) throws Exception{

        String PaymentDate="";
        switch(paymentNumber)
        {
            case "first":
                logger.info("First payment:"+paymentDateList.get(0).getText().substring(5));
                PaymentDate = paymentDateList.get(0).getText().substring(5);
                break;

            case "second":
                logger.info("Second payment:"+paymentDateList.get(1).getText().substring(5));
                PaymentDate = paymentDateList.get(1).getText().substring(5);
                break;

            case "third":
                logger.info("Third payment:"+paymentDateList.get(2).getText().substring(5));
                PaymentDate = paymentDateList.get(2).getText().substring(5);
                break;

        }
        SimpleDateFormat expectedFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date payDate = expectedFormat.parse(PaymentDate);
        Calendar date = Calendar.getInstance();
        date.setTime(payDate);
        SimpleDateFormat tfs = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");
        String firstPayDate = tfs.format(date.getTime());
        String enabledButton = String.format(SubscriptionPage.enabledButton,firstPayDate);
        logger.info("Xpath:"+enabledButton);
        performChangePackDeliveryDate(enabledButton,applyToAllPack);

    }
    private void performChangePackDeliveryDate(String enabledButton, String applyToAllPack) throws Exception {


        firstPackDeliveryDate = packDueDate.get(0).getText().substring(14);   // Stores First Dispatch date to assert after performing CPD
        clickElement(actionDropdown.get(0));
        logger.info("The appearing Options are:"+actionDropdownBox.getText());
        assertElementContainsText(actionDropdownBox,"Change Pack Delivery Date");
        clickElement(changePackDeliveryDateButton);
        clickElement(calendarBtn);
        do {
            if(isElementVisible(By.xpath(enabledButton)))
                break;
            clickElement(previousMonthArrow);
        }while(previousMonthArrow.isEnabled());

        while(nextMonthArrow.isEnabled()){
            if(isElementVisible(By.xpath(enabledButton))){
                break;
            }
            else{
                clickElement(nextMonthArrow);
            }
        }
        waitFor(enabledButton);
        getDriver().findElement(By.xpath(enabledButton)).click();
        assertElementText(authorizationConfirmationAlert,"This will impact all future delivery dates");

        if(applyToAllPack.equals("No"))
        {
            clickElement(applyToCurrentCheckBox);
        }

        selectedDispatchDate = calenderDate.getTextValue();
        logger.info("Calender Date "+selectedDispatchDate);
        clickElement(updateButton);
        logger.info("Before Initial single pack assertion:"+packDueDate.get(0).getText());
        verifyPackDispatchDateAfterPerformingChangePackDelivery(applyToAllPack);
    }
    public void verifyPackDispatchDateAfterPerformingChangePackDelivery(String applyToAllPack) throws Exception{
        waitABit(5000);
        // PackDeliveryDate.clear();
        ArrayList<String> expectedPackDueDate = new ArrayList<String>();
        expectedPackDueDate.add(selectedDispatchDate);
        SimpleDateFormat expectFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date pDate;
        if(applyToAllPack.equals("No"))
        {
            pDate = expectFormat.parse(firstPackDeliveryDate);
        }
        else{
            pDate = expectFormat.parse(selectedDispatchDate);
        }

        Calendar DueDate = Calendar.getInstance();

        logger.info("Actual Pack Due dates from UI:"+PackDeliveryDate.getText());

        for (int j=3;j/3<=8;j+=3) {
            DueDate.setTime(pDate);
            DueDate.add(Calendar.MONTH, j);
            final String newPackDate = expectFormat.format(DueDate.getTime());
            expectedPackDueDate.add(newPackDate);            // Expected Pack Delivery date

            assertEquals(PackDeliveryDate.getTextValue(), expectedPackDueDate.get(0));  // Asserting Exp & Actual Pack Due date

        }
    }
    public void verifyReleaseToSupplyChainDate() throws ParseException {

        for(int i=0;i<packDueDate.size();i++)
        {
            final String packDueDateUI = packDueDate.get(i).getText().substring(14);
            SimpleDateFormat expectFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date packDate = expectFormat.parse(packDueDateUI);
            Calendar date = Calendar.getInstance();
            date.setTime(packDate);
            if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
            {
                date.add(Calendar.DATE, -21);
            }
            else
            {
                date.add(Calendar.DATE, -14);
            }
            final String supplyChainDate = expectFormat.format(date.getTime());
            logger.info("Release to supply Chain Date:"+supplyChainDate);
            logger.info(ReleasedToSupplyChainDate.get(i).getText().substring(26));
            assertEquals(ReleasedToSupplyChainDate.get(i).getText().substring(26), supplyChainDate);
        }
        final String firstPayDate = paymentDateList.get(0).getText().substring(5);
        final String secPayDate = paymentDateList.get(1).getText().substring(5);
        SimpleDateFormat expFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date firstPaymentDate = expFormat.parse(firstPayDate);
        Date secPaymentDate = expFormat.parse(secPayDate);
        if(payerType.getText().equalsIgnoreCase("Prepay")){
            if(expFormat.parse(packDueDate.get(0).getText().substring(14)).before(secPaymentDate) || expFormat.parse(packDueDate.get(0).getText().substring(14)).equals(secPaymentDate))
            {
                assertElementText(alertReleaseToSupplyChain,"Please note that due to the scheduling of the customers Payments these goods will not be released until "+secPayDate);
            }
        }else{
            if(expFormat.parse(packDueDate.get(0).getText().substring(14)).before(firstPaymentDate) || expFormat.parse(packDueDate.get(0).getText().substring(14)).equals(firstPaymentDate))
            {
                assertElementText(alertReleaseToSupplyChain,"Please note that due to the scheduling of the customers Payments these goods will not be released until "+firstPayDate);
            }
        }
    }
    public void verifyPaymentStatusAfterPerformingHoliday(String paymentStatus,String nextPaymentAmt) {

        ArrayList actualPayments = new ArrayList<String>();

        // Storing values in Array - Actual Results
        for (int i=0;i<packPaymentList.size();i++){
            actualPayments.add(packPaymentList.get(i).getText().substring(9));
        }

        // Asserting values between arrays
        for (int i=0;i<=packPaymentList.size();i++){
            assertEquals(nextPaymentAmt, packPaymentList.get(i).getText().substring(9,13));
            break;
        }

        // Asserting Holiday payments
        for (int i=0;i<holidayPaymentStatus.size();i++){
            assertTrue(packPaymentStatusList.get(i).getText().equalsIgnoreCase(paymentStatus));
        }
    }
    public void userVerifiesCompletedPaymentStatus(String paymentStatus){
        assertElementContainsText(packPaymentStatusList.get(0),paymentStatus);
    }
    public void unableToReinstateHolidayPack() {

        for(int i=0;i<packStatusList.size();i++)
        {
            assertTrue(packStatusList.get(i).getText().equalsIgnoreCase("Holiday"));
            if(packStatusList.get(i).getText().equalsIgnoreCase("Holiday"))
            {
                logger.info("Holiday Pack");
                assertTrue(actionDropdown.get(i).isEnabled());
                break;
            }
        }
    }
    public void verifyBoxQuantities(String addressType) {

        subscriptionBackButton.waitUntilClickable();
        clickElement(subscriptionBackButton);
        clickElement(supplementaryOrders);

        for(int i = replacementtabEditSubscriptionBtnCount; i< replacementTabEditSubscriptionButton.size(); i++)
        {
            assertTrue((replacementLensSubscptnHeader.get(0).getText()).substring(0,24).equalsIgnoreCase("Lens Subscription - Pack") && replacementLensSubscptnHeader.get(0).getText().contains("Replacement"));
            clickElement(replacementTabEditSubscriptionButton.get(i));
            replacementtabEditSubscriptionBtnCount++;
            logger.info(subscriptionHeading.get(2).getText());
            assertTrue((subscriptionHeading.get(2).getText()).substring(0,24).equalsIgnoreCase("Lens Subscription - Pack") && subscriptionHeading.get(2).getText().contains("Replacement"));
            logger.info("Replacement Pack OrderID:"+replacementOrderID.getText());
            assertTrue(!replacementOrderID.getText().contains(SubscriptionPage.orderID));

            clickElement(packageTab);
            try{

                if(solutionValue.equals("Yes")){
                    verifySolutionPackage();
                }
                else{
                    verifyNoSolution();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            clickElement(subscriptionBackButton);
            clickElement(subscriptionBackButton);
            logger.info(replacementLensSubscptnHeader.get(i).getText());
            assertTrue((replacementLensSubscptnHeader.get(i).getText()).contains("Replacement")); //Expected to fail due to defact DF-1503
        }
    }
    public void verifySolutionPackage(){
        assertEquals("1", packContentSolutionQty.getText());
        assertEquals(packContentSolution.getText(), testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));

        if(leftBoxValue.contains("0") && rightBoxValue.contains("0"))
        {
            assertTrue(!packContentsLeftBoxes.isPresent());
            assertTrue(!packContentsRightBoxes.isPresent());
            logger.info("Leftbox and RightBox quantity is not available");
        }
        else if(leftBoxValue.contains("0"))
        {
            assertTrue(!packContentsLeftBoxes.isPresent());
            logger.info("Leftbox quantity is not available");
            assertEquals(rightBoxValue, packContentsRightBoxes.getText());

        }
        else if(rightBoxValue.contains("0"))
        {
            assertEquals(leftBoxValue, packContentsLeftBoxes.getText());
            assertTrue(!packContentsRightBoxes.isPresent());
            logger.info("Rightbox quantity is not available");

        }
        else
        {
            assertElementText(packContentsLeftBoxes,leftBoxValue);
            assertElementText(packContentsRightBoxes,rightBoxValue);

        }
    }

    public void verifyNoSolution(){
        waitForPageLoader();
        if(leftBoxValue.contains("0") && rightBoxValue.contains("0"))
        {
            assertTrue(!packContentsLeftBoxes.isPresent());
            assertTrue(!packContentsRightBoxes.isPresent());
            logger.info("Leftbox and RightBox quantity is not available");


        }else if(leftBoxValue.contains("0"))
        {
            assertFalse(packContentsLeftBoxes.isPresent());
            logger.info("Leftbox quantity is not available");
            assertElementText(packContentsRightBoxes,rightBoxValue.trim().substring(0,1));


        }else if(rightBoxValue.contains("0"))
        {
            logger.info(leftBoxValue);
            assertElementText(packContentsLeftBoxes,leftBoxValue.trim().substring(0,1));
            assertTrue(!packContentsRightBoxes.isPresent());
            logger.info("Rightbox quantity is not available");

        }else
        {
            assertElementText(packContentsLeftBoxes,leftBoxValue.trim().substring(0,1));
            assertElementText(packContentsRightBoxes,rightBoxValue.trim().substring(0,1));
        }
    }
    public void verifyReplacePackForMonthlySolutionToNoSolution(String replaceReason, String leftboxQty, String rightboxQty) {
        customerDashboard.clickEditSubscription();

        for (int i=0;i<selectActnDrpDownPendingDispatched.size();i++)
        {
            orderID=orderIDList.get(i).getText();
            orderID=orderID.substring(9);
        }
        selectActnDrpDownPendingDispatched.get(0).click();
        replaceBtn.get(0).click();
        assertPageObjectIsDisplayed(replaceHeader);
        assertPageObjectIsDisplayed(selectReasonlabel);
        leftQuantityBox.selectByVisibleText(leftboxQty);
        rightQuantityBox.selectByVisibleText(rightboxQty);
        leftBoxValue = leftboxQty;
        rightBoxValue = rightboxQty;
        selectDeliveryAddress.selectByIndex(0);
        this.replaceReason.selectByVisibleText(replaceReason);
        assertTrue(!this.replaceReason.getText().contains("Additional Lenses"));
        replaceSolution.selectByIndex(1);
        solutionValue = replaceSolution.getSelectedVisibleTextValue();
        logger.info("solutionValue:"+solutionValue);
        clickElement(storeAddressCheckBox);
        replaceWithStoreAddress = "Yes";
        waitABit(1000);
        clickElement(replaceConfirmBtn);
        waitABit(12000);
    }
    public void verifyCompleteSubscriptionScheduleOnPrintSchedule(WebElementFacade customerName,WebElementFacade custID,WebElementFacade storeName) throws Exception {
        waitABit(4000);
        final String custName = customerName.getText();
        final String customerID = custID.getText();
        final String storName = storeName.getText();
        final String customerAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        final String storeAddress = testDataManager.getTestInputRegionData("CommonCustomerData.StoreAddress");
        final String storeUserName = testDataManager.getTestInputRegionData("CommonCustomerData.StoreUser");

        ArrayList<String> PaymentScheduleDatesUI = new ArrayList<String>();
        ArrayList<String> PaymentOnUI = new ArrayList<String>();
        ArrayList<String> PackDueDateList = new ArrayList<String>();
        ArrayList<String> PackOrderID = new ArrayList<String>();
        ArrayList<String> PackStatusListUI = new ArrayList<String>();
        ArrayList<String> PackPaymentStatusListUI = new ArrayList<String>();
        ArrayList<String> PackAddressList = new ArrayList<String>();
        PaymentScheduleDatesUI.clear();
        PaymentOnUI.clear();
        PackDueDateList.clear();
        PackOrderID.clear();
        PackStatusListUI.clear();
        PackPaymentStatusListUI.clear();
        PackAddressList.clear();
        String packDueDateRev;

        //Get Summary details from UI
        final String nextDelDate = nextDeliverySubDetail.getText();
        logger.info("nextDelDate:"+nextDelDate);
        final String finalDelDate = finalDeliveryDate.getText();
        logger.info("finalDelDate:"+finalDelDate);
        final  String firstPayDate = updatedPaymentDate.get(0).getText().substring(5);
        logger.info("firstPayDate:"+firstPayDate);
        final String firstPayStatus = packPaymentStatusList.get(0).getText();
        //Get Payment Schedule from UI
        try
        {
            for(int i=0;i<updatedPaymentDate.size();i++) {
                PaymentScheduleDatesUI.add(updatedPaymentDate.get(i).getText().substring(5));
                PaymentOnUI.add(packPaymentList.get(i).getText().substring(9));

                if(packPaymentStatusList.get(i).getText().toLowerCase().contains("goodwill"))
                {
                    assertTrue(packPaymentStatusList.get(i).getText().toLowerCase().contains("goodwill"));
                    final String payDate = packPaymentStatusList.get(i).getText().substring(11);
                    logger.info(packPaymentStatusList.get(i).getText().substring(11));
                    logger.info("payDate:"+payDate);
                    SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
                    Date newDate = date.parse(payDate);
                    logger.info("Payment Date:"+newDate);

                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate localDate = LocalDate.now();
                    SubscriptionPage.date = dateFormat.format(localDate);
                    logger.info(SubscriptionPage.date);
                    Date todayDate = new SimpleDateFormat("dd/MM/yyyy").parse(SubscriptionPage.date);
                    logger.info(String.valueOf(todayDate));

                    assertTrue(newDate.equals(todayDate) || newDate.before(todayDate));

                    String complete = "completed \u2013 ";
                    complete = new String(complete.getBytes("UTF-8"), "UTF-8");
                    logger.info("paymentStatus:"+complete+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 8));
                    PackPaymentStatusListUI.add(complete+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 8));
                }
                else if(packPaymentStatusList.get(i).getText().toLowerCase().contains("Written off"))
                {
                    String cancel = "cancelled \u2013 ";
                    cancel = new String(cancel.getBytes("UTF-8"), "UTF-8");

                    assertTrue(packPaymentStatusList.get(i).getText().toLowerCase().contains("Written off"));
                    logger.info("paymentStatus:"+cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 11));

                    PackPaymentStatusListUI.add(cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 11));
                }
                else if(packPaymentStatusList.get(i).getText().toLowerCase().contains("Cancelled"))
                {
                    String cancel = "cancelled \u2013 ";
                    cancel = new String(cancel.getBytes("UTF-8"), "UTF-8");

                    assertTrue(packPaymentStatusList.get(i).getText().toLowerCase().contains("Cancelled"));
                    System.out.println("paymentStatus:"+cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 9));

                    PackPaymentStatusListUI.add(cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 9));
                }
                else
                {
                    PackPaymentStatusListUI.add(packPaymentStatusList.get(i).getText());
                }
            }
        }
        catch (ParseException e) {

            e.printStackTrace();

        }

        for(int j=0;j<packStatusList.size();j++) {
            logger.info("Pack size:"+packStatusList.size());

            packDueDateRev = packDueDate.get(j).getText();

            StringBuilder builder = new StringBuilder(packDueDateRev);
            packDueDateRev=builder.reverse().substring(0,10);
            StringBuilder str1 = new StringBuilder(packDueDateRev);
            packDueDateRev= str1.reverse().toString();
            logger.info("The reverse is" +packDueDateRev);
            PackDueDateList.add(packDueDateRev);
            logger.info(orderIDList.get(j).getText().substring(9));
            PackOrderID.add(orderIDList.get(j).getText().substring(9));
            PackStatusListUI.add(packStatusList.get(j).getText());
            logger.info(orderDetails.get(j).getText());

        }
        for(int j=0;j<packStatusList.size();j++){
            if (ReleasedToSupplyChainDate.size()<9 && j==0 && !packStatusList.get(j).getText().equalsIgnoreCase("Holiday") && !packStatusList.get(j).getText().equalsIgnoreCase("Cancelled")){
                PackAddressList.add(storeAddress);
            }
            else
            {
                for(int i=0; i<deliveryAddress.size(); i++){
                    PackAddressList.add(deliveryAddress.get(i).getText());
                }
                break;
            }
        }
        waitFor(printScheduleLink);
        clickElement(printScheduleLink);
        //taking time to download PDF
        waitABit(15000);

    }
    public void verifyCompleteSubscriptionScheduleWithPrintSchedule(WebElementFacade customerName,WebElementFacade custID,WebElementFacade storeName) throws Exception{
        waitABit(4000);
        final String custName = customerName.getText();
        final String customerID = custID.getText();
        final String storName = storeName.getText();
        final String customerAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        final String storeAddress = testDataManager.getTestInputRegionData("CommonCustomerData.StoreAddress");
        final String storeUserName = testDataManager.getTestInputRegionData("CommonCustomerData.StoreUser");

        final String nextDelDate = nextDeliverySubDetail.getText();
        final String finalDelDate = finalDeliveryDate.getText();
        final  String firstPayDate = updatedPaymentDate.get(0).getText().substring(5);
        final String firstPayStatus = packPaymentStatusList.get(0).getText();

        ArrayList<String> PaymentScheduleDatesUI = new ArrayList<String>();
        ArrayList<String> PaymentOnUI = new ArrayList<String>();
        ArrayList<String> PackDueDateList = new ArrayList<String>();
        ArrayList<String> PackOrderID = new ArrayList<String>();
        ArrayList<String> PackStatusListUI = new ArrayList<String>();
        ArrayList<String> PackPaymentStatusListUI = new ArrayList<String>();
        ArrayList<String> PackAddressList = new ArrayList<String>();
        PaymentScheduleDatesUI.clear();
        PaymentOnUI.clear();
        PackDueDateList.clear();
        PackOrderID.clear();
        PackStatusListUI.clear();
        PackPaymentStatusListUI.clear();
        PackAddressList.clear();
        String packDueDateRev;
        try
        {
            for(int i=0;i<updatedPaymentDate.size();i++) {
                PaymentScheduleDatesUI.add(updatedPaymentDate.get(i).getText().substring(5));
                PaymentOnUI.add(packPaymentList.get(i).getText().substring(9));

                if(packPaymentStatusList.get(i).getText().toLowerCase().contains("goodwill"))
                {
                    assertTrue(packPaymentStatusList.get(i).getText().toLowerCase().contains("goodwill"));
                    final String payDate = packPaymentStatusList.get(i).getText().substring(11);
                    logger.info(packPaymentStatusList.get(i).getText().substring(11));
                    logger.info("payDate:"+payDate);
                    SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
                    Date newDate = date.parse(payDate);
                    logger.info("Payment Date:"+newDate);

                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate localDate = LocalDate.now();
                    SubscriptionPage.date = dateFormat.format(localDate);
                    logger.info(SubscriptionPage.date);
                    Date todayDate = new SimpleDateFormat("dd/MM/yyyy").parse(SubscriptionPage.date);
                    logger.info(String.valueOf(todayDate));

                    assertTrue(newDate.equals(todayDate) || newDate.before(todayDate));

                    String complete = "completed \u2013 ";
                    complete = new String(complete.getBytes("UTF-8"), "UTF-8");
                    logger.info("paymentStatus:"+complete+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 8));
                    PackPaymentStatusListUI.add(complete+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 8));
                }
                else if(packPaymentStatusList.get(i).getText().toLowerCase().contains("Written off"))
                {
                    String cancel = "cancelled \u2013 ";
                    cancel = new String(cancel.getBytes("UTF-8"), "UTF-8");

                    assertTrue(packPaymentStatusList.get(i).getText().toLowerCase().contains("Written off"));
                    logger.info("paymentStatus:"+cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 11));

                    PackPaymentStatusListUI.add(cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 11));
                }
                else if(packPaymentStatusList.get(i).getText().toLowerCase().contains("Cancelled"))
                {
                    String cancel = "cancelled \u2013 ";
                    cancel = new String(cancel.getBytes("UTF-8"), "UTF-8");

                    assertTrue(packPaymentStatusList.get(i).getText().toLowerCase().contains("Cancelled"));
                    System.out.println("paymentStatus:"+cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 9));

                    PackPaymentStatusListUI.add(cancel+packPaymentStatusList.get(i).getText().toLowerCase().substring(0, 9));
                }
                else
                {
                    PackPaymentStatusListUI.add(packPaymentStatusList.get(i).getText());
                }
            }
        }
        catch (ParseException e) {

            e.printStackTrace();

        }

        for(int j=0;j<packStatusList.size();j++) {
            logger.info("Pack size:"+packStatusList.size());

            packDueDateRev = packDueDate.get(j).getText();

            StringBuilder builder = new StringBuilder(packDueDateRev);
            packDueDateRev=builder.reverse().substring(0,10);
            StringBuilder str1 = new StringBuilder(packDueDateRev);
            packDueDateRev= str1.reverse().toString();
            logger.info("The reverse is" +packDueDateRev);
            PackDueDateList.add(packDueDateRev);
            logger.info(orderIDList.get(j).getText().substring(9));
            PackOrderID.add(orderIDList.get(j).getText().substring(9));
            PackStatusListUI.add(packStatusList.get(j).getText());
            logger.info(orderDetails.get(j).getText());

        }
        for(int j=0;j<packStatusList.size();j++){
            if (ReleasedToSupplyChainDate.size()<9 && j==0 && !packStatusList.get(j).getText().equalsIgnoreCase("Holiday") && !packStatusList.get(j).getText().equalsIgnoreCase("Cancelled")){
                PackAddressList.add(storeAddress);
            }
            else
            {
                for(int i=0; i<deliveryAddress.size(); i++){
                    PackAddressList.add(deliveryAddress.get(i).getText());
                }
                break;
            }
        }
        waitFor(printScheduleLink);
        clickElement(printScheduleLink);
        //taking time to download PDF
        waitABit(15000);

        final FileInputStream obj =new FileInputStream(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "TestData" +File.separator + "clsp"+ File.separator + "Downloads"+ File.separator + "schedule-"+customerID+".pdf");
        PDDocument objDoc =  PDDocument.load(obj);
        PDFTextStripper objPDFStrp = new PDFTextStripper();
        String pdfContent = objPDFStrp.getText(objDoc);
        logger.info("StoreAddress:"+storeAddress);
        //Verify Customer details and Delivery Address
        assertTrue(pdfContent.contains(custName));
        assertTrue(pdfContent.contains(customerID));
        logger.info("customerAddress:"+customerAddress);
        assertTrue(pdfContent.contains(firstPayDate));
        assertTrue(pdfContent.contains(nextDelDate));
        assertTrue(pdfContent.contains(finalDelDate));
        assertTrue(pdfContent.contains(PaymentOnUI.get(0)));

        //Verify Complete payment Schedule
        for(int i=0;i<printScheduleDates.size();i++) {
            assertEquals(PaymentScheduleDatesUI.get(i), printScheduleDates.get(i).getText().substring(6));
            assertEquals(PaymentOnUI.get(i), printSchedulePayments.get(i).getText().substring(10));
            assertTrue(printSchedulePaymentStatus.get(i).getText().toLowerCase().contains(PackPaymentStatusListUI.get(i).toLowerCase()));

        }
        for(int j=0;j<printSchedulePackDelDates.size();j++) {
            assertEquals(PackDueDateList.get(j).trim(), printSchedulePackDelDates.get(j).getText().substring(20));
            assertEquals(PackOrderID.get(j), printScheduleOrderID.get(j).getText().substring(10));
            assertTrue(PackStatusListUI.get(j).equalsIgnoreCase(printSchedulePackStatus.get(j).getText().substring(8)));
        }
    }
    public void packCollectedFromStore() {

        for(int i=0;i<packStatusList.size();i++)
        {
            logger.info("completed payments:"+compPaymentStatus.size());
            clickElement(actionDropdown.get(i));
            clickElement(collectedButton);
            assertElementText(warningMessage,customerCollectiontWarningMessage);
            clickElement(confirmButton);
            assertTrue(statusList.getText().equalsIgnoreCase("Dispatched"));
            logger.info("collectedInStoreLabel:"+collectedInStoreLabel.getText());
            assertElementText(collectedInStoreLabel,"Collected in Store");
            final String todayDate = getCurrentDateStamp();
            logger.info("UI Date:"+updatedPaymentDate.get(i).getText().substring(5));
            logger.info("Cal Date:"+todayDate);
            assertEquals(updatedPaymentDate.get(i).getText().substring(5), todayDate);
            break;
        }

    }
    public void verifyUserClicksOnBackArrowButtonOnBrowser(WebElementFacade searchCustID) {

        assertPageObjectIsDisplayed(lensSubstnHeader);
        navigateBack();
        assertPageObjectIsDisplayed(customerDashboard.subscriptionTab);
        assertTrue(customerDashboard.editSubscriptnBtn.get(0).isDisplayed());
        clickElement(customerDashboard.editSubscriptnBtn.get(0));
        clickElement(packageTab);
        clickElement(completedPacksTab);
        clickElement(custDashboardBackButton);
        assertPageObjectIsDisplayed(customerDashboard.subscriptionTab);
        assertTrue(customerDashboard.editSubscriptnBtn.get(0).isDisplayed());
        navigateBack();
        assertPageObjectIsDisplayed(searchCustID);

    }
    public void editsFirstPaymentDateUpToMaxDate() throws ParseException {
        String secondPaymentDate;
        secondPaymentDate = paymentDateList.get(1).getText().substring(5);
        clickElement(selectActionBtnPendingPayment.get(0));
        clickElement(editPaymentDateVisibleButton);
        editPaymentDateVisibleButton.selectByVisibleText("Edit Payment Date");

        assertElementText(warningInfo,editPaymentDateWarningInfo);

        Date secondPayDate= new SimpleDateFormat("dd/MM/yyyy").parse(secondPaymentDate);
        logger.info("newCalenderDate:"+secondPayDate);
        SimpleDateFormat date = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");

        calendarBtn.waitUntilVisible();
        clickElement(calendarBtn);

        Calendar calender = Calendar.getInstance();
        calender.setTime(secondPayDate);
        calender.add(Calendar.DATE, -1);

        Calendar calendarD = Calendar.getInstance();
        calendarD.setTime(secondPayDate);

        final String selectCalenderDate = date.format(calender.getTime());
        logger.info("selectCalenderDate:"+selectCalenderDate);

        final String disabledSecondPaymentDate = date.format(calendarD.getTime());
        logger.info("disabledSecondPaymentDate:"+disabledSecondPaymentDate);

        final String clickableDate = String.format(enabledButton,selectCalenderDate);
        final String disabledDate = String.format(disabledbutton1, disabledSecondPaymentDate);
        logger.info(clickableDate);
        logger.info(disabledDate);

        while(previousMonthArrow.isEnabled())
        {
            clickElement(previousMonthArrow);
        }
        while(nextMonthArrow.isEnabled())
        {
            if(isElementVisible(By.id(clickableDate))==true)
            {
                break;
            }
            else
            {
                clickElement(nextMonthArrow);
            }
        }
        assertTrue(getDriver().findElement(By.xpath(disabledDate)).isDisplayed());
        getDriver().findElement(By.xpath(clickableDate)).click();

        selectedPaymentDate = calenderDate.getTextValue();
        logger.info("The new Date selected for Edit:"+selectedPaymentDate);
        clickElement(applyToCurrentCheckBox);
        clickElement(confirmButton);
        Date updatedFirstPaymentDate = new SimpleDateFormat("dd/MM/yyyy").parse(selectedPaymentDate);

        validFirstPayment = getValidPaymentDate(updatedFirstPaymentDate);
        logger.info("validFirstPayment:"+validFirstPayment);

        secondPaymentDate = paymentDateList.get(0).getText().substring(5);
        assertEquals(selectedPaymentDate, secondPaymentDate);
    }
    public void verifyPaymentStatusAndNavigateToManagePaymentTab(String paymentStatus) {

       // clickEditSubscription();
        waitFor(lensSubstnHeader);
        logger.info("status" +paymentStatus);
        logger.info("packPaymentStatus"+packPaymentStatusList.get(0).getText());
        assertTrue(packPaymentStatusList.get(0).getText().equalsIgnoreCase(paymentStatus));
        clickElement(subscriptionBackButton);
        customerDashboard.navigateToManagePaymentTab();
    }
    public void reinstatePack() {

        for(int i=0;i<packStatusList.size();i++)
        {
            if(packStatusList.get(i).getText().equalsIgnoreCase("Holiday"))
            {
                assertTrue(packStatusList.get(i).getText().equalsIgnoreCase("Holiday"));
                clickElement(actionDropdown.get(i));
                clickElement(reinstateButton.get(0));
                assertPageObjectIsDisplayed(reinstateHeader);
                clickElement(confirmButton);
            }
        }
    }
    public void verifyChangingAddressShouldImpactOnAllFuturePacks(String addressType) {

        final String address = testDataManager.getTestInputRegionData("address.number") + " " + testDataManager.getTestInputRegionData("address.name") + " " + testDataManager.getTestInputRegionData("address.addressLine") + " " + testDataManager.getTestInputRegionData("address.town") + " " + testDataManager.getTestInputRegionData("address.county") + " " + testDataManager.getTestInputRegionData("address.postcode") + " " + testDataManager.getTestInputRegionData("address.countryName");
        for (int i =0;i<packStatusList.size();i++)
        {
            if(packStatusList.get(i).getText().equalsIgnoreCase("Pending"))
            {
                assertTrue(changedDeliveryAdd.get(i).getText().replaceAll("[\r\n]+", " ").contains(address));
            }
            else
            {
                assertTrue(changedDeliveryAdd.get(i).getText().replaceAll("[\r\n]+", " ").equalsIgnoreCase(testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress")));
            }
        }
    }
    public void storePackAddress(){
        waitFor(historyTab);
        clickElement(historyTab);
        validateDeliveryAddress();
    }
    public void validateDeliveryAddress() {
        clickElement(editSubscriptionButton.get(0));
        packAddressList.clear();
        packAddressList.add(deliveryAdd.getText().replaceAll("[\r\n]+", " "));
        clickElement(subscriptionBackButton);
    }
    public void toChangeAddressForAllFuturePacks(String addressType){
        clickElement(customerDashboard.firstChangeLink.get(0));
        clickElement(newAddressDropdown);
        final String addressToSelect = testDataManager.getTestInputRegionData(addressType + ".number")+" "+testDataManager.getTestInputRegionData(addressType + ".addressLine")+" "+testDataManager.getTestInputRegionData(addressType + ".postcode");
        //TODO: to check the assertion again
        //assertTrue(newAddressDropdown.getFirstSelectedOptionVisibleText().replace("  ", " ").trim().contains(addressToSelect));
        for (int i=0;i<options.size();i++)
        {
            logger.info(options.get(i).getText().replace("  ", " ").trim());
            if(options.get(i).getText().replace("  ", " ").trim().contains(addressToSelect))
            {
                clickElement(options.get(i));
                break;
            }
        }
        if(!applyAllFuturePacks.isSelected()){
            clickElement(applyAllFuturePacks);
        }
        clickElement(futureConfirmButton);
        //taking time to load address for all the packs
        waitABit(2000);

    }
    public void verifyPackReplaceStatus(){
        waitForCondition().until(ExpectedConditions.elementToBeClickable(subscriptionBackButton));
        clickElement(subscriptionBackButton);
        clickElement(supplementaryOrders);
        assertTrue((replacementLensSubscptnHeader.get(0).getText()).substring(0,24).equalsIgnoreCase("Lens Subscription - Pack") && replacementLensSubscptnHeader.get(0).getText().contains("Replacement"));
        clickElement(replacementTabEditSubscriptionButton.get(0));
        logger.info(subscriptionHeading.get(2).getText());
        assertTrue((subscriptionHeading.get(2).getText()).substring(0,24).equalsIgnoreCase("Lens Subscription - Pack") && subscriptionHeading.get(2).getText().contains("Replacement"));
        replaceOrderID = replacementOrderID.getText().substring(9);
        logger.info("Replacement Pack OrderID:"+replaceOrderID);
        assertTrue(!replaceOrderID.contains(SubscriptionPage.orderID));
        clickElement(packageTab);
    }
    public void verifyOriginalAddressOnPackageTab()
    {
        logger.info("Printing Original Add:"+testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress"));
        logger.info("Printing Add from Web:"+replacementDeliveryAddress.getText().replaceAll("[\r\n]+", " "));
        assertEquals(replacementDeliveryAddress.getText().replaceAll("[\r\n]+", " "), testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress"));
        clickElement(subscriptionBackButton);
        assertEquals(deliveryAdd.getText().replaceAll("[\r\n]+", " "), testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress"));
    }
    public void verifiesDeliveryAddressForTheReplacedPack() {

        final String expectedAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        final String actualAddress = deliveryAdd.getText().replaceAll("[\r\n]+", " ");
        logger.info("expectedAddress"+expectedAddress);
        logger.info("actualAddress"+actualAddress);
        assertTrue(actualAddress.equalsIgnoreCase(expectedAddress));

    }
    public void verifiesPrintReceiptNotVisibleForReplacementPack() {

        for (int k=0;k<1;k++) {

            if(packStatusList.get(k).getText().equalsIgnoreCase("Pending") || packStatusList.get(k).getText().equalsIgnoreCase("Processing"))
            {
                logger.info(packStatusList.get(k).getText());
                clickElement(actionDropdown.get(k));
                for (WebElement dropdown : visibleDropdown) {
                    assertTrue(!dropdown.getText().equalsIgnoreCase("Print Receipt"));

                }
            }
            else if(packStatusList.get(k).getText().equalsIgnoreCase("Dispatched"))
            {
                logger.info(packStatusList.get(k).getText());
                clickElement(actionDropdown.get(k));
                for (WebElementFacade dropdown : visibleDropdown) {
                    logger.info("***************"+dropdown.getText());
                    assertElementText(dropdown,"Print Receipt");
                    logger.info("Action DropDown contain Print Receipt");
                }
            }
        }
    }
    public void verifiesCollectedPackOptionIsUnavailable() {

        customerDashboard.clickEditSubscription();
        clickElement(actionDropdown.get(0));

        for (int j=0;j<visibleDropdown.size();j++){
            logger.info("The elements in the Dropdown are:"+visibleDropdown.get(j).getText());
            assertTrue(!visibleDropdown.get(j).getText().equalsIgnoreCase("Collected"));
        }

    }
    public void updatingPackAsHoliday() {

        try {
            for (int k=0;k<3;k++) {
                clickElement(actionDropdown.get(k));
                if(k<2){
                    clickElement(holidayButton.get(0));
                    assertPageObjectIsDisplayed(holidayHeader);
                    clickElement(emailNotSendButton);
                    clickElement(holidayConfirm);

                }
                else{
                    for (WebElementFacade dropdown : visibleDropdown)
                    {
                        assertTrue(!dropdown.getText().equalsIgnoreCase("Holiday"));
                    }
                }
            }
            for (int k =0;k<2;k++) {

                assertTrue(holidayStatus.get(k).getText().equalsIgnoreCase("HOLIDAY"));
                logger.info("Pack status:"+holidayStatus.get(k).getText());
            }
        }
        catch(StaleElementReferenceException  ex) {
            ex.printStackTrace();
        }
    }
    public void takingCustomerOffSchemeHolidayAndVerifying() {
        try {
            for (int k=0;k<2;k++) {
                clickElement(actionDropdown.get(k));
                clickElement(reinstateButton.get(0));
                assertPageObjectIsDisplayed(reinstateHeader);
                clickElement(holidayConfirm);
            }
            for (int k =0;k<2;k++) {
                assertElementText(packStatusList.get(k),"PENDING");
            }
        }
        catch(StaleElementReferenceException  ex) {
            ex.printStackTrace();
        }
    }
    public void verifyFirstPaymentStatus() {
        // final String paymentStatus = packPaymentStatusList.get(0).getText();
        logger.info(packPaymentStatusList.get(0).getText());
        assertElementContainsText(packPaymentStatusList.get(0),testDataManager.getTestInputRegionData("payment.paymentStatus"));
    }
    public void verifyFirstPaymentStatusAfterRefund() {

        firstPaymentStatus = packPaymentStatusList.get(0).getText();
        logger.info(firstPaymentStatus);
        assertTrue(firstPaymentStatus.equalsIgnoreCase("MAXREFUNDED"));
        assertFalse(selectActionBtnCompletedPayment.get(0).isEnabled());

        final String secondPaymentStatus = packPaymentStatusList.get(1).getText();
        logger.info(secondPaymentStatus);
        assertTrue(secondPaymentStatus.equalsIgnoreCase("Refunded"));
        selectActionBtnCompletedPayment.get(0).waitUntilDisabled();
        assertFalse(selectActionBtnCompletedPayment.get(0).isEnabled());
        final String todayDate =getCurrentDateStamp();
        logger.info("Today Date:"+todayDate);
        logger.info("UI Date:"+paymentDateList.get(1).getText().substring(5));
        assertEquals(todayDate, paymentDateList.get(1).getText().substring(5));

        final String firstPayment = packPaymentList.get(0).getText().substring(9);
        logger.info("firstPayment"+firstPayment);
        paymentToBeAdded = Double.parseDouble(firstPayment);
    }
    public void userPerformsWriteOff(String writeOffType, String authCode, String alertMsgPart){
            if (writeOffType.equalsIgnoreCase("Goodwill Payment")) {
                waitABit(2000);
                if(cancelButton.isVisible())
                    clickElement(cancelButton);
                clickElement(selectActionBtnPendingPayment.get(1));
                final String payToBeAdded = packPaymentList.get(0).getText().substring(9);
                paymentToBeAdded = Double.parseDouble(payToBeAdded);
                logger.info(String.valueOf(paymentToBeAdded));
                totalPaidValue = calculateCompletedPayments();
                editPaymentDateVisibleButton.selectByVisibleText("Goodwill");
                //clickElement(goodWillPayment);
                logger.info(writeOffAlertMessage.getText());
                logger.info("Please provide Manager authorisation to process " + alertMsgPart);
                assertTrue(writeOffAlertMessage.getText().equalsIgnoreCase("Please provide Manager authorisation to process " + alertMsgPart));

            } else if (writeOffType.equalsIgnoreCase("Write On Debt")) {
                managePaymentRefunded.waitUntilEnabled();
                clickElement(managePaymentRefunded);
                final String payToBeAdded = packPaymentList.get(0).getText().substring(9);
                paymentToBeAdded = Double.parseDouble(payToBeAdded);
                logger.info(String.valueOf(paymentToBeAdded));
                totalPaidValue = calculateCompletedPayments();
                waitForCondition().until(ExpectedConditions.elementToBeClickable(editPaymentDateVisibleButton));
                editPaymentDateVisibleButton.selectByVisibleText("Write On");
                logger.info(writeOffAlertMessage.getText());
                logger.info("Please provide Manager authorisation to process " + alertMsgPart);
                assertTrue(writeOffAlertMessage.getText().equalsIgnoreCase("Please provide Manager authorisation to process " + alertMsgPart));

            } else if (writeOffType.equalsIgnoreCase("Write Off Debt")) {
                clickElement(selectActionBtnPendingPayment.get(1));
                final String payToBeAdded = packPaymentList.get(0).getText().substring(9);
                paymentToBeAdded = Double.parseDouble(payToBeAdded);
                logger.info(String.valueOf(paymentToBeAdded));
                totalPaidValue = calculateCompletedPayments();
                editPaymentDateVisibleButton.selectByVisibleText("Write Off");
                logger.info(writeOffAlertMessage.getText());
                logger.info("Please provide Manager authorisation to process " + alertMsgPart);
                assertTrue(writeOffAlertMessage.getText().equalsIgnoreCase("Please provide Manager authorisation to process " + alertMsgPart));

            }

            logger.info("Get Text value:" + authorizationCodeFieldWriteOff.getTextValue());
            waitABit(2000);
            setText(authorizationCodeFieldWriteOff, authCode);
            logger.info("After entering auth code get Text value:" + authorizationCodeFieldWriteOff.getTextValue());
            clickElement(promotionProceedBtn);
            waitABit(10000);
            //validateAuthorizationCode(authCode);
            if (confirmButton.isEnabled()) {
                clickElement(confirmButton);

            } else {
                assertPageObjectIsDisplayed(invalidAuthorizationAlert);
                assertObjectIsNotInteractable(confirmButton);
                clickElement(cancelButton);
            }

    }
    public void userVerifiesIfWriteOffIsPerformed(String writeOffType) {

            String todayDate = getCurrentDateStamp();
            if (writeOffType.equalsIgnoreCase("Goodwill Payment")) {
                logger.info("Payment Status: " + goodWillPaymentStatus.getText());
                assertElementText(goodWillPaymentStatus, "COMPLETED GOODWILL");
                assertFalse(customerDebtAlert.isPresent());
                logger.info("The colour is:" + goodWillPaymentStatus.getCssValue("color"));
                assertTrue(goodWillPaymentStatus.getCssValue("color").equalsIgnoreCase("rgba(138, 109, 59, 1)"));
                clickElement(printScheduleLink);
                //clickElement(closePrintSchedule);

                goodwillCount = 0;
                TotalGoodwillPayment = 0.00;
                for (int i = 0; i < packPaymentList.size(); i++) {
                    String packPaymentStatus = packPaymentStatusList.get(i).getText();
                    if (packPaymentStatus.equals("GOODWILL - " + todayDate)) {
                        goodwillCount = goodwillCount + 1;
                        assertEquals(paymentDateList.get(i).getText().substring(5), todayDate);
                        logger.info("The payment number" + goodwillCount + "is of value" + packPaymentList.get(i).getText().substring(9));
                        logger.info(packPaymentList.get(i).getText().substring(9));
                        TotalGoodwillPayment = TotalGoodwillPayment + Double.parseDouble(packPaymentList.get(i).getText().substring(9));
                        paymentToBeAdded = TotalGoodwillPayment;
                        logger.info("String value:" + paymentToBeAdded);
                        assertFalse(selectActionBtnCompletedPayment.get(0).isEnabled());
                    }
                }
                int a = 0;
                do {
                    if (packPaymentStatusList.get(a).getText().contains("PENDING")) {
                        logger.info(paymentDateList.get(a).getText().substring(5));
                        nextPaymentDate = paymentDateList.get(a).getText().substring(5);
                        a = packPaymentStatusList.size();
                    } else {
                        a++;
                    }
                } while (a < packPaymentStatusList.size());

            } else if (writeOffType.equalsIgnoreCase("Write On Debt")) {
                logger.info(writeOnPaymentStatus.get(0).getText());
                assertElementEqualIgnoreCase(writeOnPaymentStatus.get(0), "Completed WriteOn");
/*
                if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
                    assertElementText(writeOnPaymentStatus.get(0), "Completed WriteOn");
                else
                    assertElementText(writeOnPaymentStatus.get(0), "COMPLETED BACS");
*/


                assertFalse(customerDebtAlert.isPresent());
           /* logger.info("The colour is:" +writeOnPaymentStatus.getCssValue("color"));
            assertTrue(writeOnPaymentStatus.getCssValue("color").equalsIgnoreCase("rgba(62, 71, 199, 1)"));
            */
                clickElement(printScheduleLink);
                int pack = 0;
                do {
                    if (packPaymentStatusList.get(pack).getText().contains("PENDING")) {
                        logger.info(paymentDateList.get(pack).getText().substring(5));
                        nextPaymentDate = paymentDateList.get(pack).getText().substring(5);
                        pack = packPaymentStatusList.size();
                    } else {
                        pack++;
                    }

                } while (pack < packPaymentStatusList.size());

            }

    }
    public void userVerifiesActionDropdownBtnIsDisabled(){

        assertObjectIsNotInteractable(selectActionBtnCompletedPayment.get(0));
        assertTrue(selectActionBtnCompletedPayment.get(0).getAttribute("disabled").equalsIgnoreCase("true"));

    }
    public void verifyGoodwillOptionIsNotAvailable() {
        int count = 0;
        StringBuilder option = new StringBuilder();
        for (WebElementFacade webElementFacade : packPaymentStatusList) {
            if (webElementFacade.getText().equalsIgnoreCase("PENDING")) {
                count++;
                logger.info("AfterCount:" + count);
            }
            clickElement(selectActionBtnPendingPayment.get(0));
            List<String> options=managePaymentDropdown.getSelectOptions();

            if (count == 1) {
                for (int j = 0; j < options.size(); j++) {
                    option.append(options.get(j));
                }
                assertTrue(option.toString().contains("Goodwill"));
            } else {
                for (String opt:options) {
                    logger.info("The elements in the Dropdown are:" + opt);
                    assertFalse(opt.equalsIgnoreCase("Goodwill"));
                }
            }
            clickElement(cancelButton);
            clickElement(selectActionBtnPendingPayment.get(count - 1));
            break;
        }
    }
    public void userVerifySocratesSync(){
        clickElement(editSubscriptnBtn.get(0));
        clickElement(firstChangeLink.get(0));
        newAddressDropDown.selectByVisibleText(testDataManager.getTestInputRegionData("address.number") + " " + testDataManager.getTestInputRegionData("address.name") + " " + testDataManager.getTestInputRegionData("address.addressLine") + " " + testDataManager.getTestInputRegionData("address.postcode"));
        clickElement(updateFutureDeliveryPacks);
        clickElement(confirmButton);
        waitABit(2000);
        final String newAddressSelected = testDataManager.getTestInputRegionData("address.number") + " " + testDataManager.getTestInputRegionData("address.name") + " " + testDataManager.getTestInputRegionData("address.addressLine") + " " + testDataManager.getTestInputRegionData("address.town")  + " " + testDataManager.getTestInputRegionData("address.county")  + " " + testDataManager.getTestInputRegionData("address.postcode") + " " + testDataManager.getTestInputRegionData("createCustomer.countryName");
        logger.info(newAddressSelected);
        final String expectedAddress = changedDeliveryAdd.get(0).getText().replaceAll("[\r\n]+", " ");
        logger.info(expectedAddress);
        assertTrue(expectedAddress.contains(newAddressSelected));
        clickElement(subscriptionBackButton);
        clickElement(socratesSyncButton);
        clickElement(updateFuturePacks);
        clickElement(updateButton);
        clickElement(editSubscriptnBtn.get(0));
        final String addressSelected = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        for(int i=0;i<changedDeliveryAdd.size();i++){
            assertTrue(changedDeliveryAdd.get(i).getText().replaceAll("[\r\n]+", " ").contains(addressSelected));
        }
    }
    public void toValidateSupplementaryOrder(String customerType){
        clickElement(supplementaryOrderButton);
        assertElementContainsText(subscriptionType,testDataManager.getTestInputRegionData("CommonCustomerData.subscriptionType"));
        assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
        assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
        assertTrue(solutionOnDashBoard.getText().toLowerCase().contains(testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name").toLowerCase()));
        clickElement(editSubscriptionButton.get(0));
        final String firstDelDate = firstDelivDate.getText();
        final String nextDelDate = nextDeliverySubDetail.getText();
        assertEquals(firstDelDate, nextDelDate);
        assertElementContainsText(nextPayment,"N/A");
        for(int payment=0;payment<compPaymentStatus.size();payment++){
            assertElementContainsText(compPaymentStatus.get(payment),testDataManager.getTestInputRegionData("CommonCustomerData.paymentStatus"));
        }
    }



    //This method is for SCE
    public void selectDailyPackageForSCE(String dailyType, String deliveryType, String payerType, String firstPackOption,String customerType){

        try{
            occasional.waitUntilClickable();
            String solutionSelected = "No Solution";
            assertTrue(occasional.isVisible() && partTime.isVisible() && fullTime.isVisible());
            if(dailyType.contains("Occasional"))
                clickElement(occasional);
            else if(dailyType.contains("PartTime"))
                clickElement(partTime);
            else
                clickElement(fullTime);
            assertTrue(solutionSelected.equalsIgnoreCase(solutionDropdown.getText().trim()));
            assertEquals("", firstPaymentDate.getTextValue());
            assertTrue(paymentBasis.isVisible());
            assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));
            Select paymentTypeSelect = new Select(paymentBasis);
            if(payerType.equalsIgnoreCase("PRE")){
                paymentTypeSelect.selectByValue("0: Prepay");
                assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("0: Prepay"));
                assertEquals(deliveryMessage.getText(), PaymentCollectionInfoMessage);
            }
            else{
                paymentTypeSelect.selectByValue("1: Postpay");
                assertTrue(paymentBasis.getSelectedValue().equalsIgnoreCase("1: Postpay"));
                assertElementText(deliveryMessage, postpayPaymentCollectionInfoMessage);
            }
            if(firstPackOption.equalsIgnoreCase("Yes")){
                clickElement(firstPackFulfilment);
            }else{
                logger.info("first pack fulFilment is not selected");
            }
            accountType = paymentBasisDropdownPrepay.getSelectedVisibleTextValue();
            selectPaymentDate(payerType,customerType);

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void verifyCancelPayment() {
        waitABit(8000);
        int actualSize = 0, expectedSize = 0;
        for (int i = 0; i < selectActionBtnCompletedPayment.size(); i++) {
            clickElement(selectActionBtnCompletedPayment.get(i));
            if (actionDropdownBox.containsText("Cancel Payment")) {
                actualSize++;
            }
            clickElement(selectActionBtnCompletedPayment.get(i));
        }

        for (int i = 0; i < selectActionBtnPendingPayment.size(); i++) {
            clickElement(selectActionBtnPendingPayment.get(i));
            if (actionDropdownBox.containsText("Cancel Payment")) {
                expectedSize++;
            }
            clickElement(selectActionBtnPendingPayment.get(i));
            logger.info("My actual" + actualSize + "My expctd" + expectedSize);
            assertEquals(String.valueOf(actualSize),String.valueOf(expectedSize));
            clickElement(selectActionBtnPendingPayment.get(i));
            waitABit(2000);
            clickElement(cancelPayment.get(0));
            assertTrue(labelCancelPaymentHeader.getText().equalsIgnoreCase("Cancel Payment"));
            assertTrue(cancelPaymentAlertMessage.getText().equalsIgnoreCase("Are you sure you want to mark this payment as Cancelled?"));
            assertTrue(cancelButton.getText().equalsIgnoreCase("Cancel"));
            assertTrue(confirmButton.getText().equalsIgnoreCase("Confirm"));
            confirmButton.waitUntilVisible();
            clickElement(confirmButton);
        }
    }





























































}









