package clsp.ui.steps;


import Framework.DataManager.TestDataManager;
import clsp.ui.pages.ClspHomePage;
import clsp.ui.pages.CustomerDashboard;
import clsp.ui.pages.CustomerDetailsPage;
import clsp.ui.pages.CustomerSearchPage;
import clsp.ui.pages.PaymentPage;
import clsp.ui.pages.SearchPage;
import clsp.ui.pages.SubscriptionPage;
import clsp.ui.pages.SummaryPage;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import net.thucydides.core.steps.ScenarioSteps;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class NavigateToClsp extends ScenarioSteps {


    ClspHomePage clspHomePage;
    CustomerDetailsPage customerDetailsPage;
    CustomerDashboard customerDashboard;
    PaymentPage paymentPage;
    SearchPage searchPage;

    CustomerSearchPage customersearchPage;

    SummaryPage summaryPage;
    SubscriptionPage subScriptionPage;


    protected static final TestDataManager testDataManager = new TestDataManager();



    String customerSearchPageURL="https://cldg-sit.nonprod.innov8.space/cldg/#/subscription/new/search";
    public void navigateToHomePage() {
        clspHomePage.open();

    }

    public void createAndLaunchURL(String customerID, String customerType, String tdrNumber, String fit) {

        subScriptionPage.createAndLaunchURL(customerID,customerType,tdrNumber,fit);
        UserCreatesAPICustomer.clientUser_id = testDataManager.getTestInputRegionData("createCustomer.store_id")+"-"+customerID;
    }



    public void userCreatesACC(){


        assertThat(this.getDriver().getCurrentUrl()).isEqualToIgnoringCase(customerSearchPageURL);
        searchPage.clickElement(searchPage.createNewCustomerButton);
        waitABit(5000);

    }



    public void userSelectsDailyPackage(String dailyType,String deliveryType, String payerType, String customerType){

        subScriptionPage.selectDailyPackage(dailyType,deliveryType,payerType,"NO",customerType);

    }

    public void userSelectsSolutionType(String solutionType, String deliveryType,String payerType,String customerType) throws Exception {
        subScriptionPage.selectMonthlySolutionType(solutionType,deliveryType,payerType,"NO",customerType);
    }
    public void selectPeroxideSolutionType(String solutionType, String deliveryType,String payerType,String authCode,String customerType) throws Exception {
        subScriptionPage.selectPeroxideSolutionType(solutionType,deliveryType,payerType,"NO",authCode,customerType);
    }

    public void verifyCustomerAccDetails(String customerType, String customerName, String customerID) {

        customerDetailsPage.verifyCustomerDetails(customerType,customerName,customerID);
        subScriptionPage.clickElement(subScriptionPage.futureConfirmButton);

    }
    public void verifyCustomerAccDetailsWithoutClickingConfirm(String customerType, String customerName, String customerID) {

        customerDetailsPage.verifyCustomerDetails(customerType, customerName, customerID);
    }
    public void clicksOnConfirmButton(){
        subScriptionPage.confirmButton.click();
    }

    public void entersPaymentDetailsAndPrintsMandate(String customerName,String customerID, String authCode) throws Exception{

        paymentPage.entersPaymentDetailsAndPrintsMandate(customerName,customerID, authCode,searchPage.nextDeliveryDate,subScriptionPage.finalDeliveryDate);

    }

    public void enterPaymentDetailsAndClosePrintMandate(String customerName, String authCode){
        paymentPage.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
    }
    public void verifySummaryPage(String customerID,String customerType,String customerName,String deliveryType, String fulfilmentType) throws  Exception{

        summaryPage.verifySummaryPage(customerID,customerType,customerName,deliveryType,fulfilmentType,subScriptionPage.selectedPaymentDate);
    }

    public void verifySummaryPageWithPrintSummary(String customerID,String customerType,String customerName,String deliveryType, String fulfilmentType) throws  Exception{

        summaryPage.verifySummaryPage(customerID,customerType,customerName,deliveryType,fulfilmentType,subScriptionPage.selectedPaymentDate);
        summaryPage.verifyPrintSummary(customerID,customerName);

    }

    public void isOnTheContactCenterCustomerSearchPage(){

        searchPage.launchContactCenterCustomerSearchPage();

    }
    public void IsOnStoreCustomerSearchPage() {
        searchPage.launchStoreContactCenterCustomerPage();

    }
    public void userClicksOnGDPRVerifyConsentApp(){

        customerDashboard.userClicksOnGDPRButtonAndVerifyConsentApp();
    }
    public void findExistingCustomerByID(String customerID){

        searchPage.findCustomerByID(customerID);

    }
    public void findExistingCustomerByID(){

        searchPage.findCustomerByClientID();

    }

    public void updatesCustomerDetails(){

        customerDashboard.updateCustomerDetails();

    }

    public void verifyCustomerDetails(){
        customerDashboard.clickElement(customerDashboard.addressBook);
        customerDashboard.verifyAddressDetails();
        customerDashboard.verifyContactDetails();
    }

    public  void clickOnEditSubscription(){
        customerDashboard.clickElement(customerDashboard.editSubscriptnBtn.get(0));

        waitABit(10000);
    }
    public void performExpeditePack(){
        subScriptionPage.performExpeditePack();}

    public void userUpdatesPaymentDate(String noOfDays, String payment) throws Exception {
        subScriptionPage.updatingPaymentDate(noOfDays, payment);


    }
    public void userVerifyPaymentSchedule() throws Exception{
        final String paymentDate = String.valueOf(subScriptionPage.nextPayment.getText());
        Date payDate = new SimpleDateFormat("dd/MM/yyyy").parse(paymentDate);
        summaryPage.getNextPaymentDate(payDate);
        subScriptionPage.verifyPaymentSchedule();
    }

    public void userVerifySubsequentDeliveryDate() throws Exception{
        subScriptionPage.verifySubsequentDeliveryDate();
    }

    public void userVerifyPaymentScheduleAfterEditSecondPaymentDate() throws Exception{
        subScriptionPage.verifyPaymentScheduleAfterEditSecondPaymentDate();
    }
    public void addAnNewAddress(String addressType) {
        customerDashboard.addressBook.click();
        customerDashboard.addNewAddress(addressType);
    }
    public void editDeliveryAdd(){

        customerDashboard.clickElement(customerDashboard.subscriptionTab);
        customerDashboard.clickEditSubscription();
        subScriptionPage.editDeliveryAddressForSubscription();
    }
    public void editContactInformation(){
        customerDashboard.updatingContactInformation();
    }

    public void performChangeUsage(String newUsage,String customerType){
        subScriptionPage.userPerformsChangeUsageAndVerifiesSchedule(newUsage,customerType);
    }

    public void userClicksOnConfirmButton(){
        subScriptionPage.clickElement(subScriptionPage.futureConfirmButton);
    }
    public void userClickOnSubscriptionTab(){
        subScriptionPage.clickElement(subScriptionPage.subscriptionTab);
    }

    public void userAddsAlternatePayerDetails(){
        paymentPage.addingAlternatePayerDetails();
    }
    public void verifyReplaceButtonIsDisabled(){
        customerDashboard.verifyReplaceBtnIsDisabled();
    }
    public void verifylensDetailsOnCustomerDashboard(String lensCount,  String customerType){
        customerDashboard.verifyLensDetailsOnCustDashboard(lensCount,customerType);
    }

    public void userNavigatesToManagePaymentTabAndAddsAlternatePayer(){
        customerDashboard.NavigatesToManagePaymentTabAndAddsAlternatePayer();
        paymentPage.addingAlternatePayerDetails();
    }

    public void userClicksOnEditAltrPayerAndVerifiesPayerDetails(){
        customerDashboard.clickElement(customerDashboard.editPayer);
        paymentPage.verifiesAlternatePayerDetails();
    }
    public void userVerifyTheAlternatePayerDetailsOutsideTheInformationModal() {
        customerDashboard.verifyTheAlternatePayerDetailsOutsideTheInformationModal(paymentPage.payerConfirmButton);
        paymentPage.verifiesAlternatePayerDetails();

    }
    public void userClicksOnManagePaymentMethodTabAndClickOnReplaceButton(String customerName, String paymentType) {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        paymentPage.verifyPayerPaymentDetails(customerName,paymentType);
        customerDashboard.verifyDetailsAfterClickingOnReplaceButton();
    }
    public void userVerifiesLeadTime(String leadTime) throws Exception {
        subScriptionPage.verifyLeadTime(leadTime);
    }

    public void userClicksOnBackButton(){

        subScriptionPage.clickElement(subScriptionPage.subscriptionBackButton);
    }
    public void userVerifiesDeliveryDatesOnDashboard() {

        customerDashboard.verifyDeliveryDates();
    }
    public void verifyCustomerDetailsForMonthlyCustomerAndSelectDelivertToDifferentAddress(String customertype,String firstname,String custID, String addressType) {
        customerDetailsPage.verifyCustomerDetails(customertype,firstname,custID);
        customerDetailsPage.clickElementSuccess(customerDetailsPage.diffAddress);
        customerDetailsPage.clickElement(customerDetailsPage.addNewAddress);
        customerDashboard.enterAddress(addressType);
        customerDetailsPage.addDifferentDeliveryAddressAndSetAsDefault(addressType,customerDashboard.addNewAddressButton);

    }
    public void userVerifiesAltPayerPaymentDetails(String customerName, String paymentType) {

        paymentPage.verifyPayerPaymentDetails(customerName,paymentType);
    }
    public void userClicksOnSubscriptionTab(){
        subScriptionPage.clickElement(subScriptionPage.subscriptionTab);
    }
    public void userVerifiesPackStatus(){
        subScriptionPage.verifyPackStatus();
    }
    public void userManagePaymentAndAddNewAlternatePayerDetails(String customerName,String authCode) {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.clickElement(customerDashboard.replaceButton);
        paymentPage.entersALtPayerPaymentDetailsAndPrintsMandate(customerName,authCode);

    }
    public void userEntersALtPayerPaymentDetailsAndPrintsMandate(String authCode){
        customerDashboard.clickElement(customerDashboard.replaceButton);
        paymentPage.addingAlternatePayerDetails();
        paymentPage.entersALtPayerPaymentDetailsAndPrintsMandate(searchPage.firstName,authCode);
    }


    public void userAddingAlternatePayerDetails(String dailyType,String customerName,String custID) {
        customerDetailsPage.verifyCustomerDetails(dailyType,customerName, custID);
        subScriptionPage.futureConfirmButton.click();
        paymentPage.addingAlternatePayerDetails();
    }
    public void userVerifiesPaymentMethodAndClickOnReplaceButton(String customerName,String paymentType) {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        paymentPage.verifyPayerPaymentDetails(customerName,paymentType);
        customerDashboard.verifyDetailsAfterClickingOnReplaceButton();
    }
    public void userEntersNewPaymentDetailsAndVerifyReceipt(String paymentType, String customerName, String authCode){
        paymentPage.enterPaymentDetailsWithoutAlternatePayerAndVerifyDetails(paymentType,customerName,customerDashboard.replaceButton,authCode);
    }
    public void userEntersNewPaymentDetailsWithoutAlterPayerDetails(String paymentType,String authCode){
        paymentPage.enterPaymentDetailsWithoutAlternatePayerAndVerifyDetails(paymentType,searchPage.lastName,customerDashboard.replaceButton,authCode);
    }
    public void userPerformsPackReplace(String replaceReason,String leftboxQty, String rightboxQty) {
        customerDashboard.clickEditSubscription();
       // subScriptionPage.verifyReplaceisAvailable(); // commented this step as it was clicking the Selection Action button twice and hence we couldn't find Replace btn visible
        subScriptionPage.performPackReplace(replaceReason,leftboxQty,rightboxQty,searchPage.custType);
    }
    public void verifyPackReplaceStatus(String addressType) {
        subScriptionPage.verifyReplacePackStatusOnly(addressType);
    }
    public void closeAllBrowserWindows(){
        getDriver().quit();
    }
    public void userClicksOnActiveFitTabAndClicksOnSubscribeButton(){
        customerDashboard.clickElement(customerDashboard.activeCLFitsTab);
        customerDashboard.showDetailsBtn.get(0).click();
        customerDashboard.clickElement(customerDashboard.subscribeButton);
    }
    public void userClicksOnActiveFitTabAndClicksOnReplaceButton(String authCode){
       customerDashboard.userValidatesReplaceSubscription(authCode);

    }
    public void userValidateReplacePeroxideSolution(String solutionType,String authCode){
        customerDashboard.validateReplacePeroxideSolution(solutionType,authCode);
    }
    public void userToValidateLinkFunctionality(){
        customerDashboard.toValidateLinkFunctionality();
    }
    public void clickOnSecondEditSubscriptionButton(){
        customerDashboard.clickOnSecondEditSubscritpionButton();
    }
    public void verifyCustomerPackageDetails(String solutionType){
        subScriptionPage.verifyCustomerPackageDetails(solutionType);
    }
    public void verifyCustomerCLFitDataForMonthlySubscribed(String customerType){
        subScriptionPage.verifyCLFitDataForMonthlySubscribed(customerType);
    }
    public void userClicksAgreementConfirmButton(String authCode){
        paymentPage.clickElementAgreementAndPrintMandate(authCode);
    }
    public void userSelectDailyTypeSubscriptionWithDiscount(String dailyType, String deliveryType, String payerType, String discountType, String authCode, String customerType)
    {
        subScriptionPage.selectDiscount(discountType, authCode);
        subScriptionPage.selectDailyPackage(dailyType, deliveryType, payerType,"NO",customerType);


    }
    public void verifyCustomerDetailsOnCreateAccountPage(String customerType,String customerName,String customerID) {

        customerDetailsPage.verifyCustomerDetails(customerType, customerName, customerID);
    }
    public void userVerifiesDiscountOnSummaryPage(String discountType, String customerType){
        summaryPage.verifyDiscountOnSummaryPage(discountType, customerType);
        subScriptionPage.verifyDiscountPaymentPlan(discountType, customerType, subScriptionPage.printSchedulePayments,searchPage.firstPackStatus);
        summaryPage.clickElement(summaryPage.summaryCloseButton);

    }
    public void userVerifiesDiscountPaymentPlan(String discountType, String customerType){
        subScriptionPage.verifyDiscountPaymentPlan(discountType, customerType, subScriptionPage.printSchedulePayments,searchPage.firstPackStatus);
    }
    public void userVerifiesSingleEyeDetails(String eyeType, String customerType){
        subScriptionPage.verifySingleEyeDetailsOnNewSubscriptionPage(eyeType, customerType);
    }
    public void userVerifiesLensDetailsOnCustomerDashboard(String eyeType, String customerType){
        customerDashboard.verifyLenses(eyeType, customerType);
    }
    public void verifyCustomerCLFitDataForSingleEye(String customerType) {
        subScriptionPage.verifyCLFitDataForSingleEye(customerType);
    }
    public void verifyCustomerCLFitDataForNoSolution(String customerType) {
        subScriptionPage.verifyCLFitDataForMonthlyNoSolution(customerType);
    }
    public void userClickOnManagePaymentMethodTabAndEditAlternatePayerDetails() {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        paymentPage.changeExistingAlternatePayerDetails();
    }
    public void userVerifyAllTheUpdatedDetailsOnCustomerDashboard() {
        customerDashboard.verifyChangeInExistingAlternatePayerDetails();
    }
    public void userVerifiesAltPayerDetailsOnDashBoard() {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.verifyAlternatePayerDetails("payer");
    }
    public void userHighlightsAdditionalContactButton() {
        customerDashboard.highlightAdditionalContact();
    }
    public void userAddsContactAndVerifiesAdditionalContactButton(String customerID, String noteSub, String noteType) {
        customerDashboard.addNewNoteToSubscription(noteSub,noteType);
        customerDashboard.clickElement(customerDashboard.customerSearch);
        searchPage.findCustomerByID(customerID);
        customerDashboard.verifiesTheAdditionalContactButton();

    }
    public void unHiLightsTheAdditionalContactButtonAndVerifiesIt(String customerID) {
        customerDashboard.unhighlightTheAdditionalContactButton();
        customerDashboard.clickElement(customerDashboard.customerSearch);
        searchPage.findCustomerByID(customerID);
        customerDashboard.verifiesTheAdditionalContactButtonIsUnHighlighted();
    }

    public void performWriteOff(){
        // subScriptionPage.performWriteOff();
    }

    public void userVerifiesAlternatePayerDetails(){
        paymentPage.verifiesAlternatePayerDetails();

    }
    public void userRemovesPayerAndNewAlternatePayerDetails(String addressType) {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.verifyDetailsAfterClickingOnReplaceButton();
        customerDashboard.clickElement(customerDashboard.replaceButton);
        customerDashboard.clickRemoveButton();
        paymentPage.setText(paymentPage.accHolderName,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
        paymentPage.enterBankDetails("newPayment");
        paymentPage.evaluateJavascript("window.scrollBy(0,1000)");
        customerDashboard.addNewAddressViaPostcode(addressType);
        paymentPage.replaceAlternatePayerPaymentDetails(addressType);

    }
    public void userTriesToRemoveTheNewlyAddedAlternatePayer() {
        customerDashboard.clickRemoveButton();
    }
    public void verifyStatusOfOtherSubscription(String subStatus) {
        customerDashboard.toVerifySubscriptionStatus(subStatus);
    }
    public void performCancelSubscription(String reason) throws Exception {
        customerDashboard.clickElement(customerDashboard.subscriptionTab);
        assertTrue(!(customerDashboard.subscriptionStatus.get(0).getText()).contains("CANCELLED"));
        //customerDashboard.clickEditSubscription();
        subScriptionPage.performCancelSubscription(0, reason);
    }
    public void userVerifiesConfirmButton() {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        paymentPage.verifyIfConfirmButtonIsClickableUponAddingRemovingAltPayer(customerDashboard.replaceButton,customerDashboard.removeButton,customerDashboard.removepayerButtonPop);

    }
    public void userUpdatesMonthlySolutionPackage(String updatedSolution) {
        subScriptionPage.updateMonthlyPackage(updatedSolution);
    }
    public void userVerifiesPaymentMethodAndClickOnReplaceButton() {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.verifyDetailsAfterClickingOnReplaceButton();
    }
    public void userVerifiesEnteredBICAndIBANIsValid(String bic, String iban) {
        paymentPage.verifyEnteredBICAndIBANIsValid(bic, iban,searchPage.firstName);

    }
    public void userVerifiesValidateButtonForInvalidIBAN(String bic, String iban) {
        paymentPage.verifyValidateButtonIsDisableForInvalidIBAN(bic, iban, searchPage.firstName);

    }
    public void userValidatesAuthCodeAndPerformRefundForFirstPayment(String refundReason, String refundMethod,
                                                                     String authorizationCode) {
        subScriptionPage.verifyAuthCodeToPerformRefundForFirstPayment(refundReason,refundMethod,authorizationCode,searchPage.nextPaymentAmt);
        subScriptionPage.multipleRefund();
    }
    public void userVerifyPaymentDetails()
    {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.userVerifiesTheExistingPaymentDetailsInReprint(paymentPage.alterPayerDetailsOnMandate,searchPage.firstName,paymentPage.receiptCloseButton,searchPage.lastName,paymentPage.printSepaAddress);
    }
    public void userUpdatesDailyUsagePackage(String newPackage, String customerType) throws Exception {
        subScriptionPage.userChangesCustomerPackage(newPackage,customerType);
    }
    public void userVerifyThatTheAlternatePayerDetailsAreNotPopulated() {
        customerDashboard.userVerifiesAlternatePayerDetailsNotBeingVisible();
    }
    public void userTriesToFillTheAddAlternatePayerDetails() {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.clickElement(customerDashboard.replaceButton);
        paymentPage.addingAlternatePayerDetails();
    }
    public void userTriesToReprintTheMandate() {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.clickElement(customerDashboard.reprintButton);
    }
    public void userVerifiesReprintDetails() {
        customerDashboard.userVerifiesTheDetailsInReprint(paymentPage.alterPayerDetailsOnMandate,paymentPage.receiptCloseButton);

    }
    public void verifyDailyPackageDetails(String dailyType) {
        subScriptionPage.verifyDailyCustomerPackageDetails(dailyType);
    }
    public void userUpdatesDailyPackage(String newPackage) {
        subScriptionPage.updatePackageUsage(newPackage);

    }
    public void userVerifiesPaymentScheduleAfterUpdatingUsage(String customerType) {
        subScriptionPage.verifyPaymentScheduleAfterUpdatingUsage(customerType);
    }
    public void userAddsAnewNoteUsingTabKey(String notes){
        customerDashboard.userAddsNotesByUsingTabKey(notes);
    }
    public void makingOnePackAsHoliday(String pack, String authorizationCode) {
        subScriptionPage.updatingOnePackAsHoliday(pack,searchPage.nextPaymentAmt,authorizationCode);
    }
    public void updatingOnePackAsHolidayWithAuthorization(String pack, String authorizationCode) {
        subScriptionPage.updatingOnePackAsHolidayWithAuthorization(pack,searchPage.nextPaymentAmt,authorizationCode);
    }

    public void userVerifyThatExpeditePackUnderSelectActionDropDown() {
        subScriptionPage.verifyExpeditePack();

    }
    public void userNavigatesToEntitlementsTabAndClaimEntitlements(String entitlementType) {
        customerDashboard.verifiesClaimEntitlements(entitlementType,subScriptionPage.disabledbutton1,subScriptionPage.enabledButton);

    }
    public void addAnNewAddressInAddressBook(String addressType){
        customerDashboard.clickOnChangeFirstPackAddress();
        customerDashboard.clickElement(customerDashboard.addressBook);
        customerDashboard.addNewAddress(addressType);
    }
    public void verifiesAdditionalContactButton(String noteSub, String noteType) {
        customerDashboard.customerSearch.click();
        searchPage.clickElement(searchPage.clearSearchfieldsButton);
        searchPage.findCustomerByClientID();
        customerDashboard.verifiesTheAdditionalContactButton();
        customerDashboard.addNewNoteToSubscription(noteSub,noteType);
    }
    public void createNewNoteToSubscription(String noteSub,String noteType){
        customerDashboard.addNewNoteToSubscription(noteSub,noteType);

    }
    public void tryingToSearchExistingCustomerUsingCorrectSurname() {
        searchPage.searchExistingCustomerUsingCorrectSurname();
    }
    public void seeListOfCustomersWhoHaveMatchingDetails() {
        searchPage.listOfCustomersWhoHaveMatchingDetails();
    }
    public void tryingToSearchExistingCustomerUsingCorrectForename() {
        customersearchPage.searchExistingCustomerUsingCorrectForename(searchPage.firstName, searchPage.customerID);
    }
    public void tryingToSearchExistingCustomerUsingCorrectCustomerId() {
        customersearchPage.searchExistingCustomerUsingCorrectCustomerId(searchPage.customerID);

    }
    public void userVerifiesStoreID() {
        subScriptionPage.verifyStoreIDOnSubscriptionDetails();
    }
    public void retrievesHubServiceAndCarrierAndFHDetails() {
        subScriptionPage.retrieveHubServiceAndCarrierAndFHDetails();
    }
    public void validateSplCharacters(String percentage,String underscore,String leftSquare,String rightSquare,String caret,String errorMsg){
        customersearchPage.validateSplCharOnSearchPage(percentage,underscore,leftSquare,rightSquare,caret,errorMsg);
    }

    public void validateSplCharactersCombine(String percentage,String underscore,String leftSquare,String rightSquare,String caret,String errorMsg){
        customersearchPage.validateSplCharOnSearchPageCombineString(percentage,underscore,leftSquare,rightSquare,caret,errorMsg);
    }
    public void verifyClearAllFunction() {
        customersearchPage.verifyClearAllFunctionality(searchPage.lastName,searchPage.firstName,searchPage.customerID);
    }
    public void verifyStoresWithPrefix(String prefix) {
        customersearchPage.verifyStoreListWithPrefix(prefix);
    }
    public void userVerifiesThePackAndPaymentStatusForAllPacksInSchedule(String customerType) {
        customerDashboard.clickEditSubscription();
        subScriptionPage.verifiesThePackAndPaymentStatusForAllPacksInSchedule(customerType);
        subScriptionPage.verifyPackStatus();
    }
    public void userPerformStoreFullFilMent() {
        customerDashboard.clickEditSubscription();
        subScriptionPage.performStoreFullFilment();
    }
    public void userPerformStoreFulFillMentAndChangesToSupplyChain() {
        customerDashboard.clickEditSubscription();
        subScriptionPage.performStoreFullFilment();
        subScriptionPage.performSupplyChainFulfillment();
    }
    public void performCancelSubscriptionAndVerifyPackPaymentStatus(int cancelDays, String reason) throws Exception {
        customerDashboard.clickElement(customerDashboard.subscriptionTab);
        subScriptionPage.performCancelSubscriptionAndVerifyPacksAndPayments(cancelDays, reason);
    }
    public void userVerifiesUpdatePackageButtonIsDisabled() {
        subScriptionPage.verifyUpdatePackageButtonIsDisabled();
    }
    public void userVerifiesSelectActionDropdownIsDisabled() {
        subScriptionPage.verifiesSelectActionDropdownIsDisabled();

    }
    public void userUpdateChangePackDeliveryDate(String payment,String futurePack) throws Exception {
        subScriptionPage.selectPaymentDateToPerformChangePackDeliveryDate(payment,futurePack);

    }
    public void userVerifiesReleaseToSupplyChainDate() throws Exception {
        subScriptionPage.verifyReleaseToSupplyChainDate();

    }
    public void userLaunchesStoreCustomerSearchPageAndFindsCustomerByMandateId() {
        searchPage.launchContactCenterCustomerSearchPage();
        customersearchPage.searchExistingCustomerByMandateID();
    }
    public void userVerifiesPaymentMethodOnManagePaymentTab(String paymentType) {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        paymentPage.verifyPayerPaymentDetails(searchPage.firstName,paymentType);
        customerDashboard.userVerifiesPaymentMethod(paymentPage.mandateReflabel);

    }
    public void userVerifiesPaymentStatus(String paymentStatus) {
        subScriptionPage.verifyPaymentStatusAfterPerformingHoliday(paymentStatus,searchPage.nextPaymentAmt);

    }
    public void userShouldNotAbleToReinstateHolidayPack() {
        subScriptionPage.unableToReinstateHolidayPack();

    }
    public void verifyBoxQuantities(String addressType) {
        subScriptionPage.verifyBoxQuantities(addressType);

    }
    public void userTriesToPerformReplacePackForMonthlySolutionToNoSolution(String replaceReason, String leftboxQty,
                                                                            String rightboxQty) {
        subScriptionPage.verifyReplacePackForMonthlySolutionToNoSolution(replaceReason,leftboxQty,rightboxQty);

    }
    public void userVerifiesPrintScheduleReciept() throws Exception {
        subScriptionPage.verifyCompleteSubscriptionScheduleOnPrintSchedule(customerDetailsPage.customerName,customerDetailsPage.custID,customerDetailsPage.storeName);

    }
    public void verifyCompleteSubscriptionScheduleWithPrintSchedule() throws Exception {
        subScriptionPage.verifyCompleteSubscriptionScheduleWithPrintSchedule(customerDetailsPage.customerName,customerDetailsPage.custID,customerDetailsPage.storeName);

    }
    public void userMarksPackCollectedFromStore() {
        subScriptionPage.packCollectedFromStore();

    }
    public void  userClicksOnSearchButton()	{
        customerDashboard.clickCustomerSearchButton();
    }
    public void  userFindsCustomerIDAppearingOnSearchField()	{
        customersearchPage.verifyCustomerIDField(searchPage.customerID);
        searchPage.findCustomerByClientID();
    }
    public void userVerifyNextPaymentAndDeliveryDateOnCustomerDashboard()  {
        customerDashboard.userVerifiesNextPaymentAndDeliveryDate();
    }
    public void userClicksOnBackArrowButtonOnBrowser() {
        subScriptionPage.verifyUserClicksOnBackArrowButtonOnBrowser(customersearchPage.searchCustID);
    }
    public void userEditFirstPaymentDateUpToMaxDate() throws ParseException {
        subScriptionPage.editsFirstPaymentDateUpToMaxDate();

    }
    public void userVerifiesPaymentStatusAndNavigateToManagementPaymentMethodTab() {
        subScriptionPage.verifyPaymentStatusAndNavigateToManagePaymentTab(searchPage.paymentStatus);
    }
    public void userVerifiesReplaceButton() {
        customerDashboard.verifyReplaceButtonDisabled();
    }
    public void userReinstatePack() {
        subScriptionPage.reinstatePack();

    }
    public void verifiesChangingAddressShouldImpactOnAllFuturePacks(String addressType) {
        subScriptionPage.verifyChangingAddressShouldImpactOnAllFuturePacks(addressType);

    }
    public void userVerifyTheBookAppointmentPageIsOpened() {
        customerDashboard.userClicksOnBookAppointmentButtonAndVerify();
    }
    public void userDeletesNewlyAddedAddress() {
        subScriptionPage.storePackAddress();
        customerDashboard.userDeletesAddress(subScriptionPage.packAddressList);
    }
    public void userDeleteAddress(){

        customerDashboard.userDeletesAddress(subScriptionPage.packAddressList);
    }
    public void userAddsANewAddressForBFPO() {
        customerDashboard.addNewAddressForBFPO();

    }
    public void userTurnOnTheCustomerCareAlertAndAlternateContactAlert() {
        customerDashboard.turnOnTheCustomerCareAlertAndAlternateContactAlert();
    }
    public void userVerifiesBothTheAlertShouldBeTurnedOn() {
        searchPage.launchStoreContactCenterCustomerPage();
        searchPage.findCustomerByClientID();
        customerDashboard.toReLoadCustomerAndVerifyBothTheAlertShouldBeTurnedOn();
    }
    public void userMustBeAbleToTurnOffBothTheAlerts() {
        customerDashboard.toTurnOffCustomerAndAlternatePayerAlerts();
    }
    public void userNavigateToManagementTab(){
        customerDashboard.navigateToManagePaymentTab();
    }
    public void toChangeHisAddressForAllFuturePacks(String addressType) {

        customerDashboard.clickElement(customerDashboard.subscriptionTab);
        customerDashboard.clickEditSubscription();
        subScriptionPage.toChangeAddressForAllFuturePacks(addressType);
    }
    public void verifiesReplacedPackStatusOnPackageTab(){
        subScriptionPage.verifyPackReplaceStatus();
        subScriptionPage.verifyOriginalAddressOnPackageTab();
    }
    public void verifiesTheDeliveryAddressForTheReplacedPack() {
        subScriptionPage.verifiesDeliveryAddressForTheReplacedPack();
    }
    public void verifiesPrintReceiptNotVisibleForReplacementTab() {
        subScriptionPage.verifiesPrintReceiptNotVisibleForReplacementPack();
    }
    public void userClicksOnReplaceAndRemovesPayerDetails(String addressType) {
        customerDashboard.clickElement(customerDashboard.managePaymentMethodTab);
        customerDashboard.verifyDetailsAfterClickingOnReplaceButton();

        customerDashboard.clickRemoveButton();
    }
    public void userVerifiesCollectedPackOptionIsUnavailable() {
        subScriptionPage.verifiesCollectedPackOptionIsUnavailable();
    }
    public void makingPackAsHoliday() {
        subScriptionPage.updatingPackAsHoliday();
    }
    public void takingCustomerOffSchemeHolidayAndVerifyIt() {
        subScriptionPage.takingCustomerOffSchemeHolidayAndVerifying();
    }
    public void userVerifiesPackStatusAsPendingAndFirstPaymentStatusAsCompleted() {
        customerDashboard.getAccountSummaryValue();
        customerDashboard.clickEditSubscription();
        subScriptionPage.verifyPackStatus();
        subScriptionPage.verifyFirstPaymentStatus();
    }
    public void userValidatesServiceCreditForStoreURL(String refundReason, String refundMethod,
                                                      String authorizationCode) {
        subScriptionPage.verifyAuthCodeToPerformRefundForFirstPayment(refundReason,refundMethod,authorizationCode,searchPage.nextPaymentAmt);
    }
    public void userVerifyTheSubscriptionBalanceAndFirstPaymentStatusAfterRefund() {
        customerDashboard.verifyAccountSummaryValues(subScriptionPage.totalPaidValue);
        customerDashboard.clickEditSubscription();
        subScriptionPage.verifyPackStatus();
        subScriptionPage.verifyFirstPaymentStatusAfterRefund();
    }
    public void userTriesToPerformAWriteOff(String writeOffType, String authCode,String alertMsgPart) throws Exception {
        subScriptionPage.userPerformsWriteOff(writeOffType,authCode,alertMsgPart);

    }
    public void userMustBeAbleToVerifyThePaymentStatus(String writeOffType) {
        subScriptionPage.userVerifiesIfWriteOffIsPerformed(writeOffType);

    }
    public void userNavigatesToHistoryTab() {
        customerDashboard.clickElement(customerDashboard.historyTab);
    }
    public void userVerifiesActionDropdownButtonIsDisabled(){
        subScriptionPage.userVerifiesActionDropdownBtnIsDisabled();
    }
    public void userCanVerifyNoteAfterWriteOff(String noteSub,String clinicalNotes,String noteType,String noteStatus) {
        customerDashboard.verifyNoteAfterWriteOff(noteSub,clinicalNotes,noteType,noteStatus,searchPage.store_id);
    }
    public void userVerifiesRefundReason(String refundReason, String noteSub, String noteType, String noteStatus) {
        customerDashboard.verifiesRefundReasonAfterPerformingHoliday(refundReason,noteSub,noteType,noteStatus,subScriptionPage.firstPaymentStatus,searchPage.nextPaymentAmt);
    }
    public void userVerifiesBadDebtIcon(){
        customerDashboard.userVerifiesBadDebtIcon();
    }
    public void userVerifiesGoodwillOptionIsNotAvailable() {
        subScriptionPage.verifyGoodwillOptionIsNotAvailable();
    }
    public void userVerifySocratesSync(){
        subScriptionPage.userVerifySocratesSync();
    }
    public void userVerifiesCompletedPaymentStatus(){
        subScriptionPage.verifyFirstPaymentStatus();
    }
    public void toValidateSupplementaryOrder(String customerType){
        subScriptionPage.toValidateSupplementaryOrder(customerType);
    }

    public void userCreatesACCForSCE(){
        assertThat(this.getDriver().getCurrentUrl()).isEqualToIgnoringCase(customerSearchPageURL);
        searchPage.clickElement(searchPage.createNewCustomerButton);
    }

    //This method is for SCE only
    public void userSelectsDailyPackageForSCE(String dailyType,String deliveryType, String payerType, String customerType){
        subScriptionPage.selectDailyPackageForSCE(dailyType,deliveryType,payerType,"NO",customerType);
    }

    public void verifyCustomerAccDetailsForSCE(String customerType, String customerName, String customerID) {
        subScriptionPage.clickElement(subScriptionPage.futureConfirmButton);
    }

    public void entersPaymentDetailsAndPrintsMandateForSCE(String customerName,String customerID, String authCode) {
        paymentPage.entersPaymentDetailsAndPrintsMandateForSCE(customerName,customerID, authCode,searchPage.nextDeliveryDate,subScriptionPage.finalDeliveryDate);
    }
    public void userVerifiesPaymentStatusAndCancelsPayment() {
        subScriptionPage.verifyCancelPayment();
    }
    public void userVerifiesTheSystemNotesAfterPerformingCancelPayment(){
        customerDashboard.userVerifiesTheSystemNotesAfterPerformingCancelPayment();
    }


    public void userClicksAgreementConfirmButtonandPrintMandate(){
        paymentPage.clickAgreementAndPrintMandate();
    }




}

