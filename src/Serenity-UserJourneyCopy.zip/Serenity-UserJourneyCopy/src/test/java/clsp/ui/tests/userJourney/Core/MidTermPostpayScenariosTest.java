package clsp.ui.tests.userJourney.Core;

import Framework.Annotations.CLSP.CLSP_ROI_CorePostpay;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class MidTermPostpayScenariosTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    UserSignUp clsp;
    @Steps
    UserCreatesAPICustomer apiObj;


    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,Second,Third"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Post Pay - Apply a Holiday - Customer already holidayed 2 packs in 12 month period.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userApplyAHoliday(int status, String dailyType, int quantity, int removedStatus, String packOne, String packTwo, String packThree) {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, packOne);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, packTwo);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, packThree);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userAppliesHolidayForMaximumPacksInSubscription();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Processing,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709776", projectId = "91768", testCaseName = "Post Pay - Expedite a Pack - 2 COMPLETED Payments and Pack Status Processing or DISPATCHED.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userExpediteAPack(int status, String dailyType, int quantity, int removedStatus, String packStatus, String packStatus1) {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus1);
        clsp.userClicksOnBackButton();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,10,first"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710079", projectId = "91768", testCaseName = "Post pay - CLSP-MID-43  - Edit Payment Date - Month End", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userEditPaymentDate(int status, int removedStatus, String noOfDays, String payment) throws Exception {
        apiObj.userCreatesMonthlyNoSolutionCustomerPostPay(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,10,first"
    })
     @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710084", projectId = "91768", testCaseName = "Post pay - CLSP-MID-44  - Edit Payment Date - Weekend and Bank Holiday", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userEditPaymentDateOnHoliday(int status, int removedStatus, String noOfDays, String payment) throws Exception {
        apiObj.userCreatesNewCustomerWithMonthlyNoSolutionOnBankHoliday(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,address,payment,7ud921,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710124", projectId = "91768", testCaseName = "CLSP-FR-10 - Payment - 11 - Existing Subscription - Replace Method Remove Alt Payer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userRemovesAlternatePayer(int status, String dailyType, int quantity, int removedStatus, String addressType, String paymentType, String authCode,int newSubscriptionStatus) {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToManagePaymentAndVerifiesPaymentMethod(paymentType);
        clsp.userEntersALtPayerPaymentDetailsAndPrintsMandate(authCode);
        clsp.userClicksOnSubscriptionTab();
        clsp.userClicksOnReplaceButtonAndClicksOnRemovePayerButton(addressType);
        clsp.userEntersNewPaymentDetailsWithoutAlterPayerDetails(paymentType,authCode);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710391", projectId = "91768", testCaseName = "First payment in flight and verify collected option should not be available", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifiesFirstPaymentInFlight(int status, int removedStatus) {
        apiObj.userCreatePostPayMonthlySolutionFirstPaymentInFlight(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userPerformStoreFulFillMentAndChangesToSupplyChain();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesCollectedPackFromStoreOptionIsUnavailable();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710394", projectId = "91768", testCaseName = "PostPay_UAT_002_Lensmail_Change fulfillment status from Pending to Completed", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangeStatusOfFulFillMent(int status, int removedStatus) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformStoreFullFilMent();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userCollectsPackFromStore();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,Occasional,2,204,second,No"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710446", projectId = "91768", testCaseName = "CR_0068_Post Pay_Change Pack Delivery Date", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangePackDeliveryDate(int status, String dailyType, int quantity, int removedStatus, String payment, String futurePack) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToUpdateChangePackDeliveryDate(payment, futurePack);
        clsp.userVerifySupplyChainDate();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,Occasional,2,204,Incorrect Contents Full,1 Box,1 Box,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710450", projectId = "91768", testCaseName = "Post pay - CLSP-MID-16 - Request a Replacement Pack - DAILY - DIFFERENT LENSES", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userRequestAReplacementPack(int status, String dailyType, int quantity, int removedStatus, String replaceReason, String leftboxQty, String rightboxQty, String addressType)  {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,FullTime,dailyFullTimeCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710453", projectId = "91768", testCaseName = "CLDG-SIT-UI-DCLDG-GENERAL - Update Package - Whether or not a pack gets updated seems to be governed by the Supplier Notification Date not Status", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userUpdatePackage(int status, String dailyType, int quantity, int removedStatus, String newPackage, String customerType) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userPerformsExpeditePack();
        clsp.userUpdatesPackageForDailyCustomer(newPackage, customerType);
        clsp.userVerifyPaymentScheduleAfterUpdatingUsage(customerType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,payment,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710456", projectId = "91768", testCaseName = "DF - 1860 - CLSP_SIT_UI_Unable to replace a Payment Method for Existing Customer (Dispatched Pack)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePaymentMethodForExistingCustomer(int status, String dailyType, int quantity, int removedStatus, String paymentType, String authCode) {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThePaymentStatus();
        clsp.userNavigatesToManagePaymentAndVerifiesPaymentMethod(paymentType);
        clsp.userEntersNewPaymentDetailsWithoutAlterPayerDetails(paymentType,authCode);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,0,Oversupply,Damaged Partial,1 Box,1 Box,address,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710553", projectId = "91768", testCaseName = "POSTPAY- Perform Partial Replace for Cancel Subscription from History Tab", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsPartialReplace(int status, String dailyType, int quantity, int removedStatus, int cancelDays, String reason, String replaceReason, String leftboxQty, String rightboxQty, String addressType, String packStatus) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status,packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Dispatched,80,Moving"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42746703", projectId = "91768", testCaseName = "Future dated cancellation when pack Dispatched 1 Payment Complete Cancel After 3 Payment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelForOnePaymentCompleted(int status, int removedStatus, String packStatus, int cancelDays, String reason) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Dispatched,50,Moving,First"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710569", projectId = "91768", testCaseName = "Future dated cancellation when pack Dispatched 1 Payment Complete Cancel After 2 Payment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelForDispatchedAfterPaymentCompleted(int status, int removedStatus, String packStatus, int cancelDays, String reason, String pack) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, pack);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Dispatched,25,Moving,First"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710570", projectId = "91768", testCaseName = "Future dated cancellation when pack Dispatched 1 Payment Complete Cancel Before 2 Payment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelForDispatchedBeforePaymentCompleted(int status, int removedStatus, String packStatus, int cancelDays, String reason, String pack) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, pack);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Cancellation,Credit,a000cc"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710572", projectId = "91768", testCaseName = "CLSP-MID-38 - CORE - Process a Max Refund.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userProcessForRefund(int status, int removedStatus, String refundReason, String refundMethod, String authorizationCode)  {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesPackStatusAsPendingAndFirstPaymentStatusAsCompleted();
        clsp.userVerifiesServiceCreditForStoreURL(refundReason, refundMethod, authorizationCode);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesTheSubscriptionBalanceAndFirstPaymentStatusAfterRefund();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Cancellation,Credit,2abcd2,kihtPC,94c30"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710578", projectId = "91768", testCaseName = "CLSP-CONTACTCENTREAUTH-02 - Refunds", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformRefund(int status, int removedStatus, String refundReason, String refundMethod, String authorizationCode, String wrongAuthorizationCode, String contactCenterAuthorizationCode)  {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesServiceCreditForStoreURL(refundReason, refundMethod, authorizationCode);
        clsp.userVerifiesServiceCreditForStoreURL(refundReason, refundMethod, wrongAuthorizationCode);
        clsp.userVerifiesServiceCreditForStoreURL(refundReason, refundMethod, contactCenterAuthorizationCode);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesTheSubscriptionBalanceAndFirstPaymentStatusAfterRefund();
        apiObj.userDeletesCustomer(removedStatus);
    }


    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,NONE,FullTime,dailyFullTimeCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706937", projectId = "91768", testCaseName = "Pre Pay - Update Usage - Monthly", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userUpdateUsageMonthly(int status, String dailyType, int quantity, int removedStatus, String firstPack, String newPackage, String customerType) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPackageForDailyCustomer(newPackage, customerType);
        clsp.userVerifyPaymentScheduleAfterUpdatingUsage(customerType);
        apiObj.userDeletesCustomer(removedStatus);

    }


    @AfterEach
    @CLSP_SMOKE
    
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose(){
        driver.quit();
    }



}
