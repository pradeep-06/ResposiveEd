package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import Framework.Staf;
import au.com.bytecode.opencsv.CSVReader;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.platform.commons.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class EsuiteLogin extends clspBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(EsuiteLogin.class);

    SearchPage searchPage;
    public static String reportGenerationDate;
    public static double storeBalancePrepay=0.00;
    public static double storeBalancePostPay =0.00;
    public String prepayAmt;
    public String postPayAmt;
    @FindBy(xpath = "//h1[text()='All Reports']")
    private WebElementFacade allReportsHeader;
    @FindBy(css = "#inputAffiliateId")
    private WebElementFacade clientId;
    @FindBy(xpath = "//img[@class='logo w3-dropdown-click']")
    private WebElementFacade esuiteHeader;
    @FindBy(xpath = "//table[@class='gridViewTable']//tbody/tr[1]//div[@class='blackNormal download']")
    private WebElementFacade firstDownloadBtn;

    @FindBy(xpath = "//table[@class='gridViewTable']//tbody/tr[1]//div[@class='blackNormal view']")
    private WebElementFacade firstViewBtn;
    @FindBy(xpath = "//a[@data-selectedtab='History']")
    private WebElementFacade historyTab;
    @FindBy(xpath = "//span[@id='loginButton']//a")
    private WebElementFacade login;
    @FindBy(xpath = "//input[@id='inputPassword']")
    private WebElementFacade password;
    @FindBy(xpath = "//span[contains(.,'Specsavers Pending Fulfillments Report')]")
    private WebElementFacade pendingFulfillmentReportHeader;
    @FindBy(xpath = "//li[@data-action='ReportsData']")
    private WebElementFacade reports;
    @FindBy(xpath = "//div[@class='run ']")
    private WebElementFacade runReport;
    @FindBy(xpath = "//button[text()='Run']")
    private WebElementFacade runReportButton;
    @FindBy(xpath = "//button/span[@class='ui-button-text']")
    private WebElementFacade reportOkButton;
    @FindBy(xpath = "//p[@class='label-processing-idle']")
    private WebElementFacade reportRunStatus;

    @FindBy(xpath = "//td[contains(.,'Csv Transform')]//..//td[3]")
    private WebElementFacade reportDate;

    @FindBy(xpath = "//span[contains(.,'Next')]")
    private WebElementFacade reportNextMonthDropdown;

    @FindBy(xpath = "//a[contains(.,'Current')]")
    private WebElementFacade reportCurrentMonthOption;

    @FindBy(xpath = "//span[contains(.,'Year(s)')]")
    private WebElementFacade reportDateRangeDropdown;

    @FindBy(xpath = "//a[contains(.,'Quarter(s)')]")
    private WebElementFacade reportQuarterDropdown;

    @FindBy(xpath = "//a[contains(.,'Day(s)')]")
    private WebElementFacade reportDayDropdown;

    @FindBy(xpath = "//a[contains(.,'Month(s)')]")
    private WebElementFacade reportMonthDropdown;

    @FindBy(xpath = "//a[contains(.,'Specsavers Pending Fulfillments Report')]")
    private WebElementFacade specsaversPendingFulfillmentReport;
    @FindBy(xpath = "//input[@id='inputUserName']")
    private WebElementFacade userName;

    @FindBy(xpath = "//a[@href='/SystemAccount/LogOff']")
    private WebElementFacade logout;

    @FindBy(xpath = "//a[contains(.,'Specsavers Store Balance Sheet')]")
    private WebElementFacade storeBalanceReport;

    @FindBy(xpath = "//span[contains(.,'Specsavers Store Balance Sheet')]")
    private WebElementFacade StoreBalanceReportHeader;

    @FindBy(xpath = "//a[@class='report-name-link blueBold ellipsis'][contains(.,'Specsavers Cancellations Reason Report')]")
    private WebElementFacade cancellationReasonReport;

    @FindBy(xpath = "//span[contains(.,'Replacement')]")
    private WebElementFacade replacementAndTopUpReportHeader;

    @FindBy(xpath = "//span[contains(.,'Specsavers Cancellations Reason Report')]")
    private WebElementFacade cancellationReasonReportHeader;

    @FindBy(xpath = "//a[@class ='report-name-link blueBold ellipsis'][contains(.,'Specsavers Future Payment Transactions Report')]")
    private WebElementFacade specsaversFuturePaymentTransactions;

    @FindBy(xpath = "//span[contains(.,'Specsavers Future Payment Transactions')]")
    private WebElementFacade specsaversFuturePaymentTransactionsHeader;

    @FindBy(xpath = "//a[@class ='report-name-link blueBold ellipsis'][contains(.,'Specsavers Customers with multiple subscription')]")
    private WebElementFacade specsaversMultipleSubscriptionReport;

    @FindBy(xpath = "//a[contains(.,'Specsavers Finance Report')]")
    private WebElementFacade specsaversFinanceReport;

    @FindBy(xpath = "//span[contains(.,'Specsavers Finance Report')]")
    private WebElementFacade SpecsaversFinanceHeader;

    @FindBy(xpath = "//a[@id='selectDataRangeType-button']")
    private WebElementFacade selectDate;

    @FindBy(xpath = "//ul[@id='selectDataRangeType-menu']//a[normalize-space()='Custom']")
    private WebElementFacade customSelection;


    public void openESuiteUrl() {
        openUrl(testDataManager.getTestInputCommonData("url.eSuite"));
    }

    public void userLoginIneSuite() {
        waitFor(clientId);
        setText(clientId, testDataManager.getTestInputCommonData("login.eSuiteClientID"));
        setText(userName, testDataManager.getTestInputCommonData("login.eSuiteUserName"));
        setText(password, testDataManager.getTestInputCommonData("login.eSuitePassword"));
        clickElement(login);
        waitABit(10000);
        esuiteHeader.waitUntilVisible();
    }

    public void logoutFromESuite() {
        waitFor(logout);
        clickElement(logout);
        waitABit(5000);
        assertTrue(clientId.isVisible());
    }

    public void userClickOnReportsTab() {
        reports.waitUntilVisible();
        clickElement(reports);
        allReportsHeader.waitUntilVisible();
    }

    public void userFetchPendingFulfillmentReport() {
        waitFor(specsaversPendingFulfillmentReport);
        scrollToView(specsaversPendingFulfillmentReport);
        evaluateScriptClick(specsaversPendingFulfillmentReport);
        waitForElement();
        pendingFulfillmentReportHeader.waitUntilVisible();
        clickElement(runReport);
        reportDateRangeDropdown.waitUntilClickable();
        clickElement(reportDateRangeDropdown);
        clickElement(reportQuarterDropdown);  //verifying quarterly data as yearly data is too much
        clickElement(runReportButton);
        String reprtDate = waitUntilReportRunAndStoreReportDateTime();
        reportGenerationDate = "SpecsaversPendingFulfilmentsReport-" + reprtDate + "-" + reportGenerationDate + "-6000.csv";
        waitABit(3000);
        reportOkButton.click();
    }

    public String waitUntilReportRunAndStoreReportDateTime() {
        waitABit(30000);        // Reports take long time to execute
        assertElementContainsText(reportRunStatus, "IDLE");
        historyTab.waitUntilClickable();
        clickElement(historyTab);
        firstDownloadBtn.waitUntilClickable();
        clickElement(firstDownloadBtn);
        clickElement(firstViewBtn);
        waitABit(3000);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date today = Calendar.getInstance().getTime();
        String calculatedReportDate = dateFormat.format(today);
        calculatedReportDate = calculatedReportDate.replace("/", "");
        reportGenerationDate = reportDate.getText().substring(11);
        logger.info("Report Date is:" + reportGenerationDate);
        calculateReportTimeDuringDayLightSaving(); //added temparily for daylight saving as time in report is 1 hr less then the current time
        //reportGenerationDate = reportGenerationDate.replace(":", "");
        logger.info("Report Date is:" + reportGenerationDate);
        logger.info("Actual Report Date:" + calculatedReportDate + "-" + reportGenerationDate + "-6000");
        return calculatedReportDate;
    }

    public void calculateReportTimeDuringDayLightSaving() {
        reportGenerationDate = reportDate.getText();
        logger.info(reportGenerationDate);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime daylight = LocalDateTime.parse(reportGenerationDate,formatter).minusHours(1);
        String dayLightSaving = daylight.toString().substring(11).replace(":","");
        logger.info("Report Date is:" + dayLightSaving);
        reportGenerationDate = dayLightSaving;
    }

    public ArrayList<String> userDownloadsReportAndStoresValues() throws IOException {
            String file = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "TestData" + File.separator + "clsp" + File.separator + "Downloads" + File.separator + reportGenerationDate;
            //debugging
            logger.info("File name: "+reportGenerationDate);
            logger.info("Complete Path: "+file);
            waitABit(30000);
            ArrayList<String> records = new ArrayList<String>();
            try (CSVReader csvReader = new CSVReader(new FileReader(file));) {
                String[] values = null;
                while ((values = csvReader.readNext()) != null) {
                    records.add(Arrays.asList(values).toString());
                }
            }
            return records;
    }

    public void verifyPendingFulfillmentReport(String dailyType, String client_user_id, String store_id, String payerTypeAPI, String nonLensMailOrderValue, String nextDeliveryDate, String firstPackStatus, String supplier_notification_date, String accountID, String orderLineType, String orderId) throws Exception {
        ArrayList<String> records = userDownloadsReportAndStoresValues();

        // validating Store Balance Report Header
        int j = 0;
        do {
            assertTrue(records.get(j).contains("ClientID, StoreNumber, FulfilmentReference, FulfilmentStatus, ExpectedDeliveryDate, SupplierNotificationDate, NonLensmailOrder, OrderLineType, CartReference, RightSKU, RightQty, LeftSKU, LeftQty, SolutionSKU, LensDiscountedBundleGrossPrice, LensNondiscountedBundleGrossPrice, LensDiscountedBundleVatPrice, LensNondiscountedBundleVatPrice, AccessoriesDiscountedBundleGrossPrice, AccessoriesNondiscountedBundleGrossPrice, AccessoriesDiscountedBundleVatPrice, AccessoriesNondiscountedBundleVatPrice, Currency, PaymentInstructionId, PayerType]"));
            break;
        } while (j > 0);

        int counter = 0;
        // Validating values within the Report
        for (int i = 0; i < records.size(); i++) {
            if (records.get(i).substring(12, 24).contains(client_user_id)) {
                final String updatedRecords = records.get(i);
                logger.info("Account Details: "+accountID + ", " + client_user_id + ", " + store_id + ", " + orderId + ", " + firstPackStatus + ", " + nextDeliveryDate + " 01:00:00" + ", " + supplier_notification_date + " 01:00:00" + ", " + nonLensMailOrderValue + ", " + orderLineType);
                logger.info("NonLensMailOrderValue: " + nonLensMailOrderValue);
                if(StringUtils.isBlank(nonLensMailOrderValue))
                    assertTrue(updatedRecords.contains(accountID + ", " + client_user_id + ", " + store_id + ", " + orderId + ", " + firstPackStatus + ", " + nextDeliveryDate + " 01:00:00" + ", " + supplier_notification_date + " 01:00:00" + ", " + "" + ", " + orderLineType));
                else
                    assertTrue(updatedRecords.contains(accountID + ", " + client_user_id + ", " + store_id + ", " + orderId + ", " + firstPackStatus + ", " + nextDeliveryDate + " 01:00:00" + ", " + supplier_notification_date + " 01:00:00" + ", " + nonLensMailOrderValue + ", " + orderLineType));
                assertTrue(updatedRecords.contains(testDataManager.getTestInputRegionData(dailyType + ".SKU") + ", " + testDataManager.getTestInputRegionData(dailyType + ".quantity") + ", " + testDataManager.getTestInputRegionData(dailyType + ".SKU") + ", " + testDataManager.getTestInputRegionData(dailyType + ".quantity")));
                assertTrue(updatedRecords.contains(testDataManager.getTestInputRegionData(dailyType + ".currency")));
                assertTrue(updatedRecords.contains(payerTypeAPI));
                }
        }
    }
    public void userFetchStoreBalanceReport() {
        assertTrue(storeBalanceReport.isVisible());
        scrollToView(storeBalanceReport);
        evaluateScriptClick(storeBalanceReport);
        assertTrue(StoreBalanceReportHeader.isVisible());
        runReport.waitUntilClickable();
        clickElement(runReport);
        waitABit(3000);// time taking to run the report
        runReportButton.waitUntilVisible();
        clickElement(runReportButton);
        String reportDate = waitUntilReportRunAndStoreReportDateTime();
        reportGenerationDate = "SpecsaversStoreBalanceSheet-"+reportDate+"-"+reportGenerationDate+"-6000.csv";
        clickElement(reportOkButton);

    }
    public void captureStoreBalanceReportData() throws Exception{
        ArrayList<String> records = userDownloadsReportAndStoresValues();
        // validating Store Balance Report Header
        int j=0;
        do{
            logger.info("The Header is:"+records.get(j));
            assertTrue(records.get(j).contains("StoreID, BalanceCalculationDate, PrePayReceived, PostPayReceived, Currency]"));
            break;
        }while(j>0);
        for (int i=0; i<records.size();i++){
            logger.info("The data is:"+records.get(i));
            logger.info(records.get(i));
            if(records.get(i).contains(testDataManager.getTestInputRegionData("address.storeNo"))){
                logger.info(records.get(i));
                prepayAmt= records.get(i).substring(2, 3).replace("[", "");
                prepayAmt=prepayAmt.replace("]", "");
                postPayAmt = records.get(i).substring(3, 4).replace("[", "");
                postPayAmt = postPayAmt.replace("]", "");
                storeBalancePrepay = Double.parseDouble(prepayAmt);
                storeBalancePostPay = Double.parseDouble(postPayAmt);
                break;

            }
        }

    }
    public void verifyStoreBalanceReport(Double nextPostpayPaymentAmt,Double nextPrepayPaymentAmt) throws Exception {
        Double expectedStoreBalancePrepay = storeBalancePrepay + nextPrepayPaymentAmt;
        Double expectedStoreBalancePostpay = storeBalancePostPay + nextPostpayPaymentAmt;
        captureStoreBalanceReportData();
        assertTrue(String.format("%.02f",expectedStoreBalancePrepay).contains(prepayAmt));
        assertTrue(String.format("%.02f",expectedStoreBalancePostpay).contains(postPayAmt));
    }
    public String twoDecimalAmount(double amt){

        String amountFormat = String.format("%.02f",amt);
        logger.info("Two Decimal Amt:" +amountFormat);
        return amountFormat;
    }
    public void userFetchCancellationReasonReport() {
        waitABit(4000);
        assertTrue(cancellationReasonReport.isVisible());
        cancellationReasonReport.waitUntilClickable();
        evaluateScriptClick(cancellationReasonReport);
        assertTrue(cancellationReasonReportHeader.isVisible());
        runReport.waitUntilClickable();
        clickElement(runReport);
        waitABit(3000);
        runReportButton.waitUntilVisible();
        clickElement(runReportButton);
        String reprtDate = waitUntilReportRunAndStoreReportDateTime();
        reportGenerationDate = "SpecsaversCancellationsReport-"+reprtDate+"-"+reportGenerationDate+"-6000.csv";
        clickElement(reportOkButton);
    }
    public void verifyCancellationReasonReport(String reason,String clientUser_id,String store_id) throws Exception{

        String cancellationDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        ArrayList<String> records = userDownloadsReportAndStoresValues();
        // validating Store Balance Report Header
        int j=0;
        do{
            assertTrue(records.get(j).contains("ClientID, PaymentInstructionId, CancellationDate, CancellationCode, CancellationReason, StoreNumber]"));
            break;
        }while(j>0);

        // Validating values within the Report
        for (int i=0; i<records.size();i++){
            if(records.get(i).contains(clientUser_id)){
                logger.info(records.get(i));
                assertTrue(records.get(i).contains(clientUser_id));
                assertTrue(records.get(i).contains(cancellationDate));
                assertTrue(records.get(i).contains(reason.toLowerCase()));
                assertTrue(records.get(i).contains(store_id));
            }
        }
    }
    public void userFetchSpecsaversFuturePaymentTransactionsReport() {
        waitABit(4000);
        assertTrue(specsaversFuturePaymentTransactions.isVisible());
        specsaversFuturePaymentTransactions.waitUntilClickable();
        evaluateScriptClick(specsaversFuturePaymentTransactions);
        assertTrue(specsaversFuturePaymentTransactionsHeader.isVisible());
        runReport.waitUntilClickable();
        clickElement(runReport);
        waitABit(3000);
        runReportButton.waitUntilVisible();
        clickElement(runReportButton);
        String reportDate = waitUntilReportRunAndStoreReportDateTime();
        reportGenerationDate = "FuturePaymentTransactionsReport-"+reportDate+"-"+reportGenerationDate+"-6000.csv";
        clickElement(reportOkButton);
    }
    public void verifySpecsaversFuturePaymentTransactionsReport(String transactionType, String clientUser_id, String nextPaymentAmt, String sub_description) throws Exception{
        ArrayList<String> records = userDownloadsReportAndStoresValues();
        // validating Future SEPA Report Header
        int j=0;
        do{
            assertTrue(records.get(j).contains("Submission Date, Payment Date, ClientUserID, Reference, Transaction Type, Currency, Amount, AccountID, Payment Method]"));
            break;
        }while(j>0);

        // Validating values within the Report
        try
        {
            int	counter=0;
            for (int i=0; i<records.size();i++)
            {
                if(transactionType.equalsIgnoreCase("Cancelled"))
                {
                    assertTrue(!records.get(i).contains(clientUser_id));
                    counter++;
                }

                else if(records.get(i).contains(clientUser_id))
                {
                    assertTrue(records.get(i).contains(LocalDate.now().plusDays(5).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
                    assertTrue(records.get(i).contains(clientUser_id));
                    assertTrue(records.get(i).contains(transactionType));
                    assertTrue(records.get(i).contains(testDataManager.getTestInputRegionData("cartJsonBody.currency")));

                    if(sub_description.equalsIgnoreCase(testDataManager.getTestInputRegionData("subscriptionRequest.Description")))
                    {
                        logger.info(nextPaymentAmt);
                        logger.info(records.get(i));
                        assertTrue(records.get(i).contains(nextPaymentAmt));
                    }
                    else
                        assertTrue(records.get(i).contains(Float.toString(Float.parseFloat(nextPaymentAmt) * 3)));
                        if(Staf.getEnvironment().equals("ROI"))
                            assertTrue(records.get(i).contains("SEPA"));
                        else
                            assertTrue(records.get(i).contains("BACS"));
                    counter++;
                    break;
                }
            }

            assertTrue(counter>0);
        }
        catch (Exception e) {
            logger.info("Exception thrown");
            assertTrue(records.get(0).contains(clientUser_id));
            e.printStackTrace();
        }
    }
    public void userFetchSpecsaversCustWithMultipleSubscriptionReport(){
        waitABit(4000);
        assertTrue(specsaversMultipleSubscriptionReport.isVisible());
        evaluateScriptClick(specsaversMultipleSubscriptionReport);
        runReport.waitUntilClickable();
        clickElement(runReport);
        waitABit(3000);
        runReportButton.waitUntilVisible();
        clickElement(runReportButton);
        String reprtDate = waitUntilReportRunAndStoreReportDateTime();
        reportGenerationDate = "CustomersWithMultipleSubscriptionsReport-"+reprtDate+"-"+reportGenerationDate+"-6000.csv";
        clickElement(reportOkButton);
    }
    public void verifySpecsaversCustomerWithMultipleSubscriptionReport(String status, String clientUser_id) throws IOException, Exception{
        logger.info("Navigated to esuite");
        ArrayList<String> records = userDownloadsReportAndStoresValues();
        // validating Future SEPA Report Header
        int j=0;
        do{
            assertTrue(records.get(j).contains("StoreNumber, ClientUserID, PaymentInstructionStatus, DateCreated, FirstPaymentDate, NextPaymentDate, FirstDeliveryDate, NextDeliveryDate, FulfilmentPrice]"));
            break;
        }while(j>0);
        // Validating values within the Report
        try
        {
            int	counter=0;
            for (int i=0; i<records.size();i++)
            {
                logger.info(records.get(i));
                logger.info(records.get(i).substring(7,18));
                if(records.get(i).substring(7,18).contains(clientUser_id))
                {
                    logger.info("if loop entered");
                    logger.info(records.get(i));
                    assertTrue(records.get(i).contains(testDataManager.getTestInputRegionData("createCustomer.mpp_store_id")));
                    assertTrue(records.get(i).contains(clientUser_id));
                    assertTrue(records.get(i).contains(status));
                    counter++;

                }
            }
        }
        catch (Exception e) {
            logger.info("Exception Occured");
            assertTrue(records.get(0).contains(clientUser_id));
            e.printStackTrace();
        }
    }
    public void userFetchesSpecsaversFinanceReport() {

        waitABit(4000);
        assertTrue(specsaversFinanceReport.isVisible());
        specsaversFinanceReport.waitUntilClickable();
        evaluateScriptClick(specsaversFinanceReport);
       assertTrue(SpecsaversFinanceHeader.isVisible());
        runReport.waitUntilClickable();
        clickElement(runReport);
        waitABit(3000);
        runReportButton.waitUntilVisible();
        if (reportCurrentMonthOption.isVisible()){
            clickElement(runReportButton);
        }
        else{
            clickElement(selectDate);
            clickElement(customSelection);
            clickElement(runReportButton);
        }
        String reprtDate = waitUntilReportRunAndStoreReportDateTime();
        reportGenerationDate = "SpecsaversFinanceReport-"+reprtDate+"-"+reportGenerationDate+"-6000.csv";
        clickElementSuccess(reportOkButton);

    }
    public void verifiesSpecsaversFinanceReport(String customerType,String clientUser_id,String sub_description,String payerTypeAPI,String nonLensMailOrderValue) throws Exception {
        ArrayList<String> records = userDownloadsReportAndStoresValues();
        // validating Specsavers Finance Report Header
        int j=0;
        do{
            assertTrue(records.get(j).contains("OrderID, OrderStatus, GrossAmount, NetAmount, VATAmount, OrderDate, AccountID, ClientUserID, StoreId, FirstPayment, PayerType, PaymentMethod, DeliveryStatus, LensDiscountedBundleGrossPrice, LensNondiscountedBundleGrossPrice, LensDiscountedBundleVatPrice, LensNondiscountedBundleVatPrice, AccessoriesDiscountedBundleGrossPrice, AccessoriesNondiscountedBundleGrossPrice, AccessoriesDiscountedBundleVatPrice, AccessoriesNondiscountedBundleVatPrice, Currency, LastUpdated, FulfilmentId, WriteOffDate, WriteOffType"));
            break;
        }while(j>0);


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // Validating values within the Report
        int	counter = 0, i=0;
        double grossamt = 0;
        double netamt = 0;
        double taxamt = 0;

        while(i<records.size())
        {
            if(records.get(i).contains(clientUser_id)){
                logger.info("if loop entered");
                if(sub_description.equalsIgnoreCase(testDataManager.getTestInputRegionData("subscriptionRequest.Description")))
                {	//to calculate the single payment amount
                    logger.info(records.get(i));
                    logger.info("The data is:"+records.get(i));
                    logger.info("first if verification");
                    grossamt = calculateAmount(customerType,"gross_amount");
                    netamt = calculateAmount(customerType,"net_amount");
                    taxamt = calculateAmount(customerType,"tax_amount");
                    netamt = Math.floor(netamt * 10) / 10;
                }
                else
                {	//to calculate the single payment amount for topup payment
                    grossamt = calculateAmount(customerType,"gross_amount");
                    grossamt = grossamt*3;
                    netamt = calculateAmount(customerType,"net_amount");
                    netamt = netamt*3;
                    taxamt = calculateAmount(customerType,"tax_amount");
                    taxamt = taxamt*3;
                    grossamt = Math.floor(grossamt * 100) / 100;
                }
                logger.info("first pack verification");
                taxamt = Math.floor(taxamt * 10) / 10;
                assertTrue(records.get(i).contains(String.valueOf(grossamt)));
                assertTrue(records.get(i).contains(String.valueOf(netamt)));
                assertTrue(records.get(i).replace(" ", "").contains("Completed"));
                assertTrue(records.get(i).contains(String.valueOf(taxamt)));
                assertTrue(records.get(i).contains(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
                assertTrue(records.get(i).contains(clientUser_id));
                assertTrue(records.get(i).contains(testDataManager.getTestInputRegionData("createCustomer.store_id")));
                assertTrue(records.get(i).contains("YES"));
                assertTrue(records.get(i).contains(payerTypeAPI));
                assertTrue(records.get(i).contains(testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod")));
                logger.info("if loop completed");
                if(nonLensMailOrderValue.equalsIgnoreCase("Yes")) {
                    logger.info("second if loop verification");
                    assertTrue(records.get(i).contains("YES"));
                }else {
                    assertTrue(records.get(i).contains("NO"));
                }
                assertTrue(records.get(i).contains(testDataManager.getTestInputRegionData("cartJsonBody.currency")));
                counter++;
                logger.info("if loop completed");
                break;

            }
            i++;}
        logger.info("completed");
        //assertTrue(counter>0);
    }
    public Double calculateAmount(String customerType, String amount)
    {
        double calcAmount;
        switch(customerType)
        {
            case "montlySolutionCustomer":
                calcAmount = Double.parseDouble(testDataManager.getTestInputRegionData("montlySolutionCustomer.totalLensPrice")) * 2 /3;
                break;
            case "montlyNoSolutionCustomer":
                calcAmount = Double.parseDouble(testDataManager.getTestInputRegionData("montlyNoSolutionCustomer.lensCost")) * 2 /3;
                break;
            case "Occasional":
                calcAmount = Double.parseDouble(testDataManager.getTestInputRegionData("Occasional.total_cost")) * 2 /3;
                break;
            case "PartTime":
                calcAmount = Double.parseDouble(testDataManager.getTestInputRegionData("PartTime.total_cost")) * 2 * 2 /3;
                break;
            default:
                calcAmount = Double.parseDouble(testDataManager.getTestInputRegionData("FullTime.total_cost"))*2;
                break;
        }
        return calcAmount;
    }

















































































}