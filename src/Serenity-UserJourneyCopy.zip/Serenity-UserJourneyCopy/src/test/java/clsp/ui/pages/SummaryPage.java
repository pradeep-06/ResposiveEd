package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class SummaryPage extends clspBase {

    protected static final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(SummaryPage.class);

    public static ArrayList<String> bankHoliday = new ArrayList<String>();
    public static ArrayList<String> PaymentSchedule = new ArrayList<String>();

    public static boolean flag;
    public static Date firstpaymentDateSum;


    @FindBy(xpath = "//ul[@class='sepa-address']")
    private WebElementFacade sepaAddress;

    @FindBy(xpath = "//div[@id='sepa-body']/div[1]/text()[1]")
    private WebElementFacade sepaCustName;

    @FindBy(xpath = "//td[@class='text-grey']//..//following-sibling::td[2]")
    private WebElementFacade summaryMonthlyLensPrice;

    @FindBy(xpath = "//td[contains(.,'Total (per month)')]//..//following-sibling::td")
    public WebElementFacade summaryTotalLensPrice;

    @FindBy(xpath = "//td[contains(text(),'Fulfilment')]//following-sibling::td")
    private WebElementFacade summaryFulfilmentType;

    @FindBy(xpath = "//td[contains(text(),'First regular payment date')]//following-sibling::td")
    public WebElementFacade summaryFirstPaymentDate;

    @FindBy(xpath = "//td[contains(text(),'Next delivery date')]//following-sibling::td")
    public WebElementFacade summaryNextDeliveryDate;

    @FindBy(xpath = "//td[contains(text(),'Final delivery date')]//following-sibling::td")
    public WebElementFacade summaryFinalDeliveryDate;

    @FindBy(xpath = "//td[contains(text(),' First regular payment date ')]//following-sibling::td")
    public WebElementFacade updatedPaymentDate;

    @FindBy(xpath = "//li[contains(.,'Account Holder')]")
    private WebElementFacade summaryAccHolderName;

    @FindBy(xpath = "//li[contains(.,'BIC') or contains(.,'Account Number:')]")
    private WebElementFacade summaryBICACC;

    @FindBy(xpath = "//li[contains(.,'IBAN') or contains(.,'Sort Code:')]")
    private WebElementFacade summaryIBANSortCode;

    @FindBy(xpath = "//header[contains(text(),'Delivery address')]//..//following-sibling::p[@class='address_info']")
    private WebElementFacade summaryDeliveryAddress;

    @FindBy(xpath = "//header[contains(text(),'Contact address')]//..//following-sibling::p[@class='address_info']")
    private WebElementFacade summaryContactAddress;

    @FindBy(xpath = "//button[contains(text(),'Print Summary')]")
    private WebElementFacade summaryPrintSummaryBtn;

    @FindBy(xpath = "//div[@class='modal-footer modal-footer-display']//button[contains(text(),'Print')]")
    private WebElementFacade printSchedulePrintBtn;

    @FindBy(xpath = "//button[contains(text(),'Cancel')]")
    private WebElementFacade printScheduleCancelBtn;

    @FindBy(xpath = "//tr[contains(.,'Promotions')]/td[2]")
    private WebElementFacade promotionNameSummaryPage;

    @FindBy(xpath = "//div[@id='customer-search-link']")
    private WebElementFacade summaryCustomerSearchLink;

    @FindBy(xpath = "//div[@class='col-sm-4 customer-name']")
    private WebElementFacade summaryCustomerName;

    @FindBy(xpath = "//div[@class='col-sm-3']//span[2]")
    private WebElementFacade summaryDOB;

    @FindBy(xpath = "//div[@id='header-store-details']//span[2]")
    private WebElementFacade storeName;

    @FindBy(xpath = "//div[@class='col-sm-5']//span[2]")
    private WebElementFacade custID;

    @FindBy(xpath = "//div[@class='customer-address']//p")
    private WebElementFacade summaryCustName;

    @FindBy(xpath = "//div[@class='customer-address']//ul")
    private WebElementFacade summaryCustAddress;

    @FindBy(xpath = "//div[@class='col-sm-4 printable table-height']//..//td[contains(.,'Fulfilment')]//..//following-sibling::td")
    private WebElementFacade summaryFulfilment;

    @FindBy(xpath = "//div[@class='col-sm-4 printable table-height']//..//td[contains(.,'First regular payment date')]//..//following-sibling::td")
    private WebElementFacade summaryFirstPayment;

    @FindBy(xpath = "//div[@class='col-sm-4 printable table-height']//..//td[contains(.,'Next delivery date')]//..//following-sibling::td")
    private WebElementFacade summaryNextDelDate;

    @FindBy(xpath = "//div[@class='col-sm-4 printable table-height']//..//td[contains(.,'Final delivery date')]//..//following-sibling::td")
    private WebElementFacade summaryFinalDelDate;

    @FindBy(xpath = "//div[@class='col-sm-4 printable table-height']//..//td[contains(.,'First pack fulfilment')]//..//following-sibling::td")
    private WebElementFacade summaryFirstPack;

    @FindBy(xpath = "//div[@class='col-sm-4 printable table-height']//..//td[contains(.,'Total (per month)')]//..//following-sibling::td")
    private WebElementFacade summaryTotalPerMonth;

    @FindBy(xpath = "//button[@class='close pull-right']")
    public WebElementFacade summaryCloseButton;

    @FindBy(xpath = "//td[contains(text(),'Promotions')]//following-sibling::td")
    public WebElementFacade summaryPromotions;

    @FindBy(xpath = "//div[@class = 'float-left low-start-offer-message']/span")
    public WebElementFacade summaryDiscountMessage;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header float-right')]/div/div[1]")
    public static List<WebElementFacade> paymentDate;



    public String getValidPaymentDate(Date selecteddt) {
        wantsToAddHolidayList(64);
        PaymentSchedule.clear();
        Date firstpaymentDate = selecteddt;
        Calendar c = Calendar.getInstance();
        c.setTime(firstpaymentDate);
        c.getTime();
        SimpleDateFormat tcs = new SimpleDateFormat("dd/MM/yyyy");
        String output = tcs.format(c.getTime());
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        String paymentDay = sdf.format(c.getTime());

        do{
            if(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")||isHoliday(output)==true){
                c.setTime(c.getTime());
                c.add(Calendar.DATE, 1);
                c.getTime();
                paymentDay = sdf.format(c.getTime());
                output = tcs.format(c.getTime());
                logger.info(output);
            }

        }while(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")||isHoliday(output)==true);

        firstpaymentDateSum = c.getTime();
        logger.info("FirstPAy: "+firstpaymentDateSum);
        logger.info("firstPayment Date: "+output);
        PaymentSchedule.add(output);

        return output;

    }
    public void wantsToAddHolidayList(int noOfHolidays) {
        bankHoliday.clear();
        for(int i=0; i<=noOfHolidays;i++) {
            bankHoliday.add(testDataManager.getTestInputRegionData("BankHoliday.Date"+i));
        }

    }
    public boolean isHoliday(String str) {
        flag = false;
        for(int i =1; i<=bankHoliday.size(); i++) {
            if((testDataManager.getTestInputRegionData("BankHoliday.Date"+i)).contains(str)) {
                flag = true;
                break;
            }
            else {
                flag = false;
            }
        }
        return flag;

    }

    public void verifySummaryPage(String customerID, String customerType, String customerName, String deliveryType, String fulfilmentType, String validFirstPayment) throws Exception {
        waitABit(4000);
        logger.info("Not Clicked Summary Print");
        clickOn(summaryPrintSummaryBtn);
        logger.info("Clicked Summary Print");
        final String custName =  customerName;
        final String DOB = testDataManager.getTestInputRegionData("CommonCustomerData.DOB");
        String custNbr = customerID;
        String strName = testDataManager.getTestInputRegionData("storeAddress.storeName");
        final String Address;
        final String contactAdd = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        assertElementContainsText(summaryFulfilmentType,deliveryType);
        final String accHolderName = customerName;
        final String BIC = testDataManager.getTestInputRegionData("payment.accNumbIc");
        final String IBAN = testDataManager.getTestInputRegionData("payment.accSortiBan");
        assertTrue(summaryCustomerName.getText().contains(custName.substring(2)));
        assertElementContainsText(summaryDOB,DOB);
        assertElementContainsText(custID,custNbr);
        assertElementContainsText(storeName,strName);
        if(customerType.contains("montlySolutionCustomer"))
        {
            assertElementContainsText(summaryTotalLensPrice,testDataManager.getTestInputRegionData(customerType+".totalLensPrice"));
        }
        else if(customerType.contains("montlySolutionCustomerSingleEye"))
        {
            assertElementContainsText(summaryTotalLensPrice,testDataManager.getTestInputRegionData(customerType+".totalLensPrice"));
        }
        else
        {
            assertElementContainsText(summaryTotalLensPrice,testDataManager.getTestInputRegionData(customerType+".lensCost"));
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate selectedDate = LocalDate.parse(validFirstPayment, formatter);
        if (selectedDate.getDayOfWeek() == DayOfWeek.SATURDAY){
            final String updatedDate = selectedDate.plusDays(2).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            assertElementContainsText(summaryFirstPaymentDate, updatedDate);
        } else if (selectedDate.getDayOfWeek()==DayOfWeek.SUNDAY) {
            final String updatedDate = selectedDate.plusDays(1).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            assertElementContainsText(summaryFirstPaymentDate, updatedDate);
        }else {
            assertElementContainsText(summaryFirstPaymentDate, validFirstPayment);
        }
        verifyDeliveryDateInSummaryPage(fulfilmentType);
        assertTrue(summaryAccHolderName.getText().contains(accHolderName));
       assertTrue(summaryBICACC.getText().contains(testDataManager.getTestInputRegionData("payment.accNumbIc")));
        if (testDataManager.getTestInputRegionData("address.country").equalsIgnoreCase("IE"))
        {
            assertElementContainsText(summaryIBANSortCode,testDataManager.getTestInputRegionData("payment.accSortiBan"));
        }
        else
        {
            assertElementContainsText(summaryIBANSortCode,testDataManager.getTestInputRegionData("payment.accSortiBan").replaceFirst("(\\d{2})(\\d{2})(\\d+)", "$1-$2-$3"));
        }

         if(deliveryType.equals("Deliver to Home")) {
            Address = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
            assertTrue(summaryDeliveryAddress.getText().replaceAll("[\r\n-]+", " ").contains(Address));
        }
        else if(deliveryType.equals("Deliver to Store"))
        {
            Address = testDataManager.getTestInputRegionData("CommonCustomerData.StoreAddress");
            assertTrue(Address.contains(summaryDeliveryAddress.getText().replaceAll("[\r\n-]+", " ")));
        }
        else {
             Address =	testDataManager.getTestInputRegionData("address.name")+" "+testDataManager.getTestInputRegionData("address.number")+" "+testDataManager.getTestInputRegionData("address.addressLine")+" "+testDataManager.getTestInputRegionData("address.town")+" "+testDataManager.getTestInputRegionData("address.county")+" "+testDataManager.getTestInputRegionData("address.postcode")+" "+testDataManager.getTestInputRegionData("address.countryName");
             assertTrue(summaryDeliveryAddress.getText().replaceAll("[\r\n-]+", " ").contains(Address));
         }
        assertTrue(contactAdd.contains(summaryContactAddress.getText().replaceAll("\n", " ")));
        clickOn(summaryPrintSummaryBtn);
        waitABit(15000); // This wait is to generate & download the PDF
    }
    public void verifyPrintSummary(String customerID,String customerType,String customerName,String deliveryType,String validFirstPayment) throws Exception {
        waitABit(4000);
        final String custName =  customerName;
        final String DOB = testDataManager.getTestInputRegionData("CommonCustomerData.DOB");
        String custNbr = customerID;
        String strName = testDataManager.getTestInputRegionData("storeAddress.storeName");
        final String Address;
        final String contactAdd = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        assertElementText(summaryFulfilmentType,deliveryType);
        final String accHolderName = customerName;
       final FileInputStream obj = new FileInputStream(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "TestData" +File.separator + "clsp"+ File.separator + "Downloads"+ File.separator + "schedule-"+testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID+".pdf");
        PDDocument objDoc =  PDDocument.load(obj);
        PDFTextStripper objPDFStrp = new PDFTextStripper();
        String pdfContent = objPDFStrp.getText(objDoc);
        assertTrue(pdfContent.contains(custName.substring(2)));
        assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData("address.storeNo")+"-"+custNbr));
        if(customerType.equals("montlySolutionCustomer"))
        {
            assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData(customerType+".totalLensPrice")));
        }
        else
        {
            assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData(customerType+".lensCost")));
        }

        assertTrue(pdfContent.contains(validFirstPayment));
    }

    public void verifyDeliveryDateInSummaryPage(String fulfilmentType) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        Date firstPayDate;
        switch (fulfilmentType) {
            case "NONE":
                firstPayDate = new SimpleDateFormat("dd/MM/yyyy").parse(SubscriptionPage.selectedPaymentDate);
                if (SubscriptionPage.accountType.equalsIgnoreCase("Prepay")) {
                    c.setTime(firstPayDate);
                    c.add(Calendar.MONTH, 2);
                    String nextDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryNextDeliveryDate, nextDelivery);
                    c.add(Calendar.YEAR, 2);
                    String finalDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryFinalDeliveryDate, finalDelivery);
                } else if (SubscriptionPage.accountType.equalsIgnoreCase("Postpay")) {
                    c.setTime(firstPayDate);
                    c.add(Calendar.MONTH, 1);
                    String nextDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryNextDeliveryDate, nextDelivery);
                    c.add(Calendar.YEAR, 2);
                    String finalDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryFinalDeliveryDate, finalDelivery);
                }
                break;
            case "Store":
                firstPayDate = new SimpleDateFormat("dd/MM/yyyy").parse(SubscriptionPage.selectedPaymentDate);
                if (SubscriptionPage.accountType.equalsIgnoreCase("Prepay")) {
                    c.setTime(firstPayDate);
                    c.add(Calendar.MONTH, 2);
                    String nextDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryNextDeliveryDate, nextDelivery);
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                    Date date = new Date();
                    String dDate = formatter.format(date);
                    Date deliveryDate = new SimpleDateFormat("dd/MM/yyyy").parse(dDate);
                    c.setTime(deliveryDate);
                    c.add(Calendar.YEAR, 2);
                    String finalDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryFinalDeliveryDate, finalDelivery);
                } else if (SubscriptionPage.accountType.equalsIgnoreCase("Postpay")) {
                    c.setTime(firstPayDate);
                    c.add(Calendar.MONTH, 3);
                    String nextDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryNextDeliveryDate, nextDelivery);
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                    Date date = new Date();
                    String dDate = formatter.format(date);
                    Date deliveryDate = new SimpleDateFormat("dd/MM/yyyy").parse(dDate);
                    c.setTime(deliveryDate);
                    c.add(Calendar.YEAR, 2);
                    String finalDelivery = sdf.format(c.getTime());
                    assertElementContainsText(summaryFinalDeliveryDate, finalDelivery);
                }
                break;
            case "Lensmail (LOL)":

                if (SubscriptionPage.accountType.equalsIgnoreCase("Prepay")) {
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                    Date date = new Date();
                    String dDate = formatter.format(date);
                    Date nextDelivery = new SimpleDateFormat("dd/MM/yyyy").parse(dDate);
                    c.setTime(nextDelivery);
                    String nextDeliveryDate = sdf.format(c.getTime());
                    logger.info(summaryNextDeliveryDate.getText());
                    logger.info(nextDeliveryDate);
                    assertElementContainsText(summaryNextDeliveryDate, nextDeliveryDate);
                    c.add(Calendar.YEAR, 2);
                    String finalDelivery = sdf.format(c.getTime());
                    logger.info(summaryFinalDeliveryDate.getText());
                    logger.info(finalDelivery);
                    assertElementContainsText(summaryFinalDeliveryDate, finalDelivery);
                    logger.info("executed");
                }
        }
    }

    public void verifyPrintSummary(String customerID,String customerName) throws Exception {
        final String custName = customerName;
        final String customerAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
        final String storeAddress = testDataManager.getTestInputRegionData("CommonCustomerData.StoreAddress");
        final String storeUserName = testDataManager.getTestInputRegionData("CommonCustomerData.StoreUser");
        ArrayList<String> PaymentOnUI = new ArrayList<String>();
        final String nextDelDate = summaryNextDeliveryDate.getText();
        logger.info("nextDelDate:"+nextDelDate);
        final String finalDelDate = summaryFinalDeliveryDate.getText();
        logger.info("finalDelDate:"+finalDelDate);
        final  String firstPayDate = updatedPaymentDate.getText();
        logger.info("firstPayDate:"+firstPayDate);

        final FileInputStream obj = new FileInputStream(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "TestData" +File.separator + "clsp"+ File.separator + "Downloads"+ File.separator + "schedule-"+testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID+".pdf");
        PDDocument objDoc =  PDDocument.load(obj);
        PDFTextStripper objPDFStrp = new PDFTextStripper();
        String pdfContent = objPDFStrp.getText(objDoc);
        final String BIC = testDataManager.getTestInputRegionData("payment.accNumbIc");
        final String IBAN = testDataManager.getTestInputRegionData("payment.accSortiBan");
        String selectedPaymentDate = updatedPaymentDate.getText();
        assert(pdfContent.contains("First regular payment date "+selectedPaymentDate));
        assertTrue(pdfContent.contains(custName));
        assertTrue(pdfContent.contains(customerID));
        logger.info("customerAddress:"+customerAddress);

        //Verify Summary
        if(pdfContent.contains("Cancelled"))
        {
            assertTrue(pdfContent.contains("N/A"));
        }
        else
        {
            assertTrue(pdfContent.contains(firstPayDate));
        }
        assertTrue(pdfContent.contains(nextDelDate));
        assertTrue(pdfContent.contains(finalDelDate));
    }
    public void getNextPaymentDate(Date selectedate) {
        String output1="";
        for (int j=1;j<paymentDate.size();j++) {

            Calendar c = Calendar.getInstance();
            c.setTime(selectedate);
            int dateOfMonth1 = c.get(Calendar.DAY_OF_MONTH);
            logger.info("day1 "+dateOfMonth1);
            c.add(Calendar.MONTH, j);
            int dateOfMonth2 = c.get(Calendar.DAY_OF_MONTH);
            logger.info("day2 "+dateOfMonth2);
            if(dateOfMonth1!=dateOfMonth2) {
                c.add(Calendar.DATE, 1);
            }
            logger.info("The refernce holding date before adding a month" +c.getTime());

            c.getTime();

            SimpleDateFormat fpd = new SimpleDateFormat("EEEEE, MMMMM dd, yyyy");
            String paymentDt = fpd.format(c.getTime());
            SimpleDateFormat tcs = new SimpleDateFormat("dd/MM/yyyy");
            String output = tcs.format(c.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
            String paymentDay = sdf.format(c.getTime());
            do{
                if(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")||isHoliday(output)==true){
                    c.setTime(c.getTime());
                    c.add(Calendar.DATE, 1);
                    c.getTime();
                    paymentDay = sdf.format(c.getTime());
                    paymentDt = fpd.format(c.getTime());
                    output = tcs.format(c.getTime());
                }

            }while(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")||isHoliday(output)==true);
            PaymentSchedule.add(output);
            output1=output;
        }
    }

    public void getNextPaymentDateAfterSecondPaymentDateEdit(Date selecteddt) {

        logger.info("The Payment Date in array is:" +PaymentSchedule);

        for (int j=2;j<paymentDate.size();j++) {

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(selecteddt);
            final int dateOfMonth1 = calendar.get(Calendar.DAY_OF_MONTH);
            logger.info("day1 "+dateOfMonth1);
            calendar.add(Calendar.MONTH, j-1);
            int dateOfMonth2 = calendar.get(Calendar.DAY_OF_MONTH);
            logger.info("day2 "+dateOfMonth2);
            if(dateOfMonth1!=dateOfMonth2) {
                calendar.add(Calendar.DATE, 1);
                logger.info("the dates are not matching");
            }
            logger.info("The refernce holding date before adding a month" +calendar.getTime());
            calendar.getTime();

            SimpleDateFormat format = new SimpleDateFormat("EEEEE, MMMMM dd, yyyy");
            String paymentDt = format.format(calendar.getTime());
            SimpleDateFormat tcs = new SimpleDateFormat("dd/MM/yyyy");
            String output = tcs.format(calendar.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
            String paymentDay = sdf.format(calendar.getTime());

            do{
                if(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")|| isHoliday(output)){
                    //c.setTime(new Date());
                    calendar.setTime(calendar.getTime());
                    calendar.add(Calendar.DATE, 1);
                    calendar.getTime();
                    paymentDay = sdf.format(calendar.getTime());
                    //logger.info(paymentDay);
                    paymentDt = format.format(calendar.getTime());
                    //logger.info(paymentDt);
                    output = tcs.format(calendar.getTime());
                }

            }while(paymentDay.equals("Saturday")||paymentDay.equals("Sunday")|| isHoliday(output));
            logger.info("Adding to payment schedule:"+output);
            PaymentSchedule.add(output);
        }

    }
    public void verifyDiscountOnSummaryPage(String discountType, String customerType) {
        waitFor(summaryPromotions);
        assertElementText(summaryPromotions,discountType);
        clickElement(summaryPrintSummaryBtn);
        assertElementText(summaryDiscountMessage,"OFFER [ "+discountType+" ] APPLIED");
    }




}
