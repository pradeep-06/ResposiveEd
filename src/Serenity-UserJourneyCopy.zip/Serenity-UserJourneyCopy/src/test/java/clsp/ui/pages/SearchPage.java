package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import Framework.api.request.APIRequests;
import Framework.api.request.Headers;
import Framework.extensions.StafUtils;
import clsp.api.extentions.clspApiBase;
import clsp.ui.extentions.clspBase;
import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.Message;
import com.mailosaur.models.MessageSearchParams;
import com.mailosaur.models.SearchCriteria;
import io.restassured.response.Response;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class SearchPage extends clspBase {

    protected static final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(SearchPage.class);
    public clspApiBase clspApiRequest = new clspApiBase();
    public APIRequests apiRequests = new APIRequests();
    private static final Headers header = new Headers();
    final MailosaurClient mailosaur = new MailosaurClient(testDataManager.getTestInputCommonData("mailosaurInformation.apiKey"));
    final SearchCriteria criteria = new SearchCriteria();

    static final String serverDomain="bxd0oa0f.mailosaur.net";
    private final Random random = new Random();

    final static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy.MM.dd.HH.mm.ss");


    public static String account_id;
    private static String acc_reference;

    private static String address_reference;
    public String add_id;
    private static String cart_id;

    public  String client_user_id = "4"+getNewUserID();
    public static String lastName = "AutoTest";
    public String xApiKey=testDataManager.getTestInputCommonData("url.apiKeyCDG");
    public String xClientId=testDataManager.getTestInputCommonData("mppHeaders.clientId");
    public String xClientPassword=testDataManager.getTestInputCommonData("mppHeaders.clientPassword");
    public String xVersion=testDataManager.getTestInputCommonData("mppHeaders.versionNumber");

    public static String customerID;
    public static String custType="Test";
    public static String deliveryDateAPI;
    public String emailID = generateNewCustomerEmail();
    public static String email;
    public static String firstName = StafUtils.getFirstName(6);
    public static String title;
    public static String firstPackStatus;
    public static String getFirstPaymentDateAPI;
    public static String nextPaymentAmt="";
    public static String nextPaymentDate;
    public static String nextDeliveryDate;
    public static String nonLensMailOrderValue;
    public static String supplierNotificationDate;

    public static String orderLineType;

    public static String orderId;
    public static String packRef;
    public static String packRef_2;
    public static String packRef_3;
    public static String paymentStatus;
    public static String paymentDateAPI;
    public static String secondPaymentDate;
    public static String thirdPaymentDate;
    public static String paymentRef1;
    public static String paymentRef2;
    public static String paymentRef3;
    public static String payerTypeAPI;
    public static String paymentAmount;
    public static String secondPackSecondPayment;
    public static String secondPackThirdPayment;

    public static String secondPaymentAmount;
    public static String thirdPaymentAmount;
    public static String secondPackAmount;
    public static String secondPackDelivery;
    public static String secondPackPayment;
    public static String sub_description;
    private Response response;
    public static String store_id;
    public static String subRef;
    public static String subExpDate;
    public static String total_cost;
    private static Message message;
    private static String messageBody;
    public Double nextPrepayPaymentAmt=0.00;
    public Double nextPostpayPaymentAmt=0.00;


    @FindBy(xpath = "//button[@class='btn-secondary'][text()='Create new customer']")
    public WebElementFacade createNewCustomerButton;

    @FindBy(id = "customer-id")
    public WebElementFacade searchCustID;

    @FindBy(xpath = "//button[@class='button clear-all-search-fields']")
    public WebElementFacade clearSearchfieldsButton;

    @FindBy(xpath = "//input[@id='customer-id']")
    public WebElementFacade searchCustomerID;

    @FindBy(xpath = "//button[contains(@type,'submit')]")
    private WebElementFacade searchCustomerBtn;

    @FindBy(xpath = "//button[contains(text(),'Select')]")
    private WebElementFacade customerSelectBtn;

    @FindBy(xpath = "//button[@class='pull-right']")
    private WebElementFacade selectButton;

    @FindBy(xpath = "//h1[contains(text(),'Customer Dashboard')]")
    private WebElementFacade customerDashboardHeader;

    @FindBy(xpath = "//input[@id='customer-surname']")
    private WebElementFacade searchLastName;

    @FindBy(xpath = "//th[text()='Name']//..//..//following-sibling::tbody//tr")
    private WebElementFacade customerIdInTable;

    @FindBy(xpath = "//div[@class='pipe-separate-children']//span [contains(.,'Payment')]") //Xpath in 46
    public List<WebElement> packPaymentList;

    public static ArrayList<String> deliveryDate = new ArrayList<String>();
    public static ArrayList<String> packStatus = new ArrayList<String>();

    //Generate client user id method. To be invoked if cust creation files due to existing cust ID
    public static String getNewUserID() {

        final long varTime = System.currentTimeMillis();
        final double randomMath = Math.random() * 1000;
        final long multi = (long) (varTime * randomMath);
        final String s = multi + "";
        final String subStr = s.substring(0, 6);
        return subStr;
    }
    public static String generateNewCustomerEmail() {

        LocalDateTime datetime = LocalDateTime.now();

        return "STAF2.".concat(formatter.format(datetime)).concat("@" + serverDomain);
    }


    public void createDailyCust(String dailyType,int quantity,int status, String payerType){
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType,quantity);
        userMakesPayment();
        userCreatesSubscriptionUsingCDG(payerType);
        userGetsTheSubscriptionDetails(0);
    }
    public void userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(String dailyType, int quantity, int status, int newSubscriptionStatus) {
        userRequestsForNewCustomerToBeCreatedOnCDGWithAlternatePayer(status);
        userTriesToAddACartForDailyCustomer(dailyType, quantity);
        //userRetrievesAddressForCustomerUsingAccountID(status);
        userMakesPayment();
        userCreatedNonLensMailerSubscriptionUsingMPP(newSubscriptionStatus);
        userGetsTheSubscriptionDetails(0);
    }
    public void userRequestsForNewCustomerToBeCreatedOnCDGWithAlternatePayer(int status) {
        final String endpoint=testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG");
        final String response = apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCustAltPayerJsonBodyCDG(client_user_id,firstName,lastName,emailID));
        if(response.contains("Account with that ClientUserId already exists")){
            userReattemptsToCreateAccountWithAlternatePayer(status);
        }else{
            captureCustomerAccountDetails();

        }

    }
    public void userReattemptsToCreateAccountWithAlternatePayer(int status) {
        client_user_id = "4"+getNewUserID();
        final String endpoint=testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCustAltPayerJsonBodyCDG(client_user_id,firstName,lastName,emailID));
        account_id = apiRequests.getValueFormJsonResponseKey("account.account_id");
        client_user_id = apiRequests.getValueFormJsonResponseKey("client_user_id");
        acc_reference =  apiRequests.getValueFormJsonResponseKey("account.resource_reference");
        store_id = apiRequests.getValueFormJsonResponseKey("mpp_store_id");

    }
    public void createDailyCustPaymentCompleted(String dailyType,int quantity,int status){
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType,quantity);
        userMakesPayment();
        userCreatesSameDayPaymentSubcriptionUsingMPP(status, "PRE","");
        waitABit(150000);
        userGetsTheSubscriptionDetails(0);
    }
    public void userCreatesPostPayMonthlyNoSolutionSubscriptionPaymentCompleted(int status) {

        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userCreatesMonthlyCart("solution",status);
        userMakesPayment();
        userCreatesSameDayPaymentSubcriptionUsingMPP(status, "POST"," ");
        waitABit(150000);
        userGetsTheSubscriptionDetails(0);
    }
    public void createMonthlySolutionCust(int status, String payerType){
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userCreatesMonthlyCart("solution",status);
        userMakesPayment();
        userCreatesSubscriptionUsingCDG(payerType);
        userGetsTheSubscriptionDetails(0);
    }

    //creating customer with nosolution and firstpack
    public void createMonthlyNoSolutionCust(int status, String payerType){
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userCreatesMonthlyCart("solution",status);
        userMakesPayment();
        userCreatesSubscriptionUsingCDG(payerType);
        userGetsTheSubscriptionDetails(0);
    }

    public void userRequestsForNewCustomerToBeCreatedOnCDG(int status) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG");
        final String response = apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCustomerJsonBodyCDG(client_user_id,firstName,lastName,emailID));
        if(response.contains("Account with that ClientUserId already exists") || response.contains("The email is already in use"))
        {
            userReattemptsAccountCreation(endpoint);
        }else{
            captureCustomerAccountDetails();
        }
    }




    public void userReattemptsAccountCreation(String endpoint) {
        client_user_id = "5"+getNewUserID();
        emailID = "auto"+emailID;
        logger.info("customers id with 5 is:" +client_user_id);
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCustomerJsonBodyCDG(client_user_id,firstName,lastName,emailID));
        captureCustomerAccountDetails();

    }

    public void captureCustomerAccountDetails(){
        account_id = apiRequests.getValueFormJsonResponseKey("account.account_id");
        client_user_id = apiRequests.getValueFormJsonResponseKey("client_user_id");
        acc_reference =  apiRequests.getValueFormJsonResponseKey("account.resource_reference");
        store_id = apiRequests.getValueFormJsonResponseKey("mpp_store_id");
        emailID = apiRequests.getValueFormJsonResponseKey("customer_contact_details.email");
        add_id = apiRequests.getValueFormJsonResponseKey("address_book[0].id");
        subRef= apiRequests.getValueFormJsonResponseKey("subscriptions[0].id");
        customerID= client_user_id;
        email = emailID;

        logger.info("subID is"+ subRef);
        logger.info("The account ID is:" +account_id);
        logger.info("The client user ID is:" +client_user_id);
        logger.info("The account reference is:" +acc_reference);
        logger.info("Store Id : "+store_id);
        logger.info("Email Id : "+emailID);
        assertTrue(account_id.length()>4);

    }
    public void launchContactCenterCustomerSearchPage(){
        openUrl(testDataManager.getTestInputCommonData("url.customerCenterPageUrl"));
    }
    public void launchStoreContactCenterCustomerPage(){
        openUrl(testDataManager.getTestInputCommonData("url.storeUserContactCenterPageUrl"));
    }

    public void findCustomerByID(String customerID){
        searchCustID.waitUntilVisible().waitUntilEnabled();
        searchCustID.clear();
        setText(searchCustID,testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID);
        searchCustomerBtn.waitUntilClickable();
        clickElement(searchCustomerBtn);
        waitFor(customerSelectBtn);
        customerSelectBtn.waitUntilClickable();
        clickElement(customerSelectBtn);
        waitFor(customerDashboardHeader);

    }

    //searching customer by existing customer id got from api
    public void findCustomerByClientID() {
        waitFor(searchCustID);
        searchCustID.clear();
        setText(searchCustID,customerID);
        waitFor(searchCustomerBtn);
        clickElementSuccess(searchCustomerBtn);
        clickElement(customerSelectBtn);

    }
    public void searchExistingCustomerUsingCorrectSurname() {
        final String lastname = "AutoTest";
        searchLastName.clear();
        setText(searchLastName, lastname);
        searchCustID.clear();
        setText(searchCustID,customerID);
        waitFor(searchCustomerBtn);
        clickElementSuccess(searchCustomerBtn);
    }
    public void listOfCustomersWhoHaveMatchingDetails() {
        assertTrue(customerIdInTable.isDisplayed());

        try {
            final String customerId = customerIdInTable.getText();
            if(customerId.equals(customerID)) {
                logger.info("Customer id = "+customerID);
                clickOn(selectButton);
                waitFor(customerDashboardHeader);
            }

        }
        catch(IndexOutOfBoundsException ex) {
            ex.printStackTrace();
        }
    }

    public void userTriesToAddACartForDailyCustomer(String dailyType,int quantity) {

        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.cartEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getCartJsonBodyCDGDaily(dailyType,quantity));
        custType = dailyType;
        cart_id = apiRequests.getValueFormJsonResponseKey("id");
        total_cost =  apiRequests.getValueFormJsonResponseKey("total_cost");
    }




    public void userMakesPayment() {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.paymentEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getpaymentBody("payment", firstName));
        if(testDataManager.getTestInputRegionData("subscriptionRequest.PaymentMethod").equalsIgnoreCase("SEPA"))
            PaymentPage.mandateReference =  apiRequests.getValueFormJsonResponseKey("sepa[0].reference"); //According to 46 change
        else
            PaymentPage.mandateReference =  apiRequests.getValueFormJsonResponseKey("bacs[0].reference");
        logger.info("The customer ID:"+client_user_id+"has Mandate reference:"+PaymentPage.mandateReference);

    }

    public void userCreatesSameDayPaymentSubcriptionUsingMPP(int status, String payerType, String discountType ) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonESBURI")+"/api/accounts/"+acc_reference+"/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestFirstPaymentInFlightOrCompleted(payerType, discountType, "No",0,cart_id,add_id,custType));
    }
    public void userCreatesSameDayPaymentSubscription(int status, String payerType, String discountType ) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonESBURI")+"/api/accounts/"+acc_reference.substring(1,19)+"/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestFirstPaymentInFlightOrCompleted(payerType, discountType, "No",0,cart_id.substring(1,19),add_id,custType));
    }

    public void userGetsTheSubscriptionDetails(int subId)  {
        //Passing subId 0 for first subscription and 1 for second subscription
        final String endPointURI = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions";
        apiRequests.GETMethodWithXApiHeaders(endPointURI,xApiKey);
        subRef= apiRequests.getValueFormJsonResponseKey("subscriptions["+subId+"].id");
        logger.info("subID is"+ subRef);
        //assertTrue(subRef.length()>4);
        subExpDate= apiRequests.getValueFormJsonResponseKey("subscriptions[0].expiry_date");
        nextPaymentAmt = apiRequests.getValueFormJsonResponseKey("subscriptions[0].next_payment_amount");
        logger.info("nextPaymentAmt:"+nextPaymentAmt);
        nextPaymentDate = apiRequests.getValueFormJsonResponseKey("subscriptions[0].next_payment");
        nextDeliveryDate = apiRequests.getValueFormJsonResponseKey("subscriptions[0].next_delivery");

        final String endpointSubRef = endPointURI+"/"+subRef;
        apiRequests.GETMethodWithXApiHeaders(endpointSubRef,testDataManager.getTestInputCommonData("url.apiKeyCDG"));
        packRef = apiRequests.getValueFormJsonResponseKey("packs[0].id");
        packRef_2 = apiRequests.getValueFormJsonResponseKey("packs[1].id");
        packRef_3 = apiRequests.getValueFormJsonResponseKey("packs[2].id");
        paymentRef1 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].id");
        paymentRef2 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[1].id");
        paymentRef3 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].id");

        getFirstPaymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");

        paymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");
        secondPaymentDate = apiRequests.getValueFormJsonResponseKey("packs[0].payments[1].payment_date");
        thirdPaymentDate = apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].payment_date");
        deliveryDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].delivery_date");

        firstPackStatus = apiRequests.getValueFormJsonResponseKey("packs[0].status");
        payerTypeAPI = apiRequests.getValueFormJsonResponseKey("type");

        nonLensMailOrderValue = apiRequests.getValueFormJsonResponseKey("packs[0].non_lens_mail_order");
        orderLineType = apiRequests.getValueFormJsonResponseKey("packs[0].order_line_type");
        orderId = apiRequests.getValueFormJsonResponseKey("packs[0].order_id");
        supplierNotificationDate = apiRequests.getValueFormJsonResponseKey("packs[0].supplier_notification_date");
        paymentStatus = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].status");
        sub_description = apiRequests.getValueFormJsonResponseKey("description");
        paymentAmount = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].gross_amount");
        secondPaymentAmount = apiRequests.getValueFormJsonResponseKey("packs[0].payments[1].gross_amount");
        thirdPaymentAmount = apiRequests.getValueFormJsonResponseKey("packs[0].payments[1].gross_amount");
        secondPackAmount = apiRequests.getValueFormJsonResponseKey("packs[1].payments[0].gross_amount");
        secondPackSecondPayment =apiRequests.getValueFormJsonResponseKey("packs[1].payments[1].gross_amount");
        secondPackThirdPayment = apiRequests.getValueFormJsonResponseKey("packs[1].payments[2].gross_amount");
        secondPackPayment = apiRequests.getValueFormJsonResponseKey("packs[1].payments[0].payment_date");
        secondPackDelivery = apiRequests.getValueFormJsonResponseKey("packs[1].delivery_date");
    }

    public void userCreatesSubscriptionUsingCDG(String payerType) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions";
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getSubscriptionRequestCDGBody(payerType,acc_reference,cart_id,add_id));
    }


    public void userCreatesMonthlyCart(String solutionType, int status) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+testDataManager.getTestInputCommonData("url.cartEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getMonthlyCartJsonBodyCDG(solutionType,custType));
        cart_id = apiRequests.getValueFormJsonResponseKey("id");
    }


    public void deleteCustomer(String customerID, int status) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonMPPURI")+"/rest/api/accounts";
        apiRequests.GETMethodWithQueryParam(endPoint,"clientUserId",customerID,"surname","Auto",clspApiRequest.getMPPHeaders());
        logger.info("accreference is" + acc_reference);
        acc_reference = apiRequests.getValueFormJsonResponseKey("[0].accountReference");
        deleteCustomer(status);
    }

    public void deleteCustomer(int status){
        final String endpoint = testDataManager.getTestInputCommonData("url.commonMPPURI")+"/rest/api/accounts/"+acc_reference;
        logger.info("The Delete endpoint is:"+endpoint);
        apiRequests.DELETEMethodWithSpecificHeaders(endpoint,clspApiRequest.getHeadersForRemoveCust());
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }
    public void UpdatesPackStatusToGivenStatus(int status, String customerID, String packStatus) {
        userGetsSubscriptionDetailsForCustomerID(customerID);
        userUpdatesPackStatus(packStatus,status);
    }
    public void userGetsSubscriptionDetailsForCustomerID(String customerID) {
        final String custID = customerID.trim();
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+ testDataManager.getTestInputCommonData("url.searchCustomerEndPoint");
        apiRequests.GETMethodWithQueryParam(endPoint,"customer_id", testDataManager.getTestInputRegionData("address.storeNo")+"-"+custID,"records_per_page","50","page_number", "1",xApiKey);
        acc_reference = apiRequests.getValueFormJsonResponseKey("customers.account.resource_reference");
        logger.info("acc_reference is:"+acc_reference);
        client_user_id = apiRequests.getValueFormJsonResponseKey("client_user_id");
        SearchPage.customerID=customerID;
        emailID = apiRequests.getValueFormJsonResponseKey("customer_contact_details.email");
        firstName = apiRequests.getValueFormJsonResponseKey("first_name");
        lastName= apiRequests.getValueFormJsonResponseKey("last_name");
        title= apiRequests.getValueFormJsonResponseKey("title");
        final String endpointSubscriptions = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference.substring(1,19)+"/subscriptions";
        logger.info(endpointSubscriptions);
        apiRequests.GETMethodWithXApiHeaders(endpointSubscriptions,xApiKey);
        //assertTrue(apiRequests.verifyResponseStatusCode()==status);
        subRef= apiRequests.getValueFormJsonResponseKey("subscriptions.id");
        subExpDate= apiRequests.getValueFormJsonResponseKey("subscriptions.expiry_date");
        logger.info("Response From Json:"+subRef);
        cart_id = apiRequests.getValueFormJsonResponseKey("subscriptions.cart.id");
        logger.info("cartID is" + cart_id);
        String endpointSubRef = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference.substring(1,19)+"/subscriptions/"+subRef.substring(1,19);
        logger.info(endpointSubRef);
        apiRequests.GETMethodWithXApiHeaders(endpointSubRef,testDataManager.getTestInputCommonData("url.apiKeyCDG"));

        //assertTrue(apiRequests.verifyResponseStatusCode()==status);
        add_id = apiRequests.getValueFormJsonResponseKey("packs[0].delivery_address_id");
        logger.info("add_id is" + add_id);
        logger.info("Pack Referenace Noted");
        packRef = apiRequests.getValueFormJsonResponseKey("packs[0].id");
        logger.info("Response From Json:"+packRef);
        packRef_2 = apiRequests.getValueFormJsonResponseKey("packs[1].id");
        logger.info("Pack 2 Referance:"+packRef_2);
        paymentRef1 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].id");
        paymentRef2 = apiRequests.getValueFormJsonResponseKey("packs[0].payments[1].id");
        paymentRef3 =apiRequests.getValueFormJsonResponseKey("packs[0].payments[2].id") ;
        getFirstPaymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");

        firstPackStatus = apiRequests.getValueFormJsonResponseKey("packs[0].status");
        paymentDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].payments[0].payment_date");
        deliveryDateAPI = apiRequests.getValueFormJsonResponseKey("packs[0].delivery_date");
    }
    public void packReference(String packs, int status) {
        switch (packs) {
            case "First":
                packRef = apiRequests.getValueFormJsonResponseKey("packs[0].id");
                logger.info("pack reference0:" + packRef);
                break;

            case "Second":
                packRef = apiRequests.getValueFormJsonResponseKey("packs[1].id");
                logger.info("pack reference1:" + packRef);
                break;
        }
    }
    public void userUpdatesPackStatus(String packStatus, int status) {
        if(acc_reference.contains("["))
            acc_reference = acc_reference.substring(1,acc_reference.length()-1);
        if(subRef.contains("["))
            subRef = subRef.substring(1,subRef.length()-1);
        if(packRef.contains("["))
            packRef = packRef.substring(1,packRef.length()-1);
        logger.info(testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions/"+subRef+"/packs/"+packRef);
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions/"+subRef+"/packs/"+packRef;
        apiRequests.PUTMethodWithXApiHeaders(endpoint,xApiKey,updatePackStatusToGiven(packStatus));
        final String expStatus = Integer.toString(status);
        logger.info(expStatus);
       /* final String actualStatus = Integer.toString(response.getStatusCode());
        logger.info(actualStatus);
        logger.info(String.valueOf(response.getStatusCode()));
        assertTrue(expStatus.equals(actualStatus));*/
    }
    public void userUpdatesSecondPackStatus(String packStatus, int status) {
        logger.info(testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions/"+subRef+"/packs/");
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions/"+subRef+"/packs/"+packRef_2;
        apiRequests.PUTMethodWithXApiHeaders(endpoint,xApiKey,updatePackStatusToGiven(packStatus));
        final String expStatus = Integer.toString(status);
        logger.info(expStatus);
       /* final String actualStatus = Integer.toString(response.getStatusCode());
        logger.info(actualStatus);
        logger.info(String.valueOf(response.getStatusCode()));
        assertTrue(expStatus.equals(actualStatus));*/
    }
    private Map<String, ?> updatePackStatusToGiven(String packStatus) {
        JSONObject requestSubscriptionBody = new JSONObject();
        requestSubscriptionBody.put("status", packStatus);
        requestSubscriptionBody.put("collected_in_store", false);
        return requestSubscriptionBody.toMap();
    }
    public void userTriesToAddACart() {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+ testDataManager.getTestInputCommonData("url.cartEndPoint");
        apiRequests.POSTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getMonthlyCartJsonBodyCDG("solution",custType));
        cart_id = apiRequests.getValueFormJsonResponseKey("id");
    }
    public void userRetrievesAddressForCustomerUsingAccountID(int status){

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/"+add_id;
        logger.info(endPoint);
        apiRequests.PUTMethodWithXApiHeaders(endPoint,xApiKey,clspApiRequest.getMonthlyCartJsonBodyCDG("solution",custType));
        add_id = apiRequests.getValueFormJsonResponseKey("customer_contact_details.default_address.id");
    }
    public void userCreatesDailyCustomerSubscriptionWithCompletedPacks(String dailyType, int quantity, int status, String payerType) {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType, quantity);
        userMakesPayment();
        userCreatesSubscriptionWithOnePackUsingCDG("PRE");
    }


    public void userCreatesSubscriptionWithOnePackUsingCDG(String payerType) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"accounts/"+acc_reference+"/subscriptions";

        apiRequests.POSTMethodWithXApiHeaders(endpoint,xApiKey,clspApiRequest.getSubscriptionRequestWithRequiredPackUsingCDGBody(3,payerType,acc_reference,cart_id,add_id));

    }
    public void createMultipleSubscriptionForDailyCustomer(String dailyType, int quantity, int status, String payerType) {
        userCreatesDailyCustomerSubscription(dailyType, quantity, status, payerType);
        userCreatesSubscriptionUsingMPPWithFirstPack();
    }

    public void userCreatesDailyCustomerSubscription(String dailyType, int quantity, int status, String payerType) {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType, quantity);
        userMakesPayment();
        userCreatesSubscriptionUsingCDG(payerType);
        userGetsTheSubscriptionDetails(0);
    }
    public void userCreatesSubscriptionUsingMPPWithFirstPack() {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonESBURI")+"/api/accounts/"+acc_reference+"/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endPoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestMPPBodyWithFirstPack(cart_id,add_id));
    }
    public void userCreatesNewCustomerWithMonthlyNoSolutionSubscriptionOnBankHoliday(int status) throws  Exception {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userCreatesMonthlyCart("No solution",status);
        userMakesPayment();
        userCreatedSubscriptionWithPaymentDateOnBankHoliday();
        userGetsTheSubscriptionDetails(0);

    }
    public void userCreatedSubscriptionWithPaymentDateOnBankHoliday() throws Exception {

        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"api/accounts/"+acc_reference+"/subscriptions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestWithPaymentOnBankHoliday(cart_id,add_id,acc_reference));

    }
    public void userUpdatesTheSecondPackStatus(String packStatus, int status) {
        userGetsTheSubscriptionDetails(0);
        userUpdatesSecondPackStatusToGivenStatus(packStatus ,status);
    }
    public void userUpdatesSecondPackStatusToGivenStatus(String packStatus, int status){

        userUpdatesPackStatus(packStatus, status);

    }
    public void userCreatesMonthlyNoSolutionBankHolidayPostPay(int status) throws Exception {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userCreatesMonthlyCart("No solution",status);
        userMakesPayment();
        userCreatedSubscriptionUsingCDGWithPaymentDateOnBankHolidayPostPay();
        userGetsTheSubscriptionDetails(0);
    }
    public void userCreatedSubscriptionUsingCDGWithPaymentDateOnBankHolidayPostPay() throws Exception {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+"api/accounts/"+acc_reference+"/subscriptions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestCDGBodyWithPaymentOnBankHolidayPostPay(cart_id,add_id,acc_reference));

    }
    public void userCreatePostPayMonthlySolutionAndFirstPaymentInFlight(int status) {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACart();
        userMakesPayment();
        userCreatesSubscriptionWithFirstPaymentInFlightUsingMPP("POST");
        userGetsTheSubscriptionDetails(0);
    }
    public void userCreatesSubscriptionWithFirstPaymentInFlightUsingMPP( String payerType) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonESBURI")+"/api/accounts/"+acc_reference+"/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endpoint,xClientId,xClientPassword,xVersion,clspApiRequest.getSubscriptionRequestFirstPaymentInFlightOrCompleted(payerType," ", "No",0,cart_id,add_id,custType));


    }
    public void userCreatesDailyNonLensMailerCustomerSubscriptionPostPay(String dailyType, int quantity, int status, int newSubscriptionStatus) {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType, quantity);
        userMakesPayment();
        userCreatedNonLensMailerSubscriptionUsingMPP(newSubscriptionStatus);
        userGetsTheSubscriptionDetails(0);
    }

    public void userCreatedNonLensMailerSubscriptionUsingMPP(int status) {
        final String endPoint = testDataManager.getTestInputCommonData("url.commonESBURI") + "/api/accounts/" + acc_reference + "/payment-instructions";
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endPoint, xClientId,xClientPassword,xVersion, clspApiRequest.getNonLensMailerSubscriptionRequestMPPBody(cart_id, add_id));
    }
    public void userGetsSubscriptionDetailsAndUpdatesPackStatusToDispatch(String packStatus,int status) {
        userGetsTheSubscriptionDetails(1);
        userUpdatesPackStatus(packStatus,status);
    }
    public void userUpdatesFirstPackDueDateToTodayDate(int status, String pack) {
        userGetsTheSubscriptionDetails(0);
        switch(pack)
        {
            case "First":
                logger.info("First");
                userUpdatesPackDueDateToTodayDate(packRef);
                break;
            case "Second":
                userUpdatesPackDueDateToTodayDate(packRef_2);
                break;
            case "Third":
                userUpdatesPackDueDateToTodayDate(packRef_3);
                break;
        }
        userGetsTheSubscriptionDetails(0);
    }
    public void userUpdatesPackDueDateToTodayDate(String pack)
    {

        final String endPoint = testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+"/"+acc_reference+"/subscriptions"+subRef+"/packs/"+pack;
        apiRequests.POSTMethodWithClientIDPasswordVersionHeaders(endPoint,xClientId,xClientPassword,xVersion,clspApiRequest.jsonDataForChanegPackDeliveryDate());
    }
    public void userCreatesPostPayMonthlySolutionAndCompletedPack(int status) {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACart();
        userMakesPayment();
        userCreatesSameDayPaymentSubcriptionUsingMPP(status, "POST","");
        waitABit(120000);
        userGetsTheSubscriptionDetails(0);
    }

    public void userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(String dailyType, String discountType, int quantity, int status,int newSubscriptionStatus) {
        userRequestsForNewCustomerToBeCreatedOnCDG(status);
        userTriesToAddACartForDailyCustomer(dailyType, quantity);
        userMakesPayment();
        userCreatesSameDayPaymentSubcriptionUsingMPP(newSubscriptionStatus, "POST",discountType);
        waitABit(120000);
        userGetsTheSubscriptionDetails(0);
    }
    public void userDeletsTheCustomerFromEnv(String status){
        String endPoint=testDataManager.getTestInputCommonData("url.commonMPPURI")+"/rest/api/accounts";
        int i=1;
        while(i<100){
            apiRequests.GETMethodWithQueryParam(endPoint,"clientUserId",testDataManager.getTestInputRegionData("createCustomer.store_id")+"-4","surname","AutoTest",clspApiRequest.getMPPHeaders());
            userDeletesSocratesCustomerSubscription(apiRequests.getValueFormJsonResponseKey("["+i+"].clientUserId"), status);
        }
    }

    public Map<String, ?> getHeadersForRemoveCust() {
        Map<String, String> headers = new HashMap<>();
        headers.put("X-ClientId", testDataManager.getTestInputCommonData("mppHeaders.clientId"));
        headers.put("X-ClientPassword",testDataManager.getTestInputCommonData("mppHeaders.clientPassword"));
        headers.put("x-version", testDataManager.getTestInputCommonData("mppHeaders.versionNumber"));
        headers.put("Origin", testDataManager.getTestInputCommonData("mppHeaders.Origin"));
        headers.put("x-tokenId", testDataManager.getTestInputCommonData("mppHeaders.x-tokenId"));
        return headers;
    }

    public void userDeletesSocratesCustomerSubscription(String custID, String status) {
        String endPoint=testDataManager.getTestInputCommonData("url.commonCDGURI")+testDataManager.getTestInputCommonData("url.accountEndPointCDG")+testDataManager.getTestInputCommonData("url.searchCustomerEndPoint");
        apiRequests.GETMethodWithQueryParam(endPoint,"customer_id", custID,"records_per_page","50","page_number", "1",xApiKey);
        String accRef= apiRequests.getValueFormJsonResponseKey("customers[0].account.resource_reference");

        String endPointMPP=testDataManager.getTestInputCommonData("url.commonMPPURI")+"/rest/api/accounts/"+accRef;
        apiRequests.DELETEMethodWithSpecificHeaders(endPointMPP,getHeadersForRemoveCust());
        assertEquals(apiRequests.verifyResponseStatusCode(),Integer.valueOf(status));

    }
    public void checkEmail(String customerType, int quantity, String packUsage,int packID,int subId){
        //wait is required to read the mail from mailosaur
        waitABit(5000);
        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(Integer.parseInt(testDataManager.getTestInputCommonData("mailosaurInformation.timeOutForMessage")));
        params.withServer(testDataManager.getTestInputCommonData("mailosaurInformation.serverID"));
        logger.info(emailID);
        criteria.withSentTo(emailID);
        try {
            message=mailosaur.messages().get(params,criteria);
        } catch (IOException | MailosaurException e) {
            throw new RuntimeException(e);
        }
        assertNotNull(message);
        assertEquals("Your recent update to your easycare subscription.",message.subject());
        Document doc = Jsoup.parse(message.html().body());
        messageBody = String.valueOf(doc);
        logger.info(messageBody);
        switch (packUsage){
            case "changeUsage":
                assertTrue(messageBody.contains(testDataManager.getTestInputRegionData(customerType+".usage")));
                int leftEyeQuantityUsage =Integer.parseInt(testDataManager.getTestInputRegionData(customerType+".quantity"));
                int rightEyeQuantityUsage=Integer.parseInt(testDataManager.getTestInputRegionData(customerType+".quantity"));
                String lensesUsage = Integer.toString(leftEyeQuantityUsage + rightEyeQuantityUsage);
                logger.info(lensesUsage);
                assertTrue(messageBody.contains(lensesUsage));
                String boxSize = Integer.toString(quantity*4);
                logger.info(boxSize);
                assertTrue(messageBody.contains(boxSize));
                getPackPaymentAndDeliveryDetails(packID,subId);
                break;
            case "holiday":
                int leftEyeQuantity =Integer.parseInt(testDataManager.getTestInputRegionData(customerType+".quantity"));
                int rightEyeQuantity=Integer.parseInt(testDataManager.getTestInputRegionData(customerType+".quantity"));
                String lenses = Integer.toString(leftEyeQuantity + rightEyeQuantity);
                logger.info(lenses);
                assertTrue(messageBody.contains(lenses));
                String leftBoxSize = Integer.toString(quantity*2);
                logger.info(leftBoxSize);
                assertTrue(messageBody.contains(leftBoxSize));
                assertTrue(messageBody.contains(deliveryDateAPI));
                assertTrue(messageBody.contains(secondPackAmount));
                assertTrue(messageBody.contains(secondPackPayment));
                assertTrue(messageBody.contains(secondPackDelivery));
                break;

        }
    }
    public void getPackPaymentAndDeliveryDetails(int packID,int subId){
        switch (packID){
            case 0:
                userGetsTheSubscriptionDetails(subId);
                assertTrue(messageBody.contains(deliveryDateAPI));
                logger.info(dateFormatMonth(paymentDateAPI)+" "+"\u00A3"+paymentAmount);
                assertTrue(messageBody.contains(dateFormatMonth(paymentDateAPI)+" "+"\u00A3"+paymentAmount));
                assertTrue(messageBody.contains(dateFormatMonth(secondPaymentDate)+" "+"\u00A3"+secondPaymentAmount));
                assertTrue(messageBody.contains(dateFormatMonth(thirdPaymentDate)+" "+"\u00A3"+thirdPaymentAmount));
                assertTrue(messageBody.contains(paymentAmount));
                break;
            case 1:
                userGetsTheSubscriptionDetails(subId);
                assertTrue(messageBody.contains(secondPackDelivery));
                assertTrue(messageBody.contains(dateFormatMonth(paymentDateAPI)+" "+"\u00A3"+secondPackPayment));
                assertTrue(messageBody.contains(dateFormatMonth(secondPaymentDate)+" "+"\u00A3"+secondPackSecondPayment));
                assertTrue(messageBody.contains(dateFormatMonth(thirdPaymentDate)+" "+"\u00A3"+secondPackThirdPayment));
                assertTrue(messageBody.contains(secondPackPayment));
                break;



        }

    }


    public void userCreatesAPICAllToUpdatePack(String custID, String FullID, String date){
        String cdgbaseURL="https://sz6k6gugqg.execute-api.eu-west-1.amazonaws.com/prd_3/v0/accounts/";
         apiRequests.GETMethodWithXApiHeaders(cdgbaseURL+custID,xApiKey);
         acc_reference= apiRequests.getValueFormJsonResponseKey("account.resource_reference");

        apiRequests.GETMethodWithXApiHeaders(cdgbaseURL+acc_reference+"/subscriptions?lifecycleState=ACTIVE",xApiKey);
        subRef= apiRequests.getValueFormJsonResponseKey("subscriptions[1].id");
        //apiRequests.GETMethodWithBasicAuth("https://sds-internal-web-eu-west-1.innov8.space/cldg/accounts/"+acc_reference+"/subscriptions");

        String fulfilmentref=apiRequests.POSTMethodWithClientIDPasswordVersionHeaders("https://eu2-api.mppglobal.com/rest/api/resources/",xClientId,xClientPassword,xVersion,jsonBodyFulfilment("L",FullID) );
        System.out.print("The data is:"+fulfilmentref);

       String response = apiRequests.PUTMethodWithXApiHeaders(cdgbaseURL+acc_reference+"/subscriptions/"+subRef+"/packs/"+fulfilmentref,xApiKey,jsonBodyDueDate(date));
        assertEquals(200,apiRequests.verifyResponseStatusCode());
        assertTrue(response.contains("true"));
    }
    public Map<String, ?> jsonBodyFulfilment(String referenceType, String fulfilmentID){

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("referenceType",referenceType);
        jsonBody.put("id",fulfilmentID);

        return jsonBody.toMap();

    }
    public Map<String, ?> jsonBodyDueDate(String dueDate){

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("delivery_date",dueDate);
        jsonBody.put("apply_all",true);

        return jsonBody.toMap();

    }

    public Map<String, ?> jsonBodyStoreFulFill(){

        JSONObject jsonBody = new JSONObject();
        jsonBody.put("non_lens_mail_order",true);
        return jsonBody.toMap();

    }
    public void userStoresDeliveryDates(){
        for (int i=0; i<9; i++){
            deliveryDate.add(apiRequests.getValueFormJsonResponseKey("packs["+i+"].delivery_date"));
            logger.info(deliveryDate.get(i));
        }
    }
    public void userStoresThePackStatus(){
        for (int i=0; i<9; i++){
            packStatus.add(apiRequests.getValueFormJsonResponseKey("packs["+i+"].status"));
            logger.info(packStatus.get(i));
        }
    }
    public void retrievePaymentsForStoreBalanceReport()
    {
        userGetsTheSubscriptionDetails(0);
        for(int i=0; i<3; i++){
            if(apiRequests.getValueFormJsonResponseKey("packs[0].payments["+i+"].status").contains("Completed") || apiRequests.getValueFormJsonResponseKey("packs[0].payments["+i+"].status").contains("Goodwill") || apiRequests.getValueFormJsonResponseKey("packs[0].payments["+i+"].available_actions").contains("[]"))
            {
                if(payerTypeAPI.equalsIgnoreCase("PRE"))
                    nextPrepayPaymentAmt = nextPrepayPaymentAmt + Double.parseDouble(paymentAmount);
                else
                    nextPostpayPaymentAmt = nextPostpayPaymentAmt + Double.parseDouble(paymentAmount);
            }
        }
    }

    public void userPerformsGoodwill(String packRef, String paymentRef, int status) {
        final String endpoint = testDataManager.getTestInputCommonData("url.commonCDGURI") + "accounts/" + acc_reference + "/subscriptions/" + subRef + "/packs/" + packRef + "/payments/" + paymentRef + testDataManager.getTestInputCommonData("url.goodwill");
        logger.info("The Goodwill endpoint is:" + endpoint);
        apiRequests.POSTMethodWithXApiHeaders(endpoint, xApiKey);
        assertEquals(apiRequests.verifyResponseStatusCode(), status);
    }

    public void userPerformsGoodwill(String paymentNum, int status) {
        String paymentRef = "";
        if (paymentNum.equalsIgnoreCase("First"))
            paymentRef = paymentRef1;
        else if (paymentNum.equalsIgnoreCase("Second"))
            paymentRef = paymentRef2;
        else if (paymentNum.equalsIgnoreCase("Third"))
            paymentRef = paymentRef3;
        if (subRef.contains("["))
            subRef = subRef.substring(1, subRef.length() - 1);
        if (acc_reference.contains("["))
            acc_reference = acc_reference.substring(1, acc_reference.length() - 1);
        userPerformsGoodwill(packRef, paymentRef, status);
    }


}
