package clsp.ui.pages;


import Framework.DataManager.TestDataManager;
import Framework.Staf;
import Framework.extensions.StafUtils;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CustomerDashboard extends clspBase {
    protected static final TestDataManager testDataManager = new TestDataManager();

    private final Logger logger = LoggerFactory.getLogger(CustomerDashboard.class);

    public String consentAppTitle = "Consent app";

    SearchPage searchPage;

    public String clspTitle = "Contact Lens Subscription Service | Specsavers";
    public String bookAppointmentTitleROI = "Book an appointment | Specsavers IE";
    public String bookAppointmentTitleUK = "Book an appointment | Specsavers UK - Appointment type";
    public static String updatedFirstDeliveryDate;
    public String editPayerInformation = "Edit Alternate Payer Information";
    public String alternatePayerPostCode = "alternatePayerPostcode";
    public static String accountSummaryValue;

    @FindBy(xpath = "//ngb-alert[@class='alert alert-danger']")
    public WebElementFacade alertHome;

    @FindBy(xpath ="//a[text()='Active CL Fits']")
    public WebElementFacade activeCLFitsTab;

    @FindBy(xpath = "//button[contains(.,'Refresh')]")
    private WebElementFacade refresh;

    @FindBy(xpath ="//button[contains(.,'Show details')]")
    public List <WebElementFacade> showDetailsBtn;

    @FindBy(xpath = "//button[contains(.,'Link')]")
    private WebElementFacade linkButton;

    @FindBy(xpath = "//div[@class='alert alert-success'][contains(.,'CLFit details linked')]")
    private WebElementFacade fitSuccessAlert;

    @FindBy(xpath = "//td[contains(@class,'active-fit-detail-lensname')]//..//td[contains(@class,'text-center')]")
    List<WebElementFacade> sphereValue;

    @FindBy(xpath = "//button[contains(.,'Subscribe')]")
    public WebElementFacade subscribeButton;

    @FindBy(xpath = "//button[contains(.,'Replace')]")
    public WebElementFacade SubscribeReplaceButton;

    @FindBy(xpath = "//div[@class='alert alert-danger mb-2']")
    private WebElementFacade bankAlertMessage;

    @FindBy(xpath = "//div[@class='alert alert-warning']")
    private WebElementFacade bankAgreement;

    @FindBy(xpath = "//div[@class='alert alert-success mb-2'][contains(.,'Account Details Validated.')]")
    private WebElementFacade accountValidation;

    @FindBy(xpath = "//span[@class='fake-link back-button']")
    private WebElementFacade subscriptionBackButton;

    @FindBy(xpath = "//input[contains(@id,'authorisation-input-field')]")
    private WebElementFacade bankAuthorisationCode;

    @FindBy(xpath = "//button[contains(.,'Proceed')]")
    private WebElementFacade bankAuthorisationProceed;

    @FindBy(xpath = "//button[contains(.,'OK')]")
    private WebElementFacade okButton;


    @FindBy(xpath = "//header[text()='Alternate Payer']")
    private WebElementFacade alternatePayer;

    @FindBy(xpath = "//div[@class='view-alternate-payer-component__content']/ul/li[1]")
    private WebElementFacade alternatePayerName;

    @FindBy(xpath = "//div[@class='view-alternate-payer-component__content']/ul/li[2]")
    private WebElementFacade alternatePayeraddress;

    @FindBy(xpath= "//input[@id = 'edit_contact_title']")
    private WebElementFacade contactTitle;

    @FindBy(xpath ="//input[@id = 'edit_contact_email']")
    private WebElementFacade contactEmail;

    @FindBy(xpath = "//h4[contains(., 'Edit Contact Information')]")
    private WebElementFacade ContactInfoTitle;

    @FindBy(xpath ="//div[@class='col-sm-4 customer-name']")
    public static WebElementFacade custNameLabel;

    @FindBy(xpath = "//button[@id='edit-default-address']")
    private WebElementFacade editContactInfo;

    @FindBy(xpath = "(//button[contains(.,'Edit')])[1]")
    public static WebElementFacade editPayer;

    @FindBy(xpath="//div[@class='alert alert-danger']")
    private WebElementFacade errorAlertMsg;

    @FindBy(xpath = "//table[@class='cost-breakdown pull-left']//td[text()='L']//following-sibling::td")
    private WebElementFacade leftLensOnDashBoard;

    @FindBy(xpath = "//table[@class='cost-breakdown pull-left']//td[text()='R']//following-sibling::td")
    private WebElementFacade rightLensOnDashBoard;

    @FindBy(xpath = "//button[text()='Replace']")
    public static WebElementFacade replaceButton;

    @FindBy(xpath = "//td[text()='Solution']//following-sibling::td")
    private WebElementFacade solutionOnDashBoard;

    @FindBy(xpath ="//button[contains(.,'Update')]")
    private WebElementFacade update;

    @FindBy(xpath ="//span[contains(.,'Mid Term Replacement')]//..//..//..//following-sibling::div//button[contains(@class,'edit-subscription')]")
    private WebElementFacade editSubscriptionBtmMidTermReplace;

    @FindBy(xpath ="//button[contains(.,'Edit Subscription')]")
    public List<WebElementFacade> editSubscriptnBtn;

    @FindBy(xpath = "//a[text()='Fit']")
    private WebElementFacade fitButton;

    @FindBy(xpath = "//th[@scope='col'][contains(.,'Sphere')]//..//td")
    List<WebElementFacade> sphere;

    @FindBy(id = "gdpr-btn")
    public WebElementFacade gdprButton;

    @FindBy(xpath = "//h1[text()='Consent Web App']")
    private WebElementFacade consentAppHeader;

    @FindBy(xpath = "//div[@class='sub-header__customer-id']")
    public WebElementFacade consentAppCustomerId;
    @FindBy(xpath = "//a[text()='Payment Methods']")
    public static WebElementFacade managePaymentMethodTab;

    @FindBy(xpath = "//a[contains(., 'Address Book')]")
    public WebElementFacade addressBook;

    @FindBy(xpath = "//button[@class='delete-button']")
    private WebElementFacade deleteAddress;

    @FindBy(xpath="//h4[contains(.,'Delete Address')]")
    private WebElementFacade labelDeleteAddress;

    @FindBy(xpath="//div[@class='modal-body']")
    private WebElementFacade deleteAddressAlertMessage;

    @FindBy(xpath = "//button[contains(.,'Cancel')]")
    private WebElementFacade cancelButton;

    @FindBy(xpath = "//div[@class='address_info address_info--collapse']") //according to R45
    public WebElementFacade fullDefaultAddress;

    @FindBy(xpath = "//button[contains(., 'Add new address') or contains(., 'Add New')]")
    public WebElementFacade addNewAddress;

    @FindBy(xpath = "//h4[@class='modal-title']")
    public WebElementFacade headerTitle;

    @FindBy(xpath = "//select[@id='edit_country']")
    public WebElementFacade selectCountry;

    @FindBy(xpath = "//a[@rel='noopener noreferrer']")
    private WebElementFacade eirCodeLink;

    @FindBy(xpath ="//input[@id='service_name']")
    private WebElementFacade serviceName;

    @FindBy(xpath = "//input[@id='edit_contact_title']")
    public WebElementFacade alternateTitle ;

    @FindBy(xpath = "//input[@id='address_edit_first_name']")
    public WebElementFacade alternateFirstName ;

    @FindBy(xpath = "//input[@id='address_edit_last_name']")
    public WebElementFacade alternateLastName;

    @FindBy(xpath = "//input[@id='edit_address_line_1']")
    public WebElementFacade houseNumber;

    @FindBy(xpath = "//input[@id='edit_address_line_3']")
    public WebElementFacade addrLineOne;

    @FindBy(xpath = "//input[@id='edit_city']")
    public WebElementFacade town;

    @FindBy(xpath = "//input[@id='edit_county']")
    public WebElementFacade country;

    @FindBy(xpath = "//input[@id='edit_address_line_2']")
    public WebElementFacade houseName;

    @FindBy(xpath ="//input[@id='edit_postcode']")
    public WebElementFacade postcode;

    @FindBy(xpath = "//label[text()='BFPO Postcode']//..//input[@type='text']")
    private WebElementFacade bfpoPostcode;

    @FindBy(xpath = "//button[text()=' Find My Address ']")
    public WebElementFacade findMyAddress;

    @FindBy(xpath = "//select[@id='addresses']")
    public WebElementFacade selectAddresses;

    @FindBy(xpath = "//input[@id='edit_default']")
    public WebElementFacade defaultAddressCheckbox;

    @FindBy(xpath ="//button[contains(.,'Confirm')]")
    List<WebElementFacade> confirmButton;

    @FindBy(xpath = "//input[contains(@id,'authorisation-input-field')]")
    List<WebElementFacade> authorizationCode;

    @FindBy(xpath =  "//button[text()=' Proceed ']")
    List<WebElementFacade> proceedButton;

    @FindBy(xpath = "//div[@class='modal-footer modal-footer-display']//button[contains(., 'Confirm')]")
    public WebElementFacade solutionConfirmButton;

    @FindBy(xpath = "//select[@id='cart-solution']")
    private WebElementFacade solutionDropdown;

    @FindBy(xpath ="//a[text()='Dismiss']")
    public WebElementFacade dismiss;

    @FindBy(xpath = "//button[@class='btn-secondary pull-right add-new-address-btn']")
    public WebElementFacade addNewAddressButton;

    @FindBy(xpath ="//span[text()='Alt Address']//..//following::div[@class='address_info address_info--collapse']")
    public WebElementFacade altrAddressCustomerDashboard;

    @FindBy(xpath = "//div[@class='address_info']")
    public WebElementFacade addInContactInfo;

    @FindBy(xpath = "//ul[@class='no-margintop-first-child']//li[1]")
    List <WebElement> contactInfo;

    @FindBy(xpath ="//ul[@class='no-margintop-first-child']//li[2]")
    public WebElementFacade emailAddressCustomerDashboard;

    @FindBy(xpath ="//input[@id = 'edit_contact_home_number']")
    public WebElementFacade contactHome;

    @FindBy(xpath ="//input[@id ='view_contact_dob']")
    public WebElementFacade contactDOB;

    @FindBy(xpath ="//input[@id = 'edit_contact_mobile_number']")
    public WebElementFacade contactMobile;

    @FindBy(xpath = "//span[@class='text-label'][contains(.,'Tel')]")
    List<WebElement> contactHomeInfo;

    @FindBy(xpath = "//span[contains(@class,'text-lighter-grey')]")
    public WebElementFacade contactMobInfo;

    @FindBy(xpath ="//select[@id='edit_contact_set_default_address']")
    public WebElementFacade addressDropdown;

    @FindBy(xpath ="//a[text()='Subscriptions']")
    public WebElementFacade subscriptionTab;

    @FindBy(xpath = "//span[@class='fake-link'][text()='(Change?)']")
    public List <WebElementFacade> firstChangeLink;

    @FindBy(xpath = "//button[@class='pull-right']")
    public WebElementFacade addressBookButton;

    @FindBy(xpath = "//div[@class='modal-content']")
    public WebElementFacade alternatePayerInformationModal;

    @FindBy(xpath = "//h4[text()= 'Terms & Conditions - Direct Debit']")
    public WebElementFacade termsAndConditinHeader;

    @FindBy(xpath = "//button[text()='Terms & Condition']")
    public WebElementFacade termsConditionButton;

    @FindBy(xpath = "//button[contains(.,'Cancel')]")
    List<WebElementFacade> cancelButtonPopUp;

    @FindBy(xpath = "//button[text()= ' Remove ']")
    public WebElementFacade removeButton;

    @FindBy(xpath = "//button[text()= 'Remove']")
    public WebElementFacade removePayerButtonPop;

    @FindBy(xpath = "//span[contains(.,'Next Delivery')]//..//following-sibling::span")
    public WebElementFacade nextDeliveryDate;

    @FindBy(xpath = "//span[contains(.,'First Delivery Date')]//..//following-sibling::span")
    public static WebElementFacade firstDeliveryDate;

    @FindBy(xpath ="//li[2]//button[contains(.,'Edit Subscription')]")
    public WebElementFacade secondEditSubscriptionButton;

    @FindBy(xpath = "//div[@popovertitle='Alternate Contact']")
    private WebElementFacade alternatePayerIcon;

    @FindBy(xpath = "//span[text()='Turn on Alternate Contact alert']")
    private WebElementFacade turnOnLink;

    @FindBy(xpath = "//div[@class='icon-circle blue']")
    private WebElementFacade blueAlert;

    @FindBy(xpath = "//span[text()='Reset Customer Care Alert']")
    private WebElementFacade resetCustomerCare;

    @FindBy(xpath = "//span[text()='Reset Alternate Contact Alert']")
    private WebElementFacade resetAlternatePayer;

    @FindBy(xpath = "//div[@popovertitle='Customer Care']")
    private WebElementFacade customerCareIcon;

    @FindBy(xpath = "//button[@id='customer-value-btn']")
    private WebElementFacade accountSummaryValueButton;

    @FindBy(xpath = "//span[text()='Turn on Customer Care Alert']")
    private WebElementFacade turnOnCustomerCareLink;

    @FindBy(xpath = "//div[@class='icon-circle red']")
    private WebElementFacade redAlert;

    @FindBy(xpath = "//a[text()='Notes']")//Commenting Xpath due to change in CDG 68
    private WebElementFacade notesButton;

    @FindBy(xpath = "//span[contains(.,'System')]")
    private WebElementFacade systemButton;

    @FindBy(xpath = "//div[@class='customer-note']")
    List <WebElementFacade> customerNote;

    @FindBy(xpath = "//Select[@id='new-note-subject']")
    private WebElementFacade selectSubject;

    @FindBy(xpath = "//Select[@id='new-note-type']")
    private WebElementFacade notesType;

    @FindBy(xpath = "//button[@id='add-note-btn']")
    private WebElementFacade addNoteButton;

    @FindBy(xpath = "//a[text()='Entitlements']")
    public WebElementFacade entitlementTab;

    @FindBy(xpath = "//div[@class='entitlement-title'][contains(.,' Sun glasses discount voucher ')]//..//..//following-sibling::div[@class='input-group-append']")
    public WebElementFacade sunGlassesClaimDateCalendar;

    @FindBy(xpath = "//button[text()=' Submit New Claim Date(s) ']")
    public WebElementFacade submitNewClaimDateButton;

    @FindBy(xpath = "//div[@class='entitlement-title'][contains(.,'Free glasses voucher')]//..//..//following-sibling::div[@class='input-group-append']")
    public WebElementFacade freeGlassesClaimDateCalendar;

    @FindBy(xpath = "//div[text()=' Free glasses voucher ']//..//..//div[@id='next_delivery_label']")
    private WebElementFacade nextAvailableEntitlementDate;

    @FindBy(xpath = "//div[@class='entitlement-title'][contains(.,'Aftercare ')]//..//..//following-sibling::div[@class='input-group-append']")
    public WebElementFacade aftercareClaimDateCalendar;

    @FindBy(xpath = "//div[@class='entitlement-title'][contains(.,'Spare Lenses')]//..//..//following-sibling::div[@class='input-group-append']")
    public WebElementFacade spareLensesClaimDateCalendar;

    @FindBy(xpath = "//button[@title='Previous month']")
    private WebElementFacade previousMonthArrow;

    @FindBy(xpath = "//input[@id='new-note-author']")
    private WebElementFacade notesAuthor;

    @FindBy(xpath = "//select[@id='notify-store']")
    private WebElementFacade notesNotify;

    @FindBy(xpath = "//textarea[@id='new-note-comment']")
    private WebElementFacade notesTextBox;

    @FindBy(xpath = "//select[@id='new-spare-what']")
    public WebElementFacade spareLensWhat;

    @FindBy(xpath = "//select[@id='new-spare-solution']")
    public WebElementFacade spareLensSolution;

    @FindBy(xpath = "//span[text()=' User ']")
    private WebElementFacade userNoteTab;

    @FindBy(xpath ="//div[@class='subject-column']")
    List <WebElementFacade> noteSubjectLabel;

    @FindBy(xpath ="//div[@class='row note-body']")
    List <WebElementFacade> noteLabel;

    @FindBy(xpath ="//div[@class='type-column']")
    List <WebElement> noteTypeLabel;

    @FindBy(xpath = "//div[@class='date-column']")
    List <WebElement> noteDateLabel;

    @FindBy(xpath = "//div[@id='customer-search-link']")
    public WebElementFacade customerSearch;

    @FindBy(xpath = "//button[contains(text(),'Select')]")
    private WebElementFacade customerSelectBtn;

    @FindBy(xpath = "//div[@class='col-md-12 vertical-padding alert alert-warning no-margin']")
    private WebElementFacade noNotesFoundWarningMessage;

    @FindBy(xpath = "//div[contains(@title,'Customer Care Alert')]")
    private WebElementFacade badDebtIcon;

    @FindBy(xpath = "//span[@class='fake-link']")
    public WebElementFacade resetLink;

    @FindBy(xpath ="//a[text()='History']")
    public WebElementFacade historyTab;

    @FindBy(xpath ="//span[@ng-reflect-klass='subscription_status']")
    private WebElementFacade historySubscriptionStatus;

    @FindBy(xpath ="//span[contains(@class,'subscription_status')]")
    public
    List <WebElement> subscriptionStatus;

    @FindBy(xpath = "//button[text()= 'Remove']")
    public WebElementFacade removepayerButtonPop;

    @FindBy(xpath = "//button[text()='Reprint']")
    public static WebElementFacade reprintButton;

    @FindBy(xpath = "//tr[@class='subscription-next-payment']/td[2]")
    public WebElementFacade nextPaymentDate;

    @FindBy(xpath = "//tr[@class='subscription-next-payment-amount']/td[2]")
    public WebElementFacade nextPaymentAmount;

    @FindBy(xpath = "//section[@id='customer-account-summary']//button[@id='book-appointment']")
    private WebElementFacade bookAppointment;

    @FindBy(xpath = "//img[contains(@alt,'Specsavers logo')]")
    private WebElementFacade bookAppointmentLogo;

    @FindBy(xpath = "//div[contains(@class,'alert alert-warning important-alert')]")
    private WebElementFacade replaceSubscriptionMessage;

    @FindBy(xpath = "//div[@class='alert alert-warning']")
    private WebElementFacade  replaceSubscriptionAlert;

    @FindBy(xpath = "//span[@class='text-label'][contains(.,'Next Payment')]/following-sibling::span")
    WebElementFacade paymentDate;

    public Boolean flag;
    public String newEmail;
    public static String defaultAddress;

    private static String replaceWarningMessage="Please note there is a price change. This does not include any discounts you may be applying.\n" +
            "Any credited payments will show as Completed within 5 days.";

    public String bankAlertErrorMessage = "Account Details not Validated - Please check and try again. You can proceed with this Direct Debit but please ensure you double check the sort code and account number are correct.";

    public String bankAggrementMessage = " I can confirm that the customer has seen and agreed to the Terms & Conditions and confirmed that they wish to enter a subscription contract with Specsavers.";

    public String AccValidationMessage = "Account Details Validated.";

    public String replaceSubscriptionAlertMessage = "Please confirm the payment dates with the customer.";
    public void updateCustomerDetails(){
        //Update Cust Salutaion
        editContactInfo.waitUntilClickable();
        clickElement(editContactInfo);
        final String salTnBefore = contactTitle.getTextValue();
        final String expectedSaltn;
        clearTextFromTextBox(contactTitle);
        if(salTnBefore.equals(testDataManager.getTestInputRegionData("createCustomer.title"))){
            setText(contactTitle,testDataManager.getTestInputRegionData("createCustomer.title2"));
            expectedSaltn=testDataManager.getTestInputRegionData("createCustomer.title2");
        }
        else{
            setText(contactTitle,testDataManager.getTestInputRegionData("createCustomer.title"));
            expectedSaltn=testDataManager.getTestInputRegionData("createCustomer.title");
        }
        clearTextFromTextBox(contactEmail);
        setText(contactEmail,testDataManager.getTestInputRegionData("editCustomerInfo.emailAddress"));
        clickElement(ContactInfoTitle);
        assertPageObjectIsDisplayed(alertHome);
        contactEmail.clear();
        newEmail = StafUtils.generateNewCustomerEmail("");
        setText(contactEmail,newEmail);
        clickElement(update);
        waitForElement();
        custNameLabel.waitUntilVisible();
        String updtTitle = custNameLabel.getText();
        assertTrue(updtTitle.contains(expectedSaltn));
        assertTrue(!errorAlertMsg.isVisible());

    }

    //user clicks on GDPR button and verify the consentapp
    public void userClicksOnGDPRButtonAndVerifyConsentApp() {
        gdprButton.waitUntilClickable();
        clickElement(gdprButton);
        switchToChildWindow();
        assertEquals(getDriver().getTitle(), consentAppTitle);
        assertPageObjectIsDisplayed(consentAppHeader);
        final String custID = searchPage.customerID;
        final String customerid = consentAppCustomerId.getText().substring(13);
        assertTrue(custID.contains(customerid));
        getDriver().close();
        switchToOriginalWindow();


    }


    public void verifyReplaceBtnIsDisabled(){
        managePaymentMethodTab.waitUntilClickable();
        clickElement(managePaymentMethodTab);
        assertTrue(alternatePayer.isVisible());
        assertTrue(!replaceButton.isEnabled());
        assertTrue(!editPayer.isDisabled());
    }

    public void enterAddress(String addressType)
    {

        selectCountry.selectByVisibleText(testDataManager.getTestInputRegionData("address.countryName"));
        setText(houseNumber,testDataManager.getTestInputRegionData("address.number"));
        setText(houseName,testDataManager.getTestInputRegionData("address.name"));
        setText(addrLineOne,testDataManager.getTestInputRegionData("address.addressLine"));
        setText(town,testDataManager.getTestInputRegionData("address.town"));
        setText(country,testDataManager.getTestInputRegionData("address.county"));
        postcode.waitUntilVisible().waitUntilClickable();
        setText(postcode,testDataManager.getTestInputRegionData("address.postcode"));

    }
    public void addNewAddress(String addressType)
    {
        assertPageObjectIsDisplayed(addNewAddress);
        clickElement(addNewAddress);
        assertPageObjectIsDisplayed(headerTitle);
        clickElement(selectCountry);
        waitFor(headerTitle);
        if(headerTitle.getText().equalsIgnoreCase(editPayerInformation))
        {
            assertElementContainsText(selectCountry, "Ireland");
            assertElementContainsText(selectCountry,"United Kingdom");
            setText(alternateTitle,testDataManager.getTestInputRegionData("payer.alternateTitle"));
            setText(alternateFirstName,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
            setText(alternateLastName,testDataManager.getTestInputRegionData("payer.alternateLastName"));

            enterAddress(addressType);
            clickElement(confirmButton.get(0));
        }
        else
        {
            assertElementContainsText(selectCountry,testDataManager.getTestInputRegionData("address.countryBFPO"));
            if(Staf.getTargetRegion().equalsIgnoreCase(testDataManager.getTestInputRegionData("address.countryName")))
            {
                assertElementContainsText(selectCountry, testDataManager.getTestInputRegionData("address.countryName"));
                assertElementContainsText(selectCountry,testDataManager.getTestInputRegionData("address.countryBFPO"));
                assertPageObjectIsDisplayed(eirCodeLink);
                clickElement(eirCodeLink);
                switchToChildWindow();
                switchToOriginalWindow();
            }
            else
            {
                assertElementContainsText(selectCountry,testDataManager.getTestInputRegionData("address.countryName"));
                assertElementContainsText(selectCountry,testDataManager.getTestInputRegionData("address.countryBFPO"));
            }

            enterAddress(addressType);
            clickElement(addNewAddressButton);

        }


    }
    public void verifyAddressDetails(){

        final String defaultAddress = testDataManager.getTestInputRegionData("address.number")+" "+testDataManager.getTestInputRegionData("address.name")+" "+testDataManager.getTestInputRegionData("address.addressLine")+" "+testDataManager.getTestInputRegionData("address.town")+" "+testDataManager.getTestInputRegionData("address.county")+" "+testDataManager.getTestInputRegionData("address.postcode")+" "+testDataManager.getTestInputRegionData("address.countryName");
        assertEquals(fullDefaultAddress.getText().replaceAll("[\r\n]+", " "), defaultAddress);
        final String altAddress = testDataManager.getTestInputRegionData("address.number")+" , "+testDataManager.getTestInputRegionData("address.name")+", "+testDataManager.getTestInputRegionData("address.addressLine")+" "+testDataManager.getTestInputRegionData("address.town")+" "+testDataManager.getTestInputRegionData("address.county")+" "+testDataManager.getTestInputRegionData("address.postcode")+" "+testDataManager.getTestInputRegionData("address.countryName");
        assertEquals(altrAddressCustomerDashboard.getText().replaceAll("[\r\n]+", " "), altAddress);

    }
    public void verifyContactDetails(){
       final String homeContact = testDataManager.getTestInputRegionData("address.homeTelephoneNumber");
       final String mobContact = testDataManager.getTestInputRegionData("address.mobileNumber");
       final String addLine1Contact = testDataManager.getTestInputRegionData("address.addressLine");
       final String addCountryContact = testDataManager.getTestInputRegionData("address.countryName");
        final String email= testDataManager.getTestInputRegionData("address.emailAdd");
        assertTrue(contactInfo.get(0).getText().contains(homeContact));
        assertTrue(contactInfo.get(0).getText().contains(mobContact));
        assertElementContainsText(addInContactInfo,addLine1Contact);
        assertElementContainsText(addInContactInfo,addCountryContact);
        assertElementContainsText(emailAddressCustomerDashboard,email);


    }
    public void clickEditSubscription(){
        editSubscriptnBtn.get(0).click();

    }

    public  void updatingContactInformation()
    {
        assertTrue(editContactInfo.isVisible());
        clickElement(editContactInfo);
        assertTrue(ContactInfoTitle.isVisible());
        assertTrue(contactDOB.getAttribute("readonly").equalsIgnoreCase(testDataManager.getTestInputRegionData("createCustomer.is_default")));
        contactHome.clear();
        setText(contactHome,testDataManager.getTestInputRegionData("address.homeTelephoneNumber"));
        contactMobile.clear();
        setText(contactMobile,testDataManager.getTestInputRegionData("address.mobileNumber"));
        contactEmail.clear();
        setText(contactEmail,testDataManager.getTestInputRegionData("address.emailAdd"));
        addressDropdown.selectByVisibleText(testDataManager.getTestInputRegionData("address.number")+" "+testDataManager.getTestInputRegionData("address.name")+" "+testDataManager.getTestInputRegionData("address.addressLine")+" "+testDataManager.getTestInputRegionData("address.postcode")+" "+testDataManager.getTestInputRegionData("address.countryName"));
        waitForElement();
        clickElementSuccess(update);
        waitForElement();
        if(dismiss.isVisible()) {
            clickElement(dismiss);
        }
        verifyContactDetails();
        assertTrue(editContactInfo.isVisible());
        clickElement(editContactInfo);
        addressDropdown.selectByIndex(1);
        clickElementSuccess(update);

    }

    public void NavigatesToManagePaymentTabAndAddsAlternatePayer() {
        clickElement(managePaymentMethodTab);
        clickElement(replaceButton);

    }
    public void verifyLensDetailsOnCustDashboard(String lensType,  String customerType){
        if(customerType.contains("daily") && lensType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(!leftLensOnDashBoard.isVisible());
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("N/A"));
        }
        else if(customerType.contains("daily") && lensType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeL"))){
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(!rightLensOnDashBoard.isVisible());
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("N/A"));

        }
        else if(customerType.contains("daily") && lensType.equalsIgnoreCase("Both")){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("N/A"));
        }
        else if(customerType.contains("daily") && lensType.equalsIgnoreCase("different")){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData("dailyDifferentlens.lens_name")));
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("N/A"));

        }
        else if(customerType.equalsIgnoreCase("montlySolutionCustomer") && lensType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(!leftLensOnDashBoard.isVisible());
            assertTrue(solutionOnDashBoard.getText().toLowerCase().contains(testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name").toLowerCase()));

        }
        else if(customerType.equalsIgnoreCase("montlySolutionCustomer") && lensType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeL"))){

            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(!rightLensOnDashBoard.isVisible());
            assertTrue(solutionOnDashBoard.getText().toLowerCase().contains(testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name").toLowerCase()));

        }
        else if(customerType.equalsIgnoreCase("montlySolutionCustomer") && lensType.equalsIgnoreCase("Both")){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(solutionOnDashBoard.getText().toLowerCase().contains(testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name").toLowerCase()));

        }
        else if(customerType.equalsIgnoreCase("montlyNoSolutionCustomer") && lensType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(!leftLensOnDashBoard.isVisible());
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("No Solution"));

        }
        else if(customerType.equalsIgnoreCase("montlyNoSolutionCustomer") && lensType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(!rightLensOnDashBoard.isVisible());
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("No Solution"));

        }
        else if(customerType.equalsIgnoreCase("non-LensMail")&&lensType.equalsIgnoreCase("Both")){
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("N/A"));
        }
        else{
            assertTrue(rightLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(leftLensOnDashBoard.getText().equalsIgnoreCase(testDataManager.getTestInputRegionData(customerType+".LensName")));
            assertTrue(solutionOnDashBoard.getText().equalsIgnoreCase("No Solution"));

        }
    }
    public void verifyTheAlternatePayerDetailsOutsideTheInformationModal(WebElementFacade payerConfirmButton) {

        clickElement(managePaymentMethodTab);
        clickElement(editPayer);
        assertObjectIsClickable(subscriptionTab);
        assertPageObjectIsDisplayed(alternatePayerInformationModal);
        assertPageObjectIsDisplayed(alternateFirstName);
        clickElement(payerConfirmButton);
        clickElement(editPayer);


    }
    public void verifyDetailsAfterClickingOnReplaceButton() {
        clickElement(replaceButton);
        assertPageObjectIsDisplayed(update);
        assertPageObjectIsDisplayed(termsConditionButton);
        clickElement(termsConditionButton);
        clickElement(cancelButtonPopUp.get(0));

    }
    public void verifyDeliveryDates() {

        final String updatedFirstDeliveryDate = firstDeliveryDate.getText();
        assertElementText(nextDeliveryDate,updatedFirstDeliveryDate);

    }

    public void clickOnSecondEditSubscritpionButton(){

        editSubscriptnBtn.get(1).click();
    }
    public void verifyLenses(String eyeType, String customerType) {

        if(customerType.contains("daily") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertTrue(!leftLensOnDashBoard.isVisible());
            assertElementText(solutionOnDashBoard,"N/A");
        }
        else if(customerType.contains("daily") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeL"))){
            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertTrue(!rightLensOnDashBoard.isVisible());
            assertElementText(solutionOnDashBoard,"N/A");

        }
        else if(customerType.contains("daily") && eyeType.equalsIgnoreCase("Both")){
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementText(solutionOnDashBoard,"N/A");

        }
        else if(customerType.contains("daily") && eyeType.equalsIgnoreCase("different")){
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData("dailyDifferentlens.lens_name"));
            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementText(solutionOnDashBoard,"N/A");

        }
        else if(customerType.equalsIgnoreCase("montlySolutionCustomer") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertElementContainsText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            //assertTrue(!leftLensOnDashBoard.isVisible());
            assertElementContainsText(solutionOnDashBoard,testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));

        }
        else if(customerType.equalsIgnoreCase("montlySolutionCustomer") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeL"))){

            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertTrue(!rightLensOnDashBoard.isVisible());
            assertElementContainsText(solutionOnDashBoard,testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));

        }
        else if(customerType.equalsIgnoreCase("montlySolutionCustomer") && eyeType.equalsIgnoreCase("Both")){
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementContainsText(solutionOnDashBoard,testDataManager.getTestInputRegionData("cartJsonBody.solution_supplier_name"));

        }
        else if(customerType.equalsIgnoreCase("montlyNoSolutionCustomer") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertTrue(!leftLensOnDashBoard.isVisible());
            assertElementText(solutionOnDashBoard,"No Solution");

        }
        else if(customerType.equalsIgnoreCase("montlyNoSolutionCustomer") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeL"))){
            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertTrue(!rightLensOnDashBoard.isVisible());
            assertElementText(solutionOnDashBoard,"No Solution");

        }
        else if(customerType.equalsIgnoreCase("montlyNoSolutionCustomerSingleEye") && eyeType.equalsIgnoreCase(testDataManager.getTestInputRegionData("Occasional.eyeR"))){
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertTrue(!leftLensOnDashBoard.isVisible());
            assertElementText(solutionOnDashBoard,"No Solution");

        }
        else{
            assertElementText(rightLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementText(leftLensOnDashBoard,testDataManager.getTestInputRegionData(customerType +".LensName"));
            assertElementText(solutionOnDashBoard,"No Solution");

        }

    }

    public void verifyChangeInExistingAlternatePayerDetails() {
        final String payerFullName = testDataManager.getTestInputRegionData("alternatePayer.alternateTitle")+" "+testDataManager.getTestInputRegionData("alternatePayer.alternateFirstName")+" "+testDataManager.getTestInputRegionData("alternatePayer.alternateLastName");
        final String payerFullAddress = testDataManager.getTestInputRegionData("alternatePayer.name")+" "+testDataManager.getTestInputRegionData("alternatePayer.number")+" "+testDataManager.getTestInputRegionData("alternatePayer.addressLine")+" "+testDataManager.getTestInputRegionData("alternatePayer.town")+" "+testDataManager.getTestInputRegionData("alternatePayer.county")+" "+testDataManager.getTestInputRegionData("alternatePayer.postcode")+" "+testDataManager.getTestInputRegionData("alternatePayer.countryName");
        assertPageObjectIsDisplayed(alternatePayer);
        final String name = alternatePayerName.getText().substring(6);
        assertTrue(name.equalsIgnoreCase(payerFullName));
        final String address = alternatePayeraddress.getText().replaceAll("[\r\n]+", " ").substring(9);
        assertEquals(address, payerFullAddress);
    }
    public void verifyAlternatePayerDetails(String addressType)
    {
        final String payerFullName = testDataManager.getTestInputRegionData("payer.alternateTitle")+" "+testDataManager.getTestInputRegionData("payer.alternateFirstName")+" "+testDataManager.getTestInputRegionData("payer.alternateLastName");
        final String payerFullAddress = testDataManager.getTestInputRegionData("payer.name")+" "+testDataManager.getTestInputRegionData("payer.number")+" "+testDataManager.getTestInputRegionData("payer.addressLine")+" "+testDataManager.getTestInputRegionData("payer.town")+" "+testDataManager.getTestInputRegionData("payer.county")+" "+testDataManager.getTestInputRegionData("payer.postcode")+" "+testDataManager.getTestInputRegionData("payer.countryName");
        final String alternatePayerAddress = testDataManager.getTestInputRegionData("payer.number")+" "+testDataManager.getTestInputRegionData("payer.addressLine")+" "+testDataManager.getTestInputRegionData("payer.town")+" "+testDataManager.getTestInputRegionData("payer.postcode")+" "+testDataManager.getTestInputRegionData("payer.countryName");
        assertPageObjectIsDisplayed(alternatePayer);
        final String name = alternatePayerName.getText().substring(6);
        assertEquals(name, payerFullName);
        final String address = alternatePayeraddress.getText().replaceAll("[\r\n]+", " ").substring(9);
        if(addressType.equalsIgnoreCase(alternatePayerPostCode))
            assertEquals(address, alternatePayerAddress);
        else
            assertEquals(address, payerFullAddress);
    }
    public void highlightAdditionalContact()
    {
        waitFor(alternatePayerIcon);
        assertPageObjectIsDisplayed(alternatePayerIcon);
        clickElement(alternatePayerIcon);
        assertPageObjectIsDisplayed(turnOnLink);
        clickElement(turnOnLink);
        assertPageObjectIsDisplayed(blueAlert);
    }
    public void addNewNoteToSubscription(String noteSub,String noteType){
        final String notifyValue;
        clickElement(notesButton);
        selectSubject.selectByVisibleText(noteSub);
        waitABit(2000);
        assertTrue(selectSubject.getSelectedVisibleTextValue().equalsIgnoreCase(noteSub));
        notesType.selectByVisibleText(noteType.trim());
        assertObjectIsNotInteractable(addNoteButton);
        assertFalse(notesType.getText().contains("Chargeback"));
        assertFalse(notesType.getText().contains("Manage Offer"));
        assertFalse(notesType.getText().contains("Support Note"));
        assertFalse(notesType.getText().contains("System Account"));
        assertFalse(notesType.getText().contains("Undefined"));
        assertFalse(notesType.getText().contains("View Account"));

        setText(notesAuthor,"CLSP");

        assertFalse(addNoteButton.isEnabled());

            setText(notesTextBox,testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
            if(selectSubject.getSelectedVisibleTextValue().equalsIgnoreCase("Clinical") || selectSubject.getSelectedVisibleTextValue().equalsIgnoreCase("Detail Changes"))
            {
                notesNotify.selectByVisibleText("None");
                assertTrue(notesNotify.getSelectedVisibleTextValue().equalsIgnoreCase("None"));
                setText(notesTextBox,testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
            }
            else if(selectSubject.getSelectedVisibleTextValue().trim().equalsIgnoreCase("Spare Lens Request") )
            {
                assertTrue(notesNotify.getSelectedVisibleTextValue().equalsIgnoreCase("Store"));
                spareLensWhat.selectByIndex(1);
                assertFalse(addNoteButton.isEnabled());
                spareLensSolution.selectByIndex(2);
            }
            else
            {
                assertTrue(notesNotify.getSelectedVisibleTextValue().equalsIgnoreCase("None"));
                setText(notesTextBox,testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree"));
            }
        notifyValue = notesNotify.getSelectedVisibleTextValue();
        addNoteButton.waitUntilVisible();
        clickElement(addNoteButton);
        assertEquals(noteSubjectLabel.get(0).getText().substring(9),noteSub);
        assertEquals(noteTypeLabel.get(0).getText().substring(6), noteType);
        assertTrue(noteDateLabel.get(0).getText().substring(6, 16).contains(SubscriptionPage.todaysDateWithBackslashes(0)));
        if(noteSub.equalsIgnoreCase("Spare Lens Request"))
        {
            assertTrue(noteLabel.get(0).getText().contains("Spare lens request:\nWhat is required: Both eyes\nIs Solution Required: Yes\n[ Author: CLSP, Notify: "+notifyValue+" ]"));
        }
        else
        {
            assertTrue(noteLabel.get(0).getText().contains(testDataManager.getTestInputRegionData("createCustomer.friendly_nameFree")+"\n[ Author: CLSP, Notify: "+notifyValue+" ]"));
        }
    }
    public void verifiesTheAdditionalContactButton() {
        assertPageObjectIsDisplayed(blueAlert);

    }
    public void unhighlightTheAdditionalContactButton() {
        clickElement(blueAlert);
        resetLink.waitUntilClickable();
        clickElement(resetLink);
        assertPageObjectIsDisplayed(alternatePayerIcon);
    }
    public void verifiesTheAdditionalContactButtonIsUnHighlighted() {
        assertTrue(alternatePayerIcon.isVisible());
    }
    public void clickRemoveButton() {
        removeButton.waitUntilClickable();
        clickElement(removeButton);
        cancelButtonPopUp.get(1).waitUntilClickable();
        clickElement(cancelButtonPopUp.get(1));
        clickElement(removeButton);
        removePayerButtonPop.waitUntilClickable();
        clickElement(removePayerButtonPop);
        assertObjectIsNotInteractable(update);

    }
    public void userVerifiesAlternatePayerDetailsNotBeingVisible(){
        assertObjectIsNotInteractable(alternatePayerName);
    }
    public void addNewAddressViaPostcode(String addressType) {

        assertPageObjectIsDisplayed(addNewAddress);
        clickElement(addNewAddress);
        assertPageObjectIsDisplayed(headerTitle);
        clickElement(selectCountry);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            clickElement(cancelButtonPopUp.get(1));
            addNewAddress(addressType);
        }
        else
        {
            if(headerTitle.getText().equalsIgnoreCase("Edit Alternate Payer Information"))
            {
                setText(alternateTitle,testDataManager.getTestInputRegionData("payer.alternateTitle"));
                setText(alternateFirstName,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
                setText(alternateLastName,testDataManager.getTestInputRegionData("payer.alternateLastName"));

                assertTrue(!selectCountry.getText().contains("BFPO"));
                assertElementContainsText(selectCountry,"United Kingdom");
                assertElementContainsText(selectCountry,"Ireland");

                enterAddressViaPostCode(addressType);
                clickElement(confirmButton.get(0));
                assertTrue(addInContactInfo.getText().replaceAll("[\r\n]+", " ").equalsIgnoreCase(testDataManager.getTestInputRegionData(addressType + (".name")+" "+testDataManager.getTestInputRegionData(addressType + (".addressLine")+" "+testDataManager.getTestInputRegionData(addressType + (".town")+" "+testDataManager.getTestInputRegionData(addressType + (".postcode")+" "+testDataManager.getTestInputRegionData(addressType + (".countryName"))))))));
            }
            else
            {
                assertElementContainsText(selectCountry,"BFPO");
                assertElementContainsText(selectCountry,"United Kingdom");
                assertTrue(!selectCountry.getText().contains("Ireland"));

                enterAddressViaPostCode(addressType);
                clickElement(addNewAddressButton);
                altrAddressCustomerDashboard.waitUntilVisible();
                assertTrue((altrAddressCustomerDashboard.getText().replaceAll("[\r\n]+", " ").equalsIgnoreCase(testDataManager.getTestInputRegionData(addressType + (".name")+" "+testDataManager.getTestInputRegionData(addressType + (".addressLine")+" "+testDataManager.getTestInputRegionData(addressType + (".town")+" "+testDataManager.getTestInputRegionData(addressType + (".postcode")+" "+testDataManager.getTestInputRegionData(addressType + (".countryName")))))))));
            }
        }
    }
    public void enterAddressViaPostCode(String addressType)
    {
        selectCountry.selectByVisibleText(testDataManager.getTestInputRegionData(addressType + ".countryName"));
        setText(postcode,testDataManager.getTestInputRegionData(addressType + ".postcode"));
        clickElement(findMyAddress);
        selectAddresses.waitUntilVisible();
        selectAddresses.selectByVisibleText(testDataManager.getTestInputRegionData(addressType + ".name")+" "+testDataManager.getTestInputRegionData(addressType + (".addressLine")+" "+testDataManager.getTestInputRegionData(addressType + ".town")+" "+testDataManager.getTestInputRegionData(addressType + ".postcode")+" "+testDataManager.getTestInputRegionData(addressType + (".countryName"))));
        assertTrue(houseNumber.getTextValue().trim().equalsIgnoreCase(testDataManager.getTestInputRegionData(addressType + (".name"))));
        assertTrue(addrLineOne.getTextValue().equalsIgnoreCase(testDataManager.getTestInputRegionData(addressType + (".addressLine"))));
        assertTrue(town.getTextValue().equalsIgnoreCase(testDataManager.getTestInputRegionData(addressType + (".town"))));
        assertTrue(!defaultAddressCheckbox.isVisible());
    }
    public void toVerifySubscriptionStatus(String subStatus) {
        if (subStatus.equalsIgnoreCase("Cancelled")) {
            historyTab.waitUntilVisible();
            clickElement(historyTab);
            historySubscriptionStatus.isVisible();//use wait
        } else {
            assertTrue(subscriptionStatus.get(0).getText().equalsIgnoreCase(subStatus));

        }
    }
    public void verifySepaPrintAddress(String customerLastName, String lastName, WebElementFacade printSepaAddress) {
        if(customerLastName.contains(lastName))
        {
            final String FullAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
            assertEquals(FullAddress, printSepaAddress.getText().replaceAll("[\r\n]+", " "));
        }
        else
        {
            final String payerFullAddress = testDataManager.getTestInputRegionData("payer.name")+" "+testDataManager.getTestInputRegionData("payer.number")+" "+testDataManager.getTestInputRegionData("payer.addressLine")+" "+testDataManager.getTestInputRegionData("payer.town")+" "+testDataManager.getTestInputRegionData("payer.county")+" "+testDataManager.getTestInputRegionData("payer.postcode")+" "+testDataManager.getTestInputRegionData("payer.countryName");
            assertEquals(payerFullAddress, printSepaAddress.getText().replaceAll("[\r\n]+", " "));
        }
    }
    public void userVerifiesTheExistingPaymentDetailsInReprint(WebElementFacade alterPayerDetailsOnMandate, String firstName, WebElementFacade receiptCloseButton, String lastName, WebElementFacade printSepaAddress){
        clickElement(reprintButton);
        final String AlterPayerDetailsOnMandate = alterPayerDetailsOnMandate.getText();
        assert(alterPayerDetailsOnMandate.getText().contains(firstName));

        if (testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            //using substring for assertion
            assertTrue(alterPayerDetailsOnMandate.getText().substring(10, 20).contains(firstName));
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("payment.iBan").substring(14)));
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("payment.bIc")));
            final String customerLastName = CustomerDashboard.custNameLabel.getText();
            verifySepaPrintAddress(customerLastName,lastName,printSepaAddress);
        }
        else
        {
            //using substring for assertion
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("newPayment.accNumbIc").substring(5)));
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("newPayment.accSortiBan").replaceFirst("(\\d{2})(\\d{2})(\\d+)", "$1-$2-$3")));
        }
        receiptCloseButton.waitUntilVisible();
        clickElement(receiptCloseButton);

    }
    public void userVerifiesTheDetailsInReprint(WebElementFacade alterPayerDetailsOnMandate, WebElementFacade receiptCloseButton){
        final String AltPayDetailsOnMandate = alterPayerDetailsOnMandate.getText();

        if (testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            logger.info("iBan:"+testDataManager.getTestInputRegionData("newPayment.iBan").substring(14));
            logger.info("bic:"+testDataManager.getTestInputRegionData("newPayment.bIc"));
            assertTrue(alterPayerDetailsOnMandate.getText().substring(10, 20).contains(testDataManager.getTestInputRegionData("payer.alternateFirstName")));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.bIc"));
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("newPayment.iBan").substring(14)));   // commenting this step as the IBAN doesn't appear completely in the receipt
        }
        else
        {
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("newPayment.accNumbIc").substring(5)));
            assertTrue(alterPayerDetailsOnMandate.getText().contains(testDataManager.getTestInputRegionData("newPayment.accSortiBan").replaceFirst("(\\d{2})(\\d{2})(\\d+)", "$1-$2-$3")));
        }

        clickOn(receiptCloseButton);

    }
    public void userAddsNotesByUsingTabKey(String notes){
        clickElement(notesButton);
        getDriver().switchTo().activeElement().sendKeys(Keys.TAB);
        assertTrue(getDriver().switchTo().activeElement().getAttribute("id").equalsIgnoreCase("new-note-subject"));
        selectSubject.selectByIndex(1);
        getDriver().switchTo().activeElement().sendKeys(Keys.TAB);
        assertTrue(getDriver().switchTo().activeElement().getAttribute("id").equalsIgnoreCase("new-note-comment"));
        setText(notesTextBox,notes);
        getDriver().switchTo().activeElement().sendKeys(Keys.TAB);
        assertTrue(getDriver().switchTo().activeElement().getAttribute("id").equalsIgnoreCase("new-note-type"));
        notesType.selectByIndex(1);
        getDriver().switchTo().activeElement().sendKeys(Keys.TAB);
        getDriver().switchTo().activeElement().sendKeys(Keys.TAB);
        setText(notesAuthor,"CLSP");
        clickElement(addNoteButton);


    }
    public void verifiesClaimEntitlements(String entitlementType, String disabledbutton1, String enabledButton) {

        clickElement(entitlementTab);
        sunGlassesClaimDateCalendar.waitUntilClickable();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat tfs = new SimpleDateFormat("EEEEE, MMMMM d, yyyy");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 1);
        final String futureDateXpath = tfs.format(c.getTime());
        final String disabledDate = String.format(disabledbutton1,futureDateXpath);

        Calendar a = Calendar.getInstance();
        a.setTime(new Date());

        if(entitlementType.equalsIgnoreCase("Sun Glasses Discount Voucher"))
        {
            clickElement(sunGlassesClaimDateCalendar);
            a.add(Calendar.DATE, 0);
            final String todaysDate = sdf.format(a.getTime());

            final String output = tfs.format(a.getTime());
            //TODO: create webelement for date to select,need to try it with evalute javascript method as well
            final String dateToSelect = String.format(enabledButton,output);
            getDriver().findElement(By.xpath(dateToSelect)).click();//try to pass it through webelement

            clickElement(submitNewClaimDateButton);

            final String sunGlasses = "//div[text()=' Sun glasses discount voucher ']//..//span[text()='%1$s']";
            final String sunGlassesNewDate = String.format(sunGlasses, todaysDate);
            final String sunGlassesClaimDate = getDriver().findElement(By.xpath(sunGlassesNewDate)).getText();
            logger.info("transaction Status:"+sunGlassesClaimDate);

            assertEquals(sunGlassesClaimDate, todaysDate);

        }
        else if(entitlementType.equalsIgnoreCase("Spare Lenses"))
        {
            clickElement(spareLensesClaimDateCalendar);
            a.add(Calendar.DATE, -5);
            final String backDatedDate = sdf.format(a.getTime());
            logger.info("Backdated Date:"+backDatedDate);

            final String output = tfs.format(a.getTime());
            logger.info("Selected Date:"+output);
            final String dateToSelect = String.format(enabledButton,output);

            if(isElementVisible(By.xpath(dateToSelect)))
            {
                getDriver().findElement(By.xpath(dateToSelect)).click();

            }else
            {
                clickElement(previousMonthArrow);
                logger.info("Select previous Month");
                getDriver().findElement(By.xpath(dateToSelect)).click();
            }

            clickElement(submitNewClaimDateButton);

            final String spareLenses = "//div[text()=' Spare Lenses ']//..//span[text()='%1$s']";
            final String spareLensesNewDate = String.format(spareLenses, backDatedDate);
            final String spareLensesNewDateClaimDate = getDriver().findElement(By.xpath(spareLensesNewDate)).getText();
            logger.info("transaction Status:"+spareLensesNewDateClaimDate);
            assertEquals(spareLensesNewDateClaimDate, backDatedDate);

        }
        else if(entitlementType.equalsIgnoreCase("Aftercare"))
        {
            clickElement(aftercareClaimDateCalendar);
            a.add(Calendar.DATE, -15);
            final String backDatedDate = sdf.format(a.getTime());
            logger.info("Backdated Date:"+backDatedDate);

            String output = tfs.format(a.getTime());
            logger.info("Selected Date:"+output);
            final String dateToSelect = String.format(enabledButton,output);

            if(isElementVisible(By.xpath(dateToSelect)))
            {
                getDriver().findElement(By.xpath(dateToSelect)).click();

            }else
            {
                clickElement(previousMonthArrow);
                logger.info("Select previous Month");
                getDriver().findElement(By.xpath(dateToSelect)).click();
            }

            clickElement(submitNewClaimDateButton);

            final String aftercare = "//div[text()=' Aftercare ']//..//span[text()='%1$s']";
            final String spareLensesNewDate = String.format(aftercare, backDatedDate);
            final String aftercareClaimDate = getDriver().findElement(By.xpath(spareLensesNewDate)).getText();
            logger.info("transaction Status:"+aftercareClaimDate);
            assertEquals(aftercareClaimDate, backDatedDate);
        }
        else
        {
            clickElement(freeGlassesClaimDateCalendar);
            assertFalse(!isElementVisible(By.xpath(disabledDate)));
            a.add(Calendar.DATE, 0);
            final String todaysDate = sdf.format(a.getTime());
            logger.info("Todays Date:"+todaysDate);

            final String output = tfs.format(a.getTime());
            logger.info("Selected Date:"+output);
            final String dateToSelect = String.format(enabledButton,output);
            getDriver().findElement(By.xpath(dateToSelect)).click();

            clickElement(submitNewClaimDateButton);

            final String freeGlasses = "//div[text()=' Free glasses voucher ']//..//span[text()='%1$s']";
            final String freeGlassesNewDate = String.format(freeGlasses, todaysDate);
            final String freeGlassesClaimDate = getDriver().findElement(By.xpath(freeGlassesNewDate)).getText();
            logger.info("transaction Status:"+freeGlassesClaimDate);
            assertEquals(freeGlassesClaimDate, todaysDate);
            a.add(Calendar.YEAR, 2);
            final  String nextAvailableClaimDate = sdf.format(a.getTime());
            logger.info("nextAvailableClaimDate:"+nextAvailableClaimDate);
            assertEquals(nextAvailableEntitlementDate.getText().substring(15), nextAvailableClaimDate);
        }

    }
    public void clickOnChangeFirstPackAddress() {
        clickElement(subscriptionTab);
        clickEditSubscription();
        clickElement(firstChangeLink.get(0));
        clickElement(addressBookButton);

    }
    public void userVerifiesPaymentMethod(WebElementFacade mandateReflabel) {

        assertEquals(PaymentPage.mandateReference, mandateReflabel.getText().substring(19));

    }
    public void clickCustomerSearchButton(){
        clickOn(customerSearch);
        waitABit(3000);
    }
    public void userVerifiesNextPaymentAndDeliveryDate(){
        assertElementText(nextPaymentDate,"N/A");
        assertElementText(nextPaymentAmount,"N/A");
        assertElementText(nextDeliveryDate,"N/A");
    }
    public void navigateToManagePaymentTab() {
        managePaymentMethodTab.waitUntilClickable();
        clickElement(managePaymentMethodTab);
    }
    public void verifyReplaceButtonDisabled() {
        assertObjectIsNotInteractable(replaceButton);
    }
    public void userClicksOnBookAppointmentButtonAndVerify() {

        assertEquals(getDriver().getTitle(), clspTitle);
        waitFor(bookAppointment);
        clickElement(bookAppointment);
        waitForPageLoader();
        switchToChildWindow();
        logger.info(testDataManager.getTestInputCommonData("login.StoreName").toLowerCase().replace(" ", ""));
        assertTrue(getDriver().getCurrentUrl().contains(testDataManager.getTestInputCommonData("login.StoreName").toLowerCase().replace(" ", "")));
        bookAppointmentLogo.waitUntilVisible();
        assertPageObjectIsDisplayed(bookAppointmentLogo);
        switchToOriginalWindow();
        waitForPageLoader();
        assertEquals(getDriver().getTitle(), clspTitle);

    }
    public void userDeletesAddress(List packAddressList) {

        clickElement(addressBook);
        final String alternateAddress = altrAddressCustomerDashboard.getText().replaceAll("[\r\n]+", " ");
        clickElement(deleteAddress);
        assertElementText(labelDeleteAddress,"Delete Address");
        assertElementText(deleteAddressAlertMessage,"Are you sure you want to delete this address?");
        assertElementText(cancelButton,"Cancel");
        clickElement(confirmButton.get(0));

        for (int i=0;i<packAddressList.size();i++){
            logger.info("Actual address packAddress "+packAddressList.get(i));

            if((packAddressList.get(i)).equals(alternateAddress)){
                final String deleteAddress = errorAlertMsg.getText().replaceAll("[\r\n]+", " ");
                assertTrue(deleteAddress.equalsIgnoreCase("420 - Address is in use - Cannot delete an address that is associated to an pending or active payment instruction. Dismiss"));
                break;
            }
            else{
                assertTrue(!errorAlertMsg.isVisible());
            }
        }
    }
    public void addNewAddressForBFPO() {
        waitFor(addressBook);
        clickElement(addressBook);
        defaultAddress = fullDefaultAddress.getText().replaceAll("[\r\n]+", " ");
        logger.info("Default address :"+defaultAddress);
        assertPageObjectIsDisplayed(addNewAddress);
        clickElement(addNewAddress);
        assertPageObjectIsDisplayed(headerTitle);
        selectCountry.selectByVisibleText("BFPO");
        setText(serviceName,testDataManager.getTestInputRegionData("address.number"));
        setText(addrLineOne,testDataManager.getTestInputRegionData("address.addressLine"));
        setText(town,testDataManager.getTestInputRegionData("address.town"));
        setText(bfpoPostcode,testDataManager.getTestInputRegionData("address.postcode"));

        assertFalse(defaultAddressCheckbox.isVisible());
        clickElement(addNewAddressButton);

    }
    public void turnOnTheCustomerCareAlertAndAlternateContactAlert() {

        assertPageObjectIsDisplayed(alternatePayerIcon);
        clickElement(alternatePayerIcon);
        assertPageObjectIsDisplayed(turnOnLink);
        clickElement(turnOnLink);
        assertPageObjectIsDisplayed(blueAlert);
        assertPageObjectIsDisplayed(customerCareIcon);
        clickElement(customerCareIcon);
        assertPageObjectIsDisplayed(turnOnCustomerCareLink);
        clickElement(turnOnCustomerCareLink);
        assertPageObjectIsDisplayed(redAlert);
    }

    public void toReLoadCustomerAndVerifyBothTheAlertShouldBeTurnedOn() {
        waitFor(blueAlert);
        waitFor(redAlert);
        assertPageObjectIsDisplayed(blueAlert);
        assertPageObjectIsDisplayed(redAlert);
    }

    public void toTurnOffCustomerAndAlternatePayerAlerts() {
        clickElement(blueAlert);
        resetAlternatePayer.waitUntilVisible();
        clickElement(resetAlternatePayer);
        waitFor(alternatePayerIcon);
        assertPageObjectIsDisplayed(alternatePayerIcon);

        clickElement(redAlert);
        resetCustomerCare.waitUntilVisible();
        clickElement(resetCustomerCare);
        waitFor(customerCareIcon);
        assertPageObjectIsDisplayed(customerCareIcon);
    }
    public void getAccountSummaryValue() {
        clickElement(accountSummaryValueButton);
        accountSummaryValue = accountSummaryValueButton.getText().substring(0);
        logger.info("accountSummaryValue"+accountSummaryValue);
    }
    public void verifyAccountSummaryValues(String value) {
        clickElement(accountSummaryValueButton);
        accountSummaryValue = accountSummaryValueButton.getText().substring(1);
        logger.info("accountSummaryValue"+accountSummaryValue);
        logger.info("value"+value);
        assertEquals(accountSummaryValue, testDataManager.getTestInputRegionData("monthlyNoSolutionLensData.lensCost"));
    }
    public void verifyNoteAfterWriteOff(String noteSub,String clinicalNotes,String noteType,String noteStatus1,String store_id){
        if(!notesButton.isVisible())
            clickElement(subscriptionBackButton);
        clickElement(notesButton);
        clickElement(systemButton);
        assertPageObjectIsDisplayed(customerNote.get(0));
        final String todayDate = getCurrentDateStamp();
        assertElementContainsText(noteLabel.get(0),clinicalNotes);
        assertEquals(noteTypeLabel.get(0).getText().substring(6), noteType);
        assertTrue(noteDateLabel.get(0).getText().substring(6,16).contains(todayDate));
        assertEquals(noteSubjectLabel.get(0).getText().substring(9), noteSub);


    }
    public void verifiesRefundReasonAfterPerformingHoliday(String refundReason, String noteSub, String noteType, String noteStatus, String firstPaymentStatus, String nextPaymentAmt) {

        clickElement(notesButton);
        final String todayDate = getCurrentDateStamp();
        for(int i= 0;i<noteLabel.size();i++)
            {
                logger.info("Note verified");
                assertTrue(noteLabel.get(i).getText().substring(10,15).contains(nextPaymentAmt));
                assertTrue(noteLabel.get(i).getText().substring(93).equalsIgnoreCase(refundReason.toLowerCase()));
                assertEquals(noteSubjectLabel.get(i).getText().substring(9, 36), noteSub);
                assertEquals(noteTypeLabel.get(i).getText().substring(6), noteType);
                assertTrue(noteDateLabel.get(i).getText().substring(6,16).contains(todayDate));
                }
    }
    public void userVerifiesBadDebtIcon(){
        assertPageObjectIsDisplayed(badDebtIcon);
    }
    public void userValidatesReplaceSubscription(String authCode){
        clickEditSubscription();
        clickElement(subscriptionBackButton);
        activeCLFitsTab.waitUntilClickable();
        clickElement(activeCLFitsTab);
        clickElement(showDetailsBtn.get(0));
        scrollToView(SubscribeReplaceButton);
        clickElement(SubscribeReplaceButton);
        clickElement(confirmButton.get(0));
        assertElementContainsText(replaceSubscriptionMessage,replaceWarningMessage);
        scrollToView(confirmButton.get(0));
        clickElement(confirmButton.get(0));
        if (bankAuthorisationCode.isEnabled()) {
        assertElementContainsText(bankAgreement, bankAggrementMessage);
        setText(bankAuthorisationCode, authCode);
        clickElement(bankAuthorisationProceed);
        clickElement(confirmButton.get(1));
    }else{
        assertElementContainsText(accountValidation,AccValidationMessage);
        clickElement(confirmButton.get(0));
        clickElement(confirmButton.get(1));
    }
        if (dismiss.isVisible()) {
            clickElement(dismiss);
        }
        assertElementContainsText(replaceSubscriptionAlert,replaceSubscriptionAlertMessage);
        clickElement(okButton);
        clickElement(customerSearch);
        //housekeeper issue
        waitABit(100000);
        clickElement(customerSelectBtn);
        clickElement(historyTab);
        toVerifySubscriptionStatus("CANCELLED");
        clickElement(editSubscriptionBtmMidTermReplace);
        firstDeliveryDate.waitUntilVisible();
        final String cancelDeliveryDate = firstDeliveryDate.getText();
        clickElement(subscriptionBackButton);
        clickElement(subscriptionTab);
        clickElement(editSubscriptnBtn.get(0));
        final String replaceDeliveryDate = firstDeliveryDate.getText();
        logger.info(cancelDeliveryDate);
        logger.info(replaceDeliveryDate);
        assertEquals(cancelDeliveryDate,replaceDeliveryDate);
        logger.info(paymentDate.getText());
        logger.info(LocalDate.now().plusDays(5).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        final String firstPaymentDate= LocalDate.now().plusDays(5).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        assertElementContainsText(paymentDate, firstPaymentDate);
    }
    public void validateReplacePeroxideSolution(String solutionType,String authCode){
        clickEditSubscription();
        clickElement(subscriptionBackButton);
        clickElement(activeCLFitsTab);
        clickElement(showDetailsBtn.get(0));
        scrollToView(SubscribeReplaceButton);
        clickElement(SubscribeReplaceButton);
        clickElement(confirmButton.get(0));
        solutionDropdown.waitUntilClickable();
        solutionDropdown.selectByVisibleText(solutionType.toLowerCase());
        scrollToView(confirmButton.get(0));
        clickElement(confirmButton.get(0));
        setText(authorizationCode.get(0), authCode);
        clickElement(proceedButton.get(0));
        setText(authorizationCode.get(1),authCode);
        clickElement(proceedButton.get(1));
        solutionConfirmButton.waitUntilClickable();
        clickElement(solutionConfirmButton);
        clickElement(okButton);

    }
    public void toValidateLinkFunctionality(){
        clickElement(activeCLFitsTab);
        clickElement(refresh);
        clickElement(showDetailsBtn.get(2));
        final String leftSphere = String.valueOf(sphereValue.get(2).getText());
        final String rightSphere = String.valueOf(sphereValue.get(9).getText());
        logger.info(leftSphere);
        logger.info(rightSphere);
        assertPageObjectIsDisplayed(linkButton);
        clickElement(linkButton);
        assertPageObjectIsDisplayed(fitSuccessAlert);
        if(dismiss.isVisible()) {
            clickElement(dismiss);
        }
        clickElement(subscriptionTab);
        clickElement(editSubscriptnBtn.get(1));
        clickElement(fitButton);
        logger.info(sphere.get(0).getText());
        logger.info(sphere.get(1).getText());
        assertElementContainsText(sphere.get(0),leftSphere);
        assertElementContainsText(sphere.get(1),rightSphere);
        clickElement(subscriptionBackButton);

    }
    public void userVerifiesTheSystemNotesAfterPerformingCancelPayment() {
        waitABit(2000);
        clickElement(notesButton);
        systemButton.waitUntilVisible();
        clickElement(systemButton);
        logger.info(String.valueOf(noteSubjectLabel.get(0).getText()));
        assertTrue(noteSubjectLabel.get(0).getText().equalsIgnoreCase("Subject: Payment Instruction Cancelled"));
        assertTrue(noteLabel.get(0).getText().contains("Payment Instruction Cancelled."));
    }









}
