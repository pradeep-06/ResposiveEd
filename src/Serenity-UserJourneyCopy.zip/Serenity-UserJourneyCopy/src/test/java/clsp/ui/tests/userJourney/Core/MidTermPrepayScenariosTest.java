package clsp.ui.tests.userJourney.Core;

import Framework.Annotations.CLSP.CLSP_HEALTH_CHECK;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.CLSP.CLSP_UK_CorePrepay;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;
import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class MidTermPrepayScenariosTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    UserSignUp clsp;
    @Steps
    UserCreatesAPICustomer apiObj;



    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "200,Occasional,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695170", projectId = "91768", testCaseName = "Pre Pay - Expedite a Pack - 2 COMPLETED Payments and Pack Status PENDING", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void expediteAPendingPack(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userPerformsExpeditePack();
        apiObj.userDeletesCustomer(removedStatus);
    }


    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,1,204,10,first,second"
    })

    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704644", projectId = "91768", testCaseName = "CLDG UI - When payment date is edited then all the future payment date gets affected(Select next date/Todays Date)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void createNewCustomerAndEditSubscription(int status, String dailyType, int quantity, int removedStatus, String noOfDays, String payment, String payment1) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        clsp.userUpdatesPaymentDate(noOfDays, payment1);
        clsp.userAbleToVerifyPaymentScheduleAfterEditSecondPaymentDate();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Part Time,dailyPartTimeCustomer,changeUsage"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705955", projectId = "91768", testCaseName = "Scheme Conversion - Pre pay customer wants to increase from 30 pairs each quarter to 60 pairs each quarter", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsIncreaseChangeUsage(int status, String dailyType, int quantity, int removedStatus, String newUsage,String customerType,String packUsage) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userPerformsChangeUsage(newUsage,customerType);
        apiObj.userChecksMail(customerType,quantity,packUsage);
        apiObj.userDeletesCustomer(removedStatus);
    }


    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,Occasional,dailyOccasionalCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705952", projectId = "91768", testCaseName = "Scheme Conversion - Pre pay customer wants to decrease from 90 pairs each quarter to 30 pairs each quarter", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsDecreaseChangeUsage(int status, String dailyType, int quantity, int removedStatus, String newUsage,String customerType) {
        apiObj.userCreatesDailyCust(dailyType, quantity,  status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userPerformsChangeUsage(newUsage,customerType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_HEALTH_CHECK
    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704599", projectId = "91768", testCaseName = "Jira-1206_Add GDPR button to the frontend", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userClickAndVerifyGDPRButton(int status, int removedStatus) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClicksOnGDPRButtonAndVerifiesGDPRConsentAppIsOpened();
        apiObj.userDeletesCustomer(removedStatus);
    }


    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,1,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707565", projectId = "91768", testCaseName = "Create Subscription - Add alternate payer - Confirm and verify the payer details", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCreateSubscriptionAddAlternatePayer(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClicksOnManagePaymentAndAddAlterPaymentDetails();
        clsp.userClicksOnEditAlternatePayerAndVerifiesThePopulatedData();
        apiObj.userDeletesCustomer(removedStatus);

    }


    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704633", projectId = "91768", testCaseName = "DF-1454_Payment Method - Is enabled for Contact Centre - But they should not be able to change it.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifiesReplaceButton(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity,  status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesPaymentReplaceAndAltPayerBtnIsDisabled();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706535", projectId = "91768", testCaseName = "DF-1546_Payment Method - When replacing an existing payment method adding an alternate payer the original address is displayed on the DD Mandate rather than the Alt Payers address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplaceAndAddAlternatePayer(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity,  status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesPaymentDetails();
        clsp.userClicksOnManagePaymentAndAddAlterPaymentDetails();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706678", projectId = "91768", testCaseName = "DF-1537_Payment Method - Alt Payer - I am able to add an alt payer to an existing payment method without replacing the method itself (Existing Sub)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAddsAndRemovesAlternatePayer(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity,  status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesConfirmButtonUponAddingAndRemovingAlternatePayer();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,NONE,FullTime,dailyFullTimeCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706937", projectId = "91768", testCaseName = "Pre Pay - Update Usage - Monthly", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userUpdateUsageMonthly(int status, String dailyType, int quantity, int removedStatus, String firstPack, String newPackage, String customerType) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPackageForDailyCustomer(newPackage, customerType);
        clsp.userVerifyPaymentScheduleAfterUpdatingUsage(customerType);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698348", projectId = "91768", testCaseName = "Create Subscription - Add alternate payer details - Click Confirm (DO NOT ADD) - Try to remove the recently added alternate payer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyAfterRemovingAlternatePayer(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTryToFillTheAddAlternatePayerDetails();
        clsp.userTryToRemoveTheNewlyAddedAlternatePayer();
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698356", projectId = "91768", testCaseName = "Existing Subscription - Verify the reprint button and verify the details", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyReprintButtonAndDetails(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesPaymentDetails();
        clsp.userClicksOnManagePaymentAndAddAlterPaymentDetails();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTryToReprintTheMandate();
        clsp.userShouldBeAbleToVerifyTheAlternatePayerAndMandateReference();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,1,204,Full Time,Occasional,dailyFullTimeCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695201", projectId = "91768", testCaseName = "PREPAY- Update usage for customer - ONLY SINGLE PACK", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userUpdateCustomerSinglePackUsage(int status, int quantity,  int removedStatus, String newPackage, String dailyType, String customerType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDailyPackageDetails(dailyType);
        clsp.userUpdateDailyPackage(newPackage);
        clsp.userVerifyPaymentScheduleAfterUpdatingUsage(customerType);
        apiObj.userDeletesCustomer(removedStatus);
    }


    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Testing"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698374", projectId = "91768", testCaseName = "Tab functionality Test while adding a note", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAddsNoteForTabFunctionality(int status, String dailyType, int quantity, int removedStatus,  String notes) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToAddANewNote(notes);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,No solution,Occasional,dailyOccasionalCustomer,FullTime,dailyFullTimeCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698405", projectId = "91768", testCaseName = "CLSP-MID-05 - Update Usage - Daily - 10 and switch to - 30.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userUpdateUsageAndSwitch(int status, String dailyType, int quantity,  int removedStatus, String solutionType, String newPackage, String customerType, String newPackage1, String customerType1) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userSelectsPackageTabFromDashboardAndVerifyPackageDetails(solutionType);
        clsp.userUpdatesPackageForDailyCustomer(newPackage, customerType);
        clsp.userUpdatesPackageForDailyCustomer(newPackage1, customerType1);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,aa445,holiday,dailyPartTimeCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698472", projectId = "91768", testCaseName = "CLSP-MID-34 - Expedite a Pack - NEGATIVE - UI Validation (Holiday Pack)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userExpediteHolidayPack(int status, String dailyType, int quantity, int removedStatus,  String pack, String authorizationCode,String packUsage,String customerType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        apiObj.userChecksMail(customerType,quantity,packUsage);
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Processing"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698502", projectId = "91768", testCaseName = "CLSP-MID-34 - Expedite a Pack - NEGATIVE - UI Validation (Processing Pack)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userExpediteProcessingPack(int status, String dailyType, int quantity, int removedStatus,  String packStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Sun Glasses Discount Voucher,Spare Lenses,Aftercare,Free Glasses Voucher"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698535", projectId = "91768", testCaseName = "CLSP-UI-22 - Mid-Term Entitlements Tab", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyEntitlementsTab(int status, String dailyType, int quantity, int removedStatus,  String entitlementType, String entitlementType1, String entitlementType2, String entitlementType3) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClaimsEntitlements(entitlementType);
        clsp.userClaimsEntitlements(entitlementType1);
        clsp.userClaimsEntitlements(entitlementType2);
        clsp.userClaimsEntitlements(entitlementType3);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,address,Return,In Person",
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705834", projectId = "91768", testCaseName = "Changing contact details Delivery address from Schedule for one delivery only & Address is in the drop down_Amending Permission to speak with a Thrid Party", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangesContactAndDeliveryDetails(int status,  int removedStatus, String addressType, String noteSub, String noteType) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userShouldBeAbleToChangeHisAddressForSelectivePack();
        clsp.userClicksOnBackButton();
        clsp.userHighlightAdditionalContactButton();
        clsp.userVerifiesAdditionalContactButtonHighlighted(noteSub, noteType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Return,Phone Call"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705888", projectId = "91768", testCaseName = "Adding a Closed Note for Store Action_Store Closed Clinical Query", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAddsNoteToStore(int status, String dailyType, int quantity, int removedStatus,  String noteSub, String noteType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToAddAndCloseNoteToSubscription(noteSub, noteType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Clinical,Email"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705944", projectId = "91768", testCaseName = "Adding an Open Note for Store Action_Store action open Clinical", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAddsNoteToOpenStore(int status, String dailyType, int quantity, int removedStatus,  String noteSub, String noteType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToAddAndCloseNoteToSubscription(noteSub, noteType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706400", projectId = "91768", testCaseName = "Searching for a customer_Customer search - Name (Surname and Forename) Positive", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userSearchCustomerSurname(int status,  int removedStatus) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.isOnTheContactCenterCustomerSearchPage();
        clsp.userTryingToSearchExistingCustomerUsingCorrectSurname();
        clsp.userWillSeeListOfCustomersWhoHaveMatchingDetails();
        clsp.userTryingToSearchExistingCustomerUsingCorrectForename();
        clsp.userWillSeeListOfCustomersWhoHaveMatchingDetails();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706406", projectId = "91768", testCaseName = "Searching for a customer_Customer search customer ID Positive", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userSearchPositiveCustomerId(int status,  int removedStatus) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.isOnTheContactCenterCustomerSearchPage();
        clsp.userTryingToSearchExistingCustomerUsingCorrectCustomerId();
        clsp.userWillSeeListOfCustomersWhoHaveMatchingDetails();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706413", projectId = "91768", testCaseName = "To test Store ID is displayed properly.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyStoreID(int status,  int removedStatus) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsAbleToVerifyStoreID();
        clsp.userRetrievesHubServiceAndCarrierAndFHDetails();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "%,_,[,],^,must not contain % _ [ ] or ^"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706420", projectId = "91768", testCaseName = "Customer Search - Last Name, First Name and Postcode should not accept invalid characters - DF-1335", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyInvalidCharacters(String percentage, String underscore, String leftSquare, String rightSquare, String caret, String errorMsg) {
        clsp.isOnTheContactCenterCustomerSearchPage();
        clsp.validateSpecialCharacters(percentage, underscore, leftSquare, rightSquare, caret, errorMsg);
        clsp.validateSpecialCharactersCombine(percentage, underscore, leftSquare, rightSquare, caret, errorMsg);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706432", projectId = "91768", testCaseName = "Verify and confirm functioning of Clear all button DF-1334", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyClearAllFunctionality(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.isOnTheContactCenterCustomerSearchPage();
        clsp.verifyClearAllFn();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,dailyOccasionalCustomer"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706478", projectId = "91768", testCaseName = "CLDGUAT02_Verification of Pre pay subscription Schedule as per Business rules for Daily Lenses", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifySubscriptionSchedule(int status, String dailyType, int quantity, int removedStatus,  String customerType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesThePackAndPaymentStatusForAllPacksInSchedule(customerType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,0,Too Expensive,First,aa445",
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42708779", projectId = "91768", testCaseName = "UAT_012_Lensmail_Fulfillment method changed to store fulfillment_Cancel subscription before collection_No change usage allowed", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangesFulfillment(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason,String pack,String authorizationCode) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformStoreFullFilMent();
        clsp.userClicksOnBackButton();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userClickOnEditSubscription();
        clsp.userVerifyUpdatePackageButtonIsDisabled();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Processing"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42708831", projectId = "91768", testCaseName = "Complete 2 payments and pack should have status as processing and verify collected option", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyCollectedOption(int status, String dailyType, int quantity, int removedStatus,  String packStatus) {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformStoreFullFilMent();
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesSelectActionDropdownIsDisabled();
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,second,No"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42708840", projectId = "91768", testCaseName = "CR_0068_Change Pack Delivery Date_Release to Supply Chain Date updated", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangesDeliveryDateOfSupplyChain(int status, String dailyType, int quantity, int removedStatus,  String payment, String futurePack) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToUpdateChangePackDeliveryDate(payment, futurePack);
        clsp.userVerifySupplyChainDate();
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,third,Yes"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42708841", projectId = "91768", testCaseName = "CR_0068_Change Pack Delivery Date_Outside Date Range", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangesDeliveryDateOfThirdPayment(int status, String dailyType, int quantity, int removedStatus,  String payment, String futurePack) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToUpdateChangePackDeliveryDate(payment, futurePack);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709149", projectId = "91768", testCaseName = "DF-1777_CR0075 - search by mandate ID", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userSearchCustomerByMandate(int status, String dailyType, int quantity, int removedStatus,  String paymentType)  {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesStoreCustomerSearchPageAndFindsCustomerByMandateId();
        clsp.userNavigatesToManagePaymentAndVerifiesPaymentMethod(paymentType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,2,204,Holiday,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709208", projectId = "91768", testCaseName = "1690_Reinstate the pack that have a refund_Negative", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReinstatePackWithNegativeRefund(int status, String dailyType, int quantity, int removedStatus,  String paymentStatus, String pack,String authorizationCode)  {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        clsp.userVerifiesPaymentStatusAfterPerformingHoliday(paymentStatus);
        clsp.userReinstateHolidayPack();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,Missing,Replace Store Charge,Damaged Full,Damaged Partial,1 Box,1 Box,0 Boxes,0 Boxes"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709254", projectId = "91768", testCaseName = "CLSP-MID-11 - Request a Replacement Pack - All Monthly Combinations", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForAllMonthlyCombinations(int status, int removedStatus,  String replaceReason, String replaceReason2, String replaceReason3, String replaceReason4, String leftboxQty, String rightboxQty, String lBoxQty, String rBoxQty) {
        apiObj.userCreatesMonthlySolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformReplacePackForMonthlySolutionToNoSolution(replaceReason2, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformReplacePackForMonthlySolutionToNoSolution(replaceReason3, lBoxQty, rightboxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformReplacePackForMonthlySolutionToNoSolution(replaceReason4, leftboxQty, rBoxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, lBoxQty, rBoxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,Incorrect Contents Full,3 Boxes,3 Boxes"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709343", projectId = "91768", testCaseName = "Pre Pay - Request a Replacement Pack - Full Pack - Incorrect Goods - No Charge.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForFullPack(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,Incorrect Contents Partial,1 Box,0 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709351", projectId = "91768", testCaseName = "Pre Pay - Request a Replacement Pack - Partial Pack Â– Incorrect Goods - No Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForPartialPack(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,2,204,Replace Store Charge,2 Boxes,2 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709355", projectId = "91768", testCaseName = "Pre Pay - Request a Replacement Pack - Full Pack - Replace Store Charge Â– Store Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForFullPackStoreCharge(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Incorrect Contents Partial,1 Box,0 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709506", projectId = "91768", testCaseName = "Pre Pay - Request a Replacement Pack - Partial Pack - Replace Store Charge A– Store Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForPartialPackStoreCharge(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Damaged Full,1 Box,1 Box,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709518", projectId = "91768", testCaseName = "Pre Pay - Request a Replacement Pack - Full Pack - Not Arrived or Damaged - Lensmail Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForFullPackLensMailCharge(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Damaged Partial,1 Box,0 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709555", projectId = "91768", testCaseName = "Pre Pay - Request a Replacement Pack - Partial Pack - Not Arrived or Damaged - Lensmail Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForPartialPackLensMailCharge(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Damaged Partial,1 Box,0 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709592", projectId = "91768", testCaseName = "CLSP-MID-18 - Request a Replacement Pack -Entitlement - Store Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForEntitlementStoreCharge(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        clsp.userClickOnEditSubscription();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,Damaged Partial,1 Box,0 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695919", projectId = "91768", testCaseName = "CLSP-MID-12 - Request a Replacement Pack - Monthly No Solutions", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForMonthlyNoSolution(int status, int removedStatus, String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesMonthlySolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Damaged Full,1 Box,1 Box,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704569", projectId = "91768", testCaseName = "Complete 2 payments and perform store fullfillment and perform replacement", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformFulFillMentAndReplacement(int status, String dailyType, int quantity, int removedStatus, String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformStoreFullFilMent();
        clsp.userClicksOnBackButton();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704577", projectId = "91768", testCaseName = "Customer Search button should return to the results to improve usability", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyCustomerIdSearchButton(int status,  int removedStatus) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClicksOnSearchButton();
        clsp.userFindCustomerIDAppearingOnSearchField();
        clsp.userClickOnEditSubscription();
        clsp.userClicksOnSearchButton();
        clsp.userFindCustomerIDAppearingOnSearchField();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,PRE"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704582", projectId = "91768", testCaseName = "Process a FIT Expiry - Customer DOES NOT take a new subscription - Blanks displayed on the Customer Dashboard for Next Payment Amount and Next Delivery", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPaymentAndDeliveryDate(int status, String dailyType, int quantity, int removedStatus, String payerType) {
        apiObj.userCreatesDailyCustomerSubscriptionWithCompletedPacks(dailyType, quantity, status, payerType);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesNextPaymentAndDeliveryDateOnCustomerDashboard();
        clsp.userClickOnEditSubscription();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704584", projectId = "91768", testCaseName = "CLDG-SIT-UI-DCLDG-GENERAL- CLDG-SIT-UI-DCLDG-GENERAL- Browser Navigation - Using the browser back button is breaking the UI.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyBrowserBackButton(int status, String dailyType, int quantity, int removedStatus)  {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userClicksOnBackArrowButtonOnBrowser();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,15,second"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704637", projectId = "91768", testCaseName = "DF - 1232 CLDG-SIT-UI-DCLDG-GENERAL- Edit Payment Date - I am unable to move a payment date by more than 1 calendar month/ DF - 1490", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userEditFirstPaymentUpToMaxDate(int status, String dailyType, int quantity, int removedStatus,  String noOfDays, String payment1) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPaymentDate(noOfDays, payment1);
        clsp.userTriesToEditFirstPaymentDateUpToMaxDate();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,10,first"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704644", projectId = "91768", testCaseName = "CLDG UI - When payment date is edited then all the future payment date gets affected(Select Previous Date)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userEditFirstPaymentForPreviousDate(int status, String dailyType, int quantity, int removedStatus,  String noOfDays, String payment) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,Damaged Partial,1 Box,0 Boxes,0 Boxes,0 Boxes"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704667", projectId = "91768", testCaseName = "CLDG-SIT-UI-DCLDG-GENERAL- Replacements - Creating a replacement for Solution only breaks the UI", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForMonthlySolution(int status, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String lBoxQty, String rBoxQty) {
        apiObj.userCreatesMonthlySolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, lBoxQty, rBoxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformReplacePackForMonthlySolutionToNoSolution(replaceReason, leftboxQty, rBoxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706475", projectId = "91768", testCaseName = "Defect_Jira-1180_01_Manage Payment Methods_Payment status is Processing", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifiesManagePaymentStatus(int status, int removedStatus) {
        apiObj.userCreatesMonthlySolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThePaymentStatus();
        clsp.userVerifiesReplaceButton();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,0,Cash Buyer,PRE,PENDING"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707221", projectId = "91768", testCaseName = "Canceling a scheme the customer has a zero balance but has multiple subscriptions", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelPackForMultipleSubscription(int status, String dailyType, int quantity, int removedStatus, int cancelDays, String reason, String payerType, String subStatus) throws Exception {
        apiObj.createMultipleSubscriptionForDailyCustomer(dailyType, quantity, status, payerType);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userClicksOnSubscriptionTab();
        clsp.userMustBeAbleToVerifyStatusOfOtherSubscription(subStatus);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,second,Yes"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707246", projectId = "91768", testCaseName = "CR_0068_Change Pack Delivery Date_All Future Packs", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangesPackFutureDeliveryDate(int status, String dailyType, int quantity, int removedStatus,  String payment, String futurePack) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToUpdateChangePackDeliveryDate(payment, futurePack);
        clsp.userVerifySupplyChainDate();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,NONE,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707337", projectId = "91768", testCaseName = "1690_Allow holidaying a pack with pending payments and reinstate the pack", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReinstateHolidayPack(int status, String dailyType, int quantity, int removedStatus, String pack,String authorizationCode) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        clsp.userReinstateHolidayPack();
        clsp.userVerifyPacksStatus();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,address,Incorrect Contents Partial,1 Box,0 Boxes,"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707535", projectId = "91768", testCaseName = "CLSP-MID-14 - Request a Replacement Pack - DAILY - PART TIME + NEW ADDRESS.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAddsAddressForReplacementPack(int status, String dailyType, int quantity, int removedStatus,  String addressType, String replaceReason, String leftboxQty, String rightboxQty) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Clinical,In Person"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707576", projectId = "91768", testCaseName = "1853_CC users should be able to set the store notification to trigger based on the selected CLSP note type", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userSetStoreNotificationNoteType(int status, String dailyType, int quantity, int removedStatus,  String noteSub, String noteType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToAddAndCloseNoteToSubscription(noteSub, noteType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,Clinical,Email"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707818", projectId = "91768", testCaseName = "1853_6_When store user logs into the CLSP UI and access customer account and clicks on the Notes tab then create notification option within the New Note section should not be available", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifiesNewNoteType(int status, String dailyType, int quantity, int removedStatus,  String noteSub, String noteType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToAddAndCloseNoteToSubscription(noteSub, noteType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,10,Medical Health Laser,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707828", projectId = "91768", testCaseName = "Future dated cancellation when pack dispatched and payments completed ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelPackForDispatched(int status, String dailyType, int quantity, int removedStatus, int cancelDays, String reason,String packStatus) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status,packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707829", projectId = "91768", testCaseName = "Verify Book Appointment button and Verify Book Appointment Opens in New Window", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyBookAppointment(int status,  int removedStatus) {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifiesTheBookAppointmentPageIsOpened();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,10,Medical Health Laser"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707906", projectId = "91768", testCaseName = "Future dated cancellation when pack and payments are pending immediate cancel", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelPackForFutureDate(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,25,Oversupply"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707910", projectId = "91768", testCaseName = "Future dated cancellation when pack Pending 1 Payment Complete Cancel Before 2 Payment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelPackForPaymentCompleted(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,80,Moving"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707930", projectId = "91768", testCaseName = "Future dated cancellation when pack Pending 1 Payment Complete Cancel After 3 Payment.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userCancelPackForOnePaymentCompleted(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,PartTime,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707943", projectId = "91768", testCaseName = "Delete a BFPO address associated to a pending fulfilment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userDeleteBFPOAddress(int status, int removedStatus,  String addressType) {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userDeleteAddress();
        clsp.userAddANewAddressForBFPO();
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.userDeleteAddress();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,address,Dispatched,0,Too Expensive"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707955", projectId = "91768", testCaseName = "Delete a address from Cancelled subscription", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userDeleteCanceledSubscription(int status, int removedStatus,  String addressType, String packStatus, int cancelDays, String reason) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userDeleteAddress();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,address,PRE,Incorrect Contents Full,2 Boxes,2 Boxes,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707974", projectId = "91768", testCaseName = "Multiple subscription delete a existing delivery address of Sub 1 from Sub 2", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userDeleteMultipleSubscription(String dailyType, int quantity, int status, int removedStatus, String addressType, String payerType, String replaceReason, String leftboxQty, String rightboxQty, String pack, String authorizationCode)  {
        apiObj.createMultipleSubscriptionForDailyCustomer(dailyType, quantity, status, payerType);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userDeleteAddress();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695137", projectId = "91768", testCaseName = "Pre Pay - Update Customer Care and Third Party Authorisation Indicators", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userUpdatesCustomerCareAndThirdPartyAuthorization(int status, String dailyType, int quantity, int removedStatus) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTurnOnTheCustomerCareAlertAndAlternateContactAlert();
        clsp.userVerifyBothTheAlertShouldBeTurnedOn();
        clsp.userAbleToTurnOffBothTheAlerts();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695175", projectId = "91768", testCaseName = "Create Subscription with in Flight Pack - launch the store URL and verify the Replace button is disabled ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifiesDisabledButton(int status, int removedStatus) {
        apiObj.userCreatesMonthlySolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesManagePaymentMethod();
        clsp.userVerifiesReplaceButton();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695164", projectId = "91768", testCaseName = "CLSP-MID-44  - Edit Payment Date - Bank Holiday", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userEditPaymentDateForBankHoliday(int status, int removedStatus) throws Exception {
        apiObj.userCreatesMonthlyNoSolutionBankHolidayPostPay(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesPaymentSchedule();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695188", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for New Subscription- Pending/Holiday Packs - Daily Customer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForNewSubscription(int status, String dailyType, int quantity, int removedStatus,  String pack, String authorizationCode) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,Missing,2 Boxes,2 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42697932", projectId = "91768", testCaseName = "Replace pack with add the new address to the pack and apply it to all the future pack", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackWithNewAddress(String dailyType, int quantity, int status, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userClicksOnBackButton();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.userVerifiesReplacedPackStatusOnPackageTab();
        clsp.userVerifiesReplacedPackDeliveryAddress();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698314", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for New Subscription- Completed/Pending Packs - Daily Customer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForCompletedPayment(String dailyType, int quantity, int status, int removedStatus) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesCompletedPaymentStatus();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698334", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for New Subscription - Pending Packs - After Changing Delivery Address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForPendingPack(String dailyType, int quantity, int status, int removedStatus,  String addressType) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userToVerifyPrintScheduleReciept();
        clsp.userClicksOnBackButton();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,FullTime,2,Missing,0 Boxes,0 Boxes,1 Box,1 Box"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710208", projectId = "91768", testCaseName = "CLSP-MID-13 - Request a Replacement Pack - DAILY - FULL TIME", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForDailyFullTime(int status, int removedStatus, String dailyType, int quantity,  String replaceReason, String leftboxQty, String rightboxQty, String leftboxQty1, String rightboxQty1) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty1);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty1, rightboxQty);
        clsp.userMustBeAbleToVerifyTheBoxQuantity();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204,Occasional,2,dailyOccasionalCustomer,Other,Phone Call"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705946", projectId = "91768", testCaseName = "Ability to view the rx which was linked to the subscription for a customer on multiple subscriptions", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAbleToViewRX(int status, int removedStatus, String dailyType, int quantity,  String customerType, String noteSub, String noteType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userSelectsCLFITTabAndVerifyFITDetails(customerType);
        clsp.userClicksOnBackButton();
        clsp.userTriesToAddAndCloseNoteToSubscription(noteSub, noteType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,0,Comfort Issues"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42697707", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for Cancelled Subscription under History Tab", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleInHistoryTab(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,0,Deceased"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704565", projectId = "91768", testCaseName = "PREPAY - Verify Print Schedule for Completed/Cancelled Subscription under History Tab  ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintSchedulePaymentCompletedInHistoryTab(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,FullTime,2,204,Damaged Partial,1 Box,1 Box,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704567", projectId = "91768", testCaseName = "PREPAY - Verify Print Receipt (Select Action Dropdown) for Replacement Pack under Replacement Tab", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintReceiptForReplacement(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesPrintReceiptNotVisibleUnderReplacementTab();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,1,204,PartTime,Occasional,dailyPartTimeCustomer,dailyOccasionalCustomer,Dispatched,Processing"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704651", projectId = "91768", testCaseName = "DF - 1940 Changing the package and again change to the original package", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangePackageToOriginal(int status, int quantity,  int removedStatus, String newPackage, String dailyType, String customerType, String oldCustomerType, String packStatus, String secondPackStatus) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDailyPackageDetails(dailyType);
        clsp.userUpdatesPackageForDailyCustomer(newPackage, customerType);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        apiObj.userUpdatesTheSecondPackStatus(secondPackStatus, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdatesPackageForDailyCustomer(dailyType, oldCustomerType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,address,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706959", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for Existing Subscription - 1 Pack Completed - After Changing Delivery Address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleAfterChangingAddress(String dailyType, int quantity, int status, int removedStatus,  String addressType, String packStatus) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userToVerifyPrintScheduleReciept();
        clsp.userClicksOnBackButton();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707186", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for Existing Subscription - Perform Early Pack Request and validate Delivery Date in Print", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForEarlyPackRequest(int status, int removedStatus) throws Exception {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userPerformsExpeditePack();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707902", projectId = "91768", testCaseName = "CR-0089-Select BFPO as a territory-Alternative payer address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userSelectsBFPOAddress(int status, String dailyType, int quantity, int removedStatus,  String addressType) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddANewAddressForBFPO();
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE

    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,Second,Third"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705956", projectId = "91768", testCaseName = "Scheme Holiday For two packs pre pay And Taking a customer off a scheme holiday_Change of customer salutation, email address and tel", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userTakingCustomerOffSchemeHoliday(int status, String dailyType, int quantity, int removedStatus,  String packOne, String packTwo, String packThree)  {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, packOne);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, packTwo);
        apiObj.userUpdatesFirstPackDueDateToTodayDate(status, packThree);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userAppliesHolidayForMaximumPacksInSubscription();
        clsp.userTakingCustomerOffSchemeHolidayAndVerifyIt();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @ParameterizedTest
    @CsvSource({
            "204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42705956", projectId = "91768", testCaseName = "Delete Customer from Env", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userDeletesCustomer(String status) throws Exception {
        apiObj.userDeletesCustomerFromEnv(status);

    }
    @AfterEach
    @CLSP_SMOKE

    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose(){
        driver.quit();
    }


}
