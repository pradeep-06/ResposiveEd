package clsp.ui.tests.UK;

import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.CLSP.CLSP_UK_PDF;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class UK_PDF_VerificationTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    UserSignUp clsp;

    UserCreatesAPICustomer apiObj = new UserCreatesAPICustomer();

    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100156,dailyPartTimeCustomer,1000167,Peterson,Deliver to Home,158,PRE,address,kihtPC,Home"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42746705", projectId = "91768", testCaseName = "Pre Pay - Change Customer Details - Contact Centre or Treasury User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userChangeCustomerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String authCode, String fulfilmentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userClickOnConfirmButton();
        clsp.userEntersPaymentDetailsAndPrintsMandate(customerName, customerID, authCode);
        clsp.userVerifySummaryPageWithPrintSummary(customerID,customerType,customerName,deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userSelectsTheAddressBookAndAddANewAddress(addressType);
        clsp.userEditsCustomerContactInformation();
        clsp.verifyCustomerDetailsOnAddressBookTab();
        clsp.userShouldBeAbleToChangeHisAddressForSelectivePack();
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev AllPurpose,204,100125,montlySolutionCustomer,1000137,Backham,Deliver to Home,127,PRE,kihtPC,Home"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724384", projectId = "91768", testCaseName = "Pre Pay - Monthly - No Solution", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createMonthlyCustomer(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode, String fulfilmentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.userEntersPaymentDetailsAndPrintsMandate(customerName, customerID, authCode);
        clsp.userVerifySummaryPageWithPrintSummary(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,101120,non-Quarterly,1001209,Mr Johnn,Deliver to Store,1206,PRE,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Creating and validating the non-quarterly subscription", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createAndVerifyNonQuarterlySubscription(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.userEntersPaymentDetailsAndPrintsMandate(customerName, customerID, authCode);
        clsp.userVerifySummaryPageWithPrintSummary(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,101068,non-LensMail,1001152,Mr James,Deliver to Home,1141,PRE,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Creating and validating the non-Lens mail subscription", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createAndVerifyNonLensMailSubscription(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.userEntersPaymentDetailsAndPrintsMandate(customerName, customerID, authCode);
        clsp.userVerifySummaryPageWithPrintSummary(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,Damaged Partial,1 Box,0 Boxes,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709592", projectId = "91768", testCaseName = "CLSP-MID-18 - Request a Replacement Pack -Entitlement - Store Charge", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userReplacePackForEntitlementStoreCharge(int status, String dailyType, int quantity, int removedStatus,  String replaceReason, String leftboxQty, String rightboxQty, String addressType) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        clsp.userClickOnEditSubscription();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695188", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for New Subscription- Pending/Holiday Packs - Daily Customer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForNewSubscription(int status, String dailyType, int quantity, int removedStatus,  String pack, String authorizationCode) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698314", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for New Subscription- Completed/Pending Packs - Daily Customer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForCompletedPayment(String dailyType, int quantity, int status, int removedStatus) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesCompletedPaymentStatus();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42698334", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for New Subscription - Pending Packs - After Changing Delivery Address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForPendingPack(String dailyType, int quantity, int status, int removedStatus,  String addressType) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        clsp.userClicksOnBackButton();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,0,Comfort Issues"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42697707", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for Cancelled Subscription under History Tab", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleInHistoryTab(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,0,Deceased"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42704565", projectId = "91768", testCaseName = "PREPAY - Verify Print Schedule for Completed/Cancelled Subscription under History Tab  ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintSchedulePaymentCompletedInHistoryTab(int status, String dailyType, int quantity, int removedStatus,  int cancelDays, String reason) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatExpeditePackIsNotDisplayed();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,address,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42706959", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for Existing Subscription - 1 Pack Completed - After Changing Delivery Address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleAfterChangingAddress(String dailyType, int quantity, int status, int removedStatus,  String addressType, String packStatus) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        clsp.userClicksOnBackButton();
        clsp.userAddsTheAddressInAddressBookAndClickOnConfirmButton(addressType);
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707186", projectId = "91768", testCaseName = "PREPAY- Verify Print Schedule for Existing Subscription - Perform Early Pack Request and validate Delivery Date in Print", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrintScheduleForEarlyPackRequest(int status, int removedStatus) throws Exception {
        apiObj.userCreatesMonthlyNoSolutionCust(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userPerformsExpeditePack();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,address"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42707902", projectId = "91768", testCaseName = "CR-0089-Select BFPO as a territory-Alternative payer address", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userSelectsBFPOAddress(int status, String dailyType, int quantity, int removedStatus,  String addressType) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userAddANewAddressForBFPO();
        clsp.userShouldBeAbleToChangeHisAddressForAllFuturePacks();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @AfterEach
    @CLSP_SMOKE
    @CLSP_UK_PDF
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose() {
        driver.quit();
    }
}
