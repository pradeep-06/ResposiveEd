package clsp.ui.stepDefinitions;

import clsp.ui.steps.NavigateToESuite;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class UserJourneyBacsESuite extends ScenarioSteps {

    @Steps
    NavigateToESuite navigateToESuite;

    @Step("user login in eSuite and fetch Pending Fulfillement report")
    public void userLoginInESuiteAndFetchPendingFulfillmentReport(){
        navigateToESuite.userLoginInESuiteAndFetchPendingFulfillmentReport();
    }
    @Step("user should be able to verify the Fulfillment to appear on the Report")
    public void userShouldBeAbleToVerifyTheFulfillmentToAppearOnTheReport(String dailyType) throws Exception {
        navigateToESuite.userVerifiesPendingFulfillmentReport(dailyType);
    }
    @Step("user login in Bacs and verify today's transaction")
    public void userLoginInBacsAndVerifyTransactionForTodayDate(String dailyType) throws Exception {
        navigateToESuite.userLoginInBacsAndVerifyTransactionForTodayDate(dailyType);
    }
    @Step("user login in eSuite and fetch store balance report")
    public void userLoginInESuiteAndFetchStoreBalanceReport(){
        navigateToESuite.userLoginInEsuiteAndFetchStoreBalanceReport();
    }
    @Step("user verifies store balance report")
    public void captureStoreBalanceReportData() throws Exception {
        navigateToESuite.captureStoreBalanceReportData();
    }
    @Step("user verify store balance report")
    public void verifyStoreBalanceReport() throws Exception {
        navigateToESuite.verifyStoreBalanceReport();
    }
    @Step("user fetch cancellation report")
    public void userLoginInESuiteAndFetchCancellationReasonReport(){
        navigateToESuite.userLoginInESuiteAndFetchCancellationReasonReport();
    }
    @Step("user verify cancellation report")
    public void verifyCancellationReasonReport(String reason) throws Exception {
        navigateToESuite.verifyCancellationReasonReport(reason);
    }
    @Step("user verifies payment and submission date in Specsavers Future Payment Transactions Report")
    public void userVerifySpecsaversFuturePaymentTransactionsReport(String transactionType) throws Exception {
        navigateToESuite.userVerifySpecsaversFuturePaymentTransactionsReport(transactionType);
    }
    @Step("user login in eSuite and fetch Specsavers Future Payment Transactions Report")
    public void userLoginInESuiteAndFetchSpecsaversFuturePaymentTransactionsReport()  {
        navigateToESuite.userLoginInEsuiteAndFetchSpecsaversFuturePaymentTransactionsReport();
    }
    @Step("user login in eSuite and fetch Specsavers multiple subscription Report")
    public void userLoginInESuiteAndFetchSpecsaversMultipleSubscriptionReport() {
        navigateToESuite.userLoginInESuiteAndFetchSpecsaversMultipleSubscriptionReport();
    }
    @Step("user verifies Specsavers multiple subscription Report")
    public void userVerifiesSpecsaversMultipleSubscriptionReport(String status) throws Exception, Exception {
        navigateToESuite.userVerifiesSpecsaversMultipleSubscriptionReport(status);
    }
    @Step("user should be able to verify the specsavers finance report")
    public void userShouldBeAbleToVerifySpecsaversFinanceReport(String customerType) throws Exception {
        navigateToESuite.userVerifiesSpecsaversFinanceReport(customerType);
    }
    @Step("user login in eSuite and fetch Specsavers finance Report")
    public void userLoginToeSuiteAndFetchSpecsaversFinanceReport() {
        navigateToESuite.userLoginToeSuiteAndFetchSpecsaversFinanceReport();
    }





    }
