package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import clsp.ui.extentions.clspBase;
import io.cucumber.java.de.Wenn;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PaymentPage extends clspBase {

    SubscriptionPage subScriptionPage;
    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentPage.class);
    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(PaymentPage.class);
    public static String mandateReference;
    public String AccValidationMessage = "Account Details Validated.";
    public String AccValidationAlertMessageUK ="Account Details not Validated - Please check and try again.";
    public String AccValidationAlertMessage ="BIC incorrect, please re-enter";
    public String bankAlertmessage = "Account Details not Validated - Please check and try again. You can proceed with this Direct Debit but please ensure you double check the sort code and account number are correct.";

    public String bankAggrementMessage = " I can confirm that the customer has seen and agreed to the Terms & Conditions and confirmed that they wish to enter a subscription contract with Specsavers.";
    @FindBy(xpath = "//input[@id='payment-account-holder']")
    public WebElementFacade accHolderName;

    @FindBy(xpath = "//button[text()='Add New']")
    private WebElementFacade addNew;

    @FindBy(xpath ="//header[contains(.,'Add New Payment Method')]")
    private WebElementFacade AddNewPaymentMethodLabel;

    @FindBy(xpath = "//header[contains(.,'Replace Payment Method')]")
    private WebElementFacade replacePaymentMethod;

    @FindBy(xpath = "//h4[@class='modal-title']")
    private WebElementFacade alternatePayerHeader;

    @FindBy(xpath ="//div[@class='mandate-col-left']")
    public static WebElementFacade alterPayerDetailsOnMandate;

    @FindBy(xpath = "//input[@id='edit_contact_title']")
    private WebElementFacade alternateTitle ;

    @FindBy(xpath = "//input[@id='address_edit_first_name']")
    private WebElementFacade alternateFirstName ;

    @FindBy(xpath = "//input[@id='address_edit_last_name']")
    private WebElementFacade alternateLastName;

    @FindBy(xpath = "//input[@id='edit_address_line_3']")
    private WebElementFacade alternateAddressOne;

    @FindBy(xpath = "//*[text()='SEPA DIRECT DEBIT MANDATE' or text()='INSTRUCTION TO YOUR BANK OR BUILDING SOCIETY TO PAY BY DIRECT DEBIT']")
    private WebElementFacade directDebitMandateHeader;

    @FindBy(xpath = "//input[@id='edit_address_line_1']")
    private WebElementFacade houseNo;

    @FindBy(xpath = "//input[@id='edit_address_line_2']")
    private WebElementFacade houseName;

    @FindBy(xpath = "//input[@id='edit_city']")
    private WebElementFacade alternateTown;

    @FindBy(xpath = "//input[@id='edit_county']")
    private WebElementFacade alternateCounty;

    @FindBy(xpath = "//input[@id='edit_postcode']")
    private WebElementFacade altPostcode;

    @FindBy(xpath = "//div[@class='modal-footer modal-footer-display']//button[@class='btn-secondary pull-right']")
    public WebElementFacade agreementConfirmButton;

    @FindBy(xpath = "//input[@id='payment-account-bic' or @id='payment-account-number']")
    private WebElementFacade bicAccField;

    @FindBy(xpath = "//input[@id='payment-account-iban' or @id='payment-sort-code']")
    private WebElementFacade ibanSortCodeField;

    @FindBy(xpath = "//div[text()='Invalid IBAN']")
    private WebElementFacade invalidIBANError;

    @FindBy(xpath = "//button[@class='cancel']")
    private WebElementFacade cancelButton;

    @FindBy(xpath = "//button[(text()='Confirm')]")
    List<WebElementFacade> confirmButton;

    @FindBy(xpath = "//div[@class='alert alert-success mb-2'][contains(.,'Account Details Validated.')]")
    private WebElementFacade accountValidation;

    @FindBy(xpath = "//input[contains(@id,'authorisation-input-field')]")
    private WebElementFacade bankAuthorisationCode;

    @FindBy(xpath = "//div[@class='alert alert-danger mb-2']")
    private WebElementFacade bankAlertMessage;

    @FindBy(xpath = "//div[@class='alert alert-warning']")
    private WebElementFacade bankAgreement;

    @FindBy(xpath = "//button[contains(.,'Proceed')]")
    private WebElementFacade bankAuthorisationProceed;

    @FindBy(xpath = "//button[@class='button btn-secondary'][contains(.,'Update')]")
    public WebElementFacade updateButton;

    @FindBy(xpath ="//a[text()='Dismiss']")
    private WebElementFacade dismiss;

    @FindBy(xpath = "//div[@id='mandateRef']")
    private WebElementFacade mandateRef;

    @FindBy(xpath ="//div[@class='modal-footer modal-footer-display']//button[@class='btn-secondary pull-right']")
    public WebElementFacade payerConfirmButton;

    @FindBy(xpath = "//div[@class='edit-remove-alternate-payer']//button[text()='Edit']")
    public WebElementFacade editPayer;

    @FindBy(xpath = "//h4[@class='modal-title']")
    public WebElementFacade headerTitle;

    @FindBy(xpath = "//ul[@class='sepa-address']")
    public WebElementFacade printSepaAddress;

    @FindBy(xpath = "//button[@class='btn-sm btn-secondary'][contains(.,'Reprint')]")
    private WebElementFacade reprintButton;

    @FindBy(xpath = "//small[contains(.,'Print')]//..//i[@class='fa fa-print']")
    public static WebElementFacade receiptPrintButton;

    @FindBy(xpath = "//button[contains(text(),'Close')]")
    public static WebElementFacade receiptCloseButton;

    @FindBy(xpath ="//select[@id='edit_country']")
    private WebElementFacade selectCountry;

    @FindBy(xpath = "//button[(text()='Validate')]")
    private WebElementFacade validateButton;

    @FindBy(xpath ="//div[@class='alert alert-success mb-2']")
    private WebElementFacade accDetailsValidateAlert;

    @FindBy(xpath ="//div[@class='alert alert-danger mb-2']")
    private WebElementFacade accDetailsValidateErrorAlert;

    @FindBy(xpath = "//div[@class='app-view-payment-methods__content col-md-12']//li[2]")
    private WebElementFacade accHolderNameLable;

    @FindBy(xpath = "//div[@class='app-view-payment-methods__content col-md-12']//li[3]")
    private WebElementFacade bicLable;

    @FindBy(xpath = "//div[@class='app-view-payment-methods__content col-md-12']//li[4]")
    private WebElementFacade ibanlable;
    @FindBy(xpath = "//button[(text()=' Confirm ')]")
    private WebElementFacade managePaymentConfirmButton;
    @FindBy(xpath = "//div[@class='app-view-payment-methods__content col-md-12']//li[5]")
    public WebElementFacade mandateReflabel;
    @FindBy(xpath = "//h1[normalize-space()='New Subscription | Payment']")
    public WebElementFacade paymentPageheader;

    @FindBy(xpath = "//header[contains(@class,'content-panel-header float-right')]/div/div[1]")
    public List<WebElementFacade> updatedPaymentDate;
    @FindBy(xpath = "//*[normalize-space()='Total (per month)']//following-sibling::td")
    public WebElementFacade totalAmountinPaymentPage;

    @FindBy(css = "#payment-account-holder")
    public WebElementFacade accholderName;
    @FindBy(css = "#payment-account-number")
    public WebElementFacade accholderNumber;
    @FindBy(css = "#payment-sort-code")
    public WebElementFacade accSortCode;

    @FindBy(xpath = "//button[normalize-space()='Validate']")
    public WebElementFacade validateAccButton;

    @FindBy(css = ".btn-secondary.pull-right")
    public WebElementFacade confirmBtn;

    @FindBy(id = "authorisation-input-field")
    public WebElementFacade authorizeCode;

    @FindBy(css = ".authorisation-button")
    public WebElementFacade authProceedButton;

    @FindBy(xpath = "//*[contains(@class,'modal-footer')]//button[normalize-space()='Confirm']")
    public WebElementFacade authConfirmButton;

    @FindBy(css = "div#mandateRef")
    public WebElementFacade mandateReferenceNum;

    @FindBy(xpath = "//*[contains(text(),'Print')]//..//button[@type='button'][contains(@class,'btn')]")
    public  WebElementFacade printButton;

    @FindBy(xpath = "//button[contains(text(),'Close')][@type='button']")
    public WebElementFacade closeMandateButton;


    public void enterPaymentDetailsAndClosePrintMandate(String customerName, String authCode){
        assertElementText(AddNewPaymentMethodLabel,"Add New Payment Method");
        assertTrue(!confirmButton.get(0).isEnabled());
        setText(accHolderName,customerName);
        enterBankDetails("payment");
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("United Kingdom")) {
            assertElementContainsText(bankAlertMessage, bankAlertmessage);
            clickElement(confirmButton.get(0));
            assertElementContainsText(bankAgreement, bankAggrementMessage);
            setText(bankAuthorisationCode, authCode);
            clickElement(bankAuthorisationProceed);
            clickElement(confirmButton.get(1));
            if(dismiss.isVisible())
                clickElement(dismiss);

        }else{
            assertElementContainsText(accountValidation,AccValidationMessage);
            clickElement(confirmButton.get(0));
            clickElement(agreementConfirmButton);
        }
        waitABit(10000);
        mandateReference = mandateRef.getText();
        clickElement(receiptPrintButton);
        logger.info("Clicked on Print Receipt button");
        //taking time to download PDf
        waitABit(15000);
        clickElement(receiptCloseButton);
    }
    public void entersPaymentDetailsAndPrintsMandate(String customerName,String customerID, String authCode,String nextDelDate, WebElementFacade finalDelDate) throws Exception{

        assertElementText(AddNewPaymentMethodLabel,"Add New Payment Method");
        assertTrue(!confirmButton.get(0).isEnabled());
        setText(accHolderName,customerName);
        enterBankDetails("payment");
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("United Kingdom")) {
            assertElementContainsText(bankAlertMessage, bankAlertmessage);
            clickElement(confirmButton.get(0));
            assertElementContainsText(bankAgreement, bankAggrementMessage);
            setText(bankAuthorisationCode, authCode);
            clickElement(bankAuthorisationProceed);
            clickElement(confirmButton.get(1));
        }else{
            assertElementContainsText(accountValidation,AccValidationMessage);
            clickElement(confirmButton.get(0));
            clickElement(agreementConfirmButton);
        }
        waitABit(10000);
        mandateReference = mandateRef.getText();
        clickElement(receiptPrintButton);
        //taking time to download PDf
        waitABit(15000);
       String file = System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "TestData" +File.separator + "clsp"+ File.separator + "Downloads"+ File.separator + "mandate-"+testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID+".pdf";
        final FileInputStream obj = new FileInputStream(file);
        PDDocument objDoc =  PDDocument.load(obj);
        PDFTextStripper objPDFStrp = new PDFTextStripper();
        String pdfContent = objPDFStrp.getText(objDoc);
        assertTrue(pdfContent.contains(customerName));
        if (testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData("payment.accSortiBan").substring(14)));
            assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData("payment.accNumbIc")));
        }
        else
        {
            assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData("payment.accNumbIc").substring(5)));
            assertTrue(pdfContent.contains(testDataManager.getTestInputRegionData("payment.accSortiBan").substring(0,2)+"-"+testDataManager.getTestInputRegionData("payment.accSortiBan").substring(2,4)+"-"+testDataManager.getTestInputRegionData("payment.accSortiBan").substring(4,6)));
        }

        clickElement(receiptCloseButton);
    }

    public void entersALtPayerPaymentDetailsAndPrintsMandate(String customerName, String authCode){
        assertElementText(replacePaymentMethod,"Replace Payment Method");
        updateButton.waitUntilDisabled();
        assertTrue(!updateButton.isEnabled());// use assertnotinteractable
        setText(accHolderName,customerName);
        enterBankDetails("newPayment");
        clickElement(updateButton);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("United Kingdom")) {
            setText(bankAuthorisationCode, authCode);
            clickElement(bankAuthorisationProceed);
            clickElement(confirmButton.get(0));
            clickElement(receiptPrintButton);
        }else {
            clickElement(receiptPrintButton);
        }
        if(dismiss.isVisible()==true)
        {
            clickElement(dismiss);
        }
        mandateRef.waitUntilVisible();
        mandateReference = mandateRef.getText();
        assertElementContainsText(alterPayerDetailsOnMandate,customerName);
        //Need to look for another approach to verify details on mandate instead of subsubstring.
        assertPageObjectIsDisplayed(directDebitMandateHeader);
        if (testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.accSortiBan"));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.accNumbIc"));
            //verifySepaPrintAddress(testDataManager.getTestInputRegionData("payer.alternateLastName"));
        }
        else
        {
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.accNumbIc"));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.accSortiBan").substring(0,2)+"-"+testDataManager.getTestInputRegionData("newPayment.accSortiBan").substring(2,4)+"-"+testDataManager.getTestInputRegionData("newPayment.accSortiBan").substring(4,6));
        }
        clickElement(receiptCloseButton);
    }
    public void enterPaymentDetailsWithoutAlternatePayerAndVerifyDetails(String paymentType, String customerName,WebElementFacade replaceButton, String authCode)
    {
        clickElement(replaceButton);
        assertObjectIsNotInteractable(updateButton);
        setText(accHolderName,customerName);
        enterBankDetails("payment");
        try
        {
            if(managePaymentConfirmButton.isEnabled() == true)
            {
                assertObjectIsNotInteractable(updateButton);
                assertTrue(managePaymentConfirmButton.isPresent(),"Button is enabled");//use existing method
                clickElement(managePaymentConfirmButton);
                assertTrue(updateButton.isEnabled());
            }
        }
        catch(Exception e )
        {
            e.printStackTrace();
            assertTrue(updateButton.isEnabled());

        }
        clickElement(updateButton);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("United Kingdom")) {
            setText(bankAuthorisationCode, authCode);
            clickElement(bankAuthorisationProceed);
            clickElement(confirmButton.get(0));
            clickElement(receiptPrintButton);
        }else {
            clickElement(receiptPrintButton);
        }
        if(dismiss.isVisible()==true){
            clickElement(dismiss);
        }
        mandateReference = mandateRef.getText();
        assertElementContainsText(alterPayerDetailsOnMandate,customerName);
        assertTrue(directDebitMandateHeader.isDisplayed());//use existing
        if (testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("payment.accSortiBan"));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("payment.accNumbIc"));
            //verifySepaPrintAddress(testDataManager.getTestInputRegionData("payer.alternateLastName"));
        }
        else
        {
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("payment.accNumbIc"));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("payment.accSortiBan").substring(0,2)+"-"+testDataManager.getTestInputRegionData("newPayment.accSortiBan").substring(2,4)+"-"+testDataManager.getTestInputRegionData("newPayment.accSortiBan").substring(4,6));
        }
        clickElement(receiptCloseButton);
        final String accHolderName = accHolderNameLable.getText().substring(16);
        assertEquals(accHolderName,customerName);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            //using substring for assertion so cannot use the available page assertions
            assertEquals(bicLable.getText().substring(5),testDataManager.getTestInputRegionData("payment.accNumbIc"));
            assertEquals(ibanlable.getText().substring(26),testDataManager.getTestInputRegionData("payment.accSortiBan").substring(18));
        }
        else
        {
            //using substring for assertion so cannot use the available page assertions
            assertEquals(testDataManager.getTestInputRegionData("payment.accNumbIc").substring(5),bicLable.getText().substring(21));
            assertTrue(ibanlable.getText().substring(11).equalsIgnoreCase(testDataManager.getTestInputRegionData("payment.accSortiBan").substring(0,2)+"-"+testDataManager.getTestInputRegionData("payment.accSortiBan").substring(2,4)+"-"+testDataManager.getTestInputRegionData("payment.accSortiBan").substring(4,6)));
        }

        final String mandateReferenceCustDashBoard = mandateReflabel.getText().substring(19);
        //assertFalse(mandateReference.equals(mandateReferenceCustDashBoard));

    }
    public void enterBankDetails(String paymentType) {
        waitFor(bicAccField);
        setText(bicAccField, testDataManager.getTestInputRegionData(paymentType + ".accNumbIc"));
        waitFor(ibanSortCodeField);
        setText(ibanSortCodeField,testDataManager.getTestInputRegionData(paymentType + ".accSortiBan"));
        validateButton.waitUntilClickable();
        clickElement(validateButton);
    }

    public void verifySepaPrintAddress(String customerLastName,String lastName) {
        logger.info("customerLastName:" +customerLastName);
        if(customerLastName.contains(lastName))
        {
            final String FullAddress = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
            assertEquals(FullAddress,printSepaAddress.getText().replaceAll("[\r\n]+", " "));
        }
        else
        {
            final String payerFullAddress = testDataManager.getTestInputRegionData("payer.name")+" "+testDataManager.getTestInputRegionData("payer.number")+" "+testDataManager.getTestInputRegionData("payer.addressLine")+" "+testDataManager.getTestInputRegionData("payer.town")+" "+testDataManager.getTestInputRegionData("payer.county")+" "+testDataManager.getTestInputRegionData("payer.postcode")+" "+testDataManager.getTestInputRegionData("payer.countryName");
            assertEquals(payerFullAddress,printSepaAddress.getText().replaceAll("[\r\n]+", " "));
        }
    }
    public void printAndClosePreviewWindow(){
        try{
            clickElement(receiptPrintButton);
            Robot robot = new Robot();
            waitABit(3000);//approved by dipak
            robot.keyPress(java.awt.event.KeyEvent.VK_ESCAPE);
            robot.keyRelease(java.awt.event.KeyEvent.VK_ESCAPE);
        }catch (AWTException e) {
            e.printStackTrace();
        }

    }

    public void addingAlternatePayerDetails()
    {

        assertPageObjectIsDisplayed(addNew);
        clickElement(addNew);
        assertPageObjectIsDisplayed(alternatePayerHeader);
        selectCountry.selectByVisibleText(testDataManager.getTestInputRegionData("payer.countryName"));
        setText(alternateTitle,testDataManager.getTestInputRegionData("payer.alternateTitle"));
        setText(alternateFirstName,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
        setText(alternateLastName,testDataManager.getTestInputRegionData("payer.alternateLastName"));
        setText(alternateAddressOne,testDataManager.getTestInputRegionData("payer.addressLine"));
        setText(houseNo,testDataManager.getTestInputRegionData("payer.number"));
        setText(houseName,testDataManager.getTestInputRegionData("payer.name"));
        setText(alternateTown,testDataManager.getTestInputRegionData("payer.town"));
        setText(alternateCounty,testDataManager.getTestInputRegionData("payer.county"));
        setText(altPostcode,testDataManager.getTestInputRegionData("payer.postcode"));
        clickElement(payerConfirmButton);
    }
    public void changeExistingAlternatePayerDetails() {
        editPayer.waitUntilVisible();
        editPayer.waitUntilClickable();
        clickElement(editPayer);
        headerTitle.waitUntilVisible();
        alternateTitle.clear();
        logger.info(testDataManager.getTestInputRegionData("alternatePayer.alternateTitle"));
        setText(alternateTitle,testDataManager.getTestInputRegionData("alternatePayer.alternateTitle"));
        alternateFirstName.clear();
        setText(alternateFirstName,testDataManager.getTestInputRegionData("alternatePayer.alternateFirstName"));
        alternateLastName.clear();
        setText(alternateLastName,testDataManager.getTestInputRegionData("alternatePayer.alternateLastName"));
        alternateAddressOne.clear();
        setText(alternateAddressOne,testDataManager.getTestInputRegionData("alternatePayer.addressLine"));
        houseNo.clear();
        setText(houseNo,testDataManager.getTestInputRegionData("alternatePayer.number"));
        houseName.clear();
        setText(houseName,testDataManager.getTestInputRegionData("alternatePayer.name"));
        alternateTown.clear();
        setText(alternateTown,testDataManager.getTestInputRegionData("alternatePayer.town"));
        alternateCounty.clear();
        setText(alternateCounty,testDataManager.getTestInputRegionData("alternatePayer.county"));
        altPostcode.clear();
        setText(altPostcode,testDataManager.getTestInputRegionData("alternatePayer.postcode"));
        selectCountry.selectByValue(testDataManager.getTestInputRegionData("alternatePayer.countryName"));
        clickElement(payerConfirmButton);
    }

    public void verifiesAlternatePayerDetails(){

        assertPageObjectIsDisplayed(alternatePayerHeader);
        assertElementContainsValue(alternateTitle,testDataManager.getTestInputRegionData("payer.alternateTitle"));
        assertElementContainsValue(alternateFirstName,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
        assertElementContainsValue(alternateLastName,testDataManager.getTestInputRegionData("payer.alternateLastName"));

        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("United Kingdom"))
        {
            assertElementContainsValue(alternateAddressOne,testDataManager.getTestInputRegionData("payer.addressLine"));
            assertElementContainsValue(houseNo,testDataManager.getTestInputRegionData("payer.number"));
            assertElementContainsValue(alternateTown,testDataManager.getTestInputRegionData("payer.town"));
        }
        else
        {
            assertElementContainsValue(alternateAddressOne,testDataManager.getTestInputRegionData("payer.addressLine"));
            assertElementContainsValue(houseNo,testDataManager.getTestInputRegionData("payer.number"));
            assertElementContainsValue(houseName,testDataManager.getTestInputRegionData("payer.name"));
            assertElementContainsValue(alternateTown,testDataManager.getTestInputRegionData("payer.town"));
            assertElementContainsValue(alternateCounty,testDataManager.getTestInputRegionData("payer.county"));
            assertElementContainsValue(altPostcode,testDataManager.getTestInputRegionData("payer.postcode"));

        }
        assertElementContainsText(selectCountry.selectByVisibleText("United Kingdom"),testDataManager.getTestInputRegionData("payer.countryName"));
        clickElement(payerConfirmButton);
    }

    public void verifyPayerPaymentDetails(String customerName,String paymentType) {
        accHolderNameLable.waitUntilVisible();
        final String accHolderName = accHolderNameLable.getText().substring(16).trim();
        assertEquals(accHolderName,customerName);
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            //using substring for assertion so cannot use the available page assertions
            assertEquals(bicLable.getText().substring(5),testDataManager.getTestInputRegionData(paymentType + ".accNumbIc"));
            assertEquals(ibanlable.getText().substring(26),testDataManager.getTestInputRegionData(paymentType + ".accSortiBan").substring(18));
        }
        else
        {
            //using substring for assertion so cannot use the available page assertions
            assertEquals(testDataManager.getTestInputRegionData(paymentType + ".accNumbIc").substring(5),bicLable.getText().substring(21));
            assertTrue(ibanlable.getText().substring(11).equalsIgnoreCase(testDataManager.getTestInputRegionData(paymentType+".accSortiBan").substring(0,2)+"-"+testDataManager.getTestInputRegionData("payment.accSortiBan").substring(2,4)+"-"+testDataManager.getTestInputRegionData("payment.accSortiBan").substring(4,6)));
        }

    }
    public void clickOnAgreementAndPrintMandate(){
        clickOn(agreementConfirmButton);
        waitABit(3000);
        if(dismiss.isVisible()==true)
        {
            clickOn(dismiss);
        }
        mandateReference = mandateRef.getText();
        clickOn(receiptCloseButton);
    }
    public void clickElementAgreementAndPrintMandate(String authCode){
        waitABit(3000);//try to use fluent wait
        setText(bankAuthorisationCode, authCode);
        clickElement(bankAuthorisationProceed);
        confirmButton.get(1).waitUntilClickable();
        clickElement(confirmButton.get(1));
        if(dismiss.isVisible()==true)
        {
            clickElement(dismiss);
        }
        clickElement(receiptPrintButton);
        clickElement(receiptCloseButton);
    }

    public void replaceAlternatePayerPaymentDetails(String addressType)
    {
        clickElement(updateButton);
        clickElement(receiptPrintButton);
        waitABit(15000);//use fluent wait ,approved by dipak
        mandateReference = mandateRef.getText();
        final String AltPayDetailsOnMandate = alterPayerDetailsOnMandate.getText();

        assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
        if (testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("Ireland"))
        {
            assertTrue(alterPayerDetailsOnMandate.getText().substring(10, 20).contains(testDataManager.getTestInputRegionData("payer.alternateFirstName")));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.accSortiBan").substring(18));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.accNumbIc"));
        }
        else
        {
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.account_number"));
            assertElementContainsText(alterPayerDetailsOnMandate,testDataManager.getTestInputRegionData("newPayment.sort_code").substring(0,2)+"-"+testDataManager.getTestInputRegionData("newPayment.sort_code").substring(2,4)+"-"+testDataManager.getTestInputRegionData("newPayment.sort_code").substring(4,6));
        }

        clickElement(receiptCloseButton);
        if(dismiss.isVisible()){
            clickElement(dismiss);
        }
    }
    public void verifyIfConfirmButtonIsClickableUponAddingRemovingAltPayer(WebElementFacade replaceButton,WebElementFacade removeButton,WebElementFacade removepayerButtonPop) {

        clickElement(replaceButton);
        assertObjectIsNotInteractable(updateButton);
        addingAlternatePayerDetails();
        assertObjectIsNotInteractable(updateButton);
        setText(accHolderName,testDataManager.getTestInputRegionData("payer.alternateFirstName"));
        enterBankDetails("newPayment");
        assertTrue(updateButton.isEnabled());
        assertTrue(removeButton.isDisplayed());
        clickElement(removeButton);
        clickElement(removepayerButtonPop);
        clickElement(updateButton);

    }
    public void verifyEnteredBICAndIBANIsValid(String bic, String iban, String firstName) {

        logger.info(firstName);
        accHolderName.sendKeys(firstName);
        logger.info(bic);
        setText(bicAccField,bic);
        logger.info(iban);
        setText(ibanSortCodeField,iban);
        //ibanSortCodeField.sendKeys(Keys.TAB);
        clickElement(validateButton);
        waitABit(5000);
        assertTrue(accDetailsValidateAlert.isVisible() || accDetailsValidateErrorAlert.isVisible());

        if(validateBICIBAN(bic,iban).equalsIgnoreCase("valid"))
        {
            logger.info(accDetailsValidateAlert.getText());
            assertElementText(accDetailsValidateAlert, AccValidationMessage);
        }
        else
        {
            logger.info(accDetailsValidateErrorAlert.getText());
            assertElementText(accDetailsValidateErrorAlert,AccValidationAlertMessage);
        }

        accHolderName.clear();
        bicAccField.clear();
        ibanSortCodeField.clear();

    }
    public String validateBICIBAN(String bic, String iban)
    {
        String flag = "invalid";
        for(int i=1;i<=3;i++){
            if(testDataManager.getTestInputRegionData("validatebIcAndIban.bIc"+i).equalsIgnoreCase(bic) && testDataManager.getTestInputRegionData("validatebIcAndIban.Iban"+i).equalsIgnoreCase(iban) )
                flag = "valid";
        }
        return flag;
    }
    public void verifyValidateButtonIsDisableForInvalidIBAN(String bic, String iban, String firstName) {

        logger.info(firstName);
        accHolderName.sendKeys(firstName);
        logger.info(bic);
        setText(bicAccField,bic);
        logger.info(iban);
        setText(ibanSortCodeField,iban);
        assertPageObjectIsDisplayed(invalidIBANError);
        logger.info(invalidIBANError.getText());
        assertObjectIsNotInteractable(validateButton);
        clearTextFromTextBox(accHolderName);
        clearTextFromTextBox(bicAccField);
        clearTextFromTextBox(ibanSortCodeField);

    }

    public void entersPaymentDetailsAndPrintsMandateForSCE(String customerName,String customerID, String authCode,String nextDelDate, WebElementFacade finalDelDate) {

        assertElementText(AddNewPaymentMethodLabel,"Add New Payment Method");
        assertTrue(!confirmButton.get(0).isEnabled());
        setText(accHolderName,customerName);
        enterBankDetails("payment");
        if(testDataManager.getTestInputRegionData("payer.countryName").equalsIgnoreCase("United Kingdom")) {
            assertElementContainsText(bankAlertMessage, bankAlertmessage);
            clickElement(confirmButton.get(0));
            //clickElement(agreementConfirmButton);
            //waitABit(3000);
            if (dismiss.isVisible() == true) {
                clickElement(dismiss);
            }
            assertElementContainsText(bankAgreement, bankAggrementMessage);
            setText(bankAuthorisationCode, authCode);
            clickElement(bankAuthorisationProceed);
            clickElement(confirmButton.get(1));
        }else{
            assertElementContainsText(accountValidation,AccValidationMessage);
            clickElement(confirmButton.get(0));
            clickElement(agreementConfirmButton);
        }
        waitForCondition().until(ExpectedConditions.elementToBeClickable(receiptPrintButton));
    }
    public void clickAgreementAndPrintMandate(){
        payerConfirmButton.waitUntilClickable();
        clickElement(payerConfirmButton);
        receiptPrintButton.waitUntilClickable();
        clickElement(receiptPrintButton);
        waitABit(15000);
        clickElement(receiptCloseButton);
    }


}
