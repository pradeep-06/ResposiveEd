package clsp.ui.tests.userJourney.ROI;

import Framework.Annotations.CLSP.CLSP_ROI_Midterm;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class ROI_MidTermScenariosTest {

    @Managed(driver = "provided", uniqueSession=true)
    WebDriver driver;

    @Steps
    UserSignUp clsp;
    @Steps
    UserCreatesAPICustomer apiObj;

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Goodwill Payment,94c30,Goodwill payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695399", projectId = "91768", testCaseName = "CLSP-CONTACTCENTREAUTH-07 - Store Writeoff(Goodwill)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsGoodWill(int status, String dailyType, int quantity, int removedStatus, String writeOffType, String authCode, String alertMsgPart) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType,authCode,alertMsgPart);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,IRCEIE2D,IE64IRCE92050112345678,WELADED1MIN,DE38490501010040681272,ABNANL2AXXX,NL55ABNA0441899269"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693419", projectId = "91768", testCaseName = "CLSP-FR-10 - Payment - 12 - Validation Services (Valid BIC and IBAN)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userValidatesBicAndIban(int status, String dailyType, int quantity, int removedStatus, String bic1, String iban1, String bic2, String iban2, String bic3, String iban3) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifyPaymentMethodAndClickOnReplaceButton();
        clsp.userVerifiesPaymentDetails(bic1,iban1);
        clsp.userVerifiesPaymentDetails(bic2,iban2);
        clsp.userVerifiesPaymentDetails(bic3,iban3);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,IRCEIE2D,GB24BARC20201630093459,IRCEGB2DXXX,GB02BARC20201530093451,GB01BARC20714583608387,GB00HLFX11016111455365"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693424", projectId = "91768", testCaseName = "CLSP-FR-10 - Payment - 12 - Validation Services (Invalid Format)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userInValidatesBicAndIban(int status, String dailyType, int quantity, int removedStatus, String bic1, String iban1, String bic2, String iban2, String iban3, String iban4) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifyPaymentMethodAndClickOnReplaceButton();
        clsp.userVerifiesPaymentDetails(bic1,iban1);
        clsp.userVerifiesPaymentDetails(bic1,iban2);
        clsp.userVerifiesPaymentDetails(bic2,iban3);
        clsp.userVerifiesPaymentDetails(bic2,iban4);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,IRCEIE2D,GB24BARC20201630093459,IRCEGB2DXXX,GB02BARC20201530093451,GB01BARC20714583608387,GB00HLFX11016111455365,GB96BARC202015300934591"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693429", projectId = "91768", testCaseName = "CLSP-FR-10 - Payment - 12 - Validation Services (Invalid IBAN)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userValidatesForInvalidIban(int status, String dailyType, int quantity, int removedStatus, String bic1, String iban1, String bic2, String iban2, String iban3, String iban4, String iban5) {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userVerifyPaymentMethodAndClickOnReplaceButton();
        clsp.userVerifiesValidateButtonForInvalidIBAN(bic1,iban1);
        clsp.userVerifiesValidateButtonForInvalidIBAN(bic1,iban2);
        clsp.userVerifiesValidateButtonForInvalidIBAN(bic1,iban3);
        clsp.userVerifiesValidateButtonForInvalidIBAN(bic2,iban4);
        clsp.userVerifiesValidateButtonForInvalidIBAN(bic2,iban5);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Oversupply,Write On Debt,94c30,Write On payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693440", projectId = "91768", testCaseName = "Write On - Pack Pending - One payment Completed - Cancel Subscription", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsWriteOff(int status, int removedStatus, String reason, String writeOffType, String authCode, String alertMsgPart) throws Exception {
        apiObj.userCreatesPostPayMonthlySolutionAndFirstPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Moving,Write Off Debt,94c30,Write off payment,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693487", projectId = "91768", testCaseName = "DF-1392_Write Off Process - Bad Debt indicator is not being set when a payment is written off ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifiesBadDebtIndicator(int status, String dailyType, int quantity, int removedStatus, String reason, String writeOffType, String authCode, String alertMsgPart, String packStatus) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status,packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        clsp.userMustBeAbleToVerifyBadDebtIconToBePresent();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,Goodwill Payment,94c30,Goodwill Payment,System,Contact Centre authorisation used to process a GOODWILL,In Person,Closed"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693511", projectId = "91768", testCaseName = "DF-1384_Good Will Process - Payments Written off display as the original status on Print Schedule", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsWrittenOffStatusOnPaymentSchedule(int status, int removedStatus, String writeOffType, String authCode, String alertMsgPart, String noteSub,String clinicalNotes, String noteType,  String noteStatus1) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        clsp.userVerifiesNoteAfterWriteOffOperation(noteSub, clinicalNotes, noteType, noteStatus1);
        //clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Full Time,Processing,Goodwill Payment,94c30,Goodwill Payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695189", projectId = "91768", testCaseName = "DF - 1600 - CLSP-UAT-CLSP UI -Write Off - Goodwill payments cannot be set on the next PENDING payment when the associated pack is at a PROCESSING staus.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsWriteOffForPendingStatus(int status, String dailyType,int quantity, int removedStatus, String newPackage, String packStatus, String writeOffType, String authCode, String alertMsgPart) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userUpdateDailyPackage(newPackage);
        apiObj.userUpdatePackStatusToGivenStatus(status,packStatus);
        clsp.userLaunchesStoreUrlCustomerSearchPageAndFindsCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesGoodwillOptionIsNotDisplayed();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,0,Moving,Write On Debt,2abcd2,Write On payment,7ud921,94c30"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695762", projectId = "91768", testCaseName = "CLSP-CONTACTCENTREAUTH-07 - Store Writeoff (Write On)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsStoreWriteOn(int status,String dailyType, int quantity, int removedStatus, int cancelDays, String reason, String writeOffType, String authCode, String alertMsgPart, String storeAuthorizationCode,String contactCenterAuthorizationCode) throws Exception {
        apiObj.userCreatesPostPayMonthlySolutionAndFirstPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays,reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType,authCode,alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType,storeAuthorizationCode,alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType,contactCenterAuthorizationCode,alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        apiObj.userDeletesCustomer(removedStatus);
        clsp.userClicksOnBackButton();
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,204,New Subscription,Write Off Debt,2abcd2,Write off payment,7ud921,94c30,Dispatched"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695491", projectId = "91768", testCaseName = "CLSP-CONTACTCENTREAUTH-07 - Store Writeoff (Write off)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsStoreWriteOff(int status, int removedStatus, String reason, String writeOffType, String authCode, String alertMsgPart, String storeAuthorizationCode,String contactCenterAuthorizationCode, String packStatus) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType,storeAuthorizationCode,alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType,contactCenterAuthorizationCode,alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "FullTime,3 month 50%,1,200,201,dailyOccasionalCustomer,Goodwill Payment,94c30,Goodwill Payment,204",
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695785", projectId = "91768", testCaseName = "Manage Subscription - Application of Goodwill_Low Start 50% for 3 Months", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsDiscount(String dailyType, String discountType, int quantity, int status, int newSubscriptionStatus, String customerType, String writeOffType, String authCode, String alertMsgPart, int removedStatus) throws Exception {
        apiObj.userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(dailyType,discountType,quantity,status, newSubscriptionStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        apiObj.userDeletesCustomer(removedStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,0,Moving,Write On Debt,94c30,Write On payment,System,Contact Centre authorisation used to process a WRITE_ON,In Person,Closed"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42692985", projectId = "91768", testCaseName = "CLSP-FR-05 - Write-Off - 10 - Write On Process - Sub CANCELLED - Pack CANCELLED - Pay MAX REFUNDED", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsWriteOn(int status, String dailyType, int quantity, int removedStatus, int cancelDays, String reason, String writeOffType, String authCode, String alertMsgPart, String noteSub,String clinicalNotes, String noteType,  String noteStatus1) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays,reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType,authCode,alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        clsp.userClicksOnBackButton();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesThatTheSelectActionDropdownIsDisabled();
        clsp.userClicksOnBackButton();
        clsp.userVerifiesNoteAfterWriteOffOperation(noteSub, clinicalNotes, noteType, noteStatus1);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Cancellation,Original payment method SEPA,94c30,First,Holiday,Refund success for order ID,Support Note,Closed"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693328", projectId = "91768", testCaseName = "1690_Allow holidaying a pack with max refunded payments", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAllowHolidayPackForRefund(int status, String dailyType, int quantity, int removedStatus, String refundReason, String refundMethod, String authorizationCode, String pack, String paymentStatus, String noteSub, String noteType,  String noteStatus1) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesServiceCreditForStoreURL(refundReason,refundMethod,authorizationCode);
        clsp.userClicksOnBackButton();
        clsp.updatingOnePackAsHolidayWithAuthorization(pack,authorizationCode);
        clsp.userVerifiesPaymentStatusAfterPerformingHoliday(paymentStatus);
        clsp.userToVerifyPrintScheduleReciept();
        clsp.userClicksOnBackButton();
        clsp.userVerifiesRefundReasonAfterPerformingHoliday(refundReason, noteSub, noteType, noteStatus1);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @AfterEach
    @CLSP_SMOKE
    
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose(){
        driver.quit();
    }


}
