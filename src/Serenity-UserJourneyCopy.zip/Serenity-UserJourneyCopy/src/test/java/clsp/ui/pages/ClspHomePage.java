package clsp.ui.pages;

import clsp.ui.extentions.clspBase;
import net.serenitybdd.annotations.DefaultUrl;

@DefaultUrl("page:clsp.home.url")
public class ClspHomePage extends clspBase {
}
