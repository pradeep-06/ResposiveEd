package clsp.ui.extentions;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.core.exceptions.NoSuchElementException;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.Keys;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class clspBase extends BasePageObject {

    public void clearTextFromTextBox(WebElementFacade locator) {
        //This Method will clear text from textBox using Actions class.
        withAction().click(locator)
                .keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
    }
    public void navigateBack(){
        getDriver().navigate().back();
    }

    public String enterRandomCharacters(String length) {
        final int leftLimit = 97; // letter 'a'
        final int rightLimit = 122; // letter 'z'
        final int targetStringLength = Integer.parseInt(String.valueOf(length));
        Random random = new Random();
        final String generatedString = random.ints(leftLimit, rightLimit + 1)
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        return generatedString;
    }
    public String getCurrentDateStamp() {
        SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
        final String sysDate = formDate.format(new Date());
        return sysDate;
    }
    public void clearTextFromTextBoxAlternate(WebElementFacade locator) {
        while (locator.getValue().length() != 0) {
            withAction().click(locator).sendKeys(Keys.BACK_SPACE).build().perform();
        }
    }
    public String deliveryDateFormat(String selectedPaymentDate,int amount) {
        String date = null;
        try {
            SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MM/yyyy");
            Calendar cal = Calendar.getInstance();
            Date payDate=new SimpleDateFormat("dd/MM/yyyy").parse(selectedPaymentDate.trim());
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = dateFormat.format(payDate);

            Date paymentDate=new SimpleDateFormat("dd/MM/yyyy").parse(strDate);
            cal.setTime(paymentDate);
            cal.add(Calendar.MONTH, amount);
            date = simpleDate.format( cal.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }
    public String dateFormatMonth(String PaymentDate) {
        String nextDate = null;
        try {
            DateFormat payment = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat nextPayment = new SimpleDateFormat("MMMM");
            Date date = payment.parse(PaymentDate);
            nextDate = nextPayment.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return nextDate;
    }
    public void assertElementEqualIgnoreCase(WebElementFacade element,String text){
        try {
            assertTrue(element.getText().equalsIgnoreCase(text));
        } catch (NoSuchElementException e) {
            throw new NoSuchElementException("Could not find element " + element);
        }
    }


}
