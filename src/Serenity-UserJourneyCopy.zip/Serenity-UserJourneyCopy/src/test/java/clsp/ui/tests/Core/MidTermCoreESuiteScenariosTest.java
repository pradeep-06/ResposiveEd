package clsp.ui.tests.Core;

import Framework.Annotations.CLSP.CLSP_Esuite;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserJourneyBacsESuite;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class MidTermCoreESuiteScenariosTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    UserSignUp clsp;
    @Steps
    UserCreatesAPICustomer apiObj;
    @Steps
    UserJourneyBacsESuite eSuite;


    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Pending Fulfillment report - Pending Fulfillment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPendingFulFillMentReport(int status, String dailyType, int quantity, int removedStatus) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        apiObj.userStoresDeliveryDates();
        apiObj.userStoresThePackStatus();
        eSuite.userLoginInESuiteAndFetchPendingFulfillmentReport();
        eSuite.userShouldBeAbleToVerifyTheFulfillmentToAppearOnTheReport(dailyType);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Pending Fulfillment report - Holiday Fulfillment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPendingFulFillMentReportForHoliday(int status, String dailyType, int quantity, int removedStatus, String pack,String authorizationCode) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        apiObj.userStoresDeliveryDates();
        apiObj.userStoresThePackStatus();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyPacksStatus();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        apiObj.userRetrievesThePackStatus();
        eSuite.userLoginInESuiteAndFetchPendingFulfillmentReport();
        eSuite.userShouldBeAbleToVerifyTheFulfillmentToAppearOnTheReport(dailyType);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "UAT_006_NonLensmail_Pending Fulfillment Report", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyNonLensMailPendingFulFillMentReport(int status, String dailyType, int quantity, int removedStatus, int newSubscriptionStatus) throws Exception {
        apiObj.userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(dailyType, quantity, status,newSubscriptionStatus);
        apiObj.userStoresDeliveryDates();
        apiObj.userStoresThePackStatus();
        eSuite.userLoginInESuiteAndFetchPendingFulfillmentReport();
        eSuite.userShouldBeAbleToVerifyTheFulfillmentToAppearOnTheReport(dailyType);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Store to store transfer-Verify Pending Fulfillment Report", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPendingFulFillMentReportForStoreToStore(int status, String dailyType, int quantity, int removedStatus) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        eSuite.userLoginInESuiteAndFetchPendingFulfillmentReport();
        eSuite.userShouldBeAbleToVerifyTheFulfillmentToAppearOnTheReport(dailyType);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-06 - Completed Payments Prepay", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrepayStoreBalance(int status, String dailyType, int quantity, int removedStatus) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,First,aa445"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-04 - Holidayed Payments & Holidayed Packs", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyHolidayStoreBalance(int status, String dailyType, int quantity, int removedStatus, String pack,String authorizationCode) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userIsApplyingSchemeHolidayForOnePack(pack,authorizationCode);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,10,Medical Health Laser"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-05 - Cancelled Payments & Cancelled Packs", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyCancelStoreBalance(int status, String dailyType, int quantity, int removedStatus, int cancelDays,String reason) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Cancellation,Original payment method SEPA,94c30"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-08 - MaxRefunded Payments", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyRefundStoreBalance(int status, String dailyType, int quantity, int removedStatus, String refundReason, String refundMethod, String authorizationCode) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyPacksStatus();
        clsp.userVerifiesServiceCreditForStoreURL(refundReason,refundMethod,authorizationCode);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Goodwill Payment,94c30,Goodwill Payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-10 - Goodwill Payments", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyGoodWillStoreBalance(int status, String dailyType, int quantity, int removedStatus, String writeOffType, String authCode, String alertMsgPart) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Write On Debt,94c30,Write On payment,0,Moving"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-12 - Writeon Payments", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyWriteOnStoreBalance(int status, String dailyType, int quantity, int removedStatus, String writeOffType, String authCode, String alertMsgPart, int cancelDays, String reason) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Write Off Debt,94c30,Write off payment,Dispatched,Moving"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "CLSP-BALANCESHEET-12 - Writeoff Payments", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyWriteOffStoreBalance(int status, String dailyType, int quantity, int removedStatus, String writeOffType, String authCode, String alertMsgPart, String packStatus, String reason) throws Exception {
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        eSuite.captureStoreBalanceReportData();
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status, packStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        eSuite.userLoginInESuiteAndFetchStoreBalanceReport();
        apiObj.retrievePaymentsForStoreBalanceReport();
        eSuite.verifyStoreBalanceReport();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,0,Moving"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Cancellation reason report", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyCancellationReasonReport(int status, String dailyType, int quantity, int removedStatus, int cancelDays, String reason) throws Exception {
        apiObj.userCreatesPostpayDailyCust(dailyType, quantity, status);
        apiObj.userStoresDeliveryDates();
        apiObj.userStoresThePackStatus();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        eSuite.userLoginInESuiteAndFetchCancellationReasonReport();
        eSuite.verifyCancellationReasonReport(reason);
        apiObj.userDeletesCustomer(removedStatus);

    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Moving,Cancelled"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Scenario Outline: CR-1723-Top-ups_TopUp created before Change of Bank Details", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyFutureTransactionReport(int status, String dailyType, int quantity, int removedStatus, String reason, String transactionType) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsTheSubscription(reason);
        clsp.userToVerifyPrintScheduleReciept();
        clsp.userClicksOnBackButton();
        clsp.userVerifiesTheSystemNotesAfterPerformingCancelPayment();
        eSuite.userLoginInESuiteAndFetchSpecsaversFuturePaymentTransactionsReport();
        eSuite.userVerifySpecsaversFuturePaymentTransactionsReport(transactionType);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,Occasional,1,204,PRE,Pending"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Specsavers - as Esuite I am able to report on customers that have more than 1 pending payment instruction", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyMultipleSubscriptionReport(int status, String dailyType, int quantity, int removedStatus, String payerType,String newStatus) throws Exception {
        apiObj.createMultipleSubscriptionForDailyCustomer(dailyType, quantity, status, payerType);
        eSuite.userLoginInESuiteAndFetchSpecsaversMultipleSubscriptionReport();
        eSuite.userVerifiesSpecsaversMultipleSubscriptionReport(newStatus);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,201"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "UAT_014_NonLensmail_Specsavers Finance Report", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyNonLensMailSpecsaversFinanceReport(int status, String dailyType, int quantity, int removedStatus, int newSubscriptionStatus) throws Exception {
        apiObj.userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(dailyType, quantity, status, newSubscriptionStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyPacksStatus();
        eSuite.userLoginToeSuiteAndFetchSpecsaversFinanceReport();
        eSuite.userShouldBeAbleToVerifySpecsaversFinanceReport(dailyType);
        apiObj.userDeletesCustomer(removedStatus);


    }
    @AfterEach
    @CLSP_SMOKE
    @CLSP_Esuite
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose(){
        driver.quit();
    }

    }
