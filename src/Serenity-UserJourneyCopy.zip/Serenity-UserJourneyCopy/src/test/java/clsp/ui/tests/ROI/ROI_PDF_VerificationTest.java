package clsp.ui.tests.ROI;

import Framework.Annotations.CLSP.CLSP_ROI_PDF;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class ROI_PDF_VerificationTest {

    @Managed(driver = "provided", uniqueSession=true)
    WebDriver driver;
    @Steps
    UserSignUp clsp;
    UserCreatesAPICustomer apiObj = new UserCreatesAPICustomer();

    @CLSP_SMOKE
    @CLSP_ROI_PDF
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207667,montlyNoSolutionCustomer,1271279,Ronaldino,Deliver to Home,1,POST,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687309", projectId = "91768", testCaseName = "Pre Pay - Monthly - No Solution", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void createMonthlyCustomer(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber,String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception{
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.userEntersPaymentDetailsAndPrintsMandate(customerName,customerID, authCode);
        clsp.userVerifySummaryPageWithPrintSummary(customerID, customerType, customerName, deliveryType,payerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }
    @CLSP_SMOKE
    @CLSP_ROI_PDF
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207943,dailyPartTimeCustomer,1271565,Abraham,Deliver to Home,1,PRE,address,7ud921,Deceased"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42746704", projectId = "91768", testCaseName = "Pre Pay - Change Customer Details - Contact Centre or Treasury User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangeCustomerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String authCode, String reason) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userClickOnConfirmButton();
        clsp.userEntersPaymentDetailsAndPrintsMandate(customerName,customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userSelectsTheAddressBookAndAddANewAddress(addressType);
        clsp.userEditsCustomerContactInformation();
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.verifyCustomerDetailsOnAddressBookTab();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }
    @CLSP_SMOKE
    @CLSP_ROI_PDF
    @ParameterizedTest
    @CsvSource({
            "200,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42710394", projectId = "91768", testCaseName = "PostPay_UAT_002_Lensmail_Change fulfillment status from Pending to Completed", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userChangeStatusOfFulFillMent(int status, int removedStatus) throws Exception {
        apiObj.userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userTriesToPerformStoreFullFilMent();
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userCollectsPackFromStore();
        clsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
        apiObj.userDeletesCustomer(removedStatus);
    }
    @AfterEach
    @CLSP_SMOKE
    @CLSP_ROI_PDF
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose() {
        driver.quit();
    }
}
