package clsp.ui.tests.ROI;

import Framework.Annotations.CLSP.CLSP_ROISignup;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class NewSignupJourneyTest {
    @Managed(driver = "provided", uniqueSession=true)
    WebDriver driver;
    @Steps
    UserSignUp clsp;
    UserCreatesAPICustomer apiObj = new UserCreatesAPICustomer();

    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207625,dailyPartTimeCustomer,1271238,Ricky,Deliver to Home,1,PRE,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42692790", projectId = "91768", testCaseName = "Post Pay - Add NEW Alternate Payer - Contact Centre or Treasury User.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void verifyReplaceButtonIsDisabledForCCUser(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber,String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception{
        clsp.launchURLForNewCustomer(customerID,customerType,tdrNumber,fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType,customerName,customerID,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesPaymentReplaceAndAltPayerBtnIsDisabled();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }



    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207667,montlyNoSolutionCustomer,1271279,Ronaldino,Deliver to Home,1,POST,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687309", projectId = "91768", testCaseName = "Pre Pay - Monthly - No Solution", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void createMonthlyCustomer(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber,String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception{
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,payerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    //updating the customer details
    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,208636,dailyPartTimeCustomer,1272519,Mike,Deliver to Home,1,PRE,address,7ud921,Deceased,0"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42746704", projectId = "91768", testCaseName = "Pre Pay - Change Customer Details - Contact Centre or Treasury User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userChangeCustomerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String authCode, String reason, int cancelDays) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userSelectsTheAddressBookAndAddANewAddress(addressType);
        clsp.userEditsCustomerContactInformation();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207625,dailyPartTimeCustomer,1271238,Ricky,Deliver to Home,1,PRE,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691133", projectId = "91768", testCaseName = "Pre Pay - Add NEW Alternate Payer - Contact Centre or Treasury User.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsNewAlternatePayerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesPaymentReplaceAndAltPayerBtnIsDisabled();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207753,dailyPartTimeCustomer,1271369,Gopal,Deliver to Home,1,PRE,7ud921,payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691079", projectId = "91768", testCaseName = "Pre Pay - Select a Subscription with Alt payer - Replace payment Method and Verify if the new Mandate is generated", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userVerifiesIfTheNewMandateIsGenerated(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode, String paymentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesPaymentMethodAndClickOnReplaceButton(customerName,paymentType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev allpurpose,204,207635,montlySolutionCustomer,1271247,Robin,Deliver to Home,1,PRE,-21,10,first,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687348", projectId = "91768", testCaseName = "Pre Pay - Monthly - Update Customer Information and verifies Supply chain Lead Time and Regular Payment and Delivery Date", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userVerifiesSupplyChainLeadTime(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String leadTime, String noOfDays, String payment, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetailsWithoutClickingconfirm(customerType, customerName, customerID);
        clsp.userUpdatesCustomerDetails();
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userIsAbleToVerifyLeadTimeChanges(leadTime);
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        clsp.userIsAbleToVerifyCustomerDashboard();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207678,montlyNoSolutionCustomer,1271290,Caispass,Deliver,1,PRE,diffAddress,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687810", projectId = "91768", testCaseName = "Pre Pay - Monthly - Delivery Address - New", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsNewDeliveryAddress(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.userSelectsDeliveyTypeAsDifferentAddress(customerType,customerName,customerID,addressType);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207662,dailyPartTimeCustomer,1271274,Tessy,Deliver to Home,1,PRE,Home,7ud921,newPayment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687820", projectId = "91768", testCaseName = "Pre Pay - Add NEW Alternate Payer - Store User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddNEWAlternatePayerStoreUser(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode, String paymentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.verifyCustomerDetails(customerType,customerName,customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID,customerType,customerName,deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClicksPaymentMethodAndAddNewAlterPayerDetails(customerName,authCode);
        clsp.userVerifiesAltPayeDdeatilsAndPackStatusAsPending(customerName,paymentType);
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207807,dailyPartTimeCustomer,1271422,Astin,Deliver to Home,1,PRE,7ud921,payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687851", projectId = "91768", testCaseName = "Pre Pay - Create Subscription with Alt payer - Replace Payment Method with same Alt Payer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userReplacePaymentWithSameAlterPayer(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode, String paymentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userIsAbleToAddAlternatePayer(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifyPaymentMethodAndClickOnReplaceButton(customerName,paymentType);
        clsp.userEntersNewPaymentDetailsAndVerifyDetailsOnReceipt(payerType, customerName,authCode);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,208573,montlyNoSolutionCustomer,1272419,Rajani,Deliver to Home,montlyNoSolutionSecondCustomer,1,PRE,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691108", projectId = "91768", testCaseName = "Pre Pay - Add a second Subscription - Use EXISTING payment details", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsSecondSubscriptionUsingExistingPaymentDetails(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String secondCustomerType,String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userNavigatesToActiveClfitsTabAndClicksOnSubscribeButton();
        clsp.userCreatesNewMonthlySubscriptionfromActivefit(solutionType, deliveryType, payerType, authCode,secondCustomerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClicksSecondEditSubscriptionButton();
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        clsp.userSelectsPackageTabFromDashboardAndVerifyPackageDetails(solutionType);
        clsp.userVerifyFITDetailsForNoSolution(secondCustomerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207675,montlyNoSolutionCustomer,1271287,Thor,Deliver to Home,1,PRE,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42692769", projectId = "91768", testCaseName = "Pre Pay - Monthly - Delivery Address - Store", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsMonthlyDeliveryAddressStore(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType,customerName,customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID,customerType,customerName,deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev allpurpose,204,207636,montlySolutionCustomer,1271248,Jackson,Deliver to Home,1,Post,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42692771", projectId = "91768", testCaseName = "Post Pay - Monthly - Solution_Regular Payment and Delivery Date ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsMonthlySolutionPaymentAndDeliveryDate(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userIsAbleToVerifyCustomerDashboard();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        clsp.userVerifiesPaymentSchedule();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207941,dailyPartTimeCustomer,1271563,Chloe,Deliver to Home,1,Pre,3 month 50%,7ud921,200"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693434", projectId = "91768", testCaseName = "New Sign Up - Low Start 50% for 3 Months discount ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userVerifying3MonthsDiscount(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String discountType, String authCode, int status) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectingDailyTypeWithDiscount(dailyType,deliveryType,payerType,discountType,authCode,customerType );
        clsp.userVerifiesCustomerDetails(dailyType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesStoreUrlCustomerSearchPageAndFindsExistingCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207947,dailySingleEyePartTimeCustomer,1271571,Singleeyetest,Deliver to Home,1,Pre,dailySingleEyeFullTimeCustomer,Right,Home,7ud921,Full Time"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693489", projectId = "91768", testCaseName = "CLSP single eye subscription for ROI daily customer ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userCreatesSingleEyeSubscription(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String customerTypeSingleEye, String eyeType, String fulfilmentType, String authCode,String newUsage) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createNewAccount();
        clsp.userVerifySingleEyesDetails(eyeType, customerType);
        clsp.userSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userVerifiesCustomerDetails(dailyType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesSingleEyeLensOnDashboard(eyeType, customerType);
        clsp.userClickOnEditSubscription();
        clsp.userPerformsChangeUsage(newUsage,customerTypeSingleEye);
        clsp.userVerifyFITDetailsForSingleEye(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev allpurpose,204,207635,montlySolutionCustomer,1271247,Robin,Deliver to Home,1,Pre,Right,Both,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693949", projectId = "91768", testCaseName = "CLSP single eye subscription for ROI monthly solution customer ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userCreatesSingleEyeForMonthlySolution(String solutionType, int apiStatus, String customerId, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String eyeType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerId, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.userVerifiesCustomerDetails(solutionType, customerName, customerId);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerId, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerId);
        clsp.userVerifiesSingleEyeLensOnDashboard(eyeType, customerType);
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesPaymentSchedule();
        apiObj.userDeletesCustomer(customerId, apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207949,1271573,Sandeep,Deliver to Home,1,Pre,montlyNoSolutionCustomerSingleEye,Right,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691106", projectId = "91768", testCaseName = "CLSP single eye subscription for ROI monthly no solution customer ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userCreatesSingleEyeForMonthlyNoSolution(String solutionType, int apiStatus, String customerID, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String customerType, String eyeType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesSingleEyeLensOnDashboard(eyeType, customerType);
        clsp.userClickOnEditSubscription();
        clsp.userSelectsPackageTabFromDashboardAndVerifyPackageDetails(solutionType);
        clsp.userVerifyFITDetailsForNoSolution(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "Occasional,204,207654,dailyOccasionalCustomer,1271266,Vinod,Deliver to Home,1,Pre,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691149", projectId = "91768", testCaseName = "Pre Pay - Change EXISTING Alternate Payer Details - Store User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userChangeExistingAlternatePayerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType,customerName,customerID,authCode);
        clsp.userLaunchesStoreUrlCustomerSearchPageAndFindsExistingCustomer(customerID);
        clsp.userClicksOnManagePaymentMethodTabAndEditAlternatePayerDetails();
        clsp.userVerifiesAllTheUpdatedDetailsOnCustomerDashboard();
        apiObj.userDeletesCustomer(customerID,apiStatus);

    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207632,dailyPartTimeCustomer,1271244,Snow,Deliver to Home,1,Pre,NONE,Enquiry,Skype,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687337", projectId = "91768", testCaseName = "Pre Pay - Daily - Add an Alternate Payer and Adding and Removing Permission to speak with a Thrid Party", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddAndRemovesThirdPartyPermission(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String noteSub, String noteType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesAltPayerDetailsOnDashBoard();
        clsp.userHighlightAdditionalContactButton();
        clsp.userVerifiesAltPayerDetailsOnDashBoard();
        clsp.userAddContactIsAndVerifyAdditionalContactButton(customerID,noteSub,noteType);
        clsp.userUnHiLightsTheAdditionalContactButtonAndVerifiesIt(customerID);
        apiObj.userDeletesCustomer(customerID,apiStatus);
    }

    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "Occasional,204,207847,dailyOccasionalCustomer,1271462,Ivan,Deliver to Home,1,Pre,payer,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693950", projectId = "91768", testCaseName = "DF-1461_Payment Method - Adding a new payment method and Alternate Payer triggers - 305 - Failed to create new payment error message.DF-1537", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsNewPaymentAndTriggerAlternatePayer(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesStoreUrlCustomerSearchPageAndFindsExistingCustomer(customerID);
        clsp.userRemovesPayerAndAddsNewPaymentAndNewAlternatePayerDetails(addressType);
        apiObj.userDeletesCustomer(customerID,apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207683,montlyNoSolutionCustomer,1271295,Root,Deliver to Home,1,PRE,Home,PENDING,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693951", projectId = "91768", testCaseName = "DF-101-CLDG-SIT-UI-DCLDG-GENERAL- New subscriptions - There is currently no method to prevent duplicate subscriptions (First Sub Pending)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userPreventDuplicateSubscriptionForFirstSubPending(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String subStatus, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userNavigatesToActiveClfitsTabAndClicksOnSubscribeButton();
        clsp.userCreatesNewMonthlySubscriptionfromActivefit(solutionType, deliveryType, payerType, authCode,customerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userMustBeAbleToVerifyStatusOfOtherSubscription(subStatus);
        clsp.userClicksSecondEditSubscriptionButton();
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        apiObj.userDeletesCustomer(customerID,apiStatus);
    }


//    @CLSP_SMOKE
//    @CLSP_ROISignup
//    @ParameterizedTest
//    @CsvSource({
//            "No Solution,204,207669,montlyNoSolutionCustomer,1271281,James,Deliver to Home,1,PRE,Active,Moving,200,7ud921"
//    })
//    @Tags(value = {@Tag("uk"), @Tag("ie")})
//    @SSParametrizedTest(testCaseId = "42693952", projectId = "91768", testCaseName = "DF-101-CLDG-SIT-UI-DCLDG-GENERAL- New subscriptions - There is currently no method to prevent duplicate subscriptions (First Sub Active)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
//    void userPreventDuplicateSubscriptionForFirstSubActive(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String subStatus, String reason, int status, String authCode) throws Exception {
//        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
//        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
//        clsp.userClickOnConfirmButton();
//        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
//        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
//        clsp.userCancelsTheSubscription(reason);
//        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
//        clsp.userNavigatesToActiveClfitsTabAndClicksOnSubscribeButton();
//        clsp.userCreatesNewMonthlySubscriptionfromActivefit(solutionType, deliveryType, payerType, authCode,customerType);
//        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
//        clsp.userMustBeAbleToVerifyStatusOfOtherSubscription(subStatus);
//        clsp.userClicksSecondEditSubscriptionButton();
//        clsp.userVerifiesPaymentSchedule();
//        clsp.userAbleToVerifySubsequentDeliveryDate();
//        apiObj.userDeletesCustomer(customerID,apiStatus);
//    }



    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,207807,dailyPartTimeCustomer,1271422,Astin,Deliver to Home,1,PRE,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42692882", projectId = "91768", testCaseName = "DF-1537_Payment Method - Alt Payer - I am able to add an alt payer to an existing payment method without replacing the method itself (New Sub)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userAddsAlterWithoutReplacingMethod(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType,deliveryType,payerType,customerType);
        clsp.userVerifiesCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesConfirmButtonUponAddingAndRemovingAlternatePayer();
        apiObj.userDeletesCustomer(customerID,apiStatus);
    }

    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,207683,montlyNoSolutionCustomer,1271295,Root,Deliver to Home,1,PRE,200,Home,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691139", projectId = "91768", testCaseName = "CLSP-2746_Unspecified gender should be populated as Unknown in esuite and in Reports", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userPopulatingGenderInESuite(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, int status, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        apiObj.userDeletesCustomer(customerID,apiStatus);
    }


    @CLSP_SMOKE
    @CLSP_ROISignup
    @ParameterizedTest
    @CsvSource({
            "easyvision allpurpose ev allpurpose,204,207948,montlyNoSolutionCustomerSingleEye,1271572,Joshwa,Deliver to Home,1,PRE,200,Home,3 month 50%,No solution,NoDiscount,montlySolutionCustomerSingleEye,7ud921"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42691146", projectId = "91768", testCaseName = "single eye with completed payment and change usage without discount", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
   
    void userVerifiesSingleEyePaymentWithoutDiscount(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, int status, String fulfilmentType,String discountType, String updatedSolution,String discountType1, String customerTypeSingleEye, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        clsp.userUpdatesMonthlyPackage(updatedSolution);
        clsp.userClicksOnBackButton();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        clsp.userUpdatesMonthlyPackage(solutionType);
        clsp.userClicksOnBackButton();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        apiObj.userDeletesCustomer(customerID,apiStatus);
        clsp.CloseAllBrowser();
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerTypeSingleEye, customerName, deliveryType,fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType1, customerTypeSingleEye);
        clsp.userUpdatesMonthlyPackage(updatedSolution);
        clsp.userClicksOnBackButton();
        clsp.userVerifyDiscountPaymentPlan(discountType1, customerTypeSingleEye);
        clsp.userUpdatesMonthlyPackage(solutionType);
        clsp.userClicksOnBackButton();
        clsp.userVerifyDiscountPaymentPlan(discountType1, customerTypeSingleEye);
        apiObj.userDeletesCustomer(customerID,apiStatus);
    }
    @AfterEach
    @CLSP_SMOKE
    @CLSP_ROISignup
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose(){
        driver.quit();
    }

    


}
