package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static junit.framework.Assert.assertTrue;


public class CustomerSearchPage extends clspBase {

    protected static final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(CustomerSearchPage.class);

    public static String flag = null;

    @FindBy(xpath = "//input[contains(@id,'customer-id')]")
    public WebElementFacade searchCustID;

    @FindBy(xpath = "//input[@id='customer-surname']")
    private WebElementFacade searchLastName;

    @FindBy(xpath = "//button[contains(text(),'Search for customer')]")
    private WebElementFacade searchCustomerBtn;

    @FindBy(xpath = "//th[text()='Name']//..//..//following-sibling::tbody//tr")
    List<WebElement> customerIdInTable;

    @FindBy(xpath = "//button[@class='pull-right']")
    List <WebElement> selectButton;

    @FindBy(xpath = "//input[@id='customer-forename']")
    private WebElementFacade searchFirstName;

    @FindBy(xpath = "//button[contains(text(),'Select')]")
    private WebElementFacade customerSelectBtn;

    @FindBy(xpath = "//h1[contains(text(),'Customer Dashboard')]")
    private WebElementFacade customerDashboardHeader;

    @FindBy(xpath = "//input[@id='customer-postcode']")
    private WebElementFacade searchPostcode;

    @FindBy(xpath = "//input[@id='customer-dob']")
    private WebElementFacade searchCustDOB;

    @FindBy(xpath = "//input[@id='store']")
    private WebElementFacade searchCustStore;

    @FindBy(xpath = "//div/ngb-alert[@class='alert invalid-last-name-alert alert-danger']")
    private WebElementFacade validateLastname;

    @FindBy(xpath = "//div/ngb-alert[@class='alert invalid-first-name-alert alert-danger']")
    private WebElementFacade validateFirstname;

    @FindBy(xpath = "//div/ngb-alert[@class='alert invalid-postcode-alert alert-danger']")
    private WebElementFacade validatePostcode;

    @FindBy(xpath = "//ngb-alert[@class='invalid-dob-alert alert alert-danger']")
    private WebElementFacade dobwarning;

    @FindBy(xpath = "//div[2]/table/tbody/tr/td[3]")
    private WebElementFacade validateDOB;

    @FindBy(xpath = "//button[@class='button clear-all-search-fields']")
    public WebElementFacade clearSearchfieldsButton;

    @FindBy(xpath = "//*[@role='tooltip']")
    private WebElementFacade minReqField;

    @FindBy(xpath = "//button[@class='button clear-all-search-fields' and @disabled]")
    private WebElementFacade disabledClearSearchfieldsButton;

    @FindBy(xpath = "//input[@id='mandate-id']")
    private WebElementFacade mandateId;

    @FindBy(xpath = "//div[@role='option']")
    List <WebElement> storeList;

    public void searchExistingCustomerUsingCorrectSurname(String client_user_id) {
        final String lastname = "AutoTest";
        final String customerID = client_user_id;
        searchCustID.clear();
        searchLastName.clear();
        setText(searchCustID, customerID);
        logger.info(customerID);
        setText(searchLastName, lastname);
        clickElement(searchCustomerBtn);
    }
    public void listOfCustomersWhoHaveMatchingDetails(String client_user_id) {
        final String customerID = client_user_id;
        assertTrue(customerIdInTable.get(0).isDisplayed());


        for (int i=0;i<customerIdInTable.size();i++) {
            try {
                final String customerId = customerIdInTable.get(i).getText();
                logger.info("Customer ["+i+"] "+customerId);
                if(customerId.equals(customerID)) {
                    logger.info("Customer id = "+customerId);
                    clickOn(selectButton.get(i));
                    waitFor(customerDashboardHeader);
                }

            }
            catch(IndexOutOfBoundsException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void searchExistingCustomerUsingCorrectForename(String firstName,String client_user_id) {
        final String forename = firstName;
        final String customerID = client_user_id;
        logger.info(customerID);
        clearTextFromTextBox(searchCustID);
        setText(searchCustID,customerID);
        clearTextFromTextBox(searchFirstName);
        setText(searchFirstName,forename);
        searchCustomerBtn.waitUntilClickable();
        clickElement(searchCustomerBtn);
    }
    public void searchExistingCustomerUsingCorrectCustomerId(String client_user_id) {
        final String customerID =client_user_id;
        setText(searchCustID,customerID);
        clickElement(searchCustomerBtn);
    }
    public void validateSplCharOnSearchPageCombineString(String percentage,String underscore,String leftSquare,String rightSquare,String caret,String errorMsg) {

        setText(searchLastName,"gevfv"+percentage);
        setText(searchFirstName,"sdfsdf"+percentage);
        setText(searchPostcode,"sdh"+percentage);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,"gevfv"+underscore);
        setText(searchFirstName,"sdfsdf"+underscore);
        setText(searchPostcode,"sdh"+underscore);
        searchLastName.click();
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickOn(clearSearchfieldsButton);

        setText(searchLastName,"gevfv"+leftSquare);
        setText(searchFirstName,"sdfsdf"+leftSquare);
        setText(searchPostcode,"sdh"+leftSquare);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,"gevfv"+rightSquare);
        setText(searchFirstName,"sdfsdf"+rightSquare);
        setText(searchPostcode,"sdh"+rightSquare);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,"gevfv"+caret);
        setText(searchFirstName,"sdfsdf"+caret);
        setText(searchPostcode,"sdh"+caret);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);


    }


    //Validate special characters for firstname, lastname and Postcode
    public void validateSplCharOnSearchPage(String percentage,String underscore,String leftSquare,String rightSquare,String caret,String errorMsg) {

        setText(searchLastName,percentage);
        setText(searchFirstName,percentage);
        setText(searchPostcode,percentage);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,underscore);
        setText(searchFirstName,underscore);
        setText(searchPostcode,underscore);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,leftSquare);
        setText(searchFirstName,leftSquare);
        setText(searchPostcode,leftSquare);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,rightSquare);
        setText(searchFirstName,rightSquare);
        setText(searchPostcode,rightSquare);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName,caret);
        setText(searchFirstName,caret);
        setText(searchPostcode,caret);
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);

        clickElement(clearSearchfieldsButton);

        setText(searchLastName," ");
        setText(searchFirstName," ");
        setText(searchPostcode," ");
        clickElement(searchLastName);
        assertPageObjectIsDisplayed(validateLastname);
        assertElementContainsText(validateLastname,errorMsg);
        assertPageObjectIsDisplayed(validateFirstname);
        assertElementContainsText(validateFirstname,errorMsg);
        assertPageObjectIsDisplayed(validatePostcode);
        clickElement(clearSearchfieldsButton);
    }
    public void verifyClearAllFunctionality(String lastName,String firstName,String client_user_id) {
        assertPageObjectIsDisplayed(disabledClearSearchfieldsButton);
        setText(searchLastName,lastName);
        setText(searchFirstName,firstName);
        setText(searchPostcode,"PO157PA");
        setText(searchCustID,client_user_id);
        setText(searchCustDOB,testDataManager.getTestInputRegionData("createCustomer.date_of_birth"));
        waitFor(clearSearchfieldsButton);
        assertPageObjectIsDisplayed(clearSearchfieldsButton);
        clickElement(clearSearchfieldsButton);

        assertTrue(searchLastName.getText().isEmpty());
        assertTrue(searchFirstName.getText().isEmpty());
        assertTrue(searchPostcode.getText().isEmpty());
        assertTrue(searchCustID.getText().isEmpty());
        assertTrue(searchCustDOB.getText().isEmpty());
    }
    public void verifyStoreListWithPrefix(String prefix) {

        setText(searchCustStore,prefix);
        int j = storeList.size();
        for (int i=0;i<j;i++) {
            assertTrue(storeList.get(i).getText().startsWith(prefix));
        }

    }
    public void openCustomerCenterUrl ()
    {
        openUrl(testDataManager.getTestInputCommonData("url.customerCenterPageUrl"));
        flag = "contactCenterPageAuthCode";
        logger.info("The flag is" +flag);
    }
    public void searchExistingCustomerByMandateID() {

        String mandateID = PaymentPage.mandateReference;
        clearTextFromTextBox(mandateId);
        setText(mandateId,mandateID);
        assertObjectIsNotInteractable(searchLastName);
        assertObjectIsNotInteractable(searchFirstName);
        assertObjectIsNotInteractable(searchCustDOB);
        assertObjectIsNotInteractable(searchPostcode);
        assertObjectIsNotInteractable(searchCustID);
        clickElement(searchCustomerBtn);
        clickElement(customerSelectBtn);
        waitFor(customerDashboardHeader);

    }
    public void verifyCustomerIDField(String client_user_id){
        assertElementValue(searchCustID, client_user_id);
        clickElement(clearSearchfieldsButton);
    }


}
