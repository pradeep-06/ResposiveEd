package clsp.ui.steps;

import clsp.ui.pages.BacsLogin;
import clsp.ui.pages.EsuiteLogin;
import clsp.ui.pages.PaymentPage;
import clsp.ui.pages.SearchPage;
import clsp.ui.pages.SubscriptionPage;
import net.thucydides.core.steps.ScenarioSteps;

import java.io.IOException;

public class NavigateToESuite extends ScenarioSteps {

    EsuiteLogin esuiteLogin = new EsuiteLogin();

    SearchPage searchPage;

    BacsLogin bacsLogin;
    PaymentPage paymentPage;
    SubscriptionPage subscriptionPage;

    public void userLoginInESuiteAndFetchPendingFulfillmentReport(){
        esuiteLogin.openESuiteUrl();
        esuiteLogin.userLoginIneSuite();
        esuiteLogin.userClickOnReportsTab();
        esuiteLogin.userFetchPendingFulfillmentReport();
        esuiteLogin.logoutFromESuite();

    }
    public void userVerifiesPendingFulfillmentReport(String dailyType) throws Exception{
        esuiteLogin.verifyPendingFulfillmentReport(dailyType,searchPage.customerID,searchPage.store_id,searchPage.payerTypeAPI,searchPage.nonLensMailOrderValue,searchPage.deliveryDateAPI,searchPage.firstPackStatus,searchPage.supplierNotificationDate,searchPage.account_id,searchPage.orderLineType,searchPage.orderId);
    }
    public void userLoginInBacsAndVerifyTransactionForTodayDate(String dailyType) throws Exception {
        bacsLogin.openBacsUrl();
        bacsLogin.userLoginInBacs();
        bacsLogin.userEntersBacMandateReference(paymentPage.mandateReference,searchPage.firstName,searchPage.lastName,searchPage.email);
        bacsLogin.userVerifiesBacsTransaction(dailyType,paymentPage.mandateReference,searchPage.firstName,searchPage.lastName,searchPage.paymentAmount);
        bacsLogin.logoutFromBacs();
    }
    public void userLoginInEsuiteAndFetchStoreBalanceReport() {
        esuiteLogin.openESuiteUrl();
        esuiteLogin.userLoginIneSuite();
        esuiteLogin.userClickOnReportsTab();
        esuiteLogin.userFetchStoreBalanceReport();
        esuiteLogin.logoutFromESuite();
    }
    public void captureStoreBalanceReportData() throws Exception {
        esuiteLogin.captureStoreBalanceReportData();
    }
    public void verifyStoreBalanceReport() throws Exception {
        esuiteLogin.verifyStoreBalanceReport(searchPage.nextPostpayPaymentAmt,searchPage.nextPrepayPaymentAmt);
    }
    public void userLoginInESuiteAndFetchCancellationReasonReport() {
        esuiteLogin.openESuiteUrl();
        esuiteLogin.userLoginIneSuite();
        esuiteLogin.userClickOnReportsTab();
        esuiteLogin.userFetchCancellationReasonReport();
        esuiteLogin.logoutFromESuite();
    }
    public void verifyCancellationReasonReport(String reason) throws Exception {
        esuiteLogin.verifyCancellationReasonReport(reason,searchPage.customerID,searchPage.store_id);
    }
    public void userLoginInEsuiteAndFetchSpecsaversFuturePaymentTransactionsReport() {
        esuiteLogin.openESuiteUrl();
        esuiteLogin.userLoginIneSuite();
        esuiteLogin.userClickOnReportsTab();
        esuiteLogin.userFetchSpecsaversFuturePaymentTransactionsReport();
        esuiteLogin.logoutFromESuite();
    }
    public void userVerifySpecsaversFuturePaymentTransactionsReport(String transactionType) throws Exception {
        esuiteLogin.verifySpecsaversFuturePaymentTransactionsReport(transactionType,searchPage.customerID,searchPage.nextPaymentAmt,searchPage.sub_description);
    }
    public void userLoginInESuiteAndFetchSpecsaversMultipleSubscriptionReport() {
        esuiteLogin.openESuiteUrl();
        esuiteLogin.userLoginIneSuite();
        esuiteLogin.userClickOnReportsTab();
        esuiteLogin.userFetchSpecsaversCustWithMultipleSubscriptionReport();
        esuiteLogin.logoutFromESuite();
    }
    public void userVerifiesSpecsaversMultipleSubscriptionReport(String status) throws Exception, Exception {
        esuiteLogin.verifySpecsaversCustomerWithMultipleSubscriptionReport(status,searchPage.customerID);
    }
    public void userLoginToeSuiteAndFetchSpecsaversFinanceReport() {
        esuiteLogin.openESuiteUrl();
        esuiteLogin.userLoginIneSuite();
        esuiteLogin.userClickOnReportsTab();
        esuiteLogin.userFetchesSpecsaversFinanceReport();
        esuiteLogin.logoutFromESuite();

    }
    public void userVerifiesSpecsaversFinanceReport(String customerType) throws Exception, Exception {
        esuiteLogin.verifiesSpecsaversFinanceReport(customerType,searchPage.customerID,searchPage.sub_description,searchPage.payerTypeAPI,searchPage.nonLensMailOrderValue);
    }
}
