package clsp.ui.stepDefinitions;


import Framework.DataManager.TestDataManager;
import clsp.ui.pages.SearchPage;
import clsp.ui.steps.NavigateToApi;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;


public class UserCreatesAPICustomer extends ScenarioSteps {

    public static String clientUser_id;

    @Steps
    NavigateToApi navigateToApi = new NavigateToApi();
    @Steps
    SearchPage searchPage = new SearchPage();

    TestDataManager testDataManager= new TestDataManager();

    @Step("user creates API customer")
    public void userCreatesDailyCust(String dailyType,int quantity,int status){
        navigateToApi.createDailyCust(dailyType,quantity,status);
    }
    @Step("user creates Daily customer payment completed")
    public void userCreatesDailyCustomerPaymentCompleted(String dailyType, int quantity, int status){
        navigateToApi.createDailyCustPaymentCompleted(dailyType,quantity,status);
    }
    @Step("user creates PostPay customer with Monthly No Solution Subscription and First Payment Completed")
    public void userCreatesPostPayCustomerMonthlyNoSolutionPaymentCompleted(int status) {
        navigateToApi.createPostPayNoSolutionPaymentCompleted(status);
    }

    @Step("user creates Daily Postpay customer")
    public void userCreatesPostpayDailyCust(String dailyType,int quantity,int status){
        navigateToApi.createPostpayDailyCust(dailyType,quantity,status);
    }
    @Step("user stores delivery dates")
    public void userStoresDeliveryDates(){
        navigateToApi.userStoresDeliveryDates();
    }
    @Step("user stores pack status")
    public void userStoresThePackStatus(){
        navigateToApi.userStoresThePackStatus();
    }
    @Step("user retrieves payment for store balance report")
    public void retrievePaymentsForStoreBalanceReport(){
        navigateToApi.retrievePaymentsForStoreBalanceReport();
    }
    @Step("user retrieves the pack status")
    public void  userRetrievesThePackStatus() {
        searchPage.userGetsTheSubscriptionDetails(0);
        userStoresThePackStatus();
    }
    @Step("user creates alternate payer for nonLensMail customer")
    public void userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(String dailyType, int quantity, int status, int newSubscriptionStatus){
        navigateToApi.userCreatesAlternatePayerDailyNonLensMailerCustomerSubscription(dailyType,quantity,status,newSubscriptionStatus);
    }
    @Step("user creates Monthly SOlution customer")
    public void userCreatesMonthlySolutionCust(int status){
        navigateToApi.userCreatesMonthlySolutionCust(status);
    }

    @Step("user creates Monthly No solution customer")
    public void userCreatesMonthlyNoSolutionCust(int status){
        navigateToApi.userCreatesMonthlyNoSolutionCust(status);
    }
    @Step("user creates Monthly No solution customer PostPay")
    public void userCreatesMonthlyNoSolutionCustomerPostPay(int status){
        navigateToApi.userCreatesMonthlyNoSolutionCust(status);
    }

    @Step("user Deletes customer")
    public void userDeletesCustomer(String customerID, int status){
        navigateToApi.deleteCustomer(testDataManager.getTestInputRegionData("address.storeNo")+"-"+customerID,status);
    }

    @Step("user deletes the customer")
    public void userDeletesCustomer(int status){
        navigateToApi.deleteCustomer(searchPage.customerID,status);
    }
    @Step("user Deletes customer from Env")
    public void userDeletesCustomerFromEnv(String status) {
        navigateToApi.userDeletsTheCustomerFromEnv(status);
    }
    @Step("user checks customer mail")
    public void userChecksMail(String customerType,int quantity,String packUsage) {
        navigateToApi.userChecksMail(customerType,quantity,packUsage);
    }


    @Step("user updates pack status for new customer")
    public void userUpdatingPackStatusToGivenStatus(int status,String customerID,String packStatus) {

        navigateToApi.userUpdatesPackStatusToGivenStatus(status,customerID,packStatus);
    }


    @Step("user updates pack status to given status")
    public void userUpdatePackStatusToGivenStatus(int status,String packStatus) {

        navigateToApi.userUpdatePackStatusToGivenStatus(status,packStatus);
    }
    @Step("user updates second pack status to given status")
    public void userUpdateSecondPackStatusToGivenStatus(int status,String packStatus) {

        navigateToApi.userUpdateSecondPackStatusToGivenStatus(status,packStatus);
    }
    @Step("user gets subscription details for customer")
    public void userGetsSubscriptionDetails(String customerID){
        navigateToApi.userGetsSubscriptionDetailsForCustomer(customerID);
    }
    @Step("user creates same day payment subscription using MPP")
    public void userCreateNewCustomerWithMonthlySolutionSubscriptionAndCompletedPack(int status) {
        navigateToApi.userCreatesNewCustomerWithMonthlySolutionSubscriptionAndCompletedPack(status);
    }
    @Step("user creates same day payment subscription using MPP")
    public void userCreatesCustomerWithPaymentCompleted(int status,String customerID) {
        navigateToApi.userCreatesCustomerWithPaymentCompleted(status,customerID);
    }
    @Step("user creates Subscription with single pack completed and store collection")
    public void userCreatesDailyCustomerSubscriptionWithCompletedPacks(String dailyType, int quantity, int status, String payerType){
        navigateToApi.userCreatesDailyCustomerSubscriptionWithCompletedPacks(dailyType,quantity,status,payerType);
    }
    @Step("user adds multiple subscription to an existing Daily customer with firstPack")
    public void createMultipleSubscriptionForDailyCustomer(String dailyType, int quantity, int status, String payerType) {
        navigateToApi.createMultipleSubscriptionForDailyCustomer(dailyType,quantity,status,payerType);
    }
    @Step("user requests for new customer to be created on Bank Holiday create new Monthly No Solution Subscription")
    public void userCreatesNewCustomerWithMonthlyNoSolutionOnBankHoliday(int status) throws Exception {
        navigateToApi.userCreateMonthlyNoSolutionBankHoliday(status);
    }
    @Step("user updates the second pack status")
    public void userUpdatesTheSecondPackStatus(String packStatus, int status) {
        navigateToApi.userUpdatesTheSecondPackStatus(packStatus,status);
    }
    @Step("^user requests for new PostPay customer to be created on Week end create new Monthly No Solution Subscription")
    public void userCreatesMonthlyNoSolutionBankHolidayPostPay(int status) throws Exception {
        navigateToApi.userCreatesMonthlyNoSolutionBankHolidayPostPay(status);
    }
    @Step("user creates PostPay customer with Monthly Solution Subscription and First Payment InFlight")
    public void userCreatePostPayMonthlySolutionFirstPaymentInFlight(int status) {
        navigateToApi.userCreatePostPayMonthlySolutionAndFirstPaymentInFlight(status);
    }
    @Step("user creates NonLensMailer PostPay Customer with and")
    public void userCreatesDailyNonLensMailerCustomerSubscriptionPostPay(String dailyType, int quantity, int status, int newSubscriptionStatus) {
        navigateToApi.userCreatesDailyNonLensMailerCustomerSubscriptionPostPay(dailyType,quantity,status,newSubscriptionStatus);
    }
    @Step("user gets subscription details and updates pack status to dispatch")
    public void userGetsSubscriptionDetailsAndUpdatesPackStatusToDispatch(String packStatus,int status) {
        navigateToApi.userGetsSubscriptionDetailsAndUpdatesPackStatusToDispatch(packStatus,status);
    }
    @Step("user updates pack due date to today date via admin")
    public void userUpdatesFirstPackDueDateToTodayDate(int status, String pack) {
        navigateToApi.userUpdatesFirstPackDueDateToTodayDate(status,pack);
    }
    @Step("user creates PostPay customer with Monthly Solution Subscription and First Payment Completed")
    public void userCreatesPostPayMonthlySolutionAndFirstPaymentCompleted(int status) {
        navigateToApi.userCreatesPostPayMonthlySolutionAndCompletedPack(status);
    }
    @Step("user creates discounted customer PostPay for the same day payment")
    public void userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(String dailyType, String discountType, int quantity, int status,int newSubscriptionStatus) {
        navigateToApi.userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(dailyType,discountType,quantity,status,newSubscriptionStatus);
    }

    @Step("user updates pack due date to today date")
    public void userUpdatesPackDueDate(String custID, String FullID, String date) {
        navigateToApi.userUpdatesPackDueDate(custID, FullID, date);
    }
    @Step("User performs goodwill payment")
    public void userPerformsGoodwill(String paymentNum, int status){
        navigateToApi.userPerformsGoodwill(paymentNum,status);
        waitABit(5000);
    }


}