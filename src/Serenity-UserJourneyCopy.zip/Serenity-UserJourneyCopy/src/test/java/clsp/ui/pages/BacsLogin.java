package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BacsLogin extends clspBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(EsuiteLogin.class);

    @FindBy(xpath = "//input[@id='txt_ClientId']")
    private WebElementFacade bacsClientId;

    @FindBy(xpath = "//input[@id='txt_Username']")
    private WebElementFacade bacsUserName;

    @FindBy(xpath = "//input[@id='txt_Password']")
    private WebElementFacade bacsPassword;

    @FindBy(xpath = "//input[@id='LogOn_Button']")
    private WebElementFacade bacsLogin;

    @FindBy(xpath = "//table[@id='ManagementHeader_HeaderTable']")
    private WebElementFacade bacsHeader;

    @FindBy(xpath = "//a[@id='ManagementHeader_Button_LogOff']")
    private WebElementFacade bacsLogOff;

    @FindBy(xpath = "//font[contains(text(),'Direct Debits')]")
    private WebElementFacade bacsDirectDebitMain;

    @FindBy(xpath = "//a[contains(@href,'directdebitaccounts')]")
    private WebElementFacade bacsDirectDebit;

    @FindBy(xpath = "//input[@id='txt_directDebitAccountId']")
    private WebElementFacade bacsReferenceInput;

    @FindBy(xpath = "//font[contains(text(),'Bacs Submission Reports')]")
    private WebElementFacade bacsSubmitionReport;

    @FindBy(xpath = "//input[@id='btn_processResult_Continue']")
    private WebElementFacade continueButton;

    @FindBy(xpath = "//input[@id='btn_search']")
    private WebElementFacade searchButton;

    @FindBy(xpath = "//span[contains(@id,'irstName')]")
    private WebElementFacade firstName;

    @FindBy(xpath = "//span[contains(@id,'astName')]")
    private WebElementFacade lastName;

    @FindBy(xpath = "//span[contains(@id,'bacsReference' ) or contains(@id,'BACSReference')]")
    private WebElementFacade bacsReference;

    @FindBy(xpath = "//span[@id='repeater_ListTransactions_ctl01_lblSettlementBatchId']")
    private WebElementFacade batchID;

    @FindBy(xpath = "//span[@id='repeater_ListItems_ctl01_lblEmailAddress']")
    private WebElementFacade emailaddress;

    @FindBy(xpath = "//input[@id='repeater_ListItems_ctl01_btnView']")
    private WebElementFacade viewButton;

    @FindBy(xpath = "//span[@id='repeater_ListTransactions_ctl01_lblTransactionType']")
    private WebElementFacade transactionType;

    @FindBy(xpath = "//span[@id='repeater_ListTransactions_ctl01_lblTransactionCode']")
    private WebElementFacade transactionCode;

    @FindBy(xpath = "//span[@id='lbl_accountHolderName']")
    private WebElementFacade viewAccountHolder;

    @FindBy(xpath = "//span[@id='lbl_accountNumber']")
    private WebElementFacade viewAccountNumber;

    @FindBy(xpath = "//span[@id='lbl_sortCode']")
    private WebElementFacade viewSortCode;

    @FindBy(xpath = "//span[@id='lbl_emailAddress']")
    private WebElementFacade viewEmailAddress;

    @FindBy(xpath = "//span[contains(@id,'lblCreated') or contains(@id,'ateCreatedUTC')]")
    List <WebElementFacade> transactionDate;

    @FindBy(xpath = "//span[@id='repeater_ListTransactions_ctl01_lblAmount']")
    private WebElementFacade amount;

    @FindBy(xpath = "//span[contains(@id,'Status')]")
    List <WebElementFacade> tranStatus;

    @FindBy(xpath = "//span[@id='repeater_ListTransactions_ctl01_lblDateToProcessUTC']")
    private WebElementFacade dateToProcess;


    public void openBacsUrl() {
        openUrl(testDataManager.getTestInputCommonData("url.bacsUrl"));
    }

    public void userLoginInBacs() {
        waitFor(bacsClientId);
        setText(bacsClientId, testDataManager.getTestInputCommonData("login.bacsClientID"));
        setText(bacsUserName, testDataManager.getTestInputCommonData("login.eSuiteUserName"));
        setText(bacsPassword, testDataManager.getTestInputCommonData("login.eSuitePassword"));
        clickElement(bacsLogin);
        waitABit(10000);
        bacsHeader.waitUntilVisible();
    }

    public void logoutFromBacs() {
        waitFor(bacsLogOff);
        clickElement(bacsLogOff);
        waitABit(5000);
        assertTrue(bacsClientId.isVisible());
    }
    public void userEntersBacMandateReference(String mandateReference,String first_Name,String last_Name,String email_id) throws Exception {

        bacsDirectDebitMain.waitUntilClickable();
        clickElement(bacsDirectDebitMain);
        waitABit(3000);
        bacsDirectDebit.waitUntilClickable();
        clickElement(bacsDirectDebit);
        assertTrue(bacsReferenceInput.isVisible());
        setText(bacsReferenceInput,mandateReference);
        clickElement(searchButton);

        Date date = new SimpleDateFormat("dd/MM/yyyy").parse(String.valueOf(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");
        String strDate = formatter.format(date);
        logger.info("After search:"+strDate);
        assertTrue(transactionDate.get(0).getText().contains(strDate));
        assertEquals(firstName.getText(), first_Name);
        assertEquals(lastName.getText(), last_Name);
        assertEquals(bacsReference.getText(), mandateReference);
        assertEquals(emailaddress.getText(), email_id);
        viewButton.click();
    }
    public void userVerifiesBacsTransaction(String dailyType, String mandateReference, String first_Name, String last_Name, String paymentAmount) throws ParseException {

        Date date = new SimpleDateFormat("dd/MM/yyyy").parse(String.valueOf(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");
        String strDate = formatter.format(date);

        assertEquals(bacsReference.getText(), mandateReference);
       assertTrue(transactionDate.get(0).getText().contains(strDate));
        assertEquals(firstName.getText(), first_Name);
        assertEquals(lastName.getText(), last_Name);
        assertEquals(viewAccountHolder.getText(), first_Name);
        assertEquals(viewAccountNumber.getText().substring(4), testDataManager.getTestInputRegionData("payment.accNumbIc").substring(4));
        assertEquals(viewSortCode.getText().substring(3), testDataManager.getTestInputRegionData("payment.accSortiBan").substring(3));
        assertEquals("PendingSubmission", tranStatus.get(0).getText());

        assertTrue(dateToProcess.getText().contains(strDate));
        assertTrue(transactionDate.get(1).getText().contains(strDate));
        assertEquals(amount.getText().substring(1), paymentAmount);
        assertElementEqualIgnoreCase(tranStatus.get(0),"PendingSubmission");
        assertEquals("DirectDebit", transactionType.getText());
        assertEquals("FirstPayment (01)", transactionCode.getText());
    }






















}
