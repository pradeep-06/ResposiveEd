package clsp.ui.stepDefinitions;

import Framework.DataManager.TestDataManager;
import clsp.ui.steps.NavigateToClsp;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class UserSignUp extends ScenarioSteps {

    @Steps
    NavigateToClsp navigateToClsp;

    protected final TestDataManager testDataManager = new TestDataManager();


    @Step("User Launches URL")
    public void launchURLForNewCustomer(String customerID, String customerType, String tdrNumber, String fit) {
        navigateToClsp.createAndLaunchURL(customerID, customerType, tdrNumber, fit);

    }

    @Step("User Selects Daily Package")
    public void createAccAndSelectDailyPackage(String dailyType, String deliveryType, String payerType, String customerType) {
        navigateToClsp.userCreatesACC();
        navigateToClsp.userSelectsDailyPackage(dailyType, deliveryType, payerType,customerType);
    }

    @Step("user creates new account")
    public void createNewAccount() {
        navigateToClsp.userCreatesACC();
    }

    @Step("User Selects Monthly Solution Type")
    public void userSelectsSolutionType(String solutionType, String deliveryType, String payerType,String customerType) throws Exception {
        navigateToClsp.userCreatesACC();
        navigateToClsp.userSelectsSolutionType(solutionType, deliveryType, payerType,customerType);
    }

    @Step("User Selects Monthly peroxide Solution Type")
    public void selectPeroxideSolutionType(String solutionType, String deliveryType, String payerType, String authCode,String customerType) throws Exception {
        navigateToClsp.userCreatesACC();
        navigateToClsp.selectPeroxideSolutionType(solutionType, deliveryType, payerType,authCode,customerType);
    }


    @Step("User Verifies Customer Details")
    public void verifyCustomerDetails(String customerType, String customerName, String customerID) {
        navigateToClsp.verifyCustomerAccDetails(customerType, customerName, customerID);
    }

    @Step("User Verifies Customer Details without clicking confirm")
    public void verifyCustomerDetailsWithoutClickingconfirm(String customerType, String customerName, String customerID) {
        navigateToClsp.verifyCustomerAccDetailsWithoutClickingConfirm(customerType, customerName, customerID);
    }

    @Step("User Clicks On confirm Button")
    public void userClickOnConfirmButton() {

        navigateToClsp.clicksOnConfirmButton();
    }

    @Step("User Enters payment Details and Prints Mandate")
    public void userEntersPaymentDetailsAndPrintsMandate(String customerName,String customerID, String authCode) throws Exception {
        navigateToClsp.entersPaymentDetailsAndPrintsMandate(customerName,customerID, authCode);
    }

    @Step("user enters payment details and close Print mandate")
    public void enterPaymentDetailsAndClosePrintMandate(String customerName,String authCode){
        navigateToClsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
    }

    @Step("USer Verifies Summary Page")
    public void userVerifiesSummaryPage(String customerID, String customerType, String customerName, String deliveryType, String fulfilmentType) throws Exception {
        navigateToClsp.verifySummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
    }
    @Step("user verifies summary page with print summary")
    public void userVerifySummaryPageWithPrintSummary(String customerID,String customerType,String customerName,String deliveryType, String fulfilmentType) throws Exception{
        navigateToClsp.verifySummaryPageWithPrintSummary(customerID,customerType,customerName,deliveryType,fulfilmentType);
    }

    @Step("User Launches contact center customer URL")
    public void userLaunchesCCURLAndSearchesCustomer(String customerID) {
        navigateToClsp.isOnTheContactCenterCustomerSearchPage();
        navigateToClsp.findExistingCustomerByID(customerID);
    }
    @Step("User is on customer search page URL")
    public void isOnTheContactCenterCustomerSearchPage() {
        navigateToClsp.isOnTheContactCenterCustomerSearchPage();
    }



    @Step("user launches store URL Customer Search page and finds Existing customer")
    public void userLaunchesStoreUrlCustomerSearchPageAndFindsExistingCustomer(String customerID) {
        navigateToClsp.IsOnStoreCustomerSearchPage();
        navigateToClsp.findExistingCustomerByID(customerID);
    }
    @Step("user launches store URL Customer Search page and finds customer")
    public void userLaunchesStoreUrlCustomerSearchPageAndFindsCustomer() {
        navigateToClsp.IsOnStoreCustomerSearchPage();
        navigateToClsp.findExistingCustomerByID();
    }


    @Step("User launches CC URL and searches Existing customer")
    public void userLaunchesCCURLAndSearchesExistingCustomer() {
        navigateToClsp.isOnTheContactCenterCustomerSearchPage();
        navigateToClsp.findExistingCustomerByID();
    }
    @Step("user finds existing customer by ID")
    public void userFindExistingCustomerByID(String customerID){
        navigateToClsp.findExistingCustomerByID(customerID);
    }

    @Step("User updates Customer Details")
    public void userUpdatesCustomerDetails() {

        navigateToClsp.updatesCustomerDetails();

    }

    @Step("user should be able to view the updated Address and Contact Information")
    public void verifyCustomerDetailsOnAddressBookTab() {
        navigateToClsp.verifyCustomerDetails();
    }


    @Step("User updates payment date")
    public void userUpdatesPaymentDate(String noOfDays, String payment) throws Exception {
        navigateToClsp.userUpdatesPaymentDate(noOfDays, payment);
    }


    @Step("User verfies payment schedule")
    public void userVerifiesPaymentSchedule() throws Exception {
        navigateToClsp.userVerifyPaymentSchedule();
    }


    @Step("User verifies subsequent delivery date")
    public void userAbleToVerifySubsequentDeliveryDate() throws Exception {
        navigateToClsp.userVerifySubsequentDeliveryDate();
    }


    @Step("User verfies payment schedule after second payment date")
    public void userAbleToVerifyPaymentScheduleAfterEditSecondPaymentDate() throws Exception {
        navigateToClsp.userVerifyPaymentScheduleAfterEditSecondPaymentDate();
    }

    @Step("User Clicks Edit Subscription")
    public void userClickOnEditSubscription() {
        navigateToClsp.clickOnEditSubscription();
    }

    @Step("User Performs Expedite Pack")
    public void userPerformsExpeditePack() {
        navigateToClsp.performExpeditePack();
    }

    @Step("User Performs Change Usage")
    public void userPerformsChangeUsage(String newUsage,String customerType) {
        navigateToClsp.performChangeUsage(newUsage,customerType);
    }

    @Step("User Adds alternate payer and Payment details")
    public void userAddsAlternatePayerAndPaymentDetails(String customerType, String customerName, String customerID,String authCode) throws Exception {
        navigateToClsp.verifyCustomerAccDetails(customerType, customerName, customerID);
        navigateToClsp.userAddsAlternatePayerDetails();
        //navigateToClsp.clicksOnConfirmButton();
        navigateToClsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
    }

    @Step("User Verifies Payment Replace and Alt payer replace Btn is disabled")
    public void userVerifiesPaymentReplaceAndAltPayerBtnIsDisabled() {
        navigateToClsp.verifyReplaceButtonIsDisabled();
    }

    @Step("user selects the address book and adds a new Address")
    public void userSelectsTheAddressBookAndAddANewAddress(String addressType) {
        navigateToClsp.addAnNewAddress(addressType);
    }

    @Step("user should able to change his address for selective pack")
    public void userShouldBeAbleToChangeHisAddressForSelectivePack() {
        navigateToClsp.editDeliveryAdd();
    }
    @Step("User Verifies Lens appears on customer Dashboard")
    public void userVerifiesLensAppearsOnCustomerDashboard(String customerType) {
        navigateToClsp.verifylensDetailsOnCustomerDashboard("Both", customerType);
    }

    @Step("user edits customer contact information")
    public void userEditsCustomerContactInformation() {

        navigateToClsp.editContactInformation();
    }

    @Step("user edits customer contact information")
    public void userClicksOnManagePaymentAndAddAlterPaymentDetails() {
        navigateToClsp.userNavigatesToManagePaymentTabAndAddsAlternatePayer();
    }

    @Step("user clicks on manage payment method tab and edit alternate payer details")
    public void userClicksOnManagePaymentMethodTabAndEditAlternatePayerDetails() {
        navigateToClsp.userClickOnManagePaymentMethodTabAndEditAlternatePayerDetails();
    }

    @Step("user verifys all the updated details on customer dashboard")
    public void userVerifiesAllTheUpdatedDetailsOnCustomerDashboard() {
        navigateToClsp.userVerifyAllTheUpdatedDetailsOnCustomerDashboard();
    }

    @Step("user clicks on Edit Alternate Payer and verifies the populated data")
    public void userClicksOnEditAlternatePayerAndVerifiesThePopulatedData() {
        navigateToClsp.userClicksOnEditAltrPayerAndVerifiesPayerDetails();
    }

    @Step("user clicks on edit alt payer button and verify the Alt payer detail upon clicking outside the Information Modal")
    public void useClicksAndVerifyTheAltPayerDetailOutsideTheInformationModal() {
        navigateToClsp.userVerifyTheAlternatePayerDetailsOutsideTheInformationModal();
    }

    @Step("user Select a Subscription with Alt payer Replace payment Method and Verify if the new Mandate is generated")
    public void userVerifiesPaymentMethodAndClickOnReplaceButton(String customerName,String paymentType) {
        navigateToClsp.userClicksOnManagePaymentMethodTabAndClickOnReplaceButton(customerName,paymentType);
    }

    @Step("user is able to verify lead time changes")
    public void userIsAbleToVerifyLeadTimeChanges(String leadTime) throws Exception {
        navigateToClsp.userVerifiesLeadTime(leadTime);
    }

    @Step("user clicks on Back button$")
    public void userClicksOnBackButton() {
        navigateToClsp.userClicksOnBackButton();
    }

    @Step("user verifies delivery dates on customer dashboard")
    public void userIsAbleToVerifyCustomerDashboard() {

        navigateToClsp.userVerifiesDeliveryDatesOnDashboard();
    }

    @Step("user selects delivey type as Different Address")
    public void userSelectsDeliveyTypeAsDifferentAddress(String customertype, String customerName, String customerID, String addressType) {
        navigateToClsp.verifyCustomerDetailsForMonthlyCustomerAndSelectDelivertToDifferentAddress(customertype, customerName, customerID, addressType);
        navigateToClsp.clicksOnConfirmButton();
    }

    @Step("user verifies Alt payer deatils on dashboard and pack status as pending")
    public void userVerifiesAltPayeDdeatilsAndPackStatusAsPending(String customerName,String paymentType) throws Exception {
        navigateToClsp.userVerifiesAltPayerPaymentDetails(customerName,paymentType);
        navigateToClsp.userClicksOnSubscriptionTab();
        navigateToClsp.clickOnEditSubscription();
        navigateToClsp.userVerifiesPackStatus();
    }

    @Step("user clicks on manage payment and add new alter payerdetails")
    public void userClicksPaymentMethodAndAddNewAlterPayerDetails(String customerName,String authCode) {
        navigateToClsp.userManagePaymentAndAddNewAlternatePayerDetails(customerName,authCode);
    }
    @Step("user enters alternate payer payment details")
    public void userEntersALtPayerPaymentDetailsAndPrintsMandate(String authCode){
        navigateToClsp.userEntersALtPayerPaymentDetailsAndPrintsMandate(authCode);
    }

    @Step("user adds alternate payer")
    public void userIsAbleToAddAlternatePayer(String customertype, String customerName, String customerID) {
        navigateToClsp.userAddingAlternatePayerDetails(customertype, customerName, customerID);
    }

    @Step("user verifies payment method and click on replace button")
    public void userVerifyPaymentMethodAndClickOnReplaceButton(String customerName,String paymentType) {
        navigateToClsp.userVerifiesPaymentMethodAndClickOnReplaceButton(customerName,paymentType);
    }

    @Step("user enters new payment details and verifies details on receipt")
    public void userEntersNewPaymentDetailsAndVerifyDetailsOnReceipt(String paymentType, String customerName, String authCode) {
        navigateToClsp.userEntersNewPaymentDetailsAndVerifyReceipt(paymentType, customerName,authCode);
    }
    @Step("user enters new payment details and verifies details on receipt")
    public void userEntersNewPaymentDetailsWithoutAlterPayerDetails(String paymentType, String authCode) {
        navigateToClsp.userEntersNewPaymentDetailsWithoutAlterPayerDetails(paymentType,authCode);
    }


    @Step("user click on subscription tab")
    public void userClicksOnSubscriptionTab() {
        navigateToClsp.userClicksOnSubscriptionTab();
    }

    @Step("user tries to perform a partial pack Replace")
    public void userTriesToPerformAPartialPackReplace(String replaceReason, String leftboxQty, String rightboxQty) {
        navigateToClsp.userPerformsPackReplace(replaceReason, leftboxQty, rightboxQty);
    }

    @Step("user must be able to view pack as requested for Replace with new address")
    public void userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(String addressType) {
        navigateToClsp.verifyPackReplaceStatus(addressType);
    }

    @Step("Close All Browser")
    public void CloseAllBrowser() {

        navigateToClsp.closeAllBrowserWindows();
    }

    @Step("user navigates to Active Clfits Tab and clicks on subscribe button")
    public void userNavigatesToActiveClfitsTabAndClicksOnSubscribeButton() {
        navigateToClsp.userClicksOnActiveFitTabAndClicksOnSubscribeButton();
    }
    @Step("user navigates to Active Clfits Tab and clicks on replace button")
    public void userNavigatesToActiveClFitsTabAndClicksOnReplaceButton(String authCode) {
        navigateToClsp.userClicksOnActiveFitTabAndClicksOnReplaceButton(authCode);
    }
    @Step("user navigates to active cl fit and validate replace subscription for peroxide solution")
    public void userValidateReplacePeroxideSolution(String solutionType,String authCode){
        navigateToClsp.userValidateReplacePeroxideSolution(solutionType,authCode);
    }
    @Step("user validate link functionality")
    public void userToValidateLinkFunctionality(){
        navigateToClsp.userToValidateLinkFunctionality();
    }

    @Step("user clicks on Second Subscription button")
    public void userClicksSecondEditSubscriptionButton() {
        navigateToClsp.clickOnSecondEditSubscriptionButton();
    }

    @Step("user selects tab from dashboard and verify package details")
    public void userSelectsPackageTabFromDashboardAndVerifyPackageDetails(String solutionType) {
        navigateToClsp.verifyCustomerPackageDetails(solutionType);
    }

    @Step("user selects CL FIT tab and verify FIT details")
    public void userSelectsCLFITTabAndVerifyFITDetails(String customerType) {
        navigateToClsp.verifyCustomerCLFitDataForMonthlySubscribed(customerType);
    }

    @Step("user creates New Monthly subscription")
    public void userCreatesNewMonthlySubscription(String solutionType, String deliveryType, String payerType, String authCode, String customerType) throws Exception {
        navigateToClsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        navigateToClsp.userClicksAgreementConfirmButton(authCode);
    }
    @Step("user creates New daily subscription")
    public void userCreatesNewDailySubscription(String dailyType, String deliveryType, String payerType, String authCode, String customerType) throws Exception {
        navigateToClsp.userSelectsDailyPackage(dailyType, deliveryType, payerType,customerType);
        navigateToClsp.userClicksAgreementConfirmButton(authCode);
    }

    @Step("user selects daily type with discount")
    public void userSelectingDailyTypeWithDiscount(String dailyType, String deliveryType, String payerType, String discountType, String authCode,String customerType) {
        navigateToClsp.userCreatesACC();
        navigateToClsp.userSelectDailyTypeSubscriptionWithDiscount(dailyType, deliveryType, payerType, discountType, authCode,customerType);
    }

    @Step("user verifies customer Details")
    public void userVerifiesCustomerDetails(String customerType, String customerName, String customerID) {
        navigateToClsp.verifyCustomerDetailsOnCreateAccountPage(customerType, customerName, customerID);
        navigateToClsp.userClicksOnConfirmButton();
    }

    @Step("user verifies discount on summary page")
    public void userVerifyDiscountOnSummaryPage(String discountType, String customerType) {
        navigateToClsp.userVerifiesDiscountOnSummaryPage(discountType, customerType);
    }

    @Step("user verifies discount plan")
    public void userVerifyDiscountPaymentPlan(String discountType, String customerType) {
        navigateToClsp.userVerifiesDiscountPaymentPlan(discountType, customerType);
    }

    @Step("user verifies single eye details on subscription page")
    public void userVerifySingleEyesDetails(String eyeType, String customerType) {
        navigateToClsp.userVerifiesSingleEyeDetails(eyeType, customerType);
    }

    @Step("user selects dailypackage")
    public void userSelectDailyPackage(String dailyType, String deliveryType, String payerType, String customerType) {
        navigateToClsp.userSelectsDailyPackage(dailyType, deliveryType, payerType,customerType);
    }

    @Step("user verifies single Eye lens details on Dashboard")
    public void userVerifiesSingleEyeLensOnDashboard(String eyeType, String customerType) {
        navigateToClsp.userVerifiesLensDetailsOnCustomerDashboard(eyeType, customerType);
    }

    @Step("user verify FIT details for single eye")
    public void userVerifyFITDetailsForSingleEye(String customerType) {
        navigateToClsp.verifyCustomerCLFitDataForSingleEye(customerType);
    }
    @Step("user verify FIT details for no solution eye")
    public void userVerifyFITDetailsForNoSolution(String customerType) {
        navigateToClsp.verifyCustomerCLFitDataForNoSolution(customerType);
    }

    @Step("user verifies Alt payer details on dashboard")
    public void userVerifiesAltPayerDetailsOnDashBoard() {
        navigateToClsp.userVerifiesAltPayerDetailsOnDashBoard();
    }

    @Step("user highlights additional contact button")
    public void userHighlightAdditionalContactButton() {
        navigateToClsp.userHighlightsAdditionalContactButton();
    }

    @Step("Adds Closed Note To Advise Who The Contact Is And Verifies The Additional Contact Button")
    public void userAddContactIsAndVerifyAdditionalContactButton(String customerID, String noteSub, String noteType) {
        navigateToClsp.userAddsContactAndVerifiesAdditionalContactButton(customerID, noteSub, noteType);
    }

    @Step("user unhilights the additional contact button and verifies it (.*)")
    public void userUnHiLightsTheAdditionalContactButtonAndVerifiesIt(String customerID) {
        navigateToClsp.unHiLightsTheAdditionalContactButtonAndVerifiesIt(customerID);
    }

    @Step("user performs Write Off")
    public void userTriesToPerformWriteOff() {
        navigateToClsp.performWriteOff();
    }

    @Step("user removes payer and adds new payment and new alternate payer details")
    public void userRemovesPayerAndAddsNewPaymentAndNewAlternatePayerDetails(String addressType) {
        navigateToClsp.userRemovesPayerAndNewAlternatePayerDetails(addressType);
    }
    @Step("user must be able to verify status of other Subscription")
    public void userMustBeAbleToVerifyStatusOfOtherSubscription(String subStatus) {
        navigateToClsp.verifyStatusOfOtherSubscription(subStatus);
    }
    @Step("user only cancels the subscription")
    public void  userCancelsTheSubscription(String reason) throws Exception	{
        navigateToClsp.performCancelSubscription(reason);
    }
    @Step("user verifies confirm button upon adding and removing alternate payer")
    public void userVerifiesConfirmButtonUponAddingAndRemovingAlternatePayer() {
        navigateToClsp.userVerifiesConfirmButton();
    }
    @Step("user updates monthly package")
    public void userUpdatesMonthlyPackage(String updatedSolution) {
        navigateToClsp.userUpdatesMonthlySolutionPackage(updatedSolution);
    }
    @Step("user navigated to manage payment method tab and verifies payment method and click on replace button")
    public void userVerifyPaymentMethodAndClickOnReplaceButton() {
        navigateToClsp.userVerifiesPaymentMethodAndClickOnReplaceButton();
    }
    @Step("user verifies payment details")
    public void userVerifiesPaymentDetails(String bic, String iban) {
        navigateToClsp.userVerifiesEnteredBICAndIBANIsValid(bic, iban);
    }
    @Step("user verifies validate button is disable for invalid IBAN")
    public void userVerifiesValidateButtonForInvalidIBAN(String bic, String iban) {
        navigateToClsp.userVerifiesValidateButtonForInvalidIBAN(bic, iban);
    }
    @Step("user validates auth code and perform refund for first payment")
    public void userValidatesAuthCodeAndPerformRefundForFirstPayment(String refundReason, String refundMethod, String authorizationCode) {
        navigateToClsp.userValidatesAuthCodeAndPerformRefundForFirstPayment(refundReason,refundMethod,authorizationCode);

    }
    @Step("user clicks on manage payment tab and verify payer details")
    public void userVerifiesPaymentDetails(){
        navigateToClsp.userVerifyPaymentDetails();
    }
    @Step("user updates package usage and verifies payments")
    public void userUpdatesPackageForDailyCustomer(String newPackage, String customerType) throws Exception {
        navigateToClsp.userUpdatesDailyUsagePackage(newPackage,customerType);
    }
    @Step("user must be able to verify that the Alternate Payer Details are not populated")
    public void userVerifiesThatTheAlternatePayerDetailsAreNotPopulated() {
        navigateToClsp.userVerifyThatTheAlternatePayerDetailsAreNotPopulated();
    }
    @Step("user tries to fill the Add alternate Payer details")
    public void userTryToFillTheAddAlternatePayerDetails() {
        navigateToClsp.userTriesToFillTheAddAlternatePayerDetails();
    }
    @Step("user tries to remove the newly added Alternate payer")
    public void userTryToRemoveTheNewlyAddedAlternatePayer() {
        navigateToClsp.userTriesToRemoveTheNewlyAddedAlternatePayer();
    }
    @Step("user tries to Reprint the mandate")
    public void userTryToReprintTheMandate() {
        navigateToClsp.userTriesToReprintTheMandate();
    }
    @Step("user should be able to verify the Alternate Payer and Mandate Reference$")
    public void userShouldBeAbleToVerifyTheAlternatePayerAndMandateReference() {
        navigateToClsp.userVerifiesReprintDetails();
    }
    @Step("user clicks on package tab and verifies daily package details")
    public void  userVerifyDailyPackageDetails(String dailyType) {
        navigateToClsp.verifyDailyPackageDetails(dailyType);
    }
    @Step("user updates package usage for daily subscription")
    public void userUpdateDailyPackage(String newPackage) {
        navigateToClsp.userUpdatesDailyPackage(newPackage);

    }
    @Step("user verifies Payment Schedule After Updating Usage")
    public void userVerifyPaymentScheduleAfterUpdatingUsage(String customerType) {
        navigateToClsp.userVerifiesPaymentScheduleAfterUpdatingUsage(customerType);
    }
    @Step("user tries to add a new note using Tab functionality")
    public void  userTriesToAddANewNote(String notes) {
        navigateToClsp.userAddsAnewNoteUsingTabKey(notes);
    }
    @Step("user is applying scheme Holiday for one pack")
    public void userIsApplyingSchemeHolidayForOnePack(String pack, String authorizationCode) {
        navigateToClsp.makingOnePackAsHoliday(pack,authorizationCode);
    }
    @Step("user is applying scheme Holiday for one pack with Authorization")
    public void updatingOnePackAsHolidayWithAuthorization(String pack, String authorizationCode) {
        navigateToClsp.updatingOnePackAsHolidayWithAuthorization(pack,authorizationCode);
    }
    @Step("user verifies that Expedite Pack is not Displayed under the Pack Select Action Drop down")
    public void userVerifiesThatExpeditePackIsNotDisplayed() {
        navigateToClsp.userVerifyThatExpeditePackUnderSelectActionDropDown();
    }
    @Step("user navigates to entitlements tab and claim an entitlements")
    public void userClaimsEntitlements(String entitlementType) {
        navigateToClsp.userNavigatesToEntitlementsTabAndClaimEntitlements(entitlementType);
    }
    @Step("user adds address in address book and click on confirm button")
    public void userAddsTheAddressInAddressBookAndClickOnConfirmButton(String addressType)	{

        navigateToClsp.addAnNewAddressInAddressBook(addressType);
    }
    @Step("user verifies Additional contact button is still highlighting and add close note")
    public void userVerifiesAdditionalContactButtonHighlighted(String noteSub, String noteType) {
        navigateToClsp.verifiesAdditionalContactButton(noteSub,noteType);
    }
    @Step("user tries to add a note to the subscription")
    public void userTriesToAddAndCloseNoteToSubscription(String noteSub,String noteType) {
        navigateToClsp.createNewNoteToSubscription(noteSub,noteType);
    }
    @Step("user trying to search existing Customer using correct surname")
    public void userTryingToSearchExistingCustomerUsingCorrectSurname()  {
        navigateToClsp.tryingToSearchExistingCustomerUsingCorrectSurname();
    }
    @Step("user will see a list of customers who have matching details and will select correct one")
    public void userWillSeeListOfCustomersWhoHaveMatchingDetails() {
        navigateToClsp.seeListOfCustomersWhoHaveMatchingDetails();
    }
    @Step("user trying to search existing Customer using correct forename")
    public void userTryingToSearchExistingCustomerUsingCorrectForename()  {
        navigateToClsp.tryingToSearchExistingCustomerUsingCorrectForename();
    }
    @Step("user trying to search existing Customer using correct customer id")
    public void userTryingToSearchExistingCustomerUsingCorrectCustomerId()  {
        navigateToClsp.tryingToSearchExistingCustomerUsingCorrectCustomerId();
    }
    @Step("user is able to verify Store ID")
    public void userIsAbleToVerifyStoreID() {
        navigateToClsp.userVerifiesStoreID();
    }
    @Step("user retrieves Hub Service, Carrier, FH, Order file No details of customer")
    public void userRetrievesHubServiceAndCarrierAndFHDetails() {
        navigateToClsp.retrievesHubServiceAndCarrierAndFHDetails();
    }
    @Step("user validates special characters ")
    public void validateSpecialCharacters(String percentage,String underscore,String leftSquare,String rightSquare,String caret,String errorMsg) {
        navigateToClsp.validateSplCharacters(percentage,underscore,leftSquare,rightSquare,caret,errorMsg);
    }

    @Step("user validates special characters combine with string")
    public void validateSpecialCharactersCombine(String percentage,String underscore,String leftSquare,String rightSquare,String caret,String errorMsg) {
        navigateToClsp.validateSplCharactersCombine(percentage,underscore,leftSquare,rightSquare,caret,errorMsg);
    }
    @Step("verify functionality of clear all button")
    public void verifyClearAllFn() {
        navigateToClsp.verifyClearAllFunction();
    }
    @Step("while entering store name, user is able to view stores with")
    public void verifyStoreList(String prefix) {
        navigateToClsp.verifyStoresWithPrefix(prefix);
    }
    @Step("user verifies the pack and payment status for all packs in schedule")
    public void userVerifiesThePackAndPaymentStatusForAllPacksInSchedule(String customerType) {
        navigateToClsp.userVerifiesThePackAndPaymentStatusForAllPacksInSchedule(customerType);
    }
    @Step("user tries to perform store fullFilMent")
    public void userTriesToPerformStoreFullFilMent()	{
        navigateToClsp.userPerformStoreFullFilMent();
    }
    @Step("user tries to perform store fulFillMent and changes to supplyChain")
    public void userPerformStoreFulFillMentAndChangesToSupplyChain(){
        navigateToClsp.userPerformStoreFulFillMentAndChangesToSupplyChain();
    }
    @Step("user tries to cancels the subscription with")
    public void  userCancelsSubscriptionWithDaysAndReason(int cancelDays,String reason) throws Exception	{

        navigateToClsp.performCancelSubscriptionAndVerifyPackPaymentStatus(cancelDays,reason);
    }
    @Step("user verifies that Update Package button is not enabled")
    public void userVerifyUpdatePackageButtonIsDisabled() {
        navigateToClsp.userVerifiesUpdatePackageButtonIsDisabled();
    }
    @Step("user verifies select Action Dropdown is Disabled")
    public void userVerifiesSelectActionDropdownIsDisabled()	{
        navigateToClsp.userVerifiesSelectActionDropdownIsDisabled();
    }
    @Step("user tries to updates change pack delivery date for payment and apply to futurePack")
    public void userTriesToUpdateChangePackDeliveryDate(String payment,String futurePack) throws Exception	{
        navigateToClsp.userUpdateChangePackDeliveryDate(payment,futurePack);
    }
    @Step("user verifies release to supply chain date after updating change pack delivery date")
    public void userVerifySupplyChainDate() throws Exception	{
        navigateToClsp.userVerifiesReleaseToSupplyChainDate();
    }
    @Step("user launches Store Customer Search page and find customer by mandate ID")
    public void userLaunchesStoreCustomerSearchPageAndFindsCustomerByMandateId() {
       navigateToClsp.userLaunchesStoreCustomerSearchPageAndFindsCustomerByMandateId();
    }
    @Step("user navigates to manage payment method tab and verifies payment method")
    public void userNavigatesToManagePaymentAndVerifiesPaymentMethod(String paymentType)  {
        navigateToClsp.userVerifiesPaymentMethodOnManagePaymentTab(paymentType);
    }
    @Step("user verifies payment status after performing holiday")
    public void userVerifiesPaymentStatusAfterPerformingHoliday(String paymentStatus) {
        navigateToClsp.userVerifiesPaymentStatus(paymentStatus);
    }
    @Step("user should not able to reinstate holiday pack")
    public void userShouldNotAbleToReinstateHolidayPack() {
        navigateToClsp.userShouldNotAbleToReinstateHolidayPack();
    }
    @Step("user must be able to verify the box quantity in package tab for replacement with store address")
    public void userMustBeAbleToVerifyTheBoxQuantity() {
        navigateToClsp.verifyBoxQuantities("storeAddress");
    }
    @Step("user tries to perform Replace pack for monthlySolution to no solution")
    public void userTriesToPerformReplacePackForMonthlySolutionToNoSolution(String replaceReason,String leftboxQty, String rightboxQty) {
        navigateToClsp.userTriesToPerformReplacePackForMonthlySolutionToNoSolution(replaceReason,leftboxQty,rightboxQty);
    }
    @Step("user verifies print schedule reciept")
    public void userToVerifyPrintScheduleReciept() throws Exception {
        navigateToClsp.userVerifiesPrintScheduleReciept();
    }
    @Step("user verifies print schedule reciept by downloading")
    public void verifyCompleteSubscriptionScheduleWithPrintSchedule() throws Exception {
        navigateToClsp.verifyCompleteSubscriptionScheduleWithPrintSchedule();
    }
    @Step("user marks pack collected from store")
    public void userCollectsPackFromStore()	{
        navigateToClsp.userMarksPackCollectedFromStore();
    }
    @Step("user clicks on Search Button")
    public void  userClicksOnSearchButton()	{
        navigateToClsp.userClicksOnSearchButton();

    }
    @Step("user should find the customerID appearing on customerID search field")
    public void  userFindCustomerIDAppearingOnSearchField()	{
        navigateToClsp.userFindsCustomerIDAppearingOnSearchField();

    }
    @Step("user should be able to verify Next payment and Delivery Date on customer Dashboard$")
    public void userVerifiesNextPaymentAndDeliveryDateOnCustomerDashboard()  {
        navigateToClsp.userVerifyNextPaymentAndDeliveryDateOnCustomerDashboard();
    }
    @Step("user clicks on back arrow button on browser")
    public void userClicksOnBackArrowButtonOnBrowser() {
        navigateToClsp.userClicksOnBackArrowButtonOnBrowser();
    }
    @Step("user tries to edit first payment date upTo max date")
    public void userTriesToEditFirstPaymentDateUpToMaxDate() throws Exception  {
        navigateToClsp.userEditFirstPaymentDateUpToMaxDate();
    }
    @Step("user verifies first payment status")
    public void userVerifiesThePaymentStatus() {
        navigateToClsp.userVerifiesPaymentStatusAndNavigateToManagementPaymentMethodTab();
    }
    @Step("user verifies Replace button is disabled")
    public void userVerifiesReplaceButton() {
        navigateToClsp.userVerifiesReplaceButton();
    }
    @Step("user reinstate holiday pack")
    public void userReinstateHolidayPack() {
        navigateToClsp.userReinstatePack();
    }
    @Step("user verify packs status as pending$")
    public void userVerifyPacksStatus() {
        navigateToClsp.userVerifiesPackStatus();
    }
    @Step("user verifies changing the address should impact on all future packs and update the status")
    public void verifiesChangingAddressShouldImpactOnAllFuturePacks(String addressType) {
        navigateToClsp.verifiesChangingAddressShouldImpactOnAllFuturePacks(addressType);
    }
    @Step("user clicks on Book Appointment and verify the Book Appointment Page is opened")
    public void userVerifiesTheBookAppointmentPageIsOpened() {
        navigateToClsp.userVerifyTheBookAppointmentPageIsOpened();
    }
    @Step("user deletes address")
    public void userDeletesAddress() {
        navigateToClsp.userDeletesNewlyAddedAddress();
    }
    @Step("user deletes address")
    public void userDeleteAddress() {
        navigateToClsp.userDeleteAddress();
    }
    @Step("user selects the address book and add a new Address for BFPO")
    public void userAddANewAddressForBFPO() {
        navigateToClsp.userAddsANewAddressForBFPO();
    }
    @Step("user turn on the Customer care alert and Alternate contact alert")
    public void userTurnOnTheCustomerCareAlertAndAlternateContactAlert() {
        navigateToClsp.userTurnOnTheCustomerCareAlertAndAlternateContactAlert();
    }
    @Step("user must be able to reload customer and verify both the alert should be turned on")
    public void userVerifyBothTheAlertShouldBeTurnedOn() {
        navigateToClsp.userVerifiesBothTheAlertShouldBeTurnedOn();
    }
    @Step("user must be able to turn off both the alerts")
    public void userAbleToTurnOffBothTheAlerts() {
        navigateToClsp.userMustBeAbleToTurnOffBothTheAlerts();
    }
    @Step("user navigates to manage payment method$")
    public void userNavigatesManagePaymentMethod() {
        navigateToClsp.userNavigateToManagementTab();
    }
    @Step("user should be able to change his address for all future packs")
    public void userShouldBeAbleToChangeHisAddressForAllFuturePacks() {
        navigateToClsp.toChangeHisAddressForAllFuturePacks("address");
    }
    @Step("user verifies Replaced Pack Status on package tab")
    public void userVerifiesReplacedPackStatusOnPackageTab() {
        navigateToClsp.verifiesReplacedPackStatusOnPackageTab();
    }
    @Step("user verifies delivery address for the replaced pack is same as the earlier address")
    public void userVerifiesReplacedPackDeliveryAddress() {
        navigateToClsp.verifiesTheDeliveryAddressForTheReplacedPack();
    }
    @Step("user verifies print receipt not visible for Replacement Pack under Replacement Tab")
    public void userVerifiesPrintReceiptNotVisibleUnderReplacementTab() {
        navigateToClsp.verifiesPrintReceiptNotVisibleForReplacementTab();
    }
    @Step("user clicks on replace button and clicks on remove payer button")
    public void userClicksOnReplaceButtonAndClicksOnRemovePayerButton(String addressType) {
        navigateToClsp.userClicksOnReplaceAndRemovesPayerDetails(addressType);
    }
    @Step("user verifies collected pack from store option is unavailable")
    public void userVerifiesCollectedPackFromStoreOptionIsUnavailable()	{
        navigateToClsp.userVerifiesCollectedPackOptionIsUnavailable();
    }
    @Step("user applies Holiday for maximum packs in subscription")
    public void userAppliesHolidayForMaximumPacksInSubscription() {
        navigateToClsp.makingPackAsHoliday();
    }
    @Step("user taking a customer off a scheme holiday and verify it")
    public void userTakingCustomerOffSchemeHolidayAndVerifyIt() {
        navigateToClsp.takingCustomerOffSchemeHolidayAndVerifyIt();
    }
    @Step("user verifies pack status as pending and first payment status as completed")
    public void userVerifiesPackStatusAsPendingAndFirstPaymentStatusAsCompleted() {
        navigateToClsp.userVerifiesPackStatusAsPendingAndFirstPaymentStatusAsCompleted();
    }
    @Step("user verifies service credit for store user")
    public void userVerifiesServiceCreditForStoreURL(String refundReason, String refundMethod, String authorizationCode) {
        navigateToClsp.userValidatesServiceCreditForStoreURL(refundReason,refundMethod,authorizationCode);
    }
    @Step("user verifies the Subscription Balance and First Payment Status after performing the refund")
    public void userVerifiesTheSubscriptionBalanceAndFirstPaymentStatusAfterRefund() {
        navigateToClsp.userVerifyTheSubscriptionBalanceAndFirstPaymentStatusAfterRefund();
    }
    @Step("user tries to perform a writeOff")
    public void userTriesToPerformAWriteOff(String writeOffType, String authCode,String alertMsgPart) throws Exception {
        navigateToClsp.userTriesToPerformAWriteOff(writeOffType,authCode,alertMsgPart);

    }
    @Step("user must be able to verify the payment status")
    public void userMustBeAbleToVerifyThePaymentStatus(String writeOffType)  {
        navigateToClsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);

    }
    @Step("user navigates to History Tab")
    public void userNavigatesToHistoryTab() {
        navigateToClsp.userNavigatesToHistoryTab();

    }
    @Step("user verifies that the Select Action dropdown is Disabled")
    public void  userVerifiesThatTheSelectActionDropdownIsDisabled() {
        navigateToClsp.userVerifiesActionDropdownButtonIsDisabled();
    }
    @Step("user verifies note after Write off")
    public void userVerifiesNoteAfterWriteOffOperation(String noteSub,String clinicalNotes,String noteType,String noteStatus1) {
        navigateToClsp.userCanVerifyNoteAfterWriteOff(noteSub, clinicalNotes, noteType, noteStatus1);
    }
    @Step("user verifies Refund reason after performing holiday")
    public void userVerifiesRefundReasonAfterPerformingHoliday(String refundReason,String noteSub, String noteType, String noteStatus) {
        navigateToClsp.userVerifiesRefundReason(refundReason,noteSub,noteType,noteStatus);
    }
    @Step("user must be able to verify Bad Debt Icon to be present")
    public void userMustBeAbleToVerifyBadDebtIconToBePresent() {
        navigateToClsp.userVerifiesBadDebtIcon();
    }
    @Step("user verifies Goodwill option is not available for next pending pack when first pack is in flight")
    public void userVerifiesGoodwillOptionIsNotDisplayed() {
        navigateToClsp.userVerifiesGoodwillOptionIsNotAvailable();
    }
    @Step("User clicks on GDPR link")
    public void userClicksOnGDPRButtonAndVerifiesGDPRConsentAppIsOpened() {
        navigateToClsp.userClicksOnGDPRVerifyConsentApp();
    }
    @Step("user verify socrates sync")
    public void userVerifySocratesSync(){
        navigateToClsp.userVerifySocratesSync();
    }
    @Step("user verifies completed payment status")
    public void userVerifiesCompletedPaymentStatus(){
        navigateToClsp.userVerifiesCompletedPaymentStatus();
    }
    @Step("to validate supplementary orders")
    public void toValidateSupplementaryOrder(String customerType){
        navigateToClsp.toValidateSupplementaryOrder(customerType);
    }

   //This step is created for SCE application usages
    @Step("User Selects Daily Package for SCE customer")
    public void createAccAndSelectDailyPackageForSCEApplication(String dailyType, String deliveryType, String payerType, String customerType) {
        navigateToClsp.userCreatesACCForSCE();
        navigateToClsp.userSelectsDailyPackageForSCE(dailyType, deliveryType, payerType, customerType);
    }

    // This method is for SCE application sync
    @Step("User Adds alternate payer and Payment details for SCE")
    public void userAddsAlternatePayerAndPaymentDetailsForSCE(String customerType, String customerName, String customerID,String authCode) {
        navigateToClsp.verifyCustomerAccDetailsForSCE(customerType, customerName, customerID);
        navigateToClsp.entersPaymentDetailsAndPrintsMandateForSCE(customerName,customerID,authCode);
    }
    @Step("user performs cancel payment")
    public void userVerifiesPaymentStatusAndCancelsPayment() {
        navigateToClsp.userVerifiesPaymentStatusAndCancelsPayment();
    }
    @Step("user verifies system notes after performing cancel payment")
    public void userVerifiesTheSystemNotesAfterPerformingCancelPayment() {
        navigateToClsp.userVerifiesTheSystemNotesAfterPerformingCancelPayment();
    }


    @Step("user creates New Monthly subscription from active fit")
    public void userCreatesNewMonthlySubscriptionfromActivefit(String solutionType, String deliveryType, String payerType, String authCode, String customerType) throws Exception {
        navigateToClsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        navigateToClsp.userClicksAgreementConfirmButtonandPrintMandate();
        navigateToClsp.waitABit(10000);
    }




    }


