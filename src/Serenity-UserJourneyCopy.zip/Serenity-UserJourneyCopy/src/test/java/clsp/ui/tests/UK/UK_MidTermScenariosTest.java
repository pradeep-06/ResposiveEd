package clsp.ui.tests.UK;

import Framework.Annotations.CLSP.CLSP_Esuite;
import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.CLSP.CLSP_UK_Midterm;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserJourneyBacsESuite;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class UK_MidTermScenariosTest {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    UserSignUp clsp;
    UserCreatesAPICustomer apiObj = new UserCreatesAPICustomer();
    @Steps
    UserJourneyBacsESuite eSuite;


    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Goodwill Payment,3444f,Goodwill payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724619", projectId = "91768", testCaseName = "CLSP-CONTACTCENTREAUTH-07 - Store Writeoff(Goodwill)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsGoodWill(int status, String dailyType, int quantity, int removedStatus, String writeOffType, String authCode, String alertMsgPart) throws Exception {
        apiObj.userCreatesDailyCust(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Moving,Write Off Debt,aa445,Write Off payment,System,Contact Centre authorisation used to process a WRITE_OFF,In Person,Closed,Cancellation,Original payment method SEPA,94c30,Dispatched,Processing"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724618", projectId = "91768", testCaseName = "CLSP-FR-05 - Write-Off - 10 - Write On Process - Sub CANCELLED - Pack CANCELLED - Pay MAX REFUNDED", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsWriteOff(int status, String dailyType, int quantity, int removedStatus, String reason, String writeOffType, String authCode, String alertMsgPart, String noteSub, String clinicalNotes, String noteType, String noteStatus1, String refundReason, String refundMethod, String authorizationCode, String packStatus, String packStatus2) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        apiObj.userUpdatePackStatusToGivenStatus(status,packStatus);
        apiObj.userUpdateSecondPackStatusToGivenStatus(status,packStatus2);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userClicksOnBackButton();
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userClicksOnBackButton();
        clsp.userVerifiesNoteAfterWriteOffOperation(noteSub, clinicalNotes, noteType, noteStatus1);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @ParameterizedTest
    @CsvSource({
            "200,PartTime,2,204,Cancellation,Original payment method SEPA,94c30,First,Holiday,Refund success for order ID,Support Note,Closed"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724621", projectId = "91768", testCaseName = "1690_Allow holidaying a pack with max refunded payments", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userAllowHolidayPackForRefund(int status, String dailyType, int quantity, int removedStatus, String refundReason, String refundMethod, String authorizationCode, String pack, String paymentStatus, String noteSub, String noteType, String noteStatus1) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType,quantity,status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifiesServiceCreditForStoreURL(refundReason, refundMethod, authorizationCode);
        clsp.updatingOnePackAsHolidayWithAuthorization(pack,authorizationCode);
        clsp.userVerifiesPaymentStatusAfterPerformingHoliday(paymentStatus);
        clsp.userToVerifyPrintScheduleReciept();
        clsp.userClicksOnBackButton();
        clsp.userVerifiesRefundReasonAfterPerformingHoliday(refundReason, noteSub, noteType, noteStatus1);
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @ParameterizedTest
    @CsvSource({
            "Occasional,3 month 50%,1,200,201,dailyOccasionalCustomer,Goodwill Payment,aa445,Goodwill Payment,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724625", projectId = "91768", testCaseName = "Manage Subscription - Application of Goodwill_Low Start 50% for 3 Months", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsDiscount(String dailyType, String discountType, int quantity, int status, int newSubscriptionStatus, String customerType, String writeOffType, String authCode, String alertMsgPart, int removedStatus) throws Exception {
        apiObj.userCreatesPostPayDiscountedDailyCustomerForTheSameDayPayment(dailyType, discountType, quantity, status, newSubscriptionStatus);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        apiObj.userDeletesCustomer(removedStatus);
    }



    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @ParameterizedTest
    @CsvSource({
            "PartTime,2,200,204,Goodwill Payment,7ud921,Goodwill Payment,aa445,Other,Customer Provided Goodwill Payment,In Person,Closed"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42693511", projectId = "91768", testCaseName = "DF-1384_Good Will Process - Payments Written off display as the original status on Print Schedule", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsWrittenOffStatusOnPaymentSchedule(String dailyType, int quantity, int status, int removedStatus, String writeOffType, String authCode, String alertMsgPart, String contactCenterAuthorizationCode, String noteSub, String clinicalNotes, String noteType, String noteStatus1) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType, contactCenterAuthorizationCode, alertMsgPart);
        clsp.userToVerifyPrintScheduleReciept();
        apiObj.userDeletesCustomer(removedStatus);
    }

    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,3,204,0,Deceased,Write On Debt,7ud921, Write On payment,agan4i,aa445,Processing"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42695762", projectId = "91768", testCaseName = "CLSP-CONTACTCENTREAUTH-07 - Store Writeoff (Write On)", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userPerformsStoreWriteOn(int status, String dailyType, int quantity, int removedStatus, int cancelDays, String reason, String writeOffType, String authCode, String alertMsgPart, String storeAuthorizationCode, String contactCenterAuthorizationCode, String packStatus) throws Exception {
        apiObj.userCreatesPostPayMonthlySolutionAndFirstPaymentCompleted(status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userCancelsSubscriptionWithDaysAndReason(cancelDays, reason);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userNavigatesToHistoryTab();
        clsp.userClickOnEditSubscription();
        clsp.userTriesToPerformAWriteOff(writeOffType, authCode, alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType, storeAuthorizationCode, alertMsgPart);
        clsp.userTriesToPerformAWriteOff(writeOffType, contactCenterAuthorizationCode, alertMsgPart);
        clsp.userMustBeAbleToVerifyThePaymentStatus(writeOffType);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @CLSP_SMOKE
    @CLSP_Esuite
    @ParameterizedTest
    @CsvSource({
            "200,FullTime,2,204"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42709490", projectId = "91768", testCaseName = "Pre Pay - Same Day Payment", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized="true")
    void userVerifyPrePaySameDayPayment(int status, String dailyType, int quantity, int removedStatus) throws Exception {
        apiObj.userCreatesDailyCustomerPaymentCompleted(dailyType, quantity, status);
        clsp.userLaunchesCCURLAndSearchesExistingCustomer();
        clsp.userClickOnEditSubscription();
        clsp.userVerifyPacksStatus();
        eSuite.userLoginInBacsAndVerifyTransactionForTodayDate(dailyType);
        apiObj.userDeletesCustomer(removedStatus);
    }
    @AfterEach
    @CLSP_SMOKE
    @CLSP_UK_Midterm
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose(){
        driver.quit();
    }
}
