package clsp.ui.tests.userJourney.UK;

import Framework.Annotations.CLSP.CLSP_SMOKE;
import Framework.Annotations.CLSP.CLSP_UKSignup;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSParametrizedTest;
import Framework.Annotations.Common.SSTestType;
import clsp.ui.stepDefinitions.UserCreatesAPICustomer;
import clsp.ui.stepDefinitions.UserSignUp;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Tag("clsp")
@Execution(SAME_THREAD)
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@SuppressWarnings("squid:S2699")
class NewSignupJourneyTest {
    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    UserSignUp clsp;
    UserCreatesAPICustomer apiObj = new UserCreatesAPICustomer();

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100080,dailyPartTimeCustomer,1000079,Louis,Deliver to Home,77,PRE,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Launching clsp url", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createAndVerifyNewDailySubscription(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userUpdatesCustomerDetails();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100173,dailyPartTimeCustomer,1000185,Philips,Deliver to Home,175,POST,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724378", projectId = "91768", testCaseName = "Post Pay - Add NEW Alternate Payer - Contact Centre or Treasury User.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void verifyReplaceButtonIsDisabledForCCUser(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesPaymentReplaceAndAltPayerBtnIsDisabled();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    //updating the customer details
    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100156,dailyPartTimeCustomer,1000167,Peterson,Deliver to Home,158,PRE,address,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42746705", projectId = "91768", testCaseName = "Pre Pay - Change Customer Details - Contact Centre or Treasury User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userChangeCustomerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userSelectsTheAddressBookAndAddANewAddress(addressType);
        clsp.userEditsCustomerContactInformation();
        clsp.verifyCustomerDetailsOnAddressBookTab();
        clsp.userShouldBeAbleToChangeHisAddressForSelectivePack();
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100135,dailyPartTimeCustomer,1000146,Mickey,Deliver to Home,136,PRE,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42687522", projectId = "91768", testCaseName = "Pre Pay - Add NEW Alternate Payer - Contact Centre or Treasury User.", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userAddsNewAlternatePayerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesPaymentReplaceAndAltPayerBtnIsDisabled();
        apiObj.userDeletesCustomer(customerID, apiStatus);


    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev AllPurpose,204,100125,montlySolutionCustomer,1000137,Backham,Deliver to Home,127,PRE,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724384", projectId = "91768", testCaseName = "Pre Pay - Monthly - No Solution", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createMonthlyCustomer(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType,payerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }
    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100144,dailyPartTimeCustomer,1000154,Armaan,Deliver to Home,145,PRE,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42684814", projectId = "91768", testCaseName = "Pre Pay - Select a customer with Alt payer - Click on Edit Alternate Payer- Verify the Alt payer detail remains in the field upon click elsewhere from the Information Modal_CLSP-MIGRATEDSUBSCRIPTIONFLAG", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifyTheAlterPayerDetailOutsideTheInformationModal(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.useClicksAndVerifyTheAltPayerDetailOutsideTheInformationModal();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100142,dailyPartTimeCustomer,1000152,Robert,Deliver to Home,143,PRE,kihtPC,newPayment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724403", projectId = "91768", testCaseName = "Pre Pay - Select a Subscription with Alt payer - Replace payment Method and Verify if the new Mandate is generated", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifiesIfTheNewMandateIsGenerated(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode, String paymentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesPaymentMethodAndClickOnReplaceButton(customerName, paymentType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100136,dailyPartTimeCustomer,1000146,Gary,Deliver to Home,138,PRE,Home,kihtPC,newPayment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724398", projectId = "91768", testCaseName = "Pre Pay - Add NEW Alternate Payer - Store User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userAddNEWAlternatePayerStoreUser(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode, String paymentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClicksPaymentMethodAndAddNewAlterPayerDetails(customerName, authCode);
        clsp.userVerifiesAltPayeDdeatilsAndPackStatusAsPending(customerName, paymentType);
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }


    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev AllPurpose,204,100125,montlySolutionCustomer,1000137,Mr Backham,Deliver to Home,127,PRE,-14,10,first,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42683851", projectId = "91768", testCaseName = "Pre Pay - Monthly - Update Customer Information and verifies Supply chain Lead Time and Regular Payment and Delivery Date", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifiesSupplyChainLeadTime(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String leadTime, String noOfDays, String payment, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetailsWithoutClickingconfirm(customerType, customerName, customerID);
        clsp.userUpdatesCustomerDetails();
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userIsAbleToVerifyLeadTimeChanges(leadTime);
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        clsp.userIsAbleToVerifyCustomerDashboard();
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,100129,montlyNoSolutionCustomer,1000140,Jaaz,Deliver,130,PRE,diffAddress,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724394", projectId = "91768", testCaseName = "Pre Pay - Monthly - Delivery Address - New", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userAddsNewDeliveryAddress(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String addressType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.userSelectsDeliveyTypeAsDifferentAddress(customerType, customerName, customerID, addressType);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100123,dailyPartTimeCustomer,1000135,Guest,Deliver to Home,125,Pre,kihtPC,payment"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42684452", projectId = "91768", testCaseName = "Pre Pay - Create Subscription with Alt payer - Replace Payment Method with same Alt Payer", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userReplacePaymentWithSameAlterPayer(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode, String paymentType) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userIsAbleToAddAlternatePayer(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifyPaymentMethodAndClickOnReplaceButton(customerName, paymentType);
        clsp.userEntersNewPaymentDetailsAndVerifyDetailsOnReceipt(payerType, customerName, authCode);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,100149,montlyNoSolutionCustomer,1000159,Hariken,Deliver to Home,150,POST,1 Box,0 Boxes,Damaged Partial,200,Dispatched,address,Home,kihtPC,First"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724405", projectId = "91768", testCaseName = "Pre Pay - Replacement for the monthly package", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userReplaceMonthlyPackage(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String leftboxQty, String rightboxQty, String replaceReason, int status, String packStatus, String addressType, String fulfilmentType, String authCode, String firstPack) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        apiObj.userUpdatingPackStatusToGivenStatus(status, customerID, packStatus);
        apiObj.userGetsSubscriptionDetails(customerID);
        apiObj.userPerformsGoodwill(firstPack,status);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userSelectsTheAddressBookAndAddANewAddress(addressType);
        clsp.userClicksOnSubscriptionTab();
        clsp.userTriesToPerformAPartialPackReplace(replaceReason, leftboxQty, rightboxQty);
        clsp.userMustBeAbleToViewPackAsRequestedForReplaceWithNewAddress(addressType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,100891,montlyNoSolutionCustomer,708,Krish,Deliver to Home,1482,PRE,Home,kihtPC,200"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724399", projectId = "91768", testCaseName = "Pre Pay - Add a second Subscription - Use EXISTING payment details", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userAddsSecondSubscriptionUsingExistingPaymentDetails(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode, int status) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userNavigatesToActiveClfitsTabAndClicksOnSubscribeButton();
        clsp.userCreatesNewMonthlySubscription(solutionType, deliveryType, payerType, authCode, customerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClicksSecondEditSubscriptionButton();
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        clsp.userSelectsPackageTabFromDashboardAndVerifyPackageDetails(solutionType);
        clsp.userVerifyFITDetailsForNoSolution(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,100126,montlyNoSolutionCustomer,1000138,Marvel,Deliver to Home,128,PRE,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724402", projectId = "91768", testCaseName = "Pre Pay - Monthly - Delivery Address - Store", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userAddsMonthlyDeliveryAddressStore(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "Occasional,204,100133,dailyOccasionalCustomer,1000144,Luther,Deliver to Home,134,Pre,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724396", projectId = "91768", testCaseName = "Pre Pay - Change EXISTING Alternate Payer Details - Store User", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userChangeExistingAlternatePayerDetails(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userLaunchesStoreUrlCustomerSearchPageAndFindsExistingCustomer(customerID);
        clsp.userClicksOnManagePaymentMethodTabAndEditAlternatePayerDetails();
        clsp.userVerifiesAllTheUpdatedDetailsOnCustomerDashboard();
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev AllPurpose,204,100191,montlySolutionCustomer,1000205,Dr Unspecified,Deliver to Home,196,PRE,200,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724389", projectId = "91768", testCaseName = "CLSP-2746_Unspecified gender should be populated as Unknown in esuite and in Reports", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userPopulatingGenderInESuite(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, int status, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        apiObj.userGetsSubscriptionDetails(customerID);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100123,dailyPartTimeCustomer,1000135,Guest,Deliver to Home,125,Pre,Home,Other,Email,kihtPC"

    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724388", projectId = "91768", testCaseName = "Pre Pay - Daily - Add an Alternate Payer and Adding and Removing Permission to speak with a Thrid Party", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userAddAndRemovesThirdPartyPermission(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String noteSub, String noteType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userAddsAlternatePayerAndPaymentDetails(customerType, customerName, customerID, authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesAltPayerDetailsOnDashBoard();
        clsp.userHighlightAdditionalContactButton();
        clsp.userVerifiesAltPayerDetailsOnDashBoard();
        clsp.userAddContactIsAndVerifyAdditionalContactButton(customerID, noteSub, noteType);
        clsp.userUnHiLightsTheAdditionalContactButtonAndVerifiesIt(customerID);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev AllPurpose,204,100154,montlySolutionCustomerSingleEye,1000165,Monthlynosolutionsingleey,Deliver to Home,156,PRE,200,Home,3 month 50%,No solution,NoDiscount,montlySolutionCustomerSingleEye,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724392", projectId = "91768", testCaseName = "single eye with completed payment and change usage without discount", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifiesSingleEyePaymentWithoutDiscount(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, int status, String fulfilmentType, String discountType, String updatedSolution, String discountType1, String customerTypeSingleEye, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType, customerType);
        clsp.userUpdatesMonthlyPackage(updatedSolution);
        apiObj.userDeletesCustomer(customerID, apiStatus);
        clsp.CloseAllBrowser();
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userVerifyDiscountPaymentPlan(discountType1, customerTypeSingleEye);
        clsp.userUpdatesMonthlyPackage(updatedSolution);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100123,dailyPartTimeCustomer,1000135,Guest,Deliver to Home,125,Pre,Home,address,kihtPC"

    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724388", projectId = "91768", testCaseName = "Verify Socrates Sync Functionality", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifySocrateSyncFunctionality(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String addressType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userSelectsTheAddressBookAndAddANewAddress(addressType);
        clsp.userClicksOnSubscriptionTab();
        clsp.userVerifySocratesSync();
        apiObj.userDeletesCustomer(customerID, apiStatus);

    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,100891,dailyPartTimeCustomer,1000943,Krish,Deliver to Home,945,PRE,kihtPC,200,Deceased"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724399", projectId = "91768", testCaseName = "To verify replace subscription from active cl fit ", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifiesReplaceSubscription(String dailyType, int apiStatus, String customerId, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode, int status, String reason) throws Exception {
        clsp.launchURLForNewCustomer(customerId, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        apiObj.userCreatesCustomerWithPaymentCompleted(status, customerId);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerId);
        clsp.userCancelsTheSubscription(reason);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerId);
        clsp.userClickOnEditSubscription();
        clsp.userClicksOnBackButton();
        clsp.userNavigatesToActiveClFitsTabAndClicksOnReplaceButton(authCode);
       apiObj.userDeletesCustomer(customerId, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "3x250ml peroxide ev 3x250ml peroxide ev,204,100129,montlySolutionCustomer,1000140,Jaaz,Deliver to Home,130,PRE,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724399", projectId = "91768", testCaseName = "To verify replace subscription from active cl fit with peroxide solution", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userVerifiesReplaceSubscriptionWithPeroxide(String solutionType, int apiStatus, String customerId, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerId, customerType, tdrNumber, fit);
        clsp.selectPeroxideSolutionType(solutionType, deliveryType, payerType, authCode, customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerId);
        clsp.userValidateReplacePeroxideSolution(solutionType, authCode);
        apiObj.userDeletesCustomer(customerId, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "No Solution,204,101120,non-Quarterly,1001209,Mr Johnn,Deliver to Store,1206,PRE,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Creating and validating the non-quarterly subscription", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createAndVerifyNonQuarterlySubscription(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "PartTime,204,101068,non-LensMail,1001152,Mr James,Deliver to Home,1141,PRE,Home,kihtPC"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "38067477", projectId = "96896", testCaseName = "Creating and validating the non-Lens mail subscription", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void createAndVerifyNonLensMailSubscription(String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.createAccAndSelectDailyPackage(dailyType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetails(customerType, customerName, customerID);
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userVerifiesLensAppearsOnCustomerDashboard(customerType);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "No Solution,PartTime,204,101069,montlyNoSolutionCustomer,871,Mr Javeed,Deliver to Home,1360,PRE,Home,kihtPC,200"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42724399", projectId = "91768", testCaseName = "to validate link button for multiple subscription with multiple fit", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userValidatingMultipleFitsAndMultipleSubscription(String solutionType, String dailyType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String fulfilmentType, String authCode, int status) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userNavigatesToActiveClfitsTabAndClicksOnSubscribeButton();
        clsp.userCreatesNewDailySubscription(dailyType, deliveryType, payerType, authCode, customerType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userToValidateLinkFunctionality();
        clsp.userVerifiesPaymentSchedule();
        clsp.userAbleToVerifySubsequentDeliveryDate();
        apiObj.userDeletesCustomer(customerID, apiStatus);


    }

    @CLSP_SMOKE
    
    @ParameterizedTest
    @CsvSource({
            "Easyvision AllPurpose Ev AllPurpose,204,100125,montlySolutionCustomer,1000137,Mr Backham,Deliver to Home,127,PRE,-14,Weekend,first,Home,kihtPC,Deceased"
    })
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    @SSParametrizedTest(testCaseId = "42683851", projectId = "91768", testCaseName = "Pre Pay - Monthly - Update Customer Information and verifies Supply chain Lead Time and Regular Payment and Delivery Date", testType = SSTestType.SMOKE, testCaseVersion = "5.0", parameterized = "true")
    void userCreationandEditPaymentDate(String solutionType, int apiStatus, String customerID, String customerType, String tdrNumber, String customerName, String deliveryType, String fit, String payerType, String leadTime, String noOfDays, String payment, String fulfilmentType, String authCode,String reason) throws Exception {
        clsp.launchURLForNewCustomer(customerID, customerType, tdrNumber, fit);
        clsp.userSelectsSolutionType(solutionType, deliveryType, payerType, customerType);
        clsp.verifyCustomerDetailsWithoutClickingconfirm(customerType, customerName, customerID);
        clsp.userUpdatesCustomerDetails();
        clsp.userClickOnConfirmButton();
        clsp.enterPaymentDetailsAndClosePrintMandate(customerName,authCode);
        clsp.userVerifiesSummaryPage(customerID, customerType, customerName, deliveryType, fulfilmentType);
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userClickOnEditSubscription();
        clsp.userIsAbleToVerifyLeadTimeChanges(leadTime);
        clsp.userUpdatesPaymentDate(noOfDays, payment);
        clsp.userVerifiesPaymentSchedule();
        clsp.userLaunchesCCURLAndSearchesCustomer(customerID);
        clsp.userCancelsTheSubscription(reason);
        apiObj.userDeletesCustomer(customerID, apiStatus);
    }


    @AfterEach
    @CLSP_SMOKE
    
    @Tags(value = {@Tag("uk"), @Tag("ie")})
    void browserClose() {
        driver.quit();
    }
}