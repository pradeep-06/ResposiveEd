package clsp.ui.pages;

import Framework.DataManager.TestDataManager;
import clsp.ui.extentions.clspBase;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CustomerDetailsPage extends clspBase {

    protected final TestDataManager testDataManager = new TestDataManager();
    private final Logger logger = LoggerFactory.getLogger(CustomerDetailsPage.class);

    SubscriptionPage subScriptionPage;

    public static String completeAddress;

    @FindBy(xpath = "//span[contains(.,'Preferred Tel')]/preceding::li[contains(.,'Age')]")
    public WebElementFacade ageDetails;
    @FindBy(xpath = "//p[text()='Address']//..//following-sibling::p[@class='address_info']")
    public WebElementFacade addressInfo;

    @FindBy(xpath = "//div[contains(@class,'customer-name')]")
    public WebElementFacade customerName;

    @FindBy(xpath = "//input[@value='default']")
    public static WebElementFacade 	deliveryAddress;

    @FindBy(xpath = "//div[@class='col-sm-5']//span[2]")
    public WebElementFacade custID;

    @FindBy(xpath = "//div[@class='col-md-12']//span")
    public WebElementFacade custNameDetails;

    @FindBy(xpath = "//div[@id='customer-contact-details']//li[1]")
    public WebElementFacade dobDetails;

    @FindBy(xpath = "//div[@class='col-sm-3']//span[2]")
    public WebElementFacade dob;

    @FindBy(xpath = "//td[@class='text-grey']//following-sibling::td")
    public WebElementFacade lensCostPrice;

    @FindBy(xpath = "//div[@id='header-store-details']//span[2]")
    public WebElementFacade storeName;

    @FindBy(xpath = "//input[@value='diff']")
    public WebElementFacade diffAddress;

    @FindBy(xpath = "//button[contains(.,'Add new address')]")
    public WebElementFacade addNewAddress;

    @FindBy(xpath = "//select[@id='replace-delivery']")
    private WebElementFacade deliveryAddressDropDown;


    public Calendar getCalendar(String date) throws Exception{
        Date orgDate=new SimpleDateFormat("dd/MM/yyyy").parse(date);
        Calendar cal = Calendar.getInstance();
        cal.setTime(orgDate);
        return cal;
    }
    public void verifyCustomerDetails(String customerType,String customerFName,String customerID){
        try
        {
            final String custName =  customerFName +" Automation";
            final String DOB = testDataManager.getTestInputRegionData("CommonCustomerData.DOB");
            final  String custNbr = customerID;
            final String strName = testDataManager.getTestInputRegionData("CommonCustomerData.storeName");
            final String Address = testDataManager.getTestInputRegionData("address.number")+" , "+testDataManager.getTestInputRegionData("address.name")+", "+testDataManager.getTestInputRegionData("address.addressLine")+" "+testDataManager.getTestInputRegionData("address.town")+" "+testDataManager.getTestInputRegionData("address.county")+" "+testDataManager.getTestInputRegionData("address.postcode")+" "+testDataManager.getTestInputRegionData("address.countryName");
            final  String Address1 = testDataManager.getTestInputRegionData("CommonCustomerData.homeAddress");
            assertElementContainsText(customerName,custName);
            assertElementText(dob,DOB);
            assertElementContainsText(custID,custNbr);
            assertElementContainsText(storeName,strName);
            assertElementContainsText(custNameDetails,custName);
            assertElementContainsText(dobDetails,DOB);
            Calendar a =  getCalendar(DOB);		//Passing customers DOB to calendar
            Calendar b = getCalendar(SubscriptionPage.todaysDateWithBackslashes(0));		//Passing todays date to calendar
            int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
            if(a.get(Calendar.DAY_OF_YEAR)> b.get(Calendar.DAY_OF_YEAR)){
                diff--;
            }

            assertElementContainsText(ageDetails,String.valueOf(diff));

            String lensCost = testDataManager.getTestInputRegionData(customerType+".lensCost");
            addressInfo.waitUntilVisible();
            if(Address.contains(addressInfo.getText().replaceAll("\n", " ")))
            {
                assertTrue(addressInfo.getText().replaceAll("\n", " ").contains(Address));
            }
            else{
                assertTrue(addressInfo.getText().replaceAll("\n", " ").contains(Address1));
            }

            assertTrue(lensCostPrice.getText().substring(1).contains(lensCost));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void addDifferentDeliveryAddressAndSetAsDefault(String addressType,WebElementFacade addNewAddressButton) {

        clickElement(addNewAddressButton);
        final String differentAddress = testDataManager.getTestInputRegionData("address.name")+" "+testDataManager.getTestInputRegionData("address.number")+" "+testDataManager.getTestInputRegionData("address.addressLine")+" null "+testDataManager.getTestInputRegionData("address.town")+" "+testDataManager.getTestInputRegionData("address.postcode")+" "+testDataManager.getTestInputRegionData("address.countryName");
        assertTrue(deliveryAddressDropDown.getSelectedVisibleTextValue().replaceAll("\n", " ").equalsIgnoreCase(differentAddress));
    }
}
