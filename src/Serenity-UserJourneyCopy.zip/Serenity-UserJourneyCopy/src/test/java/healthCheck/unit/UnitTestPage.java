package healthCheck.unit;

import Framework.BaseObject.BasePageObject;
import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;


@DefaultUrl("page:health.check.test.url")
public class UnitTestPage extends BasePageObject {

    private static final Logger logger = LoggerFactory.getLogger(UnitTestPage.class);

    @FindBy(id="test-select")
    public WebElementFacade selectElement;


    @FindBy(id="test-button")
    private WebElementFacade testButton;

    @FindBy(id="test-input")
    private WebElementFacade testInput;

    @FindBy(id="display-text")
    private WebElementFacade displayText;

    private String selectElementXpath = "//select[@id='test-select']";

    public void selectDropDownItemByVisibleText(String option) {


        selectDropDownItemByVisibleText(selectElement, option);
    }

    public String getDisplayText() {
        return displayText.getText();
    }
    public String getInputText() {
        return testInput.getValue();
    }

    public void clickTestButton_clickElement2() {
        List<WebElement> list = getDriver().findElements(By.id("test-button"));
        logger.info("FOUND ELEMENTS: " + list.size());
        clickElement2(testButton);
    }

    public void setInputText_setText(String text) {
        setText(testInput, text);
    }



    public String getDropDownItemVisibleText() {
        Select select = new Select(getDriver().findElement(By.xpath(selectElementXpath)));
        String val = select.getFirstSelectedOption().getText();
        return select.getFirstSelectedOption().getText();
    }
}
