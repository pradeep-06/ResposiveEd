package healthCheck.unit;


import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.Common.UNIT;
import Framework.Drivers.BrowserOsConfig;
import net.thucydides.model.environment.SystemEnvironmentVariables;
import net.thucydides.model.util.EnvironmentVariables;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.parallel.Execution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;


@Execution(SAME_THREAD)
public class BrowserDeviceTests {
    private final Logger logger = LoggerFactory.getLogger(BrowserDeviceTests.class);
    EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();
    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceUnset", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void browserDeviceUnset() {
        BrowserOsConfig.nullifyConfig();
        BrowserOsConfig browserOsConfig = BrowserOsConfig.getConfig();
        Assertions.assertEquals(environmentVariables.getProperty("webdriver.managed.driver"), browserOsConfig.getBrowser(), "Browser");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getOs(), "OS");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getBrowserVersion(), "Browser version");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getDeviceModel(), "Device model");
    }

    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceEmptyStr", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void browserDeviceEmptyStr() {
        BrowserOsConfig.nullifyConfig();

        System.setProperty("browser", "");
        System.setProperty("os", "");
        System.setProperty("browserVersion", "");
        System.setProperty("deviceModel", "");

        BrowserOsConfig browserOsConfig = BrowserOsConfig.getConfig();
        Assertions.assertEquals(environmentVariables.getProperty("webdriver.managed.driver"), browserOsConfig.getBrowser(), "Browser");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getOs(), "OS");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getBrowserVersion(), "Browser version");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getDeviceModel(), "Device model");
    }

    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceDefault", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void browserDeviceDefault() {
        BrowserOsConfig.nullifyConfig();

        System.setProperty("browser", "default");
        System.setProperty("os", "default");
        System.setProperty("browserVersion", "default");
        System.setProperty("deviceModel", "default");

        BrowserOsConfig browserOsConfig = BrowserOsConfig.getConfig();
        Assertions.assertEquals(environmentVariables.getProperty("webdriver.managed.driver"), browserOsConfig.getBrowser(), "Browser");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getOs(), "OS");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getBrowserVersion(), "Browser version");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getDeviceModel(), "Device model");
    }

    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceSet", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void browserDeviceSet() {
        BrowserOsConfig.nullifyConfig();

        System.setProperty("browser", "madeUpBrowser");
        System.setProperty("os", "madeUpOs");
        System.setProperty("browserVersion", "madeUpBrowserVersion");
        System.setProperty("deviceModel", "madeUpDeviceModel");



        BrowserOsConfig browserOsConfig = BrowserOsConfig.getConfig();
        Assertions.assertEquals("madeUpBrowser", browserOsConfig.getBrowser(), "Browser");
        Assertions.assertEquals("madeUpOs", browserOsConfig.getOs(), "OS");
        Assertions.assertEquals("madeUpBrowserVersion", browserOsConfig.getBrowserVersion(), "Browser version");
        Assertions.assertEquals("madeUpDeviceModel", browserOsConfig.getDeviceModel(), "Device model");
    }

    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceIosDefault", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void browserDeviceIosDefault() {
        BrowserOsConfig.nullifyConfig();
        System.setProperty("os", "ios");

        BrowserOsConfig browserOsConfig = BrowserOsConfig.getConfig();
        Assertions.assertEquals("Safari", browserOsConfig.getBrowser(), "Browser");
        Assertions.assertEquals("ios", browserOsConfig.getOs(), "OS");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getBrowserVersion(), "Browser version");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getDeviceModel(), "Device model");
    }

    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceAndroidDefault", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void browserDeviceAndroidDefault() {
        BrowserOsConfig.nullifyConfig();

        System.setProperty("os", "android");

        BrowserOsConfig browserOsConfig = BrowserOsConfig.getConfig();
        Assertions.assertEquals("Chrome", browserOsConfig.getBrowser(), "Browser");
        Assertions.assertEquals("android", browserOsConfig.getOs(), "OS");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getBrowserVersion(), "Browser version");
        Assertions.assertEquals(BrowserOsConfig.UNSET, browserOsConfig.getDeviceModel(), "Device model");
    }


}
