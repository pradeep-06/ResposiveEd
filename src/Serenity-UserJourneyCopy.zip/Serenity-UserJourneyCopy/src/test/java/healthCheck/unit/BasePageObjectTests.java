package healthCheck.unit;

import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.Common.UNIT;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.Assert;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.parallel.Execution;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.parallel.ExecutionMode.SAME_THREAD;

@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)
@Execution(SAME_THREAD)
public class BasePageObjectTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;

    @Steps
    UnitTestSteps unitTestSteps;


    @SSTest(testCaseId = "", projectId = "", testCaseName = "selectDropDownItemByVisibleText", testType = SSTestType.UNIT, testCaseVersion = "")
    @UNIT
    public void selectDropDownItemByVisibleText() {
        unitTestSteps.openUnitTestPage();
        unitTestSteps.selectTestSelect_selectDropDownItemByVisibleText("OPTION 2");
        Assert.assertEquals("Selected text", "OPTION 2", unitTestSteps.getDropDownItemVisibleText());
    }


    @SSTest(testCaseId = "", projectId = "", testCaseName = "clickElement2", testType = SSTestType.UNIT, testCaseVersion = "")
    @UNIT
    public void clickElement2() {
        unitTestSteps.openUnitTestPage();
        unitTestSteps.clickTestButton_clickElement2();
        Assert.assertEquals("Displayed text", "Button clicked", unitTestSteps.getDisplayText());
    }

    @SSTest(testCaseId = "", projectId = "", testCaseName = "setText", testType = SSTestType.UNIT, testCaseVersion = "")
    @UNIT
    public void setText() {
        unitTestSteps.openUnitTestPage();
        unitTestSteps.setInputText_setText("abc");
        Assert.assertEquals("Input text", "abc", unitTestSteps.getInputText());
    }
}