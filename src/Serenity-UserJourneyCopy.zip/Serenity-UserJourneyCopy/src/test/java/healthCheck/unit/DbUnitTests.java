package healthCheck.unit;

import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import Framework.Annotations.Common.UNIT;
import Framework.DbConnection.databaseConnection;
import Framework.DbConnection.databaseHandler;
import healthCheck.HealthCheckUtils;
import org.junit.jupiter.api.Assertions;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DbUnitTests {

    @SSTest(testCaseId = "", projectId = "", testCaseName = "browserDeviceDefault", testType = SSTestType.UNIT, testCaseVersion = "")
    @UNIT
    public void dbConnectGetValue() {
        Connection conn;
        try {
            Map<String, String> unitTestMap = new HashMap<>();
            unitTestMap.put("driverClass", "h2");
            unitTestMap.put("dbURL", "jdbc:h2:mem:");
            HealthCheckUtils.setEnv(unitTestMap);
            conn = databaseConnection.establishDBConn("dataBaseName");

            int myValue = databaseHandler.getValue(conn, "SELECT 1+1 as myColumn", "myColumn");
            Assertions.assertEquals(2, myValue, "Query result");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @UNIT
    @SSTest(testCaseId = "", projectId = "", testCaseName = "dbConnectGetResultSet", testType = SSTestType.UNIT, testCaseVersion = "2.0")
    public void dbConnectGetResultSet() {
        Connection conn;
        try {
            Map<String, String> unitTestMap = new HashMap<>();
            unitTestMap.put("driverClass", "h2");
            unitTestMap.put("dbURL", "jdbc:h2:mem:");
            HealthCheckUtils.setEnv(unitTestMap);

            conn = databaseConnection.establishDBConn("");
            ResultSet resultSet = databaseHandler.getResultSet(conn, "SELECT 1+1 as myColumn");
            int rows = 0;
            while(resultSet.next()) {
                Assertions.assertEquals(2, resultSet.getInt(1), "Query result");
                rows++;
            }
            Assertions.assertEquals(1, rows, "No. of rows");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


}
