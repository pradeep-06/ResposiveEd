package healthCheck.unit;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UnitTestSteps extends ScenarioSteps {


    private static final Logger logger = LoggerFactory.getLogger(UnitTestSteps.class);

    @Steps
    UnitTestPage unitTestPage;

    @Step
    public void selectTestSelect_selectDropDownItemByVisibleText(String option) {
        unitTestPage.selectDropDownItemByVisibleText(option);
    }

    @Step
    public String getDropDownItemVisibleText() {
        return unitTestPage.getDropDownItemVisibleText();
    }

    @Step
    public String getDisplayText() {
        return unitTestPage.getDisplayText();
    }

    @Step
    public void clickTestButton_clickElement2() {
        unitTestPage.clickTestButton_clickElement2();
    }

    @Step
    public void setInputText_setText(String text) {
        unitTestPage.setInputText_setText(text);
    }

    @Step
    public String getInputText() {
        return unitTestPage.getInputText();
    }

    @Step
    public void openUnitTestPage() {
        String dir = System.getProperty("user.dir");
        String path = dir + "/src/test/java/healthCheck/unitTest.html";

        getDriver().navigate().to("file://"+path);
        logger.info("Test HTML Page opened!");
    }

}
