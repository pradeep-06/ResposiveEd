package healthCheck.serenity;

import Framework.Annotations.Common.HEALTH_CHECK;
import Framework.Annotations.Common.SSDisplayNameGenerator;
import Framework.Annotations.Common.SSTest;
import Framework.Annotations.Common.SSTestType;
import healthCheck.unit.UnitTestSteps;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.WebDriver;
@DisplayNameGeneration(SSDisplayNameGenerator.class)
@ExtendWith(SerenityJUnit5Extension.class)

public class SerenityTests {

    @Managed(driver = "provided", uniqueSession = true)
    WebDriver driver;
    @Steps
    UnitTestSteps unitTestSteps;


    @SSTest(testCaseId = "44424783", projectId = "80919", testCaseName = "openPage", testType = SSTestType.SMOKE, testCaseVersion = "1.0")
    @Tags(value = {@Tag("uk")})
    @HEALTH_CHECK
    public void openPage() {
        unitTestSteps.openUnitTestPage();
        unitTestSteps.setInputText_setText("Specsavers");
    }
}
