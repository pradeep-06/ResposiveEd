﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace microservicename.Helper
{
    public static class EnvironmentHelper
    {
        public static string GetEnvironmentUrl()
        {
            string EnvVariable = "http://localhost:8100";

            return EnvVariable;

        }

    }
}
