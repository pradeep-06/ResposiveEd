
using microservicename.Models;
using microservicename.Services;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;
using Xunit.Gherkin.Quick;

namespace MSATestSuites.prod_test_aat_seven.StepDefinitions
{
    [FeatureFile("Features/HealthCheck.feature")]
    public sealed class HealthCheck : Feature
    {
        

        private HealthCheckDto healthCheckDto = new HealthCheckDto();
        public HealthCheck(ITestOutputHelper testOutputHelper)
        {
            Logger = testOutputHelper;
        }
        private readonly ITestOutputHelper Logger;
      
      
        [Given(@"the microservice is running")]
        public void microservice_is_running()
        {

        }


        [When(@"I connect to the '(.*)' endpoint")]

        public async Task I_connect_to_endpointAsync(string path)
        {
            HealthCheckService healthCheckService = new HealthCheckService();

            healthCheckDto = await healthCheckService.GetHealthCheckResponseAsync(path);
        }

        [Then(@"it should respond with HTTP status 200")]
        public void It_shpuld_respond_with_httpstatus_200()
        {
            Assert.Equal(200, healthCheckDto.HttpResponseStatus);
        }

        [Then(@"it should respond with body status of '(.*)'")]
        public void It_should_respond_with_status_up(string key)
        {
            Assert.Equal(key, healthCheckDto.status);
        }

      

    }
}