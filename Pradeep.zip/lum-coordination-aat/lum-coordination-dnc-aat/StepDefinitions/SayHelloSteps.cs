
using Xunit.Gherkin.Quick;
using Xunit;
using Xunit.Abstractions;

namespace MSATestSuites.prod_test_aat_seven.StepDefinitions
{
    [FeatureFile("Features/SayHello.feature")]
    public sealed class ExampleSteps : Feature
    {
        public ExampleSteps(ITestOutputHelper testOutputHelper)
        {
            Logger = testOutputHelper;
        }
        private readonly ITestOutputHelper Logger;
        private string actualMessage {get; set;}

        [When(@"I visit '(.*)'")]
        public void I_visit(string path)
        {
            
        }

        [Then(@"I should see '(.*)'")]
        public void I_should_see(string expectedMessage)
        {
            Assert.Equal(1, 1);
        }
    }
}