
using Xunit.Gherkin.Quick;
using Xunit;
using Xunit.Abstractions;
using System.Threading.Tasks;
using microservicename.Services;
using microservicename.Models;

namespace MSATestSuites.prod_test_aat_seven.StepDefinitions
{
    [FeatureFile("Features/CacheCheck.feature")]
    public sealed class CacheCheckSteps : Feature
    {
        

        private MemberDto memberDto = new MemberDto();
        public CacheCheckSteps(ITestOutputHelper testOutputHelper)
        {
            Logger = testOutputHelper;
        }
        private readonly ITestOutputHelper Logger;
       
        [Given(@"the microservice is running")]
        public void microservice_is_running()
        {

        }
      
        [When(@"I connect to the '(.*)' endpoint")]

        public async Task I_connect_to_endpointAsync(string path)
        {
            CacheDemoService cacheDemoService = new CacheDemoService();

            memberDto = await cacheDemoService.GetCacheDemoAsync(path);
        }

        [Then(@"it should respond with HTTP status 200")]
        public void It_shpuld_respond_with_httpstatus_200()
        {
            Assert.Equal(200, memberDto.HttpResponseStatus);
        }

        
        [And(@"it should contains a response having firstName as '(.*)'")]
        public void It_should_respond_with_matching_firstname(string key)
        {
            
            Assert.Equal(key,memberDto.FirstName);
        }

        
    }
}