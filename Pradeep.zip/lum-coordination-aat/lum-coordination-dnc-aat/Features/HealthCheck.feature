Feature: HealthCheck

Scenario: Healthcheck is good
    Given the microservice is running
    When I connect to the '/actuator/Health' endpoint
    Then it should respond with HTTP status 200
    Then it should respond with body status of 'UP'