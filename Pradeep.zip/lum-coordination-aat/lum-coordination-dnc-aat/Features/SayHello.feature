Feature: Say Hello

Scenario: Lower case name
    When I visit '/test/tester'
    Then I should see 'Hello tester'

Scenario: Mixed case name
    When I visit '/test/Tester'
    Then I should see 'Hello Tester'

Scenario: Upper case name
    When I visit '/test/TESTER'
    Then I should see 'Hello TESTER'