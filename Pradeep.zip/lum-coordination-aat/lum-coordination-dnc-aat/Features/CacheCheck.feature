Feature: CacheCheck

Scenario: CacheDemo End point returns Cache response
    Given the microservice is running
    When I connect to the '/api/v1/CacheDemo/1226281523' endpoint
    Then it should respond with HTTP status 200
    And it should contains a response having firstName as 'Alex'