﻿using System;
using System.Collections.Generic;
using System.Text;

namespace microservicename.Models
{
    public class MemberDto
    {


        public string FirstName { get; set; }

        public string EntityNumber { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public int HttpResponseStatus { get; set; }


    }
}
