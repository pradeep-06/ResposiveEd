﻿using System;
using System.Collections.Generic;
using System.Text;

namespace microservicename.Models
{
    public class HealthCheckDto
    {
        public string status { get; set; }
        public string TotalChecksDuration { get; set; }

        public int HttpResponseStatus { get; set; }

    }
}
