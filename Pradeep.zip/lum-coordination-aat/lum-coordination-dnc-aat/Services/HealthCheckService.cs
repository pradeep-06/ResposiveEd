﻿using microservicename.Helper;
using microservicename.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace microservicename.Services
{
    public class HealthCheckService
    {
        public static string Url;
        public static string Resource;

        private string baseUrl = EnvironmentHelper.GetEnvironmentUrl();

        public async Task<HealthCheckDto> GetHealthCheckResponseAsync(string path)
        {
            
            var _client = new HttpClient();
            string appUrl = baseUrl + path;

            HttpResponseMessage httpResponse = await _client.GetAsync(appUrl);

            if (!httpResponse.IsSuccessStatusCode)
            {
                throw new Exception("Cannot retrieve tasks");
            }

            string content = await httpResponse.Content.ReadAsStringAsync();

            var response = JsonConvert.DeserializeObject<HealthCheckDto>(content);
            response.HttpResponseStatus = 200;
            return response;
        }
    }
}
