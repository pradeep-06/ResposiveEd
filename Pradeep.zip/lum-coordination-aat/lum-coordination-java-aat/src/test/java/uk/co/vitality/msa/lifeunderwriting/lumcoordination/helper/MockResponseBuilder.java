package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

import java.io.IOException;

import org.springframework.http.HttpStatus;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;

public class MockResponseBuilder {

	public static ResponseDefinitionBuilder getResponseDefinitionBuilderOk(String mockData) throws IOException {
		ResponseDefinitionBuilder stubResponse = new ResponseDefinitionBuilder();
		stubResponse.withStatus(HttpStatus.OK.value());
		stubResponse.withHeader("Content-Type", "application/json");
		stubResponse.withBody(mockData);
		return stubResponse;
	}
}
