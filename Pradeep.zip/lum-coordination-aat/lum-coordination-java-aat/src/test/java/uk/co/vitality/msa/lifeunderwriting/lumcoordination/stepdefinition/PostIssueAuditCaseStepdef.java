package uk.co.vitality.msa.lifeunderwriting.lumcoordination.stepdefinition;

import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.data.LumCoordinationCaseData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.database.DBValidation;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.RandomGenerator;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.ResponseValidation;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.kafka.KafkaProducerApi;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.mockingService.SalesforceAuthenticationMock;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.mockingService.SalesforceNotificationApiMock;

public class PostIssueAuditCaseStepdef {

	@Given("post issue audit is created and events is published to topic")
	public void post_issue_audit_is_created_and_events_is_published_to_topic() throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setPIAEntity(RandomGenerator.getRandomEntityId());
		LumCoordinationCaseData.postIssueAuditCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.pia");
		KafkaProducerApi.publishPostIssueAuditToOutboundTopic("piaentity.created");
	}
	
	@Given("post issue audit is update events is published to topic")
	public void post_issue_audit_is_update_events_is_published_to_topic() throws Exception{
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setPIAEntity(RandomGenerator.getRandomEntityId());
		LumCoordinationCaseData.postIssueAuditCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.pia");
		KafkaProducerApi.publishPostIssueAuditToOutboundTopic("piaentity.updated");
	}
	
	@Given("Same post issue audit is updated twice before the case is inserted in salesforce")
	public void same_post_issue_audit_is_updated_twice_before_the_case_is_inserted_in_salesforce() throws Exception{
		LumCoordinationCaseData.postIssueAuditCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.pia");
		KafkaProducerApi.publishPostIssueAuditToOutboundTopic("piaentity.created");
		Thread.sleep(10000);
	}
	
	@When("The PIASetId is inserted in db with status new")
	public void the_pia_set_id_is_inserted_in_db_with_status_new() throws Exception {
		DBValidation.getRequestFromCoordinationTable();
		KafkaProducerApi.publishPostIssueAuditToOutboundTopic("piaentity.created");
		Thread.sleep(10000);
	}
	
	@Given("Multiple post issue audit events are created and published to topic")
	public void multiple_post_issue_audit_events_are_created_and_published_to_topic() throws Exception{
		System.out.println("Salesforce API is invoked");
	}
	
	@When("the PIA request data stored in database with status as New for both create and update case")
	public void the_pia_request_data_stored_in_database_with_status_as_new_for_both_create_and_update_case() throws Exception{
		DBValidation.insertPIACreateRecord();
		DBValidation.getRequestFromCoordinationTable();
		ResponseValidation.validateCoordinationStatus("New");
		Thread.sleep(5000);
	}

	@Then("the PIA details are inserted into salesforce when the maximum cound reached")
	public void the_pia_details_are_inserted_into_salesforce_when_the_maximum_cound_reached() throws Exception{
		HelperClass.setPIAEntity(RandomGenerator.getRandomEntityId());
		LumCoordinationCaseData.postIssueAuditCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.pia");
		KafkaProducerApi.publishPostIssueAuditToOutboundTopic("piaentity.created");
	}
	
	@When("the maximum time interval reached")
	public void the_maximum_time_interval_reached() throws JsonProcessingException, ClassNotFoundException, SQLException {
		DBValidation.insertPIACreateRecord();
	}
	
	@Then("the request data should published to salesforce")
	public void the_request_data_should_published_to_salesforce() throws InterruptedException {
        Thread.sleep(120000);
	}
	
	@Given("the lum microservice is up and running")
	public void the_microservice_is_up_and_running() throws ClassNotFoundException, SQLException, IOException {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setAccessToken(RandomGenerator.generateAccessToken());
		HelperClass.setPIAEntity(RandomGenerator.getRandomEntityId());
		HelperClass.setReferenceId(UUID.randomUUID().toString());
		LumCoordinationCaseData.notificationPIARequestCreateAndUpdate();
		SalesforceAuthenticationMock.authenticationMock();
		SalesforceNotificationApiMock.notificationApiMock();
	}
}
