package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

import java.util.Collections;
import java.util.List;

import org.junit.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;

import uk.co.vitality.msa.lifeunderwriting.lumcoordination.database.DBValidation;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CoordinationHistoryTableData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CoordinationTableData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.SalesforceRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.SalesforceResponse;

public class ResponseValidation {

	public static void validateCoordinationStatus(String status) {
		Assert.assertEquals(status, HelperClass.getCoordinationTableData().get(0).getCoordination_status());
	}

	public static void validateCoordinationStatusSuccess(String status) {
		try {
			for (int i = 0; i < 5; i++) {
				DBValidation.getRequestFromCoordinationTable();
				if (HelperClass.getCoordinationTableData().get(15).getCoordination_status().equals(status)) {
					for (int count = 1; count < HelperClass.getCoordinationTableData().size()-1; count++) {
						String currentStatus = HelperClass.getCoordinationTableData().get(count)
								.getCoordination_status();
						System.out.println("Record " + count + " status: " + currentStatus);
						Assert.assertEquals(status, currentStatus);
					}
					break;
				} else {
					System.out.println("Status mismatch, retrying in 30 seconds...");
					Thread.sleep(30000);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void validateOperationType(String operationType) {
		for (int count = 0; count < HelperClass.getCoordinationTableData().size(); count++) {
			Assert.assertEquals(operationType, HelperClass.getCoordinationTableData().get(count).getOperationType());
		}
	}

	public static void validateResponseMessage() throws JsonProcessingException {
		SalesforceResponse response = HelperClass.getResponseBody();
		for (int count = 0; count < HelperClass.getCoordinationTableData().size(); count++) {

			Assert.assertEquals(HelperClass.getCoordinationTableData().get(count).getResponse_message(),
					HelperClass.getObjectMapper().writeValueAsString(response.getCompositeResponse().get(count)));
		}
	}

	public static void validateOperationTypeCreateUpdate() throws JsonProcessingException {
		SalesforceRequest response = HelperClass.getRequestBody();
		List<CompositeRequest> compositeRequest = response.getCompositeRequest();
		Collections.reverse(compositeRequest);
		for (int count = 0; count < HelperClass.getCoordinationTableData().size(); count++) {
			Assert.assertEquals(HelperClass.getCoordinationTableData().get(count).getOperationType().toString(),
					HelperClass.getObjectMapper().writeValueAsString(compositeRequest.get(count).getBody().getOperationTypeC())
							.toString());
		}
		
	}

	public static void validateObjectIdentifierCreateUpdate() throws JsonProcessingException {
		for (int count = 0; count < HelperClass.getCoordinationTableData().size(); count++) {
			Assert.assertEquals(HelperClass.getCoordinationTableData().get(count).getObjectIdentifier().toString(),
					HelperClass.getParentCaseId());
		}
	}

	public static void validateCoordinationHistoryTable() throws JsonProcessingException {
		List<CoordinationHistoryTableData> coordinationHistoryTableData = HelperClass.getCoordinationHistoryTableData();
		Assert.assertTrue(coordinationHistoryTableData.size() == 10);
		List<CoordinationTableData> coordinationTableData = HelperClass.getCoordinationTableData();
		Assert.assertTrue(coordinationTableData.size() == 10);
	}
}
