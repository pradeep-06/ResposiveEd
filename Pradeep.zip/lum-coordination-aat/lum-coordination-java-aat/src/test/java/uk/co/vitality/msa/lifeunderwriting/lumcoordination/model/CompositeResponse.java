package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompositeResponse {

    @JsonProperty("body")
    private JsonNode body;
    @JsonProperty("httpHeaders")
    private HttpHeaders httpHeaders;
    @JsonProperty("httpStatusCode")
    private Integer httpStatusCode;
    @JsonProperty("referenceId")
    private String referenceId;
}
