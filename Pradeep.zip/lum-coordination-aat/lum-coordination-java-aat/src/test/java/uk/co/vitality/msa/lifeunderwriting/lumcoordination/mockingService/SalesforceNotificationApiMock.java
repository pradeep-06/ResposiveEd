package uk.co.vitality.msa.lifeunderwriting.lumcoordination.mockingService;

import java.io.IOException;

import com.github.tomakehurst.wiremock.client.WireMock;

import uk.co.vitality.msa.lifeunderwriting.lumcoordination.config.WireMockServerConfig;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.ApplicationPropertiesReader;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.Constant;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.MockResponseBuilder;

public class SalesforceNotificationApiMock {
	
	public static void notificationApiMock() throws IOException {
		String urlpath = new StringBuilder().append(ApplicationPropertiesReader.getApplicationProperty(Constant.SALESFORCE_NOTIFICATION_PATH))
				.toString();
		String responseBody = HelperClass.getObjectMapper().writeValueAsString(HelperClass.getResponseBody());
		WireMockServerConfig.wireMockServers.get(Constant.SALESFORCE_SERVICE_NAME)
		.stubFor(WireMock.post(urlpath)
				.withHeader("Content-Type", WireMock.equalTo("application/json"))
				.withHeader("Authorization", WireMock.equalTo("Bearer" + " " + HelperClass.getAccessToken()))
				.willReturn(MockResponseBuilder.getResponseDefinitionBuilderOk(responseBody)));
	}
	
	public static void notificationApiVerify() throws IOException {
		String urlpath = new StringBuilder().append(ApplicationPropertiesReader.getApplicationProperty(Constant.SALESFORCE_NOTIFICATION_PATH))
				.toString();
		String requestBody = HelperClass.getObjectMapper().writeValueAsString(HelperClass.getRequestBody());
		WireMockServerConfig.wireMockServers.get(Constant.SALESFORCE_SERVICE_NAME).verify(1,
				WireMock.postRequestedFor(WireMock.urlEqualTo(urlpath))
				.withHeader("Content-Type", WireMock.equalTo("application/json"))
				.withHeader("Authorization", WireMock.equalTo("Bearer " + " " + HelperClass.getAccessToken()))
				.withRequestBody(WireMock.equalToJson(requestBody)));
	}
}
