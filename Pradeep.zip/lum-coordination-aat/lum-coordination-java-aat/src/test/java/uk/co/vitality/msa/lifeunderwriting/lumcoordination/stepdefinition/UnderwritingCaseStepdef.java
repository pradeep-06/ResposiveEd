package uk.co.vitality.msa.lifeunderwriting.lumcoordination.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.data.LumCoordinationCaseData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.database.DBValidation;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.RandomGenerator;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.ResponseValidation;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.kafka.KafkaProducerApi;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.mockingService.SalesforceAuthenticationMock;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.mockingService.SalesforceNotificationApiMock;

public class UnderwritingCaseStepdef {

	@Given("underwriting case is created and events is published to topic")
	public void underwriting_case_is_created_and_events_is_published_to_topic() throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setCaseId(UUID.randomUUID().toString());
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.create");
	}

	@When("the request data stored in database with status as New")
	public void the_request_data_stored_in_database_with_status_as_new() throws Exception {
		Thread.sleep(10000);
		DBValidation.getRequestFromCoordinationTable();
	}

	@Then("the request data should be published to salesforce with operation as create")
	public void the_request_data_should_be_published_to_salesforce_with_operation_as_create()
			throws JsonProcessingException {
		ResponseValidation.validateOperationType("Create");
	}

	@Then("the published data should have object identifier as parentcaseId")
	public void the_published_data_should_have_object_identifier_as_parentcase_id() throws JsonProcessingException {
		ResponseValidation.validateObjectIdentifierCreateUpdate();
	}

	@Given("underwriting case update event is published to topic")
	public void underwriting_case_update_event_is_published_to_topic() throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setCaseId(UUID.randomUUID().toString());
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.update");
	}

	@Then("the request data should be published to salesforce with operation as update")
	public void the_request_data_should_be_published_to_salesforce_with_operation_as_update()
			throws JsonProcessingException {
		ResponseValidation.validateOperationType("Update");
	}

	@Given("Multiple underwriting case events are published to topic with operation type as create and update")
	public void multiple_underwriting_case_events_are_published_to_topic_with_operation_type_as_create_and_update()
			throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setAccessToken(RandomGenerator.generateAccessToken());
		HelperClass.setCaseId(UUID.randomUUID().toString());
		HelperClass.setReferenceId(UUID.randomUUID().toString());
		LumCoordinationCaseData.notificationRequestCreateAndUpdate();
		SalesforceAuthenticationMock.authenticationMock();
		SalesforceNotificationApiMock.notificationApiMock();
	}

	@When("the request data stored in database with status as New for both create and update case")
	public void the_request_data_stored_in_database_with_status_as_new_for_both_create_and_update_case()
			throws Exception {
		Thread.sleep(20000);
		DBValidation.insertCaseCreateRecord();
		DBValidation.getRequestFromCoordinationTable();
		ResponseValidation.validateCoordinationStatus("New");

	}

	@Then("the reqeust data should be published to salesforce")
	public void the_reqeust_data_should_be_published_to_salesforce_with_operation_as_create_and_update()
			throws Exception {
		HelperClass.setCaseId(UUID.randomUUID().toString());
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.create");
		Thread.sleep(30000);
	}

	@Given("Same underwriting case is updated twice before the case is inserted in salesforce")
	public void same_underwriting_case_is_updated_twice_before_the_case_is_inserted_in_salesforce() throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setCaseId(UUID.randomUUID().toString());
		HelperClass.setParentCaseId(UUID.randomUUID().toString());
		HelperClass.setCaseTypeCode("8");
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.create");
	}

	@When("The case Id is inserted in db with status new")
	public void the_case_id_is_inserted_in_db_with_status_new() throws Exception {
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.create");
		Thread.sleep(10000);
	}

	@Then("the same case Id should be updated with status duplicate")
	public void the_same_case_id_should_be_updated_with_status_duplicate() throws Exception {
		DBValidation.getRequestFromCoordinationTable();
		ResponseValidation.validateCoordinationStatus("Duplicate");
	}

	@Given("Cases details are in database")
	public void cases_details_are_in_database() throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		DBValidation.deleteRecordFromCoordinationHistoryTable();
		LumCoordinationCaseData.createSalesforceOldRecord();
		Thread.sleep(30000);
	}

	@When("the data are older than {int} days")
	public void the_data_are_older_than_days(Integer int1) throws JsonProcessingException, Exception {
		DBValidation.insertOldCaseRecord();
		LumCoordinationCaseData.createSalesforceOldRecord();
		DBValidation.insertOldCaseRecords();
		Thread.sleep(30000);
	}

	@Then("the details should be moved to history table")
	public void the_details_should_be_moved_to_history_table() throws Exception {
		Thread.sleep(60000);
		DBValidation.getRecordsFromCoordinationHistoryTable();
		DBValidation.getRequestFromCoordinationTable();
		ResponseValidation.validateCoordinationHistoryTable();
	}

	@Given("Multiple underwriting case events are created and published to topic")
	public void multiple_underwriting_case_events_are_created_and_published_to_topic() throws Exception {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setParentCaseId(UUID.randomUUID().toString());
		HelperClass.setCaseTypeCode("8");
		HelperClass.setCaseId(UUID.randomUUID().toString());
		HelperClass.setReferenceId(UUID.randomUUID().toString());
		LumCoordinationCaseData.notificationRequestCreateAndUpdate();
		SalesforceAuthenticationMock.authenticationMock();
		SalesforceNotificationApiMock.notificationApiMock();
	}

	@When("the cases reach the maximum count")
	public void the_cases_reach_the_maximum_count() throws Exception {
		DBValidation.insertCaseCreateRecord();
	}

	@Then("the details are inserted into salesforce when the maximum cound reached")
	public void the_details_are_inserted_into_salesforce() throws Exception {
		HelperClass.setCaseId(UUID.randomUUID().toString());
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.create");
		Thread.sleep(30000);
	}

	@Then("the status is to be updated to success")
	public void the_status_is_to_be_updated_to_success() throws Exception {
		Thread.sleep(5000);
		DBValidation.getRequestFromCoordinationTable();
		ResponseValidation.validateCoordinationStatusSuccess("Success");
	}

	@When("the maximum time interval reached and the events published to salesforce")
	public void the_maximum_time_interval_reached_and_the_events_published_to_salesforce() throws Exception {
		DBValidation.insertCaseCreateRecord();
		Thread.sleep(120000);
	}

	@Given("underwriting case is created and events is published to topic for {string} with {string}")
	public void underwriting_case_is_created_and_events_is_published_to_topic_for(String caseType, String caseTypeCode)
			throws ClassNotFoundException, SQLException, IOException, InterruptedException, ExecutionException {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setCaseId(UUID.randomUUID().toString());
		HelperClass.setParentCaseId(UUID.randomUUID().toString());
		HelperClass.setCaseTypeCode(caseTypeCode);
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.created");
	}

	@Given("underwriting case update event is published to topic for {string} with {string}")
	public void underwriting_case_update_event_is_published_to_topic_for(String caseType, String caseTypeCode)
			throws ClassNotFoundException, SQLException, IOException, InterruptedException, ExecutionException {
		DBValidation.deleteRecordFromCoordinationTable();
		HelperClass.setCaseId(UUID.randomUUID().toString());
		HelperClass.setParentCaseId(UUID.randomUUID().toString());
		HelperClass.setCaseTypeCode(caseTypeCode);
		LumCoordinationCaseData.underwritingCaseRequest();
		HelperClass.setOutboundTopic("life.lifeunderwriting.underwritingcase");
		KafkaProducerApi.publishUnderwritingCaseDataToOutboundTopic("case.update");
		}

	@Then("the request data should not be stored in database")
	public void the_request_data_should_not_be_stored_in_database() throws JsonMappingException, ClassNotFoundException,
			JsonProcessingException, SQLException, InterruptedException {
		Thread.sleep(10000);
		DBValidation.getRequestFromCoordinationTable();
		assertEquals(HelperClass.getSize(), 0);
	}
}
