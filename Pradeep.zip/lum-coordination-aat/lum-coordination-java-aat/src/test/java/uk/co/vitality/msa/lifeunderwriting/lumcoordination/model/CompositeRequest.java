package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
public class CompositeRequest implements Serializable {

    private static final long serialVersionUID = 4119214357161674863L;
    
    @JsonProperty("method")
    private String method;
    @JsonProperty("url")
    private String url;
    @JsonProperty("referenceId")
    private String referenceId;
    @JsonProperty("body")
    private CompositeRequestBody body;

}
