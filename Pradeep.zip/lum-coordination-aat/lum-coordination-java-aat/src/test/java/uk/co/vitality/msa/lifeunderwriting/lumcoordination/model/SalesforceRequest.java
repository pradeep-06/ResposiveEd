package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * @author VITALITY\c701346
 *
 */
@Getter
@Setter
@Accessors(chain = true)
public class SalesforceRequest implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 6080712794486097912L;
    
    @JsonProperty("allOrNone")
    private Boolean allOrNone;
    @JsonProperty("collateSubrequests")
    private Boolean collateSubrequests;
    @JsonProperty("compositeRequest")
    private List<CompositeRequest> compositeRequest;
    

}
