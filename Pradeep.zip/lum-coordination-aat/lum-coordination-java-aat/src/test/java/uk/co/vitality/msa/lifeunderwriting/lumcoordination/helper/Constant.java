package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

public class Constant {
	
	/**
	 * SUT_URL
	 */
	public static final String SUT_URL = "msa_service_lifeunderwriting_lum_coordination_url";

	/**
	 * SALESFORCE_SERVICE_URL
	 */
	public static final String SALESFORCE_SERVICE_URL = "msa_externalservice_salesforce_url";

	/**
	 * BOOTSTRAP_SERVERS
	 */
	public static final String BOOTSTRAP_SERVERS = "aat_kafkabootstrap_servers";

	/**
	 * SALESFORCE_AUTH_PATH
	 */
	public static final String SALESFORCE_AUTH_PATH = "msa_externalservice_salesforce_auth_path";

	/**
	 * SALESFORCE_NOTIFICATION_PATH
	 */
	public static final String SALESFORCE_NOTIFICATION_PATH = "msa_externalservice_salesforce_notification_path";

	/**
	 * SALESFORCE_SERVICE_NAME
	 */
	public static final String SALESFORCE_SERVICE_NAME = "Salesforce";
}
