package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JsonFileReader {

	public static String getJsonFile(String fileName) throws IOException
	{
		return new String(Files.readAllBytes(Paths.get(fileName)));
	}
}
