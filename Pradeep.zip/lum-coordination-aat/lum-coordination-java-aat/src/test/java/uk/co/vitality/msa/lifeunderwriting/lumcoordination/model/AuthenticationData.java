package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class AuthenticationData {

	/**
	 * Field accessToken
	 */
	@JsonProperty("access_token")
	private String accessToken;
	
	/**
	 * Field instance_url
	 */
	private String instance_url;
	
	/**
	 * Field id
	 */
	private String id;
	
	/**
	 * Field tokenType
	 */
	@JsonProperty("token_type")
	private String tokenType;
	
	/**
	 * Field issuedAt
	 */
	@JsonProperty("issued_at")
	private String issuedAt;
	
	/**
	 * Field signature
	 */
	private String signature;
}
