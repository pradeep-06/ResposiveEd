package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


/**
 * @author VITALITY\c701346
 *
 */
@Getter
@Setter
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SalesforceResponse {
    
    @JsonProperty("compositeResponse")
    private List<CompositeResponse> compositeResponse;

}
