package uk.co.vitality.msa.lifeunderwriting.lumcoordination.mockingService;

import java.io.IOException;
import com.github.tomakehurst.wiremock.client.WireMock;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.config.WireMockServerConfig;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.ApplicationPropertiesReader;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.Constant;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.JsonFileReader;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.MockResponseBuilder;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.AuthenticationData;

public class SalesforceAuthenticationMock {

	public static void authenticationMock() throws IOException {
		String oauthResponse = JsonFileReader.getJsonFile("stubdata/mockdata/authentication_response.json");
		AuthenticationData authenticationData = HelperClass.getObjectMapper().readValue(oauthResponse,
				AuthenticationData.class);
		HelperClass.setAccessToken(authenticationData.getAccessToken());
		String noteUrlpath = new StringBuilder()
				.append(ApplicationPropertiesReader.getApplicationProperty(Constant.SALESFORCE_AUTH_PATH)).toString()
				.replace("{client_id}", "provided_by_platform")
				.replace("{grant_type}", "password")
				.replace("{client_secret}", "provided_by_platform")
				.replace("{username}", "provided_by_platform")
				.replace("{password}", "provided_by_platform"
						.concat("provided_by_platform"));
		System.out.println(noteUrlpath);
		WireMockServerConfig.wireMockServers.get(Constant.SALESFORCE_SERVICE_NAME)
				.stubFor(WireMock.post(WireMock.urlEqualTo(noteUrlpath))
						.willReturn(MockResponseBuilder.getResponseDefinitionBuilderOk(
								HelperClass.getObjectMapper().writeValueAsString(authenticationData))));
	}
}
