package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

import java.util.Random;

public class RandomGenerator {

	public static int getRandomNumber(String CHAR_LIST) {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}

	public static String generateAccessToken() {
		String CHAR_LIST = "9123456789";
		int RANDOM_STRING_LENGTH = 20;
		StringBuffer randStr = new StringBuffer();
		for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
			int number = getRandomNumber(CHAR_LIST);
			char ch = CHAR_LIST.charAt(number);
			randStr.append(ch);
		}
		System.out.println("accesstoken:" + randStr.toString());
		return randStr.toString();
	}

	public static String getRandomEntityId() {
		Random random = new Random();
		int entityIdLength = 10;
		StringBuffer entityBuffer = new StringBuffer();
		for (int i = 1; i < entityIdLength + 1; i++) {
			int temp = random.nextInt(entityIdLength);
			if (temp == 0) {
				entityBuffer.append(i);
			} else {
				entityBuffer.append(temp);
			}
		}
		return entityBuffer.toString();
	}
}
