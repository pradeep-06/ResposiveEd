package uk.co.vitality.msa.lifeunderwriting.lumcoordination.config;


import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import com.github.tomakehurst.wiremock.WireMockServer;

import io.cucumber.java.After;
import io.cucumber.java.Before;

import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.Constant;

public class WireMockServerConfig {
	
	/**
	 * holds all the mock services
	 */
	public static Map<String, WireMockServer> wireMockServers = new HashMap<>();

	/**
	 * get the environment variables call for the wiremock configuration start the
	 * servers
	 */
	@Before
	public void setUp() throws IOException, URISyntaxException
	{
		setUpWiremock(System.getenv(Constant.SALESFORCE_SERVICE_URL), Constant.SALESFORCE_SERVICE_NAME);
		startServers();
	}

	/**
	 * stop the servers
	 */
	@After
	public void teardown()
	{
		stopServers();
	}

	/**
	 * @param serviceURl
	 * @param serviceURlName wiremock configuration
	 */
	private void setUpWiremock(String serviceURl, String serviceURlName)
			throws MalformedURLException, URISyntaxException
	{
		assertThat(serviceURl).withFailMessage(serviceURl + " is null").isNotBlank();
		if (serviceURl != null)
		{
			int port = new URI(serviceURl).getPort();
			WireMockServer wireMockServer = new WireMockServer(options().port(port));
			wireMockServers.put(serviceURlName, wireMockServer);
		}
	}

	/**
	 * start the servers
	 */
	private void startServers()
	{
		wireMockServers.forEach((k, v) -> v.start());
	}

	/**
	 * stop the servers
	 */
	private void stopServers()
	{
		wireMockServers.forEach((k, v) -> v.stop());
	}

}
