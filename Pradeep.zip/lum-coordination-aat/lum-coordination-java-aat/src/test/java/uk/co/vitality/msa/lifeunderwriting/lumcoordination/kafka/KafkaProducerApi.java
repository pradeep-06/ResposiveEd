package uk.co.vitality.msa.lifeunderwriting.lumcoordination.kafka;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.Collections;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.DeleteTopicsResult;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.serialization.StringSerializer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.Constant;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.pia.schema.PIASet;
import uk.co.vitality.msa.lifeunderwriting.underwritingcase.schema.UnderwritingCase;

public class KafkaProducerApi {

	/**
	 * bootStrapServer
	 */
	private static String bootStrapServer = System.getenv(Constant.BOOTSTRAP_SERVERS);

	/**
	 * outboundTopic
	 */
	private static String outboundTopic = HelperClass.getOutboundTopic();
	private static String underwritingOutboundTopic = "life.lifeunderwriting.underwritingcase";
	private static String piaOutboundTopic = "life.lifeunderwriting.pia";

	public static void publishUnderwritingCaseDataToOutboundTopic(String eventType)
			throws InterruptedException, ExecutionException, JsonMappingException, JsonProcessingException {
		KafkaProducer<String, UnderwritingCase> producer = new KafkaProducer<String, UnderwritingCase>(
				getProducerProperties());
		ProducerRecord<String, UnderwritingCase> record = new ProducerRecord<String, UnderwritingCase>(underwritingOutboundTopic,
				"UnderwritingCaseRequest", HelperClass.getUnderwritingCase());
		record.headers().add(new RecordHeader("eventType", eventType.getBytes()));
		producer.send(record);
		producer.close();
	}

	public static Properties getProducerProperties() throws InterruptedException, ExecutionException {
		Properties properties = new Properties();
		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootStrapServer);
		properties.put(ProducerConfig.CLIENT_ID_CONFIG, "msa-p");
		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
		properties.put("schema.registry.url", System.getenv("SPRING_KAFKA_PROPERTIES_SCHEMA_REGISTRY_URL"));
		return properties;
	}

	public static void publishPostIssueAuditToOutboundTopic(String eventType)
			throws InterruptedException, ExecutionException, JsonMappingException, JsonProcessingException {
		KafkaProducer<String, PIASet> producer = new KafkaProducer<String, PIASet>(getProducerProperties());
		ProducerRecord<String, PIASet> record = new ProducerRecord<String, PIASet>(piaOutboundTopic, "piaCaseRequest",
				HelperClass.getPiaSet());
		record.headers().add(new RecordHeader("eventType", eventType.getBytes()));
		producer.send(record);
		producer.close();
	}
}
