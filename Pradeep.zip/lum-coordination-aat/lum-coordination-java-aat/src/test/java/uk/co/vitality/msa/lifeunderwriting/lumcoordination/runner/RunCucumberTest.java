package uk.co.vitality.msa.lifeunderwriting.lumcoordination.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},
features = { "src/test/resources/uk/co/vitality/msa/lifeunderwriting/lumcoordination" },
glue = { "uk.co.vitality.msa.lifeunderwriting.lumcoordination" },
stepNotifications = true,
//tags = "@test",
monochrome = true)

public class RunCucumberTest {
}
