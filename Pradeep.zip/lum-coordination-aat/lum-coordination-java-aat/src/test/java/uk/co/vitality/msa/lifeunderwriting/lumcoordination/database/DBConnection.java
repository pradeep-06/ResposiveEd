package uk.co.vitality.msa.lifeunderwriting.lumcoordination.database;

import java.sql.Connection;
import java.sql.DriverManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBConnection {

	/**
	 * field LOG
	 */
	private static final Logger LOG = LoggerFactory.getLogger(DBConnection.class.getName());

	DBConnection()
	{
		// not-called
	}

	/**
	 * @return Connection
	 * @throws ClassNotFoundException
	 */
	public static Connection getpostgresConnection() throws ClassNotFoundException
	{
		Connection connection = null;
		try
		{
			Class.forName("org.postgresql.Driver");

			String jdbcURI = "jdbc:postgresql://" + System.getenv("aat_db_host") + ":" + System.getenv("aat_db_port")
					+ "/postgres";

			connection = DriverManager.getConnection(jdbcURI, System.getenv("aat_db_username"),
					System.getenv("aat_db_password"));

			LOG.info("Connected to PostgreSQL database!");

		} catch (Exception e1)
		{
			LOG.error("The exception raised is:" + e1);
		}
		return connection;
	}
}
