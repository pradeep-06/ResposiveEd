package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CoordinationHistoryTableData {
	
	/**
	 * Field coordination_history_id
	 */
	public String coordination_history_id;
	
	/**
	 * Field coordination_history_ts
	 */
	public String coordination_history_ts;
	
	/**
	 * Field coordination_id
	 */
	public String coordination_id;
	
	/**
	 * Field message_key
	 */
	public String message_key;
	
	/**
	 * Field source_system
	 */
	public String source_system;
	
	/**
	 * Field distination_system
	 */
	public String distination_system;
	
	/**
	 * Field sent_message
	 */
	public String sent_message;
	
	/**
	 * Field received_message
	 */
	public String received_message;
	
	/**
	 * Field coordination_datetime
	 */
	public String coordination_datetime;
	
	/**
	 * Field coordination_status
	 */
	public String coordination_status;

}
