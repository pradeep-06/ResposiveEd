package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CoordinationTableData {
	
	/**
	 * Field coordination_id
	 */
	public String coordination_id;
	
	/**
	 * Field message_key
	 */
	public String message_key;
	
	/**
	 * Field source_system
	 */
	public String source_system;
	
	/**
	 * Field distination_system
	 */
	public String distination_system;
	
	/**
	 * Field request_message
	 */
	public String request_message;
	
	/**
	 * Field response_message
	 */
	public String response_message;
	
	/**
	 * Field coordination_datetime
	 */
	public String coordination_datetime;
	
	/**
	 * Field sent_datetime
	 */
	public String sent_datetime;
	
	/**
	 * Field coordination_status
	 */
	public String coordination_status;
	
	/**
	 * Field operationType
	 */
	public String operationType;
	
	/**
	 * Field operationType
	 */
	public String objectIdentifier;

}
