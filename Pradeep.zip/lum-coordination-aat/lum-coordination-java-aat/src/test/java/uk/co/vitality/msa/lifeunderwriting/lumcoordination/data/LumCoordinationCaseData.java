package uk.co.vitality.msa.lifeunderwriting.lumcoordination.data;

import java.io.IOException;
import java.util.UUID;

import org.apache.kafka.common.Uuid;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;
import java.util.ArrayList;

import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.JsonFileReader;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.RandomGenerator;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeRequestBody;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeResponse;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.HttpHeaders;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.SalesforceRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.SalesforceResponse;
import uk.co.vitality.msa.lifeunderwriting.pia.schema.PIASet;
import uk.co.vitality.msa.lifeunderwriting.underwritingcase.schema.UnderwritingCase;

public class LumCoordinationCaseData {

	public static void underwritingCaseRequest() throws IOException {
		String uwCase = JsonFileReader.getJsonFile("stubdata/underwritingcasedata/underwritingcase_request.json");
		UnderwritingCase request = HelperClass.getObjectMapper().readValue(uwCase, UnderwritingCase.class);
		request.setCaseId(HelperClass.getCaseId());
		request.setParentCaseId(HelperClass.getParentCaseId());
		request.getCaseType().setCode(HelperClass.getCaseTypeCode());
		HelperClass.setUnderwritingCase(request);
	}

	public static void readUnderwritingCaseRequest(String fileName) throws IOException {
		String uwCase = JsonFileReader.getJsonFile("stubdata/underwritingcasedata/" + fileName + "_request.json");
		UnderwritingCase request = HelperClass.getObjectMapper().readValue(uwCase, UnderwritingCase.class);
		request.setCaseId(HelperClass.getCaseId());
		request.setParentCaseId(HelperClass.getParentCaseId());
		HelperClass.setUnderwritingCase(request);
	}

	public static void postIssueAuditCaseRequest() throws IOException {
		String piaCase = JsonFileReader.getJsonFile("stubdata/postissueauditcasedata/postissueauditcase_request.json");
		PIASet request = HelperClass.getObjectMapper().readValue(piaCase, PIASet.class);
		request.getEntities().get(0).setPiaEntityId(HelperClass.getPIAEntity());
		HelperClass.setPiaSet(request);
	}

	public static void notificationRequest() throws JsonProcessingException {
		List<CompositeRequest> compositeRequestList = new ArrayList<>();
		List<CompositeResponse> compositeResponseList = new ArrayList<>();
		for (int i = 0; i < 100; i++) {
			HelperClass.setCaseId(UUID.randomUUID().toString());
			String referenceId = UUID.randomUUID().toString();
			HelperClass.setReferenceId(referenceId.replace('-', '_'));
			CompositeRequest request = new CompositeRequest();
			request.setMethod("POST");
			request.setUrl("/services/data/v60.0/sobjects/apiNotification__c");
			request.setReferenceId(HelperClass.getReferenceId());
			CompositeRequestBody body = new CompositeRequestBody();
			body.setObjectIdentifierC(HelperClass.getCaseId());
			body.setObjectNameC("case");
			body.setOperationTypeC("create");
			request.setBody(body);
			compositeRequestList.add(request);
			CompositeResponse compositeResponse = new CompositeResponse();
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation("/services/data/v60.0/sobjects/apiNotification__c/aBTVd0000003fBVOAY");
			compositeResponse.setHttpHeaders(headers);
			compositeResponse.setHttpStatusCode(201);
			compositeResponse.setReferenceId(HelperClass.getReferenceId());
			JsonNode responsebody = HelperClass.getObjectMapper().readTree(getCompositeResponseBody());
			compositeResponse.setBody(responsebody);
			compositeResponseList.add(compositeResponse);
		}
		HelperClass.setCompositeRequest(compositeRequestList);
		SalesforceRequest salesforceRequst = new SalesforceRequest();
		salesforceRequst.setAllOrNone(false);
		salesforceRequst.setCollateSubrequests(false);
		salesforceRequst.setCompositeRequest(compositeRequestList);
		HelperClass.setRequestBody(salesforceRequst);
		SalesforceResponse salesforceResponse = new SalesforceResponse();
		salesforceResponse.setCompositeResponse(compositeResponseList);
		HelperClass.setResponseBody(salesforceResponse);

	}

	public static void createSalesforceOldRecord() throws JsonMappingException, JsonProcessingException {
		List<CompositeRequest> compositeRequestList = new ArrayList<>();
		List<CompositeResponse> compositeResponseList = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			HelperClass.setCaseId(UUID.randomUUID().toString());
			String referenceId = UUID.randomUUID().toString();
			HelperClass.setReferenceId(referenceId.replace('-', '_'));
			CompositeRequest request = new CompositeRequest();
			request.setMethod("POST");
			request.setUrl("/services/data/v60.0/sobjects/apiNotification__c");
			request.setReferenceId(HelperClass.getReferenceId());
			CompositeRequestBody body = new CompositeRequestBody();
			body.setObjectIdentifierC(HelperClass.getCaseId());
			body.setObjectNameC("case");
			body.setOperationTypeC("create");
			request.setBody(body);
			compositeRequestList.add(request);

			CompositeResponse compositeResponse = new CompositeResponse();
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation("/services/data/v60.0/sobjects/apiNotification__c/aBTVd0000003fBVOAY");
			compositeResponse.setHttpHeaders(headers);
			compositeResponse.setHttpStatusCode(201);
			compositeResponse.setReferenceId(HelperClass.getReferenceId());
			JsonNode responsebody = HelperClass.getObjectMapper().readTree(getCompositeResponseBody());
			compositeResponse.setBody(responsebody);
			compositeResponseList.add(compositeResponse);
		}
		HelperClass.setCompositeRequest(compositeRequestList);
		SalesforceRequest salesforceRequst = new SalesforceRequest();
		salesforceRequst.setAllOrNone(false);
		salesforceRequst.setCollateSubrequests(false);
		salesforceRequst.setCompositeRequest(compositeRequestList);
		HelperClass.setRequestBody(salesforceRequst);
		SalesforceResponse salesforceResponse = new SalesforceResponse();
		salesforceResponse.setCompositeResponse(compositeResponseList);
		HelperClass.setResponseBody(salesforceResponse);
	}

	public static void notificationRequestCreateAndUpdate() throws JsonProcessingException {
		List<CompositeRequest> compositeRequestList = new ArrayList<>();
		List<CompositeResponse> compositeResponseList = new ArrayList<>();
		for (int i = 0; i < 25; i++) {
			HelperClass.setPIAEntity(RandomGenerator.getRandomEntityId());
			String referenceId = UUID.randomUUID().toString();
			HelperClass.setReferenceId(referenceId.replace('-', '_'));
			CompositeRequest request = new CompositeRequest();
			request.setMethod("POST");
			request.setUrl("/services/data/v60.0/sobjects/apiNotification__c");
			request.setReferenceId(HelperClass.getReferenceId());
			CompositeRequestBody body = new CompositeRequestBody();
			body.setObjectIdentifierC(HelperClass.getCaseId());
			body.setObjectNameC("case");
			if (i < 13)
				body.setOperationTypeC("create");
			if (i >= 12)
				body.setOperationTypeC("update");
			request.setBody(body);
			compositeRequestList.add(request);
			CompositeResponse compositeResponse = new CompositeResponse();
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation("/services/data/v60.0/sobjects/apiNotification__c/aBTVd0000003fBVOAY");
			compositeResponse.setHttpHeaders(headers);
			compositeResponse.setHttpStatusCode(201);
			compositeResponse.setReferenceId(HelperClass.getReferenceId());
			JsonNode responsebody = HelperClass.getObjectMapper().readTree(getCompositeResponseBody());
			compositeResponse.setBody(responsebody);
			compositeResponseList.add(compositeResponse);
		}
		HelperClass.setCompositeRequest(compositeRequestList);
		SalesforceRequest salesforceRequest = new SalesforceRequest();
		salesforceRequest.setAllOrNone(false);
		salesforceRequest.setCollateSubrequests(false);
		salesforceRequest.setCompositeRequest(compositeRequestList);
		HelperClass.setRequestBody(salesforceRequest);
		SalesforceResponse salesforceResponse = new SalesforceResponse();
		salesforceResponse.setCompositeResponse(compositeResponseList);
		HelperClass.setResponseBody(salesforceResponse);
	}

	public static void notificationPIARequestCreateAndUpdate() throws JsonProcessingException {
		List<CompositeRequest> compositeRequestList = new ArrayList<>();
		List<CompositeResponse> compositeResponseList = new ArrayList<>();
		for (int i = 0; i < 25; i++) {
			HelperClass.setPIAEntity(RandomGenerator.getRandomEntityId());
			String referenceId = UUID.randomUUID().toString();
			HelperClass.setReferenceId(referenceId.replace('-', '_'));
			CompositeRequest request = new CompositeRequest();
			request.setMethod("POST");
			request.setUrl("/services/data/v60.0/sobjects/apiNotification__c");
			request.setReferenceId(HelperClass.getReferenceId());
			CompositeRequestBody body = new CompositeRequestBody();
			body.setObjectIdentifierC(HelperClass.getCaseId());
			body.setObjectNameC("PIA Entity");
			if (i < 13)
				body.setOperationTypeC("create");
			if (i >= 12)
				body.setOperationTypeC("update");
			request.setBody(body);
			compositeRequestList.add(request);
			CompositeResponse compositeResponse = new CompositeResponse();
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation("/services/data/v60.0/sobjects/apiNotification__c/aBTVd0000003fBVOAY");
			compositeResponse.setHttpHeaders(headers);
			compositeResponse.setHttpStatusCode(201);
			compositeResponse.setReferenceId(HelperClass.getReferenceId());
			JsonNode responsebody = HelperClass.getObjectMapper().readTree(getCompositeResponseBody());
			compositeResponse.setBody(responsebody);
			compositeResponseList.add(compositeResponse);
		}
		HelperClass.setCompositeRequest(compositeRequestList);
		SalesforceRequest salesforceRequst = new SalesforceRequest();
		salesforceRequst.setAllOrNone(false);
		salesforceRequst.setCollateSubrequests(false);
		salesforceRequst.setCompositeRequest(compositeRequestList);
		HelperClass.setRequestBody(salesforceRequst);
		SalesforceResponse salesforceResponse = new SalesforceResponse();
		salesforceResponse.setCompositeResponse(compositeResponseList);
		HelperClass.setResponseBody(salesforceResponse);

	}

	public static String getCompositeResponseBody() {
		String responseBody = "{\n" + "         \"id\": \"aBTVd0000003fBVOAY\",\n" + "         \"success\": true,\n"
				+ "         \"errors\": []\n" + "      }";
		return responseBody;
	}
}
