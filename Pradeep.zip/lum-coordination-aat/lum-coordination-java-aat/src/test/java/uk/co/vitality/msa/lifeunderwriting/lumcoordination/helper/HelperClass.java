package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CoordinationHistoryTableData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CoordinationTableData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.SalesforceRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.SalesforceResponse;
import uk.co.vitality.msa.lifeunderwriting.pia.schema.PIASet;
import uk.co.vitality.msa.lifeunderwriting.underwritingcase.schema.UnderwritingCase;

public class HelperClass {
	
	private static String outboundTopic;
	private static UnderwritingCase underwritingCase;
	private static PIASet piaSet;
	private static String PIAEntity;
	private static String caseId;
	private static String parentCaseId;
	private static String referenceId;
	private static String accessToken;
	private static List<CoordinationTableData> coordinationTableData;
	private static List<CoordinationHistoryTableData> coordinationHistoryTableData;
	private static int size;
	private static String caseTypeCode;
	private static List<CompositeRequest> compositeRequest;
	private static SalesforceRequest requestBody;
	private static SalesforceResponse responseBody;
	
	public static List<CompositeRequest> getCompositeRequest() {
		return compositeRequest;
	}

	public static void setCompositeRequest(List<CompositeRequest> compositeRequest) {
		HelperClass.compositeRequest = compositeRequest;
	}

	public static SalesforceRequest getRequestBody() {
		return requestBody;
	}

	public static void setRequestBody(SalesforceRequest requestBody) {
		HelperClass.requestBody = requestBody;
	}

	public static SalesforceResponse getResponseBody() {
		return responseBody;
	}

	public static void setResponseBody(SalesforceResponse responseBody) {
		HelperClass.responseBody = responseBody;
	}

	private static ObjectMapper mapper = new ObjectMapper();
	
	public static String getOutboundTopic() {
		return outboundTopic;
	}

	public static void setOutboundTopic(String outboundTopic) {
		HelperClass.outboundTopic = outboundTopic;
	}

	public static UnderwritingCase getUnderwritingCase() {
		return underwritingCase;
	}

	public static void setUnderwritingCase(UnderwritingCase underwritingCase) {
		HelperClass.underwritingCase = underwritingCase;
	}

	public static String getCaseId() {
		return caseId;
	}

	public static void setCaseId(String caseId) {
		HelperClass.caseId = caseId;
	}
	
	public static String getParentCaseId() {
		return parentCaseId;
	}

	public static void setParentCaseId(String parentCaseId) {
		HelperClass.parentCaseId = parentCaseId;
	}

	public static String getAccessToken() {
		return accessToken;
	}

	public static void setAccessToken(String accessToken) {
		HelperClass.accessToken = accessToken;
	}

	public static String getReferenceId() {
		return referenceId;
	}

	public static void setReferenceId(String referenceId) {
		HelperClass.referenceId = referenceId;
	}

	public static List<CoordinationTableData> getCoordinationTableData() {
		return coordinationTableData;
	}

	public static void setCoordinationTableData(List<CoordinationTableData> coordinationTableData) {
		HelperClass.coordinationTableData = coordinationTableData;
	}

	public static List<CoordinationHistoryTableData> getCoordinationHistoryTableData() {
		return coordinationHistoryTableData;
	}

	public static void setCoordinationHistoryTableData(List<CoordinationHistoryTableData> coordinationHistoryTableData) {
		HelperClass.coordinationHistoryTableData = coordinationHistoryTableData;
	}

	public static PIASet getPiaSet() {
		return piaSet;
	}

	public static void setPiaSet(PIASet piaSet) {
		HelperClass.piaSet = piaSet;
	}

	public static String getPIAEntity() {
		return PIAEntity;
	}

	public static void setPIAEntity(String pIAEntity) {
		PIAEntity = pIAEntity;
	}
	
	public static int getSize() {
		return size;
	}

	public static void setSize(int size) {
		HelperClass.size = size;
	}
	
	public static String getCaseTypeCode() {
		return caseTypeCode;
	}

	public static void setCaseTypeCode(String caseTypeCode) {
		HelperClass.caseTypeCode = caseTypeCode;
	}

	public static ObjectMapper getObjectMapper()
	{
		mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.setSerializationInclusion(Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return mapper;
	}
}
