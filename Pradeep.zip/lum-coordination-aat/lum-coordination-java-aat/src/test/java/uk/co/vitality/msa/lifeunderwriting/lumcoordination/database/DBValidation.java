package uk.co.vitality.msa.lifeunderwriting.lumcoordination.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;

import uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper.HelperClass;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeRequest;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CompositeRequestBody;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CoordinationHistoryTableData;
import uk.co.vitality.msa.lifeunderwriting.lumcoordination.model.CoordinationTableData;

public class DBValidation {	

	public static void getRequestFromCoordinationTable()
			throws ClassNotFoundException, SQLException, JsonMappingException, JsonProcessingException {
		int size = 0;
		String query = "select * from t_lum_coordination order by coordination_datetime desc;";
		try (Connection connection = DBConnection.getpostgresConnection();
				Statement stmt = connection.createStatement()) {
			ResultSet resultSet = stmt.executeQuery(query);
			List<CoordinationTableData> coordinationTableData = new ArrayList<>();
			while (resultSet.next()) {
				size++;
				CoordinationTableData coordinationData = new CoordinationTableData();
				coordinationData.setCoordination_id(resultSet.getString("coordination_id"));
				coordinationData.setMessage_key(resultSet.getString("message_key"));
				coordinationData.setSource_system(resultSet.getString("source_system"));
				coordinationData.setDistination_system(resultSet.getString("destination_system"));
				coordinationData.setRequest_message(resultSet.getString("request_message"));
				coordinationData.setResponse_message(resultSet.getString("response_message"));
				coordinationData.setCoordination_datetime(resultSet.getString("coordination_datetime"));
				coordinationData.setSent_datetime(resultSet.getString("sent_datetime"));
				coordinationData.setCoordination_status(resultSet.getString("coordination_status"));
				CompositeRequest compositeRequest = HelperClass.getObjectMapper().readValue(resultSet.getString("request_message"),
						CompositeRequest.class);
				CompositeRequestBody body = compositeRequest.getBody();
				coordinationData.setOperationType(body.getOperationTypeC());
				coordinationData.setObjectIdentifier(body.getObjectIdentifierC());
				coordinationTableData.add(coordinationData);
			}
			HelperClass.setCoordinationTableData(coordinationTableData);
			HelperClass.setSize(size);
			connection.close();
		}
	}

	public static void insertCaseCreateRecord() throws ClassNotFoundException, SQLException, JsonProcessingException {
		List<CompositeRequest> compositeRequestList = HelperClass.getCompositeRequest();
		for (int i = 0; i < compositeRequestList.size(); i++) {
			CompositeRequest record = compositeRequestList.get(i);
			String request = HelperClass.getObjectMapper().writeValueAsString(record);
			JsonNode node = HelperClass.getObjectMapper().readTree(request);
			String query = "insert into t_lum_coordination(coordination_id, message_key, source_system, "
					+ "destination_system, request_message, response_message, coordination_datetime, "
					+ "sent_datetime, coordination_status)\n" + "values('"
					+ compositeRequestList.get(i).getReferenceId().replace('_', '-') + "', '" + UUID.randomUUID()
					+ "', 'underwriting-case', 'Salesforce', '" + node + "', " + null + ", '" + LocalDateTime.now()
					+ "', " + null + ",'New');";

			try (Connection connection = DBConnection.getpostgresConnection();
					Statement stmt = connection.createStatement()) {
				stmt.executeUpdate(query);
			}
		}
	}

	public static void insertOldCaseRecord() throws JsonProcessingException, ClassNotFoundException, SQLException {
		List<CompositeRequest> compositeRequestList = HelperClass.getCompositeRequest();
		LocalDateTime sixDays = LocalDateTime.now().minusDays(6);
		for (int i = 0; i < compositeRequestList.size(); i++) {
			CompositeRequest compositeRequest = compositeRequestList.get(0);
			String request = HelperClass.getObjectMapper().writeValueAsString(compositeRequest);
			JsonNode requestNode = HelperClass.getObjectMapper().readTree(request);
			String response = HelperClass.getObjectMapper()
					.writeValueAsString(HelperClass.getResponseBody().getCompositeResponse().get(i));
			JsonNode responseNode = HelperClass.getObjectMapper().readTree(response);
			String query = "insert into t_lum_coordination(coordination_id, message_key, source_system, "
					+ "destination_system, request_message, response_message, coordination_datetime, "
					+ "sent_datetime, coordination_status)\n" + "values('"
					+ compositeRequestList.get(i).getReferenceId().replace('_', '-') + "', '" + UUID.randomUUID()
					+ "', 'underwriting-case', 'Salesforce', '" + requestNode + "', '" + responseNode + "', '"
					+ sixDays + "', '" + sixDays + "','Success');";

			try (Connection connection = DBConnection.getpostgresConnection();
					Statement stmt = connection.createStatement()) {
				stmt.executeUpdate(query);
			}
		}
	}
	
	public static void insertOldCaseRecords() throws JsonProcessingException, ClassNotFoundException, SQLException {
		List<CompositeRequest> compositeRequestList = HelperClass.getCompositeRequest();
		LocalDateTime eightDays = LocalDateTime.now().minusDays(8);
		for (int i = 0; i < compositeRequestList.size(); i++) {
			CompositeRequest compositeRequest = compositeRequestList.get(0);
			String request = HelperClass.getObjectMapper().writeValueAsString(compositeRequest);
			JsonNode requestNode = HelperClass.getObjectMapper().readTree(request);
			String response = HelperClass.getObjectMapper()
					.writeValueAsString(HelperClass.getResponseBody().getCompositeResponse().get(i));
			JsonNode responseNode = HelperClass.getObjectMapper().readTree(response);
			String query = "insert into t_lum_coordination(coordination_id, message_key, source_system, "
					+ "destination_system, request_message, response_message, coordination_datetime, "
					+ "sent_datetime, coordination_status)\n" + "values('"
					+ compositeRequestList.get(i).getReferenceId().replace('_', '-') + "', '" + UUID.randomUUID()
					+ "', 'underwriting-case', 'Salesforce', '" + requestNode + "', '" + responseNode + "', '"
					+ eightDays + "', '" + eightDays + "','Success');";

			try (Connection connection = DBConnection.getpostgresConnection();
					Statement stmt = connection.createStatement()) {
				stmt.executeUpdate(query);
			}
		}
	}

	public static void getRecordsFromCoordinationHistoryTable() throws ClassNotFoundException, SQLException {
		String query = "select * from t_lum_coordination_history order by coordination_datetime desc;";
		try (Connection connection = DBConnection.getpostgresConnection();
				Statement stmt = connection.createStatement()) {
			ResultSet resultSet = stmt.executeQuery(query);
			List<CoordinationHistoryTableData> coordinationTableData = new ArrayList<>();
			while (resultSet.next()) {
				CoordinationHistoryTableData coordinationData = new CoordinationHistoryTableData();
				coordinationData.setCoordination_id(resultSet.getString("coordination_id"));
				coordinationData.setMessage_key(resultSet.getString("message_key"));
				coordinationData.setSource_system(resultSet.getString("source_system"));
				coordinationData.setDistination_system(resultSet.getString("destination_system"));
				coordinationData.setSent_message(resultSet.getString("sent_message"));
				coordinationData.setReceived_message(resultSet.getString("received_message"));
				coordinationData.setCoordination_datetime(resultSet.getString("coordination_datetime"));
				coordinationData.setCoordination_status(resultSet.getString("coordination_status"));
				coordinationTableData.add(coordinationData);
			}
			HelperClass.setCoordinationHistoryTableData(coordinationTableData);
			connection.close();
		}
	}

	public static void deleteRecordFromCoordinationTable() throws ClassNotFoundException, SQLException {
		String query = "delete from t_lum_coordination;";
		try (Connection connection = DBConnection.getpostgresConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate(query);
		}
	}

	public static void insertPIACreateRecord() throws JsonProcessingException, ClassNotFoundException, SQLException {
		List<CompositeRequest> compositeRequestList = HelperClass.getCompositeRequest();
		for (int i = 0; i < compositeRequestList.size(); i++) {

			CompositeRequest record = compositeRequestList.get(i);
			String request = HelperClass.getObjectMapper().writeValueAsString(record);
			JsonNode node = HelperClass.getObjectMapper().readTree(request);

			String query = "insert into t_lum_coordination(coordination_id, message_key, source_system, "
					+ "destination_system, request_message, response_message, coordination_datetime, "
					+ "sent_datetime, coordination_status)\n" + "values('"
					+ compositeRequestList.get(i).getReferenceId().replace('_', '-') + "', '" + UUID.randomUUID()
					+ "', 'post-issue-audit', 'Salesforce', '" + node + "', " + null + ", '" + LocalDateTime.now()
					+ "', " + null + ",'New');";

			try (Connection connection = DBConnection.getpostgresConnection();
					Statement stmt = connection.createStatement()) {
				stmt.executeUpdate(query);
			}
		}
	}

	public static void deleteRecordFromCoordinationHistoryTable() throws ClassNotFoundException, SQLException {
		String query = "delete from t_lum_coordination_history;";
		try (Connection connection = DBConnection.getpostgresConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate(query);
		}
	}
}
