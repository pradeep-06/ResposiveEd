package uk.co.vitality.msa.lifeunderwriting.lumcoordination.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
public class CompositeRequestBody implements Serializable {

    private static final long serialVersionUID = 2239041326164764080L;
    /**
     * objectNameC
     */
    @JsonProperty("ObjectName__c")
    private String  objectNameC;
    /**
     * objectIdentifierC
     */
    @JsonProperty("ObjectIdentifier__c")
    private String  objectIdentifierC;
    /**
     * operationTypeC
     */
    @JsonProperty("OperationType__c")
    private String operationTypeC;
}
