package uk.co.vitality.msa.lifeunderwriting.lumcoordination.helper;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ApplicationPropertiesReader {

	// To read the properties from the application.properties
		public static String getApplicationProperty(String propertyName) throws IOException
		{
			FileReader reader = new FileReader("properties/application.properties");
			Properties properties = new Properties();
			properties.load(reader);
			return String.valueOf(properties.getProperty(propertyName));
		}
}
