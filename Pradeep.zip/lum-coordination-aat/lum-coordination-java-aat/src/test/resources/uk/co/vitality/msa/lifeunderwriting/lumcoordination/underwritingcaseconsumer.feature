@UnderwritingCase
Feature: Publish Underwriting Case created and updated events to salesforce

  Scenario: underwriting cases should be published for both create and update when maximum count has reached
  Given Multiple underwriting case events are created and published to topic
  When the request data stored in database with status as New for both create and update case
  Then the details are inserted into salesforce when the maximum cound reached
  And the status is to be updated to success
  
  Scenario: underwriting cases should be published when based on the time interval
  Given Multiple underwriting case events are created and published to topic
  When the maximum time interval reached and the events published to salesforce
  Then the status is to be updated to success
  
  @test
  Scenario Outline: Create new Underwriting case for "<caseType>"
    Given underwriting case is created and events is published to topic for "<caseType>" with "<caseTypeCode>"
    When the request data stored in database with status as New
    Then the request data should be published to salesforce with operation as create
    And the published data should have object identifier as parentcaseId

    Examples: 
      | caseType | caseTypeCode |
      | PIAC     |            8 |
      | NBMAN    |            6 |

  Scenario Outline: Update new underwriting case for "<caseType>"
    Given underwriting case update event is published to topic for "<caseType>" with "<caseTypeCode>"
    When the request data stored in database with status as New
    Then the request data should be published to salesforce with operation as update
    And the published data should have object identifier as parentcaseId

    Examples: 
      | caseType | caseTypeCode |
      | PIAC     |            8 |
      | NBMAN    |            6 |
@test
  Scenario Outline: No data should be published to salesforce for the "<caseType>"
    Given underwriting case is created and events is published to topic for "<caseType>" with "<caseTypeCode>"
    Then the request data should not be stored in database

    Examples: 
      | caseType | caseTypeCode |
      | UMC      |            4 |
      | AIS      |            1 |
      | QTMT     |            2 |
      | QTMR     |            3 |
      | TUC      |            5 |
      | PIAP     |            7 |
      | NBMANP   |            9 |
      | NBPC     |           10 |
      | SUPC     |           11 |
      | SUCC     |           12 |
      
      
  Scenario: Old data should be moved to History table after 7 days
    Given Cases details are in database
    When the data are older than 7 days
    Then the details should be moved to history table

  #Scenario: underwriting case is updated twice before the data is published
  #  Given Same underwriting case is updated twice before the case is inserted in salesforce
  #  When The case Id is inserted in db with status new
   # Then the same case Id should be updated with status duplicate
