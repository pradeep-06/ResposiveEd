@postissueaudit
Feature: Publish post issue audit created and updated events to salesforce

	Background: 
    Given the lum microservice is up and running

  Scenario: post issue audit should be published for both create and update when maximum count has reached
    Given Multiple post issue audit events are created and published to topic
    When the PIA request data stored in database with status as New for both create and update case
    Then the PIA details are inserted into salesforce when the maximum cound reached
    And the status is to be updated to success

  Scenario: Create new post issue audit
    Given post issue audit is created and events is published to topic
    When the request data stored in database with status as New
    Then the request data should be published to salesforce with operation as create

  Scenario: Update new post issue audit
    Given post issue audit is update events is published to topic
    When the request data stored in database with status as New
    Then the request data should be published to salesforce with operation as update

  Scenario: post issue audit should be published when based on the time interval
    Given Multiple post issue audit events are created and published to topic
    When the maximum time interval reached
   Then the request data should published to salesforce
    And the status is to be updated to success
    
  #Scenario: post issue audit is updated twice before the data is published
  #  Given Same post issue audit is updated twice before the case is inserted in salesforce
   # When The PIASetId is inserted in db with status new
   # Then the same case Id should be updated with status duplicate
    

